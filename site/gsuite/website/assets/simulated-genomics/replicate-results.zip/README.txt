Connected genomic workflow: ten fixed-design simulations

Seeds 20261100 through 20262000 in increments of 100. The original example
(seed 20260921) is excluded. All ten attempts completed. Each uses 10,000
individuals, 50,000 markers, three continuous traits, the same annotations,
priors, chain settings and Bayesian working summary-noise variance one.

plan/status: all planned seeds and outcomes; timing uses concurrent workers.
checks: selected OLS and truth-weight score errors (tolerance 1e-9).
source-hashes: identities of the three frozen analysis scripts.
estimation: labelled estimates, population truths, scopes and uncertainty.
  Reference totals, annotation categories and regions are distinct.
  Frequentist intervals are normal approximations using method-specific SEs;
  Bayesian intervals are conditional equal-tailed posterior intervals.
  Missing estimates/intervals and out-of-range values are retained.
accuracy: per-trait/pair reference summaries over the ten datasets.
prediction: held-out correlations, RMSE in training-phenotype-SD units,
  calibration slope from regressing standardized genetic truth on score.
marginal_effects: GWAS estimate versus population R times raw effects;
  slope regresses estimated marginal effects on marginal truth.
bayesian/posterior: marker recovery, parameters and native diagnostics.
credible_sets: component sets in two simple strong-signal regions.
coloc: H0-H4 probabilities for no/either/distinct/shared causal signals.
pathways: nominal p-values and PIPs; different methods have different nulls.
availability: finite estimates, uncertainty availability and boundaries.
tails: controlled-series availability and separate approximate-route
  availability/fallbacks. Approximate values are not controlled certificates.
timings: stage execution records, not controlled benchmarks.
association: scan and causal-status summaries.

Ten simulations under one non-null design do not establish general power,
false-positive control, interval calibration or comparative method rankings.
Bayesian priors are fixed and truth-informed. Ridge is not tuned.
