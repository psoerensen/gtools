library(testthat)

pathway_fixture <- function() {
  set.seed(41)
  genes <- paste0("g",1:80)
  sets <- list(A=genes[1:15],B=genes[11:25],C=genes[41:60])
  X <- vapply(sets,function(x) as.numeric(genes %in% x),numeric(length(genes)))
  rownames(X)<-genes
  y<-2*X[,1]-X[,2]+rnorm(80)
  list(genes=genes,sets=sets,X=X,stat=data.frame(gene=genes,score=y),sampling=list(gene_covariance="independent"))
}

test_that("ORA and ranked enrichment retain the background and labels", {
  f<-pathway_fixture();s<-transform(f$stat,selected=score>1)
  a<-gsea(s,f$sets,"ora",control=list(adjustment="BH"))
  expected<-vapply(f$sets,function(x) phyper(sum(s$selected[s$gene %in% x])-1,sum(s$selected),sum(!s$selected),length(x),lower.tail=FALSE),numeric(1))
  expect_equal(a$pathways$p_value,unname(expected),tolerance=1e-12)
  expect_equal(a$pathways$adjusted_p,unname(p.adjust(expected,"BH")),tolerance=1e-12)
  r<-gsea(f$stat,f$sets,"preranked",control=list(replicates=99,seed=8))
  expect_equal(r$pathways$pathway,names(f$sets))
  expect_true(all(is.finite(r$pathways$nes)))
  expect_true(all(unlist(r$details$trait$leading_edge) %in% f$genes))
  expect_equal(gsea(f$stat,f$sets,"preranked",control=list(replicates=99,seed=8,threads=2))$pathways,r$pathways)
})

test_that("competitive GLS matches an independent dense R calculation", {
  f<-pathway_fixture();D<-cbind(1,f$X)
  C<-diag(80);C[1,2]<-C[2,1]<-.25;dimnames(C)<-list(f$genes,f$genes)
  fit<-gsea(f$stat,f$sets,"competitive",sampling=list(gene_covariance=C),control=list(adjustment="BY"))
  inv<-solve(C);information<-crossprod(D,inv%*%D);b<-solve(information,crossprod(D,inv%*%f$stat$score))
  residual<-f$stat$score-D%*%b;v<-drop(crossprod(residual,inv%*%residual))/76
  expect_equal(fit$pathways$estimate,unname(b[-1]),tolerance=1e-10)
  expect_equal(fit$pathways$standard_error,sqrt(diag(solve(information)*v))[-1],ignore_attr=TRUE,tolerance=1e-10)
  reordered<-gsea(f$stat,f$sets,"competitive",sampling=list(gene_covariance=C[80:1,80:1]),control=list(adjustment="BY"))
  expect_equal(reordered$pathways,fit$pathways,tolerance=1e-10)
  separate<-gsea(f$stat,f$sets,"competitive",sampling=f$sampling,control=list(joint=FALSE,adjustment="BH"))
  expect_equal(separate$pathways$adjusted_p,p.adjust(separate$pathways$p_value,"BH"))
  expect_error(gsea(f$stat,f$sets,"competitive"),"gene_covariance")
  expect_error(gsea(f$stat,cbind(f$X,f$X[,1,drop=FALSE]),"competitive",sampling=f$sampling),"unique")
  expect_error(gsea(f$stat,f$sets,"competitive",sampling=list(gene_covariance=-C)),"covariance/design")
})

test_that("bounded MAGMA preparation and per-set inference are connected", {
  f<-pathway_fixture();s<-transform(f$stat,p_value=pnorm(score,lower.tail=FALSE))
  off<-list(correct_size=FALSE,correct_density=FALSE,correct_sample_size=FALSE,correct_mac=FALSE,truncate=FALSE,joint=FALSE,adjustment="BH")
  fit<-gsea(s,f$sets,"magma",sampling=f$sampling,control=off)
  ref<-gsea(f$stat,f$sets,"competitive",sampling=f$sampling,control=list(joint=FALSE,adjustment="BH"))
  expect_equal(fit$pathways$estimate,ref$pathways$estimate,tolerance=1e-10)
  expect_equal(fit$pathways$p_value,ref$pathways$p_value,tolerance=1e-10)
  expect_error(gsea(s,f$sets,"magma",sampling=f$sampling),"marker_count")
  s$marker_count<-10;s$effective_parameters<-8;s$sample_size<-1000;s$mean_minor_allele_count<-200
  expect_length(gsea(s,f$sets,"magma",sampling=f$sampling)$pathways$pathway,3)
})

test_that("scalar Bayesian fits share native chains, units and learning", {
  f<-pathway_fixture();cc<-list(burnin=20,sampling_sweeps=100,seeds=c(11,22))
  p<-list(residual_variance=1,effect_variance=1)
  a<-gsea(f$stat,f$sets,"bayesc",sampling=f$sampling,prior=p,control=cc)
  b<-gsea(f$stat,f$X,"bayesc",sampling=f$sampling,prior=p,control=cc)
  expect_equal(a$pathways,b$pathways)
  prep<-a$preparation$trait
  expect_equal(a$pathways$mean,unname(a$details$trait$prepared_mean*prep$response_scale/prep$feature_scales))
  expect_length(a$chains$trait,2)
  expect_equal(summary(a)$pathways,a$pathways)
  device<-tempfile(fileext=".pdf");grDevices::pdf(device)
  expect_equal(nrow(plot(a,n=2)),2)
  grDevices::dev.off();unlink(device)
  expect_true(all(a$pathways$pip>=0&a$pathways$pip<=1))
  p$effect_variance_prior<-list(df=4,scale=1);p$residual_variance_prior<-list(df=4,scale=1);p$weight_prior<-c(1,1)
  a<-gsea(f$stat,f$sets,"bayesc",sampling=f$sampling,prior=p,control=c(cc,list(estimate_effect_variance=TRUE,estimate_residual_variance=TRUE,estimate_weights=TRUE)))
  expect_true(is.finite(a$parameters$trait$residual_variance))
  r<-gsea(f$stat,f$sets,"bayesr",sampling=f$sampling,prior=list(residual_variance=1,effect_variance=1),control=cc)
  expect_length(r$parameters$trait$weights,4)
  file<-tempfile();saveRDS(r,file);expect_equal(readRDS(file)$pathways,r$pathways);unlink(file)
})

test_that("joint Bayesian traits preserve covariance and pattern labels", {
  f<-pathway_fixture();stat<-list(t1=f$stat,t2=transform(f$stat,score=score/2+cos(seq_along(score))),t3=transform(f$stat,score=sin(seq_along(score))))
  covariance<-diag(3);covariance[1,2]<-covariance[2,1]<-.2;dimnames(covariance)<-list(names(stat),names(stat))
  sampling<-c(f$sampling,list(trait_covariance=covariance));prior<-list(effect_covariance=covariance)
  cc<-list(burnin=20,sampling_sweeps=100,seeds=c(3,7),retain_pattern_probabilities=TRUE)
  for(method in c("bayesc","bayesr")) {
    fit<-gsea(stat,f$sets,method,sampling=sampling,prior=prior,control=cc)
    expect_equal(fit$pathways$trait,rep(names(stat),each=3))
    expect_equal(dimnames(fit$parameters$joint$effect_covariance),dimnames(covariance))
    expect_equal(rowSums(fit$details$joint$pattern_probability),rep(1,3),ignore_attr=TRUE)
    expect_equal(rowSums(fit$details$joint$component_probability),fit$joint$any_pip,ignore_attr=TRUE)
    expect_true(all(fit$joint$any_pip>=fit$pathways$pip[1:3]))
  }
  learned<-gsea(stat,f$sets,"bayesc",sampling=sampling,
    prior=c(prior,list(covariance_prior=list(df=6,scale=covariance),pattern_prior=rep(1,8))),
    control=c(cc,list(estimate_covariance=TRUE,estimate_pattern_weights=TRUE)))
  expect_true(all(is.finite(learned$parameters$joint$effect_covariance)))
  expect_equal(sum(learned$parameters$joint$pattern_weights),1)
  expect_error(gsea(stat,f$sets,"bayesc",sampling=f$sampling,prior=prior),"trait_covariance")
  stat$t2<-stat$t2[80:1,];expect_error(gsea(stat,f$sets,"bayesc",sampling=sampling,prior=prior),"same gene")
})


