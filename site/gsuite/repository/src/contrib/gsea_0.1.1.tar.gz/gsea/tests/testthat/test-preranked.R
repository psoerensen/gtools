test_that("preranked enrichment is deterministic",{
  s<-data.frame(rsids=paste0("m",1:6),stat=c(4,3,2,-1,-2,-3))
  sets<-list(top=c("m1","m2"),bottom=c("m5","m6"));a<-gsea_preranked(s,sets,replicates=19,seed=7)
  expect_identical(a,gsea_preranked(s,sets,replicates=19,seed=7));expect_equal(a$es,c(1,-1))
})
