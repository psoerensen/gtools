test_that("familiar pathway arguments reuse competitive and Bayesian engines", {
  genes <- paste0('g', 1:40)
  sets <- list(A=genes[1:10], B=genes[11:20], C=genes[21:30])
  score <- setNames(sin(seq_along(genes)) + as.numeric(genes %in% sets$A), genes)
  stat <- data.frame(gene=genes,score=unname(score))
  simple <- magma(score, sets, type='marginal')
  native <- gsea(stat, sets, method='competitive',
    sampling=list(gene_covariance='independent'), control=list(joint=FALSE))
  expect_equal(simple$pathways, native$pathways, tolerance=0)
  familiar <- magma(score, sets, method='bayesC', pi=.2, nit=20, nburn=2, nrun=2, seed=7)
  direct <- gsea(stat, sets, 'bayesc', sampling=list(gene_covariance='independent'),
    prior=familiar$prior, control=familiar$control)
  expect_equal(familiar$pathways, direct$pathways, tolerance=0)
  expect_equal(familiar$PIP[,1], setNames(direct$pathways$pip, names(sets)))
  joint <- magma(cbind(one=score,two=rev(score)), sets, method='bayesC',
    pi=.2, nit=12, nburn=2, nrun=2, seed=9)
  expect_equal(dim(joint$PIP), c(3L,2L))
  expect_identical(colnames(joint$PIP), c('one','two'))
  expect_true(all(is.finite(joint$PIP) & joint$PIP >= 0 & joint$PIP <= 1))
  expect_error(magma(score, sets, method='bayesC',pi=.2,
    prior=list(inclusion_probability=.2)), 'either pi')
  expect_error(magma(score, sets, method='bayesC',nit=12,
    control=list(sampling_sweeps=12)), 'flat MCMC')
})

test_that('gene sets preserve chromosome-held-out PoPS predictions', {
  genes <- paste0('g',1:12)
  f <- list(stat=data.frame(gene=genes,chromosome=rep(c('1','2','3'),each=4),
    score=seq(-2,2,length.out=12)+sin(1:12)))
  sets <- list(signal=f$stat$gene[c(1,4,5,8,9,12)], noise=f$stat$gene[c(2,6,10)])
  fit <- pops(f$stat, sets=sets, method='rr', threshold=1,
    sampling=list(gene_covariance='independent'),
    control=list(ridge_penalties=1,maximum_selected_per_fold=2L))
  changed <- f$stat
  changed$score[changed$chromosome=='1'] <- c(100,-100,50,-50)
  ref <- pops(changed, sets=sets, method='rr', threshold=1,
    sampling=list(gene_covariance='independent'),
    control=list(ridge_penalties=1,maximum_selected_per_fold=2L))
  expect_equal(ref$predictions$score[1:4], fit$predictions$score[1:4], tolerance=1e-12)
})
