pops_fixture <- function(){
  genes<-paste0("g",1:12);chromosome<-rep(c("1","2","3"),each=4)
  signal<-seq(-2,2,length.out=12);noise<-rep(c(-1,1),6)
  features<-cbind(signal=signal,noise=noise);rownames(features)<-genes
  list(stat=data.frame(gene=genes,chromosome=chromosome,score=2*signal+sin(seq_along(signal))),features=features)
}

test_that("PoPS-style scores are labelled, ranked and chromosome-held-out",{
  f<-pops_fixture();control<-list(ridge_penalties=1,maximum_selected_per_fold=2L)
  fit<-pops(f$stat,f$features,sampling=list(gene_covariance="independent"),control_features="signal",control=control)
  expect_s3_class(fit,"pops_fit");expect_identical(fit$predictions$gene,f$stat$gene)
  expect_equal(nrow(fit$folds),3L);expect_true(all(fit$folds$selected_features>=1L))
  expect_true(all(is.finite(fit$predictions$score)));expect_equal(sort(fit$predictions$genome_rank),1:12)
  changed<-f$stat;changed$score[changed$chromosome=="1"]<-c(1000,-1000,500,-500)
  ref<-pops(changed,f$features,sampling=list(gene_covariance="independent"),control_features="signal",control=control)
  expect_equal(ref$predictions$score[changed$chromosome=="1"],fit$predictions$score[f$stat$chromosome=="1"],tolerance=1e-12)
  expect_identical(summary(fit)$predictions,fit$predictions)
})

test_that("PoPS validates identities, controls and chromosome covariance",{
  f<-pops_fixture();s<-list(gene_covariance="independent")
  expect_error(pops(f$stat,f$features[12:1,],sampling=s),"row names")
  expect_error(pops(f$stat,f$features,sampling=s,control_features="missing"),"control_features")
  covariance<-diag(12);dimnames(covariance)<-list(f$stat$gene,f$stat$gene)
  expect_error(pops(f$stat,f$features,sampling=list(gene_covariance=list(mixed=covariance))),"spans chromosomes")
})
