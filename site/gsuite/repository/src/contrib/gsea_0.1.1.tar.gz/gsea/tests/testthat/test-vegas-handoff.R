test_that("gsea re-exports the exact glma vegas interface", {
  expect_identical(gsea::vegas, glma::vegas)
  expect_identical(gsea::prepare_vegas, glma::prepare_vegas)
})

test_that("gsea_input validates and labels VEGAS evidence", {
  genes <- c("gene_a", "gene_b", "gene_c")
  one <- data.frame(set = genes, marker_count = c(2, 3, 1),
    effective_parameters = c(1.5, 2, 1), score = c(1, -0.5, 2),
    p_value = c(0.2, 0.7, 0.01), p_available = rep(TRUE, 3),
    sample_size = rep(1000, 3), mean_minor_allele_count = c(200, 300, 100))
  evidence <- structure(list(stat = list(trait_a = one, trait_b = one),
    reference = list(study = "test")), class = c("vegas_fit", "list"))
  input <- gsea_input(evidence)
  expect_s3_class(input, "gsea_input")
  expect_identical(input$stat$trait_a$gene, genes)
  expect_false("set" %in% names(input$stat$trait_a))
  expect_null(input$sampling)
  expect_identical(input$provenance$source, "glma::vegas")
  expect_identical(input$provenance$covariance, "not computed")
  expect_identical(input$reference, evidence$reference)

  unavailable <- evidence
  unavailable$stat$trait_a$p_available[[2L]] <- FALSE
  expect_error(gsea_input(unavailable), "must be available")
  reordered <- evidence
  reordered$stat$trait_b <- reordered$stat$trait_b[c(2, 1, 3), ]
  expect_error(gsea_input(reordered), "same genes in the same order")
})
