test_that('Bayesian PoPS reuses native posteriors without held-out response leakage', {
  genes <- paste0('g',1:30)
  chromosome <- rep(c('1','2','3'),each=10)
  x <- cbind(signal=sin(1:30),other=cos(1:30))
  rownames(x) <- genes
  stat <- data.frame(gene=genes,chromosome=chromosome,
    score=2*x[,1]+.1*cos(2*(1:30)))
  changed <- stat; changed$score[1:10] <- seq(-100,100,length.out=10)
  for (method in c('bayesC','bayesR')) {
    fit <- pops(stat,x,method=method,pi=.3,nit=25,nburn=5,nrun=2,seed=11)
    ref <- pops(changed,x,method=method,pi=.3,nit=25,nburn=5,nrun=2,seed=11)
    expect_equal(ref$predictions$score[1:10],fit$predictions$score[1:10],tolerance=0)
    expect_true(all(is.finite(fit$predictions$score)))
    expect_true(all(fit$folds$training_gene_count==20L))
    expect_true(all(fit$features$pip>=0 & fit$features$pip<=1))
    direct <- gsea(stat[11:30,],x[11:30,,drop=FALSE],tolower(method),
      sampling=list(gene_covariance='independent'),
      prior=fit$fits[['1']]$prior,control=fit$control)
    expected <- drop(sweep(x[1:10,,drop=FALSE],2,colMeans(x[11:30,,drop=FALSE]),`-`) %*%
      direct$pathways$mean)
    expect_equal(fit$predictions$score[1:10],unname(expected),tolerance=0)
    expect_null(fit$fits[['1']]$sets)
    expect_null(fit$fits[['1']]$sampling$gene_covariance)
  }
  covariance <- diag(30); dimnames(covariance) <- list(genes,genes)
  expect_error(pops(stat,x,method='bayesC',nit=10,nburn=2,
    sampling=list(gene_covariance=covariance)), 'span chromosomes')
})

test_that('Bayesian feature screening and covariance use only the training chromosomes', {
  genes <- paste0('g',1:30); chr <- rep(c('1','2','3'),each=10)
  x <- cbind(signal=sin(1:30),other=cos(1:30)); rownames(x) <- genes
  stat <- data.frame(gene=genes,chromosome=chr,score=2*x[,1]+cos(2*(1:30)))
  covariance <- lapply(split(genes,chr),function(ids) {
    matrix(.05,length(ids),length(ids),dimnames=list(ids,ids))+diag(.95,length(ids))
  })
  fit <- pops(stat,x,method='bayesC',threshold=.05,control_features='signal',pi=.3,nit=12,nburn=2,
    updateB=FALSE,updateE=FALSE,updatePi=FALSE,
    sampling=list(gene_covariance=covariance))
  changed <- stat; changed$score[1:10] <- rep(c(-100,100),5)
  ref <- pops(changed,x,method='bayesC',threshold=.05,control_features='signal',pi=.3,nit=12,nburn=2,
    updateB=FALSE,updateE=FALSE,updatePi=FALSE,
    sampling=list(gene_covariance=covariance))
  expect_equal(ref$predictions$score[1:10],fit$predictions$score[1:10],tolerance=0)
  expect_true(all(fit$features$marginal_p < .05 | fit$features$feature=='signal'))
})
