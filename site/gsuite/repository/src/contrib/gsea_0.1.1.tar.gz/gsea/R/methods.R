#' @rdname gsea
#' @export
print.gsea_fit <- function(x, ...) {
  cat("gsea:",x$method,"|",length(x$genes),"genes |",length(unique(x$pathways$pathway)),"pathways |",length(x$traits),"trait(s)\n")
  if(x$provenance$joint_traits) cat("Joint Bayesian trait model; residual trait covariance fixed.\n")
  print(x$pathways,row.names=FALSE,...)
  invisible(x)
}
#' @rdname gsea
#' @export
summary.gsea_fit <- function(object, ...) {
  list(method=object$method,traits=object$traits,gene_count=length(object$genes),
       pathways=object$pathways,parameters=object$parameters,joint=object$joint,
       diagnostics=object$diagnostics,provenance=object$provenance)
}
#' @rdname gsea
#' @param x,object A gsea_fit.
#' @param trait Trait to display; required when more than one is present.
#' @param quantity Plot quantity; defaults to pip for Bayesian methods, nes for
#'   preranked, and minus_log10_p for other methods. Adjusted p-values are optional.
#' @param n Maximum displayed pathways, ordered by plot quantity.
#' @param ... Additional print or graphics arguments.
#' @export
plot.gsea_fit <- function(x, trait=NULL, quantity=NULL, n=20, ...) {
  trait <- .gmap_select_one(trait,x$traits,"trait")
  if(is.null(quantity)) quantity <- if(x$method %in% c("bayesc","bayesr")) "pip" else if(x$method=="preranked") "nes" else "minus_log10_p"
  p <- x$pathways[x$pathways$trait==trait,,drop=FALSE]
  allowed <- intersect(c("pip","mean","nes","es","estimate","fold_enrichment"),names(p))
  if("p_value" %in% names(p)) allowed <- c(allowed,"minus_log10_p","minus_log10_adjusted_p")
  quantity <- match.arg(quantity,allowed);.gmap_integer(n,"n")
  value <- if(quantity=="minus_log10_p") -log10(pmax(p$p_value,.Machine$double.xmin)) else if(quantity=="minus_log10_adjusted_p") -log10(pmax(p$adjusted_p,.Machine$double.xmin)) else p[[quantity]]
  keep <- which(is.finite(value));if(!length(keep)) .gsuite_stop("No finite values for this plot quantity.")
  take <- utils::head(keep[order(abs(value[keep]),decreasing=TRUE)],n)
  graphics::dotchart(rev(value[take]),labels=rev(p$pathway[take]),xlab=quantity,main=paste(x$method,trait),...)
  invisible(p[take,,drop=FALSE])
}

