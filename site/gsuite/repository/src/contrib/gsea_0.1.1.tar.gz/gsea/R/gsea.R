gsea_native_info <- function() cpp_gsea_native_info()
.onLoad <- function(libname,pkgname) {
  x <- cpp_gsea_native_info()
  if (!identical(x$runtime_version,"0.1.0") || !identical(as.character(x$runtime_abi),"0") || !isTRUE(x$headers_match_runtime))
    stop("Loaded gsea native version/ABI is incompatible.",call.=FALSE)
}

.gsea_input_error <- function(...) stop(..., call. = FALSE)

#' Prepare VEGAS evidence for gene-set enrichment
#'
#' Converts the marker-set evidence returned by [vegas()] into explicit
#' gene-labelled statistics. VEGAS does not construct cross-gene covariance;
#' methods that require it must receive a separately prepared sampling model.
#'
#' @param evidence A `vegas_fit` returned by [vegas()].
#' @return A `gsea_input` list containing `stat`, `sampling=NULL`, and `reference`.
#' @export
gsea_input <- function(evidence) {
  if (!inherits(evidence, "vegas_fit") || !is.list(evidence))
    .gsea_input_error("`evidence` must be a `vegas_fit` returned by `vegas()`.")
  stat <- evidence$stat
  if (!is.list(stat) || !length(stat) || is.null(names(stat)) ||
      anyNA(names(stat)) || any(!nzchar(names(stat))) || anyDuplicated(names(stat)))
    .gsea_input_error("VEGAS evidence must contain uniquely named traits.")
  stat <- lapply(stat, function(value) {
    required <- c("set", "score", "p_value", "p_available")
    if (!is.data.frame(value) || anyDuplicated(names(value)) ||
        !all(required %in% names(value)))
      .gsea_input_error("Each VEGAS trait must contain set, score, p_value, and p_available.")
    if (!is.character(value$set) || !length(value$set) || anyNA(value$set) ||
        any(!nzchar(value$set)) || anyDuplicated(value$set))
      .gsea_input_error("VEGAS set identifiers must be unique nonempty gene identifiers.")
    if (!is.logical(value$p_available) || anyNA(value$p_available) ||
        any(!value$p_available))
      .gsea_input_error("All VEGAS gene p-values must be available before enrichment.")
    if (!is.numeric(value$score) || any(!is.finite(value$score)) ||
        !is.numeric(value$p_value) || any(!is.finite(value$p_value)) ||
        any(value$p_value <= 0 | value$p_value > 1))
      .gsea_input_error("VEGAS scores and available p-values must be finite and valid.")
    names(value)[match("set", names(value))] <- "gene"
    value
  })
  genes <- stat[[1L]]$gene
  if (any(!vapply(stat, function(value) identical(value$gene, genes), logical(1))))
    .gsea_input_error("All VEGAS traits must contain the same genes in the same order.")
  structure(list(stat = stat, sampling = NULL,
    reference = evidence$reference,
    provenance = list(source = "glma::vegas",
      covariance = "not computed")), class = c("gsea_input", "list"))
}

#' Run deterministic preranked enrichment
#' @param stat An ordinary checked data frame containing `rsids` and either
#'   `stat`, `z`, `b`/`seb`, or `score`/`information`.
#' @param sets Named list of marker sets.
#' @param ranking Signed Z or squared Z ranking.
#' @param replicates Nonnegative permutation count.
#' @param seed Exact nonnegative integer seed.
#' @return A data frame of enrichment results.
#' @export
gsea_preranked <- function(stat,sets,ranking=c("signed_z","chi_square"),replicates=99L,seed=1L) {
  ranking <- match.arg(ranking)
  if (!identical(class(stat),"data.frame") || !nrow(stat) ||
      !"rsids" %in% names(stat)) stop("stat must be a nonempty ordinary data frame with rsids.",call.=FALSE)
  if ("stat" %in% names(stat)) z <- stat$stat
  else if ("z" %in% names(stat)) z <- stat$z
  else if (all(c("b","seb") %in% names(stat))) z <- stat$b/stat$seb
  else if (all(c("score","information") %in% names(stat))) z <- stat$score/sqrt(stat$information)
  else stop("stat must contain stat, z, b/seb or score/information.",call.=FALSE)
  values <- if (ranking=="signed_z") z else z^2
  if (!is.list(sets) || is.null(names(sets)) || any(!nzchar(names(sets))) || anyDuplicated(names(sets)) || !length(sets))
    stop("sets must be a nonempty uniquely named list.",call.=FALSE)
  sets <- lapply(sets,as.character)
  if (any(vapply(sets,function(x) !length(x)||anyNA(x)||anyDuplicated(x)||any(!x %in% stat$rsids),logical(1))))
    stop("Every set must contain unique known markers.",call.=FALSE)
  if (length(replicates)!=1L || !is.finite(replicates) || replicates<0 || replicates!=floor(replicates) ||
      length(seed)!=1L || !is.finite(seed) || seed<0 || seed!=floor(seed)) stop("replicates and seed must be nonnegative whole numbers.",call.=FALSE)
  cpp_gsea_preranked(stat$rsids,values,sets,as.numeric(replicates),as.numeric(seed))
}
