#pragma once

#include <Rcpp.h>
#include <gbayes/bayesr.hpp>

#include <cstdint>

namespace gsea_r {

inline gbayes::BayesCControls chain_controls(const Rcpp::List& control) {
  gbayes::BayesCControls value;
  value.burnin = Rcpp::as<int>(control["burnin"]);
  value.sampling_sweeps = Rcpp::as<int>(control["sampling_sweeps"]);
  value.thinning = Rcpp::as<int>(control["thinning"]);
  value.threads = Rcpp::as<int>(control["threads"]);
  value.retain_diagnostics = Rcpp::as<bool>(control["retain_diagnostics"]);
  value.chain_seeds.clear();
  for (double seed : Rcpp::as<Rcpp::NumericVector>(control["seeds"]))
    value.chain_seeds.push_back(static_cast<std::uint32_t>(seed));
  return value;
}

}
