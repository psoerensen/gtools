#include <Rcpp.h>
#include <gsea/preranked.hpp>
#include <gsolve/version.hpp>
#include <sstream>

// [[Rcpp::export]]
Rcpp::List cpp_gsea_native_info(){return Rcpp::List::create(
  Rcpp::Named("header_version")="0.1.0",Rcpp::Named("header_abi")=0,
  Rcpp::Named("runtime_version")=gsea::version_string(),Rcpp::Named("runtime_abi")=gsea::abi_version(),
  Rcpp::Named("headers_match_runtime")=std::string(gsea::version_string())=="0.1.0"&&gsea::abi_version()==0,
  Rcpp::Named("gsolve_version")=gsolve::version_string(),Rcpp::Named("gsolve_abi")=gsolve::abi_version());}

// [[Rcpp::export]]
Rcpp::DataFrame cpp_gsea_preranked(std::vector<std::string> ids,std::vector<double> values,
    Rcpp::List sets,double replicates,double seed){
  gsea::Universe universe; universe.ids=ids; universe.id_type="marker"; universe.provenance="gbase summary";
  std::vector<gsea::SetDefinition> definitions; Rcpp::CharacterVector names=sets.names();
  for(R_xlen_t i=0;i<sets.size();++i) definitions.push_back({Rcpp::as<std::string>(names[i]),Rcpp::as<std::vector<std::string>>(sets[i])});
  gsea::PreparedSets prepared(std::move(universe),definitions); gsea::NamedValues ranking{ids,values};
  gsea::PrerankedOptions options; options.replicates=static_cast<std::uint64_t>(replicates); options.seed=static_cast<std::uint64_t>(seed); options.threads=1;
  const auto result=gsea::preranked(prepared,ranking,options);
  Rcpp::CharacterVector name,diagnostic,leading; Rcpp::IntegerVector size; Rcpp::LogicalVector tested;
  Rcpp::NumericVector es,nes,p;
  for(const auto& row:result.rows){std::ostringstream edge;for(std::size_t i=0;i<row.leading_edge.size();++i){if(i)edge<<",";edge<<row.leading_edge[i];}name.push_back(row.name);size.push_back(static_cast<int>(row.size));tested.push_back(row.tested);es.push_back(row.es);nes.push_back(row.nes);p.push_back(row.p_value);diagnostic.push_back(row.diagnostic);leading.push_back(edge.str());}
  return Rcpp::DataFrame::create(Rcpp::Named("set")=name,Rcpp::Named("size")=size,Rcpp::Named("tested")=tested,
    Rcpp::Named("es")=es,Rcpp::Named("nes")=nes,Rcpp::Named("p_value")=p,Rcpp::Named("leading_edge")=leading,Rcpp::Named("diagnostic")=diagnostic);
}
