#include <Rcpp.h>
#include <gsea/pops.hpp>
#include <algorithm>
namespace {
using namespace Rcpp;using Strings=std::vector<std::string>;using Values=std::vector<double>;
std::vector<gsea::GeneCovarianceBlock> covariance(const List& sampling,std::size_t n){
  if(as<bool>(sampling["independent"]))return gsea::independent_gene_covariance(n);
  std::vector<gsea::GeneCovarianceBlock> out;for(SEXP item:as<List>(sampling["blocks"])){List b(item);gsea::GeneCovarianceBlock block;for(int i:as<IntegerVector>(b["indices"]))block.indices.push_back(static_cast<std::size_t>(i-1));block.covariance=as<Values>(b["covariance"]);out.push_back(std::move(block));}return out;
}
}
// [[Rcpp::export]]
Rcpp::List cpp_gsea_pops(Rcpp::DataFrame stat,Rcpp::NumericMatrix features,
    Rcpp::NumericMatrix covariates,Rcpp::CharacterVector control_features,
    Rcpp::List sampling,Rcpp::List control){
  using namespace Rcpp;const auto genes=as<Strings>(stat["gene"]),chromosomes=as<Strings>(stat["chromosome"]);gsea::PopsDesign d;
  d.gene_ids=genes;d.chromosomes=chromosomes;d.feature_names=as<Strings>(colnames(features));d.features=as<Values>(features);d.covariates=as<Values>(covariates);if(covariates.ncol())d.covariate_names=as<Strings>(colnames(covariates));
  const auto controls=as<Strings>(control_features);for(const auto& name:controls)d.control_features.push_back(static_cast<std::size_t>(std::find(d.feature_names.begin(),d.feature_names.end(),name)-d.feature_names.begin()));
  gsea::PopsOptions o;o.marginal_p_threshold=as<double>(control["marginal_p_threshold"]);o.minimum_reciprocal_condition=as<double>(control["minimum_reciprocal_condition"]);o.maximum_features=as<std::size_t>(control["maximum_features"]);o.maximum_selected_per_fold=as<std::size_t>(control["maximum_selected_per_fold"]);o.maximum_union_features=as<std::size_t>(control["maximum_union_features"]);o.maximum_covariates=as<std::size_t>(control["maximum_covariates"]);o.maximum_block_size=as<std::size_t>(control["maximum_block_size"]);o.maximum_preparation_bytes=as<std::uint64_t>(control["maximum_preparation_bytes"]);o.ridge_penalties=as<Values>(control["ridge_penalties"]);
  const auto out=gsea::pops_loco(d,{genes,as<Values>(stat["score"])},covariance(sampling,genes.size()),o);
  Strings fold_chr,feature_name;Values training,penalty,gcv,edf,marginal,coefficient;LogicalVector is_control;IntegerVector fold_index,selected;
  for(std::size_t k=0;k<out.folds.size();++k){const auto& fold=out.folds[k];fold_chr.push_back(fold.chromosome);training.push_back(static_cast<double>(fold.training_gene_count));selected.push_back(static_cast<int>(fold.features.size()));penalty.push_back(fold.ridge_penalty);gcv.push_back(fold.gcv);edf.push_back(fold.effective_df);for(const auto& x:fold.features){fold_index.push_back(static_cast<int>(k+1));feature_name.push_back(out.feature_names[x.feature_index]);marginal.push_back(x.marginal_p);coefficient.push_back(x.coefficient);is_control.push_back(x.control);}}
  return List::create(_["scores"]=wrap(out.scores),_["folds"]=DataFrame::create(_["chromosome"]=fold_chr,_["training_genes"]=training,_["selected_features"]=selected,_["ridge_penalty"]=penalty,_["gcv"]=gcv,_["effective_df"]=edf),_["features"]=DataFrame::create(_["fold"]=fold_index,_["feature"]=feature_name,_["marginal_p"]=marginal,_["coefficient"]=coefficient,_["control"]=is_control),_["feature_means"]=wrap(out.feature_means),_["feature_scales"]=wrap(out.feature_scales),_["interpretation"]=out.interpretation);
}
