#' Report the qualified native dependency contracts
#'
#' @return A named list of expected and loaded versions and ABIs.
#' @export
glma_native_info <- function() cpp_glma_native_info()

.onLoad <- function(libname, pkgname) {
  info <- cpp_glma_native_info()
  compatible <- vapply(info, function(x) isTRUE(x$compatible), logical(1))
  if (!all(compatible)) {
    stop("Loaded glma native dependency version/ABI is incompatible: ",
      paste(names(info)[!compatible], collapse = ", "), ".", call. = FALSE)
  }
}

.glma_stop <- function(...) stop(..., call. = FALSE)

.glma_count <- function(value, name) {
  if (!is.numeric(value) || length(value) != 1L || !is.finite(value) ||
      value < 1 || value != floor(value) || value > .Machine$integer.max) {
    .glma_stop("`", name, "` must be a positive integer.")
  }
  as.integer(value)
}

.glma_exact_nonnegative <- function(value, name) {
  if (!is.numeric(value) || length(value) != 1L || !is.finite(value) ||
      value < 0 || value != floor(value) || value > 2^53) {
    .glma_stop("`", name, "` must be a nonnegative exact integer.")
  }
  value
}

.glma_controls <- function(controls, method) {
  if (!is.list(controls) || is.object(controls) ||
      (length(controls) && (is.null(names(controls)) || anyNA(names(controls)) ||
        any(!nzchar(names(controls))) || anyDuplicated(names(controls))))) {
    .glma_stop("`controls` must be an ordinary, uniquely named list.")
  }
  allowed <- switch(method,
    infinitesimal_loco = c("calibration_count", "rhs_batch_size",
      "simulation_count", "rhe_probes", "loco_batch_size", "seed"),
    prior_selected_loco = c("scaling_factor", "decode_threads",
      "stream_read_gap_bytes", "validation_fraction", "split_seed",
      "maximum_sweeps"))
  extra <- setdiff(names(controls), allowed)
  if (length(extra))
    .glma_stop("Unsupported `", extra[[1L]], "` control for `", method, "`.")
  for (name in intersect(names(controls), c("calibration_count", "rhs_batch_size",
      "simulation_count", "rhe_probes", "loco_batch_size", "decode_threads",
      "maximum_sweeps"))) {
    controls[[name]] <- .glma_count(controls[[name]], paste0("controls$", name))
  }
  for (name in intersect(names(controls), c("seed", "split_seed",
      "stream_read_gap_bytes"))) {
    controls[[name]] <- .glma_exact_nonnegative(controls[[name]],
      paste0("controls$", name))
  }
  if (!is.null(controls$stream_read_gap_bytes) &&
      controls$stream_read_gap_bytes > 64 * 1024^2)
    .glma_stop("`controls$stream_read_gap_bytes` must be at most 64 MiB.")
  if (!is.null(controls$validation_fraction) &&
      (!is.numeric(controls$validation_fraction) ||
       length(controls$validation_fraction) != 1L ||
       !is.finite(controls$validation_fraction) ||
       controls$validation_fraction <= 0 || controls$validation_fraction >= 1))
    .glma_stop("`controls$validation_fraction` must lie strictly between 0 and 1.")
  if (!is.null(controls$scaling_factor) &&
      (!is.numeric(controls$scaling_factor) ||
       length(controls$scaling_factor) != 1L ||
       !is.finite(controls$scaling_factor) || controls$scaling_factor <= 0))
    .glma_stop("`controls$scaling_factor` must be positive when supplied.")
  controls
}

.glma_inputs <- function(phenotype, Glist, covariates, logistic = FALSE) {
  gbase::validate_Glist(Glist)
  keep <- which(lengths(Glist$rsids) > 0L)
  if (!length(keep)) .glma_stop("`Glist` selects no markers.")
  selected_rows <- as.integer(Glist$sample_source_indices_0based) + 1L
  ids <- Glist$ids[selected_rows]
  multi <- is.matrix(phenotype)
  if (multi) {
    if (logistic) .glma_stop("Logistic association requires one phenotype vector.")
    if (!is.numeric(phenotype) || ncol(phenotype) < 1L ||
        is.null(colnames(phenotype)) || anyNA(colnames(phenotype)) ||
        any(!nzchar(colnames(phenotype))) || anyDuplicated(colnames(phenotype))) {
      .glma_stop("Matrix `phenotype` requires unique, nonempty trait names.")
    }
    if (!is.null(rownames(phenotype))) {
      if (anyNA(rownames(phenotype)) || anyDuplicated(rownames(phenotype)) ||
          !all(ids %in% rownames(phenotype))) {
        .glma_stop("Phenotype row names must identify every selected Glist individual.")
      }
      phenotype <- phenotype[match(ids, rownames(phenotype)), , drop = FALSE]
    }
    if (nrow(phenotype) != length(ids) || anyNA(phenotype) ||
        any(!is.finite(phenotype))) {
      .glma_stop("Matrix `phenotype` must contain finite values for every selected sample.")
    }
    trait_names <- colnames(phenotype)
  } else {
    if (!is.numeric(phenotype) || !is.null(dim(phenotype)))
      .glma_stop("`phenotype` must be a numeric vector or matrix.")
    if (!is.null(names(phenotype))) {
      if (anyNA(names(phenotype)) || anyDuplicated(names(phenotype)) ||
          !all(ids %in% names(phenotype))) {
        .glma_stop("Named `phenotype` must identify every selected Glist individual.")
      }
      phenotype <- phenotype[match(ids, names(phenotype))]
    }
    if (length(phenotype) != length(ids) || anyNA(phenotype) ||
        any(!is.finite(phenotype))) {
      .glma_stop("`phenotype` must contain one finite value per selected Glist sample.")
    }
    trait_names <- "trait"
  }
  if (logistic && any(!phenotype %in% c(0, 1)))
    .glma_stop("Logistic `phenotype` must contain only zero and one.")
  if (is.null(covariates)) {
    covariates <- matrix(numeric(), nrow = length(ids), ncol = 0L)
  } else {
    if (is.data.frame(covariates)) covariates <- as.matrix(covariates)
    if (!is.matrix(covariates) || !is.numeric(covariates))
      .glma_stop("`covariates` must be a numeric matrix.")
    if (!is.null(rownames(covariates))) {
      if (anyNA(rownames(covariates)) || anyDuplicated(rownames(covariates)) ||
          !all(ids %in% rownames(covariates))) {
        .glma_stop("Covariate row names must identify every selected Glist individual.")
      }
      covariates <- covariates[match(ids, rownames(covariates)), , drop = FALSE]
    }
    if (nrow(covariates) != length(ids) || anyNA(covariates) ||
        any(!is.finite(covariates))) {
      .glma_stop("`covariates` must have one finite row per selected sample.")
    }
  }
  paths <- lapply(keep, function(i) list(
    bed = Glist$bedfiles[[i]], bim = Glist$bimfiles[[i]], fam = Glist$famfiles[[i]]))
  list(phenotype = unname(phenotype), covariates = unname(covariates),
    multi = multi, trait_names = trait_names, keep = keep, paths = paths,
    sample_indices = Glist$sample_source_indices_0based, ids = ids,
    marker_ids = unname(Glist$rsids[keep]))
}

.glma_finish <- function(result, keep) {
  result$associations$file <- as.integer(keep[result$associations$file])
  class(result) <- c("glma_fit", "list")
  result
}

#' Fit ordinary or conditional quantitative-trait marker associations
#'
#' @param phenotype Finite numeric vector or a numeric matrix whose uniquely
#'   named columns are traits. Names or row names, when present, align samples.
#' @param Glist A validated genotype object from [gbase::gprep()].
#' @param covariates Optional finite numeric sample-by-covariate matrix without
#'   an intercept.
#' @param condition_on Optional unique 1-based positions in selected Glist
#'   marker order. These genotypes enter one joint fixed-effect design.
#' @param threads Positive operation-local thread count.
#' @param block_size Positive marker block size.
#' @return A `glma_fit`, or a named `glma_multi_fit` for multiple traits.
#' @export
glma_linear <- function(phenotype, Glist, covariates = NULL,
                        condition_on = NULL, threads = 1L,
                        block_size = 256L) {
  input <- .glma_inputs(phenotype, Glist, covariates)
  marker_count <- sum(lengths(input$marker_ids))
  if (is.null(condition_on)) {
    conditioning <- numeric()
  } else {
    if (!is.numeric(condition_on) || is.object(condition_on) ||
        !is.null(dim(condition_on)) || !length(condition_on) ||
        any(!is.finite(condition_on)) || any(condition_on != floor(condition_on)) ||
        any(condition_on < 1 | condition_on > marker_count) || anyDuplicated(condition_on)) {
      .glma_stop("`condition_on` must contain unique Glist marker positions.")
    }
    conditioning <- as.numeric(condition_on) - 1
  }
  phenotypes <- if (input$multi) input$phenotype else matrix(input$phenotype, ncol = 1L)
  results <- cpp_glma_linear_glist(input$paths, input$sample_indices, input$ids,
    input$marker_ids, phenotypes, input$covariates, conditioning,
    .glma_count(threads, "threads"), .glma_count(block_size, "block_size"))
  names(results) <- input$trait_names
  results <- lapply(results, .glma_finish, keep = input$keep)
  if (!input$multi) return(results[[1L]])
  class(results) <- c("glma_multi_fit", "list")
  results
}

#' Fit binary-trait marker associations
#'
#' @inheritParams glma_linear
#' @return A `glma_fit` containing per-marker log-odds Wald tests.
#' @export
glma_logistic <- function(phenotype, Glist, covariates = NULL,
                          threads = 1L, block_size = 256L) {
  input <- .glma_inputs(phenotype, Glist, covariates, logistic = TRUE)
  result <- cpp_glma_logistic_glist(input$paths, input$sample_indices, input$ids,
    input$marker_ids, input$phenotype, input$covariates,
    .glma_count(threads, "threads"), .glma_count(block_size, "block_size"))
  .glma_finish(result, input$keep)
}

.glma_loco <- function(phenotype, Glist, covariates, background_markers,
                       method, algorithm, storage, threads, block_size,
                       memory_limit_bytes, controls) {
  input <- .glma_inputs(phenotype, Glist, covariates)
  marker_count <- sum(lengths(input$marker_ids))
  if (is.null(background_markers)) {
    background <- numeric()
  } else {
    if (!is.numeric(background_markers) || is.object(background_markers) ||
        !is.null(dim(background_markers)) || !length(background_markers) ||
        any(!is.finite(background_markers)) ||
        any(background_markers != floor(background_markers)) ||
        any(background_markers < 1 | background_markers > marker_count) ||
        anyDuplicated(background_markers)) {
      .glma_stop("`background_markers` must contain unique Glist marker positions.")
    }
    background <- sort(as.numeric(background_markers) - 1)
  }
  algorithms <- switch(method,
    infinitesimal_loco = c("chunk_ridge", "observation_pcg", "marker_coordinates"),
    prior_selected_loco = c("decoded_full", "packed_full",
      "decoded_adaptive", "packed_adaptive"))
  if (!is.character(algorithm) || length(algorithm) != 1L || is.na(algorithm) ||
      !algorithm %in% algorithms)
    .glma_stop("`algorithm` is not supported for `", method, "`.")
  if (!is.character(storage) || length(storage) != 1L || is.na(storage) ||
      !storage %in% c("prepared", "streamed"))
    .glma_stop("`storage` must be `prepared` or `streamed`.")
  if (method == "infinitesimal_loco" && storage != "prepared")
    .glma_stop("Infinitesimal LOCO requires prepared genotype storage.")
  if (method == "prior_selected_loco" && storage == "streamed" &&
      startsWith(algorithm, "packed_"))
    .glma_stop("Packed prior products require prepared genotype storage.")
  if (!is.numeric(memory_limit_bytes) || length(memory_limit_bytes) != 1L ||
      !is.finite(memory_limit_bytes) || memory_limit_bytes < 1)
    .glma_stop("`memory_limit_bytes` must be positive and finite.")
  controls <- .glma_controls(controls, method)
  phenotypes <- if (input$multi) input$phenotype else matrix(input$phenotype, ncol = 1L)
  results <- cpp_glma_loco_glist(input$paths, input$sample_indices, input$ids,
    input$marker_ids, background, phenotypes, input$covariates, method,
    algorithm, storage, .glma_count(threads, "threads"),
    .glma_count(block_size, "block_size"), memory_limit_bytes, controls)
  names(results) <- input$trait_names
  results <- lapply(results, .glma_finish, keep = input$keep)
  if (!input$multi) return(results[[1L]])
  class(results) <- c("glma_multi_fit", "list")
  results
}

#' Fit an infinitesimal LOCO association scan
#'
#' @inheritParams glma_linear
#' @param background_markers Optional unique 1-based positions in selected
#'   Glist marker order used to fit the background. All markers are tested.
#' @param algorithm Gaussian projection route.
#' @param storage Genotype storage; infinitesimal LOCO requires `"prepared"`.
#' @param memory_limit_bytes Positive native workflow admission budget.
#' @param controls Method controls: `calibration_count`, `rhs_batch_size`,
#'   `simulation_count`, `rhe_probes`, `loco_batch_size`, and `seed`.
#' @return A `glma_fit`, or a named `glma_multi_fit` for multiple traits.
#' @export
glma_infinitesimal_loco <- function(phenotype, Glist, covariates = NULL,
                                    background_markers = NULL,
                                    algorithm = c("chunk_ridge", "observation_pcg",
                                      "marker_coordinates"),
                                    storage = "prepared", threads = 1L,
                                    block_size = 256L,
                                    memory_limit_bytes = 1024^3,
                                    controls = list()) {
  algorithm <- match.arg(algorithm)
  .glma_loco(phenotype, Glist, covariates, background_markers,
    "infinitesimal_loco", algorithm, storage, threads, block_size,
    memory_limit_bytes, controls)
}

#' Fit a prior-selected LOCO association scan
#'
#' @inheritParams glma_infinitesimal_loco
#' @param algorithm Prediction product backend and marker schedule.
#' @param storage `"prepared"` or `"streamed"`; packed algorithms require
#'   prepared storage.
#' @param controls Method controls: optional `scaling_factor`, `decode_threads`,
#'   `stream_read_gap_bytes`, `validation_fraction`, `split_seed`, and
#'   `maximum_sweeps`.
#' @export
glma_prior_selected_loco <- function(phenotype, Glist, covariates = NULL,
                                     background_markers = NULL,
                                     algorithm = c("decoded_full", "packed_full",
                                       "decoded_adaptive", "packed_adaptive"),
                                     storage = "prepared", threads = 1L,
                                     block_size = 256L,
                                     memory_limit_bytes = 1024^3,
                                     controls = list()) {
  algorithm <- match.arg(algorithm)
  .glma_loco(phenotype, Glist, covariates, background_markers,
    "prior_selected_loco", algorithm, storage, threads, block_size,
    memory_limit_bytes, controls)
}

#' Fit an individual-level association method
#'
#' @param phenotype,Glist See [glma_linear()].
#' @param ... Method-specific arguments passed to the focused function.
#' @param method Association method.
#' @return The focused method result.
#' @export
glma <- function(phenotype, Glist, ..., method = c("linear", "logistic",
                 "infinitesimal_loco", "prior_selected_loco")) {
  method <- match.arg(method)
  fun <- switch(method, linear = glma_linear, logistic = glma_logistic,
    infinitesimal_loco = glma_infinitesimal_loco,
    prior_selected_loco = glma_prior_selected_loco)
  do.call(fun, c(list(phenotype = phenotype, Glist = Glist), list(...)))
}

#' @export
print.glma_fit <- function(x, ...) {
  cat(sprintf("<glma_fit> %s: %d markers, %d successful\n", x$method,
    nrow(x$associations), sum(x$associations$status == "ok")))
  invisible(x)
}

#' @export
print.glma_multi_fit <- function(x, ...) {
  cat(sprintf("<glma_multi_fit> %d quantitative traits: %s\n",
    length(x), paste(names(x), collapse = ", ")))
  invisible(x)
}
