two_term_survival <- function(q, eigenvalues) {
  stopifnot(length(eigenvalues) == 2L, all(eigenvalues > 0))
  density <- function(x) dchisq(x / eigenvalues[[1L]], df = 1) /
    eigenvalues[[1L]]
  cdf <- integrate(function(x) density(x) *
      pchisq((q - x) / eigenvalues[[2L]], df = 1),
    0, q, subdivisions = 2000L, rel.tol = 1e-11, abs.tol = 1e-12)$value
  1 - cdf
}

test_that("vegas satisfies independent and perfect-correlation analytic gates", {
  independent <- as.matrix(expand.grid(rep(list(c(0, 2)), 3L)))
  fixture <- prepare_glma_sparse_glist(independent, paste0("i", 1:3))
  on.exit({ unlink(fixture$paths); unlink_glma_sparse_ld(fixture$prefix) }, add = TRUE)
  summary <- glma_z_summary(fixture$Glist, c(1, 2, 0.5))
  fit <- vegas(summary, fixture$Glist, list(all = paste0("i", 1:3)),
    control = list(tail_method = "controlled_series"))
  q <- sum(c(1, 2, 0.5)^2)
  expect_s3_class(fit, "vegas_fit")
  expect_identical(fit$method, "vegas")
  expect_equal(fit$stat$trait$statistic, q, tolerance = 1e-12)
  expect_equal(fit$stat$trait$p_value, pchisq(q, 3, lower.tail = FALSE),
    tolerance = 1e-10)

  repeated <- rep(c(0, 1, 2, 0, 1, 2), 2L)
  perfect <- prepare_glma_sparse_glist(cbind(repeated, repeated), c("p1", "p2"))
  on.exit({ unlink(perfect$paths); unlink_glma_sparse_ld(perfect$prefix) }, add = TRUE)
  z <- c(1.25, 1.25)
  perfect_fit <- vegas(glma_z_summary(perfect$Glist, z), perfect$Glist,
    list(pair = c("p1", "p2")), control = list(tail_method = "controlled_series"))
  perfect_q <- sum(z^2)
  expect_equal(perfect_fit$stat$trait$p_value,
    pchisq(perfect_q / 2, 1, lower.tail = FALSE), tolerance = 1e-9)
  expect_equal(perfect_fit$stat$trait$effective_rank, 1)
})

test_that("vegas matches an independent numerical mixture calculation", {
  genotype <- cbind(
    c(0, 0, 0, 1, 1, 1, 2, 2, 2, 0, 1, 2),
    c(0, 0, 1, 0, 1, 1, 1, 2, 2, 0, 2, 1))
  fixture <- prepare_glma_sparse_glist(genotype, c("a", "b"))
  on.exit({ unlink(fixture$paths); unlink_glma_sparse_ld(fixture$prefix) }, add = TRUE)
  z <- c(1.4, -0.7)
  fit <- vegas(glma_z_summary(fixture$Glist, z), fixture$Glist,
    list(region = c("a", "b")), control = list(tail_method = "controlled_series"))
  correlation <- cor(genotype)
  eigenvalues <- eigen(correlation, symmetric = TRUE, only.values = TRUE)$values
  expected <- two_term_survival(sum(z^2), eigenvalues)
  expect_equal(fit$stat$trait$p_value, expected, tolerance = 2e-7)
})

test_that("vegas handles weighted overlapping sets gene by gene", {
  genotype <- as.matrix(expand.grid(rep(list(c(0, 2)), 4L)))
  fixture <- prepare_glma_sparse_glist(genotype, paste0("m", 1:4))
  on.exit({ unlink(fixture$paths); unlink_glma_sparse_ld(fixture$prefix) }, add = TRUE)
  sets <- list(first = c("m1", "m2"), second = c("m2", "m3"))
  weights <- list(first = c(m1 = 2, m2 = 1), second = c(m2 = 3, m3 = 1))
  z <- c(1, 2, -0.5, 0.25)
  fit <- vegas(glma_z_summary(fixture$Glist, z), fixture$Glist,
    sets, weights = weights, control = list(tail_method = "controlled_series"))
  expect_equal(fit$stat$trait$statistic, c(6, 12.25), tolerance = 1e-12)
  expect_identical(unname(vapply(fit$diagnostics, `[[`, character(1), "set")),
    names(sets))
  expect_identical(fit$execution$order, "set-major, trait-minor")
  expect_true(fit$execution$reader_reused)
  expect_null(fit$sampling)
})

test_that("vegas prepares each gene once for all traits and reports progress", {
  genotype <- as.matrix(expand.grid(rep(list(c(0, 2)), 3L)))
  fixture <- prepare_glma_sparse_glist(genotype, paste0("t", 1:3))
  on.exit({ unlink(fixture$paths); unlink_glma_sparse_ld(fixture$prefix) }, add = TRUE)
  summaries <- list(first = glma_z_summary(fixture$Glist, c(1, 2, 0.5)),
    second = glma_z_summary(fixture$Glist, c(-0.5, 1, 1.5)))
  progress <- capture.output(fit <- vegas(stat = summaries,
    Glist = fixture$Glist,
    sets = list(gene_a = c("t1", "t2"), gene_b = c("t2", "t3")),
    control = list(tail_method = "controlled_series"), verbose = TRUE))
  expect_identical(names(fit$stat), names(summaries))
  expect_identical(fit$stat$first$set, c("gene_a", "gene_b"))
  expect_identical(fit$stat$second$set, c("gene_a", "gene_b"))
  expect_equal(unname(vapply(fit$diagnostics, `[[`, numeric(1),
    "prepared_once_for_traits")), rep(2, 2))
  expect_true(any(grepl("VEGAS preparation 2/2: gene_b", progress, fixed = TRUE)))
})

test_that("prepared vegas spectra are reusable and serializable", {
  genotype <- as.matrix(expand.grid(rep(list(c(0, 2)), 4L)))
  fixture <- prepare_glma_sparse_glist(genotype, paste0("r", 1:4))
  on.exit({ unlink(fixture$paths); unlink_glma_sparse_ld(fixture$prefix) }, add = TRUE)
  sets <- list(first = c("r1", "r2"), second = c("r2", "r3", "r4"))
  summaries <- list(first = glma_z_summary(fixture$Glist, c(1, 2, 0.5, -1)),
    second = glma_z_summary(fixture$Glist, c(-0.5, 1, 1.5, 0.25)))
  prepared <- prepare_vegas(fixture$Glist, sets, threads = 2L)
  expect_s3_class(prepared, "vegas_prepared")
  expect_true(prepared$execution$eigenvalues_only)
  expect_lte(prepared$diagnostics$threads_used, 2L)
  expect_gte(prepared$diagnostics$peak_batch_size, 2)
  expect_equal(prepared$diagnostics$memory_budget_bytes, 128 * 1024^2)

  direct <- vegas(summaries, fixture$Glist, sets, threads = 2L)
  reused <- vegas(summaries, prepared = prepared)
  expect_equal(reused$stat, direct$stat, tolerance = 1e-12)
  expect_true(reused$execution$prepared_reused)

  path <- tempfile(fileext = ".rds")
  on.exit(unlink(path), add = TRUE)
  saveRDS(prepared, path)
  restored <- readRDS(path)
  expect_equal(vegas(summaries, prepared = restored)$stat, reused$stat,
    tolerance = 1e-12)
})

test_that("prepared vegas validates summary identities and unambiguous inputs", {
  genotype <- as.matrix(expand.grid(rep(list(c(0, 2)), 2L)))
  fixture <- prepare_glma_sparse_glist(genotype, c("v1", "v2"))
  on.exit({ unlink(fixture$paths); unlink_glma_sparse_ld(fixture$prefix) }, add = TRUE)
  sets <- list(pair = c("v1", "v2"))
  prepared <- prepare_vegas(fixture$Glist, sets)
  summary <- glma_z_summary(fixture$Glist, c(1, 2))
  altered <- summary
  altered$ea[[1L]] <- "changed"
  expect_error(vegas(altered, prepared = prepared), "marker and allele order")
  expect_error(vegas(summary, fixture$Glist, sets, prepared = prepared),
    "Do not supply")
})

test_that("controlled vegas tails report explicit budget unavailability", {
  genotype <- as.matrix(expand.grid(rep(list(c(0, 2)), 3L)))
  fixture <- prepare_glma_sparse_glist(genotype, paste0("u", 1:3))
  on.exit({ unlink(fixture$paths); unlink_glma_sparse_ld(fixture$prefix) }, add = TRUE)
  summary <- glma_z_summary(fixture$Glist, c(1, 1, 1))
  fit <- vegas(summary, fixture$Glist, list(weighted = c("u1", "u2")),
    weights = list(weighted = c(u1 = 1, u2 = 100)),
    control = list(tail_method = "controlled_series", maximum_series_terms = 1L))
  expect_false(fit$stat$trait$p_available)
  expect_true(nzchar(fit$stat$trait$unavailable_reason))
})
