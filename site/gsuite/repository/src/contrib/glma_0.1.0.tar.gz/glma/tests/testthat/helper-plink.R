write_glma_bed <- function(genotypes, path) {
  encode <- function(x) {
    if (is.na(x)) return(1L)
    switch(as.character(x), "2" = 0L, "1" = 2L, "0" = 3L)
  }
  body <- raw()
  for (marker in seq_len(ncol(genotypes))) {
    codes <- vapply(genotypes[, marker], encode, integer(1))
    bytes <- raw(ceiling(nrow(genotypes) / 4))
    for (byte in seq_along(bytes)) {
      value <- 0L
      for (offset in 0:3) {
        sample <- (byte - 1L) * 4L + offset + 1L
        if (sample <= length(codes))
          value <- bitwOr(value, bitwShiftL(codes[[sample]], 2L * offset))
      }
      bytes[[byte]] <- as.raw(value)
    }
    body <- c(body, bytes)
  }
  writeBin(c(as.raw(c(0x6c, 0x1b, 0x01)), body), path)
}

write_glma_plink <- function(genotypes, marker_ids, chromosome = "1") {
  prefix <- tempfile("glma-plink-")
  paths <- setNames(paste0(prefix, c(".bed", ".bim", ".fam")),
    c("bed", "bim", "fam"))
  write_glma_bed(genotypes, paths[["bed"]])
  write.table(data.frame(chromosome = rep_len(chromosome, ncol(genotypes)),
    marker_id = marker_ids, genetic_distance_cm = 0,
    base_pair_position = seq_len(ncol(genotypes)) * 100,
    allele1 = "A", allele2 = "G"), paths[["bim"]], quote = FALSE,
    row.names = FALSE, col.names = FALSE)
  write.table(data.frame(family_id = paste0("F", seq_len(nrow(genotypes))),
    individual_id = paste0("I", seq_len(nrow(genotypes))), paternal_id = "0",
    maternal_id = "0", sex = "0", phenotype = "-9"), paths[["fam"]],
    quote = FALSE, row.names = FALSE, col.names = FALSE)
  paths
}

unlink_glma_sparse_ld <- function(prefix) unlink(paste0(prefix, c(
  ".row_ptr.u64.bin", ".col_idx.u32.0based.bin", ".values.f32.bin",
  ".meta.txt", ".markers.tsv")))

prepare_glma_sparse_glist <- function(genotypes, marker_ids,
                                      chromosome = "1") {
  paths <- write_glma_plink(genotypes, marker_ids, chromosome)
  prefix <- tempfile("glma-sparse-ld-")
  Glist <- gbase::gprep(bedfiles = paths[["bed"]])
  Glist <- gbase::gprep(Glist = Glist, task = "sparseld",
    out_prefix = prefix, max_distance_bp = 0, max_distance_variants = ncol(genotypes),
    r2 = 0, block_size = 16L, nthreads = 1L, allow_full_ld = FALSE)
  list(Glist = Glist, paths = paths, prefix = prefix)
}

glma_z_summary <- function(Glist, z, trait = "trait") {
  markers <- Glist$sparseLD$marker_metadata
  data.frame(rsids = markers$marker_id, chr = markers$chromosome,
    pos = markers$base_pair_position, ea = markers$allele1,
    nea = markers$allele2, z = z, n = Glist$sparseLD$n,
    stringsAsFactors = FALSE)
}
