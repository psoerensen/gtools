test_that("focused LOCO scans retain diagnostics and dispatcher routes", {
  set.seed(1910)
  n <- 64L
  m <- 48L
  genotype <- matrix(rbinom(n * m, 2L, 0.35), n, m)
  paths <- write_glma_plink(genotype, paste0("l", seq_len(m)),
    chromosome = rep(c("1", "2"), each = m / 2L))
  on.exit(unlink(paths), add = TRUE)
  Glist <- gbase::gprep(bedfiles = paths[["bed"]])
  covariate <- matrix(rnorm(n), ncol = 1L)
  phenotype <- 0.25 * covariate[, 1L] + 0.4 * genotype[, 2L] +
    0.3 * genotype[, 29L] + rnorm(n)
  controls <- list(simulation_count = 4L, rhe_probes = 8L,
    calibration_count = 6L, loco_batch_size = 2L)

  infinitesimal <- glma_infinitesimal_loco(phenotype, Glist, covariate,
    block_size = 16L, controls = controls)
  expect_s3_class(infinitesimal, "glma_fit")
  expect_identical(infinitesimal$method, "infinitesimal_loco")
  expect_identical(infinitesimal$associations$marker,
    unlist(Glist$rsids, use.names = FALSE))
  expect_true(any(is.finite(infinitesimal$associations$p)))
  expect_equal(nrow(infinitesimal$fit$loco), 2L)

  prior <- glma(phenotype, Glist, covariate,
    method = "prior_selected_loco", block_size = 16L,
    controls = list(scaling_factor = 1))
  expect_s3_class(prior, "glma_fit")
  expect_identical(prior$diagnostics$scaling_source, "caller_supplied")
  expect_true(nzchar(prior$fit$selected_prior))
  expect_true(any(is.finite(prior$associations$p)))

  traits <- cbind(primary = phenotype,
    secondary = phenotype + 0.1 * genotype[, 7L])
  multi_infinitesimal <- glma_infinitesimal_loco(traits, Glist, covariate,
    block_size = 16L, controls = controls)
  expect_s3_class(multi_infinitesimal, "glma_multi_fit")
  expect_identical(names(multi_infinitesimal), c("primary", "secondary"))
  expect_true(multi_infinitesimal$secondary$diagnostics$shared_prepared_genotypes)
  multi_prior <- glma_prior_selected_loco(traits, Glist, covariate,
    block_size = 16L, controls = list(scaling_factor = 1))
  expect_s3_class(multi_prior, "glma_multi_fit")
  expect_true(multi_prior$primary$diagnostics$shared_prepared_genotypes)

  background <- c(seq_len(20L), 25:44)
  subset <- glma_prior_selected_loco(phenotype, Glist, covariate,
    background_markers = rev(background), storage = "streamed",
    block_size = 16L, controls = list(scaling_factor = 1))
  expect_equal(subset$diagnostics$background_marker_count, length(background))
  expect_identical(nrow(subset$associations), m)
  expect_error(glma_infinitesimal_loco(phenotype, Glist,
    storage = "streamed"), "prepared")
  expect_error(glma_prior_selected_loco(phenotype, Glist,
    algorithm = "packed_full", storage = "streamed",
    controls = list(scaling_factor = 1)), "prepared")
  expect_error(glma_prior_selected_loco(phenotype, Glist,
    background_markers = c(1L, 1L)), "background_markers")
})
