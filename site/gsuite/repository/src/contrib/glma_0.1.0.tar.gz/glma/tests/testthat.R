library(testthat);library(glma);test_check("glma")
