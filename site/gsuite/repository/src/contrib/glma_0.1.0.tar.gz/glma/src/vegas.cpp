#include <Rcpp.h>

#include <glma/gene_evidence.hpp>
#include <gmat/sparse_ld_disk.hpp>

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <limits>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace {
using Strings = std::vector<std::string>;

glma::GeneEvidenceOptions evidence_options(const Rcpp::List& control) {
  glma::GeneEvidenceOptions options;
  options.maximum_markers = Rcpp::as<std::size_t>(control["maximum_markers"]);
  options.maximum_genes = 1;
  options.tail_method = Rcpp::as<std::string>(control["tail_method"]) ==
      "controlled_series" ? glma::GeneTailMethod::controlled_series :
                              glma::GeneTailMethod::saddlepoint;
  options.tail_absolute_tolerance = Rcpp::as<double>(control["tail_absolute_tolerance"]);
  options.tail_relative_tolerance = Rcpp::as<double>(control["tail_relative_tolerance"]);
  options.maximum_series_terms = Rcpp::as<std::size_t>(control["maximum_series_terms"]);
  options.relative_psd_tolerance = Rcpp::as<double>(control["relative_psd_tolerance"]);
  return options;
}

std::vector<std::uint64_t> selected_indices(const Rcpp::List& indices,
                                             R_xlen_t set_index) {
  std::vector<std::uint64_t> selected;
  for (int index : Rcpp::as<Rcpp::IntegerVector>(indices[set_index])) {
    if (index == NA_INTEGER || index < 1) Rcpp::stop("Invalid LD index");
    selected.push_back(static_cast<std::uint64_t>(index - 1));
  }
  return selected;
}

Rcpp::DataFrame result_frame(const glma::GeneEvidence& result) {
  return Rcpp::DataFrame::create(
      Rcpp::_ ["set"] = Rcpp::CharacterVector::create(result.name),
      Rcpp::_ ["marker_count"] = Rcpp::NumericVector::create(result.marker_count),
      Rcpp::_ ["effective_rank"] = Rcpp::NumericVector::create(result.effective_rank),
      Rcpp::_ ["statistic"] = Rcpp::NumericVector::create(result.statistic),
      Rcpp::_ ["null_mean"] = Rcpp::NumericVector::create(result.null_mean),
      Rcpp::_ ["null_variance"] = Rcpp::NumericVector::create(result.null_variance),
      Rcpp::_ ["score"] = Rcpp::NumericVector::create(result.standardized_score),
      Rcpp::_ ["p_value"] = Rcpp::NumericVector::create(result.p_value),
      Rcpp::_ ["p_available"] = Rcpp::LogicalVector::create(result.p_available),
      Rcpp::_ ["tail_method"] = Rcpp::CharacterVector::create(result.tail_method),
      Rcpp::_ ["unavailable_reason"] = Rcpp::CharacterVector::create(result.unavailable_reason),
      Rcpp::_ ["moment_fallback"] = Rcpp::LogicalVector::create(result.moment_fallback),
      Rcpp::_ ["clipped_eigenvalues"] = Rcpp::NumericVector::create(result.clipped_eigenvalues),
      Rcpp::_ ["tail_error_bound"] = Rcpp::NumericVector::create(result.tail_error_bound),
      Rcpp::_ ["tail_terms"] = Rcpp::NumericVector::create(result.tail_terms),
      Rcpp::_ ["effective_parameters"] = Rcpp::NumericVector::create(result.snpwise_mean_parameters));
}
}  // namespace

// [[Rcpp::export]]
Rcpp::List cpp_glma_prepare_vegas(std::string prefix, Rcpp::List sets,
    Rcpp::List indices, Rcpp::List control, int threads, bool verbose) {
  const auto options = evidence_options(control);
  if (threads < 1 || threads > 64) Rcpp::stop("VEGAS threads must lie in [1,64]");
  if (sets.size() != indices.size()) Rcpp::stop("VEGAS set/index dimensions differ");

  Rcpp::List output(sets.size());
  output.attr("names") = sets.names();
  gmat::SparseLdDiskReadOptions reader_options;
  reader_options.maximum_columns = options.maximum_markers;
  const gmat::SparseLdDiskReader reader(prefix, reader_options);
  const auto set_names = Rcpp::as<Strings>(Rcpp::CharacterVector(sets.names()));
  constexpr std::size_t memory_budget_bytes = 128u * 1024u * 1024u;
  constexpr std::size_t maximum_batch_sets = 256u;
  unsigned threads_used = 1;
  std::size_t peak_batch_size = 0;

  for (std::size_t first = 0; first < static_cast<std::size_t>(sets.size());
       ) {
    Rcpp::checkUserInterrupt();
    std::size_t count = 0;
    std::size_t estimated_bytes = 0;
    while (first + count < static_cast<std::size_t>(sets.size()) &&
           count < maximum_batch_sets) {
      const auto dimension = static_cast<std::size_t>(
          Rcpp::as<Rcpp::IntegerVector>(
              indices[static_cast<R_xlen_t>(first + count)]).size());
      const auto matrix_bytes = dimension * dimension * sizeof(double);
      if (count > 0 && estimated_bytes + matrix_bytes > memory_budget_bytes)
        break;
      estimated_bytes += matrix_bytes;
      ++count;
    }
    peak_batch_size = std::max(peak_batch_size, count);
    std::vector<glma::GeneSpectrumInput> inputs;
    std::vector<std::vector<std::uint64_t>> global_indices;
    inputs.reserve(count);
    global_indices.reserve(count);
    for (std::size_t local = 0; local < count; ++local) {
      const auto set_index = static_cast<R_xlen_t>(first + local);
      auto selected = selected_indices(indices, set_index);
      auto region = reader.read_region(selected, options.maximum_markers);
      Rcpp::List set = sets[set_index];
      glma::GeneDefinition definition{
          set_names[first + local], Rcpp::as<Strings>(set["markers"]),
          Rcpp::as<std::vector<double>>(set["weights"])};
      inputs.push_back({std::move(region), std::move(definition)});
      global_indices.push_back(std::move(selected));
    }
    const auto batch = glma::prepare_gene_spectra(
        inputs, options, static_cast<unsigned>(threads));
    threads_used = std::max(threads_used, batch.threads_used);
    for (std::size_t local = 0; local < count; ++local) {
      const auto& spectrum = batch.spectra[local];
      const auto& region = inputs[local].ld;
      std::unordered_map<std::string, std::size_t> positions;
      for (std::size_t j = 0; j < region.markers.size(); ++j)
        positions.emplace(region.markers[j].marker_id, j);
      Rcpp::CharacterVector allele1(spectrum.markers.size());
      Rcpp::CharacterVector allele2(spectrum.markers.size());
      Rcpp::IntegerVector retained(spectrum.markers.size());
      for (std::size_t j = 0; j < spectrum.markers.size(); ++j) {
        const auto found = positions.find(spectrum.markers[j]);
        if (found == positions.end()) Rcpp::stop("Prepared marker identity was lost");
        const auto position = found->second;
        allele1[static_cast<R_xlen_t>(j)] = region.markers[position].allele1;
        allele2[static_cast<R_xlen_t>(j)] = region.markers[position].allele2;
        const auto index = global_indices[local][position] + 1u;
        if (index > static_cast<std::uint64_t>(std::numeric_limits<int>::max()))
          Rcpp::stop("Prepared marker index exceeds R integer range");
        retained[static_cast<R_xlen_t>(j)] = static_cast<int>(index);
      }
      output[static_cast<R_xlen_t>(first + local)] = Rcpp::List::create(
          Rcpp::_ ["set"] = spectrum.name,
          Rcpp::_ ["markers"] = spectrum.markers,
          Rcpp::_ ["allele1"] = allele1,
          Rcpp::_ ["allele2"] = allele2,
          Rcpp::_ ["indices"] = retained,
          Rcpp::_ ["weights"] = spectrum.weights,
          Rcpp::_ ["eigenvalues"] = spectrum.eigenvalues,
          Rcpp::_ ["null_mean"] = spectrum.null_mean,
          Rcpp::_ ["null_variance"] = spectrum.null_variance,
          Rcpp::_ ["effective_rank"] = spectrum.eigenvalues.size(),
          Rcpp::_ ["clipped_eigenvalues"] = spectrum.clipped_eigenvalues,
          Rcpp::_ ["reference_sample_count"] =
              static_cast<double>(spectrum.reference_sample_count));
      if (verbose) {
        Rcpp::Rcout << "\rVEGAS preparation " << (first + local + 1) << "/"
                    << sets.size() << ": " << spectrum.name;
        if (first + local + 1 == static_cast<std::size_t>(sets.size()))
          Rcpp::Rcout << "\n";
      }
    }
    first += count;
  }
  return Rcpp::List::create(Rcpp::_ ["spectra"] = output,
                            Rcpp::_ ["threads_used"] = threads_used,
                            Rcpp::_ ["peak_batch_size"] = peak_batch_size,
                            Rcpp::_ ["memory_budget_bytes"] =
                                static_cast<double>(memory_budget_bytes));
}

// [[Rcpp::export]]
Rcpp::List cpp_glma_evaluate_vegas(Rcpp::List statistics,
    Rcpp::List spectra, Rcpp::List control) {
  const auto options = evidence_options(control);
  Rcpp::List output(spectra.size());
  output.attr("names") = spectra.names();
  for (R_xlen_t set_index = 0; set_index < spectra.size(); ++set_index) {
    Rcpp::List saved = spectra[set_index];
    glma::PreparedGeneSpectrum prepared;
    prepared.name = Rcpp::as<std::string>(saved["set"]);
    prepared.markers = Rcpp::as<Strings>(saved["markers"]);
    prepared.weights = Rcpp::as<std::vector<double>>(saved["weights"]);
    prepared.eigenvalues = Rcpp::as<std::vector<double>>(saved["eigenvalues"]);
    prepared.null_mean = Rcpp::as<double>(saved["null_mean"]);
    prepared.null_variance = Rcpp::as<double>(saved["null_variance"]);
    prepared.clipped_eigenvalues = Rcpp::as<std::size_t>(saved["clipped_eigenvalues"]);
    const double reference_sample_count =
        Rcpp::as<double>(saved["reference_sample_count"]);
    if (!std::isfinite(reference_sample_count) || reference_sample_count < 0 ||
        reference_sample_count > static_cast<double>(
            std::numeric_limits<std::uint64_t>::max()))
      Rcpp::stop("Prepared VEGAS reference sample count is invalid");
    prepared.reference_sample_count =
        static_cast<std::uint64_t>(reference_sample_count);
    const Rcpp::IntegerVector indices = saved["indices"];
    const Rcpp::CharacterVector allele1 = saved["allele1"];
    const Rcpp::CharacterVector allele2 = saved["allele2"];
    if (indices.size() != static_cast<R_xlen_t>(prepared.markers.size()) ||
        allele1.size() != indices.size() || allele2.size() != indices.size())
      Rcpp::stop("Prepared VEGAS marker dimensions are invalid");
    Rcpp::List traits(statistics.size());
    traits.attr("names") = statistics.names();
    for (R_xlen_t trait = 0; trait < statistics.size(); ++trait) {
      Rcpp::DataFrame statistic = statistics[trait];
      Rcpp::CharacterVector ids = statistic["marker"];
      Rcpp::CharacterVector a1 = statistic["allele1"];
      Rcpp::CharacterVector a2 = statistic["allele2"];
      Rcpp::NumericVector z = statistic["z"];
      std::vector<double> values;
      values.reserve(static_cast<std::size_t>(indices.size()));
      for (R_xlen_t j = 0; j < indices.size(); ++j) {
        const int index_r = indices[j];
        if (index_r == NA_INTEGER || index_r < 1 || index_r > ids.size())
          Rcpp::stop("Prepared VEGAS index is invalid");
        const auto index = index_r - 1;
        if (Rcpp::as<std::string>(ids[index]) != prepared.markers[static_cast<std::size_t>(j)] ||
            Rcpp::as<std::string>(a1[index]) != Rcpp::as<std::string>(allele1[j]) ||
            Rcpp::as<std::string>(a2[index]) != Rcpp::as<std::string>(allele2[j]))
          Rcpp::stop("Prepared VEGAS identities/alleles do not match summaries");
        values.push_back(z[index]);
      }
      traits[trait] = result_frame(glma::evaluate_gene_spectrum(prepared, values, options));
    }
    output[set_index] = Rcpp::List::create(
        Rcpp::_ ["statistics"] = traits,
        Rcpp::_ ["diagnostics"] = Rcpp::List::create(
            Rcpp::_ ["set"] = prepared.name,
            Rcpp::_ ["marker_count"] = static_cast<double>(prepared.markers.size()),
            Rcpp::_ ["reference_sample_count"] =
                static_cast<double>(prepared.reference_sample_count),
            Rcpp::_ ["prepared_once_for_traits"] = statistics.size()));
  }
  return output;
}
