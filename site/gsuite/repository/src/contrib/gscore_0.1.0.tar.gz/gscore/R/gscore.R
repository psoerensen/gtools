#' Report the qualified native dependency contract
#'
#' @return The expected and loaded gscore version and ABI.
#' @export
gscore_native_info <- function() cpp_gscore_native_info()

.onLoad <- function(libname, pkgname) {
  info <- cpp_gscore_native_info()
  if (!all(vapply(info, `[[`, logical(1), "compatible")))
    stop("Loaded gscore native dependency versions/ABIs are incompatible.",
      call. = FALSE)
}

.gscore_stop <- function(...) stop(..., call. = FALSE)

.gscore_count <- function(value, name, minimum = 1) {
  if (!is.numeric(value) || length(value) != 1L || !is.finite(value) ||
      value < minimum || value != floor(value) || value > 2^53)
    .gscore_stop("`", name, "` must be a whole number at least ", minimum, ".")
  as.double(value)
}

.gscore_probability <- function(value, name, open_zero = FALSE) {
  if (!is.numeric(value) || length(value) != 1L || !is.finite(value) ||
      value > 1 || value < 0 || (open_zero && value == 0))
    .gscore_stop("`", name, "` must be one finite number in ",
      if (open_zero) "(0, 1]." else "[0, 1].")
  as.double(value)
}

#' Construct clumped-and-thresholded genomic-score weights
#'
#' `clump_threshold()` consumes reported association effects and a sparse-LD
#' reference prepared by `gbase::gprep(task = "sparseld")`. It aligns and
#' standardizes the reported effects with the public native gscore interface,
#' then performs stable ascending-p greedy clumping. The returned ordinary
#' weight table can be passed directly to `gscore()`.
#'
#' @param stat An ordinary checked data frame containing `rsids`, `chr`, `pos`,
#'   `ea`, `nea`, `b`, `seb`, `p`, and `n`.
#' @param Glist A validated Glist containing a sparse-LD resource. Its resource
#'   must have been built with `max_distance_variants = 0`, at least the
#'   requested base-pair window, and no larger an r-squared threshold.
#' @param p_threshold Inclusive association p-value threshold.
#' @param r2_threshold Inclusive squared-correlation clumping threshold.
#' @param window_bp Positive clumping window in base pairs.
#' @return An ordinary allele-labelled weight data frame in sparse-LD marker
#'   order. Its `weight` column is per standardized genotype and standardized
#'   quantitative trait; excluded markers have weight zero.
#' @export
clump_threshold <- function(stat, Glist, p_threshold = 0.05,
                            r2_threshold = 0.1, window_bp = 250000) {
  required <- c("rsids", "chr", "pos", "ea", "nea", "b", "seb", "p", "n")
  if (!identical(class(stat), "data.frame") || !nrow(stat) ||
      length(missing <- setdiff(required, names(stat))))
    .gscore_stop("`stat` must be an ordinary data frame containing: ",
      paste(required, collapse = ", "), ".")
  gbase::validate_Glist(Glist)
  if (is.null(Glist$sparseLD))
    .gscore_stop("`Glist` must contain sparse LD from gprep(task = \"sparseld\").")
  p_threshold <- .gscore_probability(p_threshold, "p_threshold")
  r2_threshold <- .gscore_probability(r2_threshold, "r2_threshold",
    open_zero = TRUE)
  window_bp <- .gscore_count(window_bp, "window_bp")
  marker_n <- as.double(stat$n)
  if (anyNA(marker_n) || any(!is.finite(marker_n)) || any(marker_n <= 0))
    .gscore_stop("Positive sample counts are required for every marker.")
  native <- cpp_gscore_clump_threshold(
    as.character(stat$rsids), as.character(stat$chr),
    as.double(stat$pos), as.character(stat$ea),
    as.character(stat$nea), as.double(stat$b),
    as.double(stat$seb), marker_n, as.double(stat$p),
    "trait", Glist$sparseLD$prefix,
    paste(Glist$sparseLD$sample_ids, collapse = "\x1f"), p_threshold,
    r2_threshold, window_bp)
  metadata <- Glist$sparseLD$marker_metadata
  if (!identical(as.character(native$marker), as.character(metadata$marker_id)))
    .gscore_stop("Native clumping returned an unexpected marker order.")
  data.frame(marker = metadata$marker_id,
    chromosome = metadata$chromosome,
    position = metadata$base_pair_position,
    effect_allele = metadata$allele1,
    other_allele = metadata$allele2,
    allele_frequency = metadata$allele_frequency,
    weight = as.double(native$weight), stringsAsFactors = FALSE)
}

.gscore_control <- function(control) {
  defaults <- list(threads = 1L, marker_tile_size = 64L,
    sample_tile_size = 1024L, score_tile_size = 32L,
    memory_limit_bytes = 256 * 1024^2, missing_markers = "drop")
  if (!is.list(control) || is.object(control) ||
      (length(control) && (is.null(names(control)) || anyNA(names(control)) ||
        any(!nzchar(names(control))) || anyDuplicated(names(control)))))
    .gscore_stop("`control` must be an ordinary uniquely named list.")
  extra <- setdiff(names(control), names(defaults))
  if (length(extra)) .gscore_stop("Unsupported control: ", extra[[1L]], ".")
  values <- utils::modifyList(defaults, control)
  for (name in c("threads", "marker_tile_size", "sample_tile_size",
      "score_tile_size", "memory_limit_bytes"))
    values[[name]] <- .gscore_count(values[[name]], paste0("control$", name))
  values$missing_markers <- match.arg(values$missing_markers,
    c("drop", "error"))
  values
}

.gscore_weights <- function(weights) {
  if (!identical(class(weights), "data.frame") || !nrow(weights))
    .gscore_stop("`weights` must be a nonempty ordinary data frame.")
  required <- c("marker", "chromosome", "position", "effect_allele",
    "other_allele", "allele_frequency")
  missing <- setdiff(required, names(weights))
  if (length(missing))
    .gscore_stop("`weights` is missing: ", paste(missing, collapse = ", "), ".")
  score_names <- setdiff(names(weights), required)
  if (!length(score_names)) .gscore_stop("`weights` must contain a score column.")
  if (!is.character(weights$marker) || anyDuplicated(names(weights)) ||
      anyDuplicated(weights$marker) ||
      anyNA(weights[required]) || any(!nzchar(as.character(weights$marker))) ||
      any(!vapply(weights[score_names], is.numeric, logical(1))))
    .gscore_stop("Weight markers and columns must be unique, complete and numeric.")
  numeric_values <- unlist(weights[c("position", "allele_frequency", score_names)],
    use.names = FALSE)
  if (!is.numeric(weights$position) || !is.numeric(weights$allele_frequency) ||
      any(!is.finite(numeric_values)) ||
      any(weights$allele_frequency < 0 | weights$allele_frequency > 1))
    .gscore_stop("Positions, allele frequencies and score weights must be finite; frequencies must lie in [0,1].")
  list(data = weights, score_names = score_names)
}

.gscore_alignment <- function(weights, Glist, missing_markers) {
  marker <- unlist(Glist$rsids, use.names = FALSE)
  component <- rep.int(seq_along(Glist$rsids), lengths(Glist$rsids))
  within <- sequence(lengths(Glist$rsids))
  target <- match(weights$marker, marker)
  absent <- is.na(target)
  if (any(absent) && missing_markers == "error")
    .gscore_stop("Weighted marker is absent from Glist: ",
      weights$marker[which(absent)[1L]], ".")
  used <- which(!absent)
  if (!length(used)) .gscore_stop("No weighted marker is present in Glist.")
  target <- target[used]
  flat <- function(x) unlist(x, use.names = FALSE)[target]
  coordinate_ok <- as.character(weights$chromosome[used]) ==
    as.character(flat(Glist$chr)) & as.double(weights$position[used]) ==
    as.double(flat(Glist$pos))
  if (any(!coordinate_ok))
    .gscore_stop("Weighted marker coordinate does not match Glist: ",
      weights$marker[used[which(!coordinate_ok)[1L]]], ".")
  effect <- toupper(as.character(weights$effect_allele[used]))
  other <- toupper(as.character(weights$other_allele[used]))
  a1 <- toupper(as.character(flat(Glist$a1)))
  a2 <- toupper(as.character(flat(Glist$a2)))
  exact <- effect == a1 & other == a2
  swapped <- effect == a2 & other == a1
  if (any(!exact & !swapped))
    .gscore_stop("Weighted marker alleles do not match Glist: ",
      weights$marker[used[which(!exact & !swapped)[1L]]], ".")
  list(weight_rows = used, component = component[target], within = within[target],
    swapped = swapped, missing = which(absent))
}

.gscore_sets <- function(sets, set_weights, weights, Glist, aligned,
                         missing_markers) {
  if (!is.list(sets) || is.object(sets) || !length(sets) ||
      is.null(names(sets)) || anyNA(names(sets)) ||
      any(!nzchar(names(sets))) || anyDuplicated(names(sets)))
    .gscore_stop("`sets` must be a nonempty uniquely named ordinary list.")
  valid <- vapply(sets, function(value)
    is.character(value) && length(value) && !anyNA(value) &&
      all(nzchar(value)) && !anyDuplicated(value), logical(1))
  if (any(!valid))
    .gscore_stop("Every marker set must contain unique nonempty marker names.")
  if (is.null(set_weights))
    set_weights <- stats::setNames(rep(1, length(sets)), names(sets))
  if (!is.numeric(set_weights) || length(set_weights) != length(sets) ||
      anyNA(set_weights) || any(!is.finite(set_weights)) ||
      is.null(names(set_weights)) || !identical(names(set_weights), names(sets)))
    .gscore_stop("`set_weights` must be a finite numeric vector named exactly like `sets`.")

  glist_markers <- unlist(Glist$rsids, use.names = FALSE)
  used_markers <- weights$marker[aligned$weight_rows]
  resolved <- lapply(sets, function(markers) intersect(markers, used_markers))
  missing_glist <- lapply(sets, setdiff, y = glist_markers)
  missing_weights <- lapply(sets, setdiff, y = weights$marker)
  unavailable <- Map(union, missing_glist, missing_weights)
  if (missing_markers == "error" && any(lengths(unavailable))) {
    first <- which(lengths(unavailable) != 0L)[[1L]]
    .gscore_stop("Marker set `", names(sets)[[first]],
      "` contains an unavailable marker: ", unavailable[[first]][[1L]], ".")
  }
  if (any(!lengths(resolved)))
    .gscore_stop("Every marker set must retain at least one weighted marker in Glist: ",
      names(sets)[which(!lengths(resolved))[[1L]]], ".")

  rows <- lapply(resolved, match, table = used_markers)
  membership <- vector("list", length(used_markers))
  for (set in seq_along(rows))
    for (row in rows[[set]])
      membership[[row]] <- c(membership[[row]], as.integer(set - 1L))
  coverage <- data.frame(set = names(sets), requested_markers = lengths(sets),
    markers_in_Glist = lengths(sets) - lengths(missing_glist),
    weighted_markers = lengths(sets) - lengths(missing_weights),
    used_markers = lengths(resolved),
    missing_from_Glist = lengths(missing_glist),
    missing_from_weights = lengths(missing_weights),
    set_weight = as.double(set_weights), stringsAsFactors = FALSE)
  list(names = names(sets), membership = membership, rows = rows,
    resolved = resolved,
    coverage = coverage, set_weights = as.double(set_weights),
    missing = Map(function(glist, weight)
      list(Glist = glist, weights = weight), missing_glist, missing_weights))
}

#' Apply allele-labelled genomic-score weights to a prepared Glist
#'
#' `gscore()` performs scoring only. Weight learning belongs to the package
#' that fits the underlying model, such as glma or gbayes.
#' @param weights An ordinary data frame with marker, chromosome, position,
#'   effect_allele, other_allele and allele_frequency columns, followed by one
#'   or more numeric score-weight columns.
#' @param Glist A validated `gbase::gprep()` Glist.
#' @param sets Optional uniquely named list of marker-ID vectors. Marker names
#'   are resolved through `Glist`; overlapping and cross-component sets are valid.
#' @param set_weights Optional finite numeric vector named exactly like `sets`.
#'   Multipliers are applied after optional score standardization.
#' @param include_total Whether set scoring should also retain the original
#'   genome-wide score columns.
#' @param coding Native genotype coding.
#' @param scale_scores Standardize each completed score across selected samples.
#' @param control Native thread/tile controls and `missing_markers`, either
#'   `"drop"` or `"error"`.
#' @return A serializable `gscore_prediction` containing a sample-by-score matrix.
#' @export
gscore <- function(weights, Glist, sets = NULL, set_weights = NULL,
                   include_total = FALSE,
                   coding = c("standardized", "raw_mean_imputed"),
                   scale_scores = TRUE, control = list()) {
  call <- match.call()
  coding <- match.arg(coding)
  if (!is.logical(scale_scores) || length(scale_scores) != 1L || is.na(scale_scores))
    .gscore_stop("`scale_scores` must be TRUE or FALSE.")
  gbase::validate_Glist(Glist)
  parsed <- .gscore_weights(weights)
  controls <- .gscore_control(control)
  aligned <- .gscore_alignment(parsed$data, Glist, controls$missing_markers)
  used <- parsed$data[aligned$weight_rows, , drop = FALSE]
  if (!is.logical(include_total) || length(include_total) != 1L ||
      is.na(include_total))
    .gscore_stop("`include_total` must be TRUE or FALSE.")
  if (is.null(sets) && !is.null(set_weights))
    .gscore_stop("`set_weights` requires `sets`.")
  prepared_sets <- if (is.null(sets)) NULL else .gscore_sets(sets,
    set_weights, parsed$data, Glist, aligned, controls$missing_markers)
  coefficients <- as.matrix(used[parsed$score_names])
  frequencies <- as.double(used$allele_frequency)
  original <- coefficients
  coefficients[aligned$swapped, ] <- -coefficients[aligned$swapped, , drop = FALSE]
  frequencies[aligned$swapped] <- 1 - frequencies[aligned$swapped]
  if (coding == "standardized" && any(frequencies <= 0 | frequencies >= 1))
    .gscore_stop("Standardized scoring requires allele frequencies in (0,1).")
  selected_rows <- as.integer(Glist$sample_source_indices_0based + 1)
  base_count <- ncol(coefficients)
  if (is.null(prepared_sets)) {
    score_names <- parsed$score_names
  } else {
    set_score_names <- if (base_count == 1L) prepared_sets$names else
      unlist(lapply(prepared_sets$names, function(set)
        paste(set, parsed$score_names, sep = ":")), use.names = FALSE)
    score_names <- c(if (include_total) parsed$score_names, set_score_names)
  }
  if (Glist$n * length(score_names) * 8 > controls$memory_limit_bytes)
    .gscore_stop("Requested score matrix exceeds `control$memory_limit_bytes`.")
  scores <- matrix(0, nrow = length(selected_rows), ncol = length(score_names),
    dimnames = list(Glist$ids[selected_rows], score_names))
  for (part in unique(aligned$component)) {
    take <- which(aligned$component == part)
    if (!is.null(prepared_sets) && !include_total)
      take <- take[lengths(prepared_sets$membership[take]) != 0L]
    if (!length(take)) next
    physical <- Glist$source_marker_indices_0based[[part]][aligned$within[take]]
    if (is.null(prepared_sets)) {
      contribution <- gscore_bed(Glist$bedfiles[[part]], Glist$n,
        Glist$physical_marker_counts[[part]], physical, frequencies[take],
        coefficients[take, , drop = FALSE], coding = coding,
        control = controls)
    } else {
      memberships <- prepared_sets$membership[take]
      offsets <- c(0, cumsum(lengths(memberships)))
      contribution <- cpp_gscore_bed_sets(
        normalizePath(Glist$bedfiles[[part]], winslash = "/", mustWork = TRUE),
        Glist$n, Glist$physical_marker_counts[[part]], physical,
        frequencies[take], coefficients[take, , drop = FALSE],
        length(prepared_sets$names), as.double(offsets),
        as.double(unlist(memberships, use.names = FALSE)), include_total,
        coding, controls)
    }
    scores <- scores + contribution[selected_rows, , drop = FALSE]
  }
  if (coding == "raw_mean_imputed" && any(aligned$swapped))
    if (is.null(prepared_sets)) {
      scores <- sweep(scores, 2L,
        2 * colSums(original[aligned$swapped, , drop = FALSE]), "+")
    } else {
      correction <- numeric(length(score_names))
      cursor <- 1L
      if (include_total) {
        correction[seq_len(base_count)] <-
          2 * colSums(original[aligned$swapped, , drop = FALSE])
        cursor <- base_count + 1L
      }
      for (set in seq_along(prepared_sets$names)) {
        rows <- prepared_sets$rows[[set]]
        rows <- rows[aligned$swapped[rows]]
        correction[cursor:(cursor + base_count - 1L)] <- if (length(rows))
          2 * colSums(original[rows, , drop = FALSE]) else rep(0, base_count)
        cursor <- cursor + base_count
      }
      scores <- sweep(scores, 2L, correction, "+")
    }
  if (scale_scores) {
    center <- colMeans(scores)
    spread <- apply(scores, 2L, stats::sd)
    if (any(!is.finite(spread) | spread == 0))
      .gscore_stop("Every score must have nonzero finite sample variation before scaling.")
    scores <- sweep(sweep(scores, 2L, center, "-"), 2L, spread, "/")
  }
  if (!is.null(prepared_sets)) {
    multipliers <- c(if (include_total) rep(1, base_count),
      rep(prepared_sets$set_weights, each = base_count))
    scores <- sweep(scores, 2L, multipliers, "*")
  }
  structure(list(call = call, scores = scores,
    samples = data.frame(individual_id = Glist$ids[selected_rows],
      stringsAsFactors = FALSE), weights = used, coding = coding,
    scale_scores = scale_scores, control = controls,
    coverage = if (is.null(prepared_sets)) NULL else prepared_sets$coverage,
    set_membership = if (is.null(prepared_sets)) NULL else prepared_sets$resolved,
    missing_set_markers = if (is.null(prepared_sets)) NULL else prepared_sets$missing,
    alignment = list(used_markers = used$marker,
      swapped_markers = used$marker[aligned$swapped],
      dropped_markers = parsed$data$marker[aligned$missing]),
    provenance = list(owner = "gscore", dosage_allele = "Glist a1",
      native = gscore_native_info())), class = c("gscore_prediction", "list"))
}

#' @export
print.gscore_prediction <- function(x, ...) {
  cat("<gscore_prediction>", nrow(x$scores), "samples x",
    ncol(x$scores), "scores |", length(x$alignment$used_markers),
    "markers\n")
  invisible(x)
}

#' Score selected markers from a PLINK BED file
#' @param bed_path Path to a SNP-major PLINK BED file.
#' @param sample_count,physical_marker_count Positive file dimensions.
#' @param marker_indices Zero-based physical marker indices.
#' @param allele_frequencies Frequencies in coefficient order.
#' @param coefficients Marker-by-score coefficient matrix.
#' @param coding Genotype coding convention.
#' @param control Native thread and tile controls.
#' @return Sample-by-score numeric matrix.
#' @export
gscore_bed <- function(bed_path, sample_count, physical_marker_count,
                       marker_indices, allele_frequencies, coefficients,
                       coding = c("standardized", "raw_mean_imputed"),
                       control = list()) {
  coding <- match.arg(coding)
  controls <- .gscore_control(control)
  if (!is.character(bed_path) || length(bed_path) != 1L || !file.exists(bed_path))
    .gscore_stop("`bed_path` must exist.")
  sample_count <- .gscore_count(sample_count, "sample_count")
  physical_marker_count <- .gscore_count(physical_marker_count,
    "physical_marker_count")
  if (!is.matrix(coefficients) || !is.numeric(coefficients) ||
      nrow(coefficients) != length(marker_indices) ||
      length(allele_frequencies) != length(marker_indices))
    .gscore_stop("Coefficient rows, indices and frequencies must align.")
  if (sample_count * ncol(coefficients) * 8 > controls$memory_limit_bytes)
    .gscore_stop("Requested score matrix exceeds `control$memory_limit_bytes`.")
  if (any(!is.finite(coefficients)) || any(!is.finite(allele_frequencies)) ||
      any(allele_frequencies < 0 | allele_frequencies > 1) ||
      (coding == "standardized" && any(allele_frequencies <= 0 |
        allele_frequencies >= 1)))
    .gscore_stop("Coefficients and frequencies are invalid for the requested coding.")
  cpp_gscore_bed(normalizePath(bed_path, winslash = "/", mustWork = TRUE),
    sample_count, physical_marker_count, marker_indices, allele_frequencies,
    coefficients, coding, controls)
}
