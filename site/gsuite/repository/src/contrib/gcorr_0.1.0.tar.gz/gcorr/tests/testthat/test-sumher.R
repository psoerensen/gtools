make_sumher_summary <- function(trait, z, markers, sample_sizes) {
    data.frame(
      rsids = markers,
      chr = rep("1", length(markers)),
      pos = seq_along(markers) * 100,
      ea = rep("A", length(markers)),
      nea = rep("G", length(markers)),
      z = z,
      n = sample_sizes,
      stringsAsFactors = FALSE
    )
}

sumher_fixture <- function() {
  marker_count <- 30L
  markers <- paste0("s", seq_len(marker_count))
  index <- seq_len(marker_count)
  architecture_weights <- cbind(
    baseline = 1 + (index %% 7) / 10,
    selected = 0.25 + ((index * 5) %% 11) / 20
  )
  rownames(architecture_weights) <- markers
  weight_sums <- colSums(architecture_weights)
  sample_sizes <- 800 + index * 5
  component_h2 <- c(baseline = 0.2, selected = 0.1)
  mean <- 1 + sample_sizes * drop(sweep(architecture_weights, 2,
    weight_sums, "/") %*% component_h2)
  categories <- cbind(
    all = 1,
    early = as.numeric(index <= 18),
    even = as.numeric(index %% 2 == 0)
  )
  rownames(categories) <- markers
  list(
    markers = markers,
    architecture_weights = architecture_weights,
    architecture_ld_scores = architecture_weights,
    weight_sums = weight_sums,
    tagging = setNames(rep(1, marker_count), markers),
    blocks = setNames(rep(paste0("b", 1:5), each = 6), markers),
    sample_sizes = sample_sizes,
    z = sqrt(mean),
    categories = categories
  )
}

test_that("focused SumHer fits an exact architecture with per-marker sizes", {
  fixture <- sumher_fixture()
  fit <- gcorr_sumher(
    make_sumher_summary("one", fixture$z, fixture$markers,
      fixture$sample_sizes),
    fixture$architecture_ld_scores, fixture$weight_sums,
    fixture$tagging, fixture$blocks, reference_sample_size = 500)
  expect_s3_class(fit, "gcorr_sumher_fit")
  component <- fit$estimates[fit$estimates$quantity == "h2" &
    fit$estimates$component != "all", ]
  expect_identical(component$component, c("baseline", "selected"))
  expect_equal(component$estimate, c(.2, .1), tolerance = 1e-9)
  expect_equal(fit$estimates$estimate[fit$estimates$component == "all" &
    fit$estimates$quantity == "h2"], .3, tolerance = 1e-9)
  expect_identical(fit$diagnostics$used_marker_ids, fixture$markers)
  expect_output(print(fit), "Single-trait SumHer")
})

test_that("SumHer dispatcher exposes multivariate components and totals", {
  fixture <- sumher_fixture()
  statistics <- list(
    one = make_sumher_summary("one", fixture$z, fixture$markers,
      fixture$sample_sizes),
    two = make_sumher_summary("two", fixture$z, fixture$markers,
      fixture$sample_sizes),
    three = make_sumher_summary("three", fixture$z, fixture$markers,
      fixture$sample_sizes))
  fit <- gcorr(statistics,
    architecture_ld_scores = fixture$architecture_ld_scores,
    weight_sums = fixture$weight_sums, tagging = fixture$tagging,
    blocks = fixture$blocks, reference_sample_size = 500,
    overlap_intercepts = 1, method = "sumher")
  expect_s3_class(fit, "gcorr_sumher_fit")
  expect_identical(names(fit$matrices$components),
    c("baseline", "selected"))
  expect_equal(unname(fit$matrices$total$genetic_correlation),
    matrix(1, 3, 3), tolerance = 1e-9)
  expect_equal(sum(fit$estimates$quantity == "rg" &
    fit$estimates$component == "all"), 3L)
  grouped <- gcorr_grouped_covariance(fit, continuous = TRUE,
    units = c(one = "u", two = "u", three = "u"))
  expect_identical(grouped$kind, "sumher_components")
  expect_identical(grouped$group_names, c("baseline", "selected"))
  expect_true(all(vapply(fit$diagnostics$pairs,
    function(x) isTRUE(x$overlap_intercept_fixed), logical(1))))
  expect_output(print(fit), "Multivariate SumHer")
})

test_that("SumHer supports explicit inflation and native category summaries", {
  fixture <- sumher_fixture()
  summary <- make_sumher_summary("one", fixture$z, fixture$markers,
    fixture$sample_sizes)
  fit <- gcorr_sumher(summary, fixture$architecture_ld_scores,
    fixture$weight_sums, fixture$tagging, fixture$blocks,
    reference_sample_size = 500,
    architecture_weights = fixture$architecture_weights,
    categories = fixture$categories,
    expected_proportions = c(all = 1, early = .6, even = .5))
  expect_true(all(c("category_h2", "heritability_proportion", "enrichment",
    "enrichment_contrast") %in% fit$estimates$quantity))
  all_enrichment <- fit$estimates$estimate[
    fit$estimates$component == "all" & fit$estimates$quantity == "enrichment"]
  expect_equal(all_enrichment, 1, tolerance = 1e-9)
  expect_identical(fit$diagnostics$category$category_names,
    c("all", "early", "even"))

  multiplier <- .8
  multiplied <- summary
  multiplied$z <- sqrt(multiplier * summary$z^2)
  inflated <- gcorr_sumher(multiplied, fixture$architecture_ld_scores,
    fixture$weight_sums, fixture$tagging, fixture$blocks,
    reference_sample_size = 500, inflation = "multiplicative")
  expect_equal(inflated$estimates$estimate[
    inflated$estimates$quantity == "inflation"], multiplier,
    tolerance = 1e-8)
})

test_that("multivariate SumHer transforms category covariance", {
  fixture <- sumher_fixture()
  statistics <- list(
    one = make_sumher_summary("one", fixture$z, fixture$markers,
      fixture$sample_sizes),
    two = make_sumher_summary("two", fixture$z, fixture$markers,
      fixture$sample_sizes))
  fit <- gcorr_sumher(statistics, fixture$architecture_ld_scores,
    fixture$weight_sums, fixture$tagging, fixture$blocks,
    reference_sample_size = 500, overlap_intercepts = 1,
    architecture_weights = fixture$architecture_weights,
    categories = fixture$categories)
  expect_identical(names(fit$matrices$category_genetic_covariance),
    c("all", "early", "even"))
  expect_equal(dim(fit$matrices$category_genetic_covariance$all), c(2L, 2L))
  expect_identical(names(fit$diagnostics$category), c("one", "two"))
  grouped <- gcorr_grouped_covariance(fit, kind = "categories",
    continuous = TRUE, units = c(one = "u", two = "u"))
  expect_identical(grouped$kind, "sumher_categories")
  expect_identical(grouped$group_names, c("all", "early", "even"))
})

test_that("SumHer rejects ambiguous architecture and overlap inputs", {
  fixture <- sumher_fixture()
  statistics <- list(
    one = make_sumher_summary("one", fixture$z, fixture$markers,
      fixture$sample_sizes),
    two = make_sumher_summary("two", fixture$z, fixture$markers,
      fixture$sample_sizes))
  scores <- fixture$architecture_ld_scores
  scores[1, 1] <- -1
  expect_error(gcorr_sumher(statistics[[1]], scores, fixture$weight_sums,
    fixture$tagging, fixture$blocks, 500), "uncorrected and nonnegative")
  expect_error(gcorr_sumher(statistics, fixture$architecture_ld_scores,
    fixture$weight_sums, fixture$tagging, fixture$blocks, 500,
    overlap_intercepts = matrix(c(NA, 1, 2, NA), 2, 2,
      dimnames = list(c("one", "two"), c("one", "two")))), "symmetric")
  expect_error(gcorr_sumher(statistics[[1]], fixture$architecture_ld_scores,
    fixture$weight_sums, fixture$tagging, fixture$blocks, 500,
    categories = fixture$categories), "supplied together")
  expect_error(gcorr_sumher(statistics[[1]], fixture$architecture_ld_scores,
    fixture$weight_sums, fixture$tagging, fixture$blocks, 500,
    architecture_weights = fixture$architecture_weights,
    categories = fixture$categories,
    expected_proportions = c(all = 1, all = .6, even = .5)),
    "uniquely named")
})
