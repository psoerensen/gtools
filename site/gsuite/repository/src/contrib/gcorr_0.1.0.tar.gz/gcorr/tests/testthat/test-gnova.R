make_gnova_summary <- function(trait, z, markers, n = 1000) {
    data.frame(
      rsids = markers,
      chr = rep("1", length(markers)),
      pos = seq_along(markers) * 100,
      ea = rep("A", length(markers)),
      nea = rep("G", length(markers)),
      z = z,
      n = rep(n, length(markers)),
      stringsAsFactors = FALSE
    )
}

gnova_fixture <- function() {
  markers <- paste0("g", seq_len(30))
  index <- seq_len(30)
  ordinary <- setNames(1 + index / 20, markers)
  annotations <- cbind(
    baseline = rep(1, 30),
    coding = as.numeric(index %% 3 == 0)
  )
  rownames(annotations) <- markers
  # Diagonal-LD fixture with varying marker weights: A' L is exactly symmetric,
  # while the baseline score remains distinct from the fitted intercept.
  annotation_ld_scores <- cbind(
    baseline = unname(ordinary),
    coding = annotations[, "coding"] * unname(ordinary)
  )
  rownames(annotation_ld_scores) <- markers
  z <- sqrt(1 + 1000 * drop(annotation_ld_scores %*% c(1e-4, 5e-5)))
  list(
    markers = markers,
    ordinary = ordinary,
    annotation_ld_scores = annotation_ld_scores,
    annotations = annotations,
    blocks = setNames(rep(paste0("b", 1:5), each = 6), markers),
    z = z
  )
}

test_that("ordinary GNOVA fits one trait through the focused interface", {
  fixture <- gnova_fixture()
  fit <- gcorr_gnova(
    make_gnova_summary("one", fixture$z, fixture$markers),
    blocks = fixture$blocks, ld_scores = fixture$ordinary)
  expect_s3_class(fit, "gcorr_gnova_fit")
  expect_identical(fit$method, "gnova")
  expect_identical(fit$assumptions$route, "ordinary")
  expect_identical(fit$diagnostics$used_marker_ids, fixture$markers)
  expect_true(all(c("h2", "component_h2", "intercept") %in%
    fit$estimates$quantity))
})

test_that("ordinary multivariate GNOVA is available through gcorr dispatcher", {
  fixture <- gnova_fixture()
  statistics <- list(
    one = make_gnova_summary("one", fixture$z, fixture$markers),
    two = make_gnova_summary("two", fixture$z, fixture$markers),
    three = make_gnova_summary("three", fixture$z, fixture$markers))
  fit <- gcorr(statistics, blocks = fixture$blocks,
    ld_scores = fixture$ordinary, overlap_intercepts = 1,
    method = "gnova")
  expect_equal(unname(fit$matrices$categories$all$genetic_correlation),
    matrix(1, 3, 3), tolerance = 1e-10)
  expect_equal(sum(fit$estimates$quantity == "rg"), 3L)
  expect_true(is.list(fit$diagnostics$joint_jackknife))
  expect_output(print(fit), "Multivariate GNOVA")
})

test_that("annotation-aware GNOVA exposes categories and components", {
  fixture <- gnova_fixture()
  statistics <- list(
    one = make_gnova_summary("one", fixture$z, fixture$markers),
    two = make_gnova_summary("two", fixture$z, fixture$markers))
  fit <- gcorr_gnova(statistics, blocks = fixture$blocks,
    annotation_ld_scores = fixture$annotation_ld_scores,
    annotations = fixture$annotations,
    weight_ld_scores = fixture$ordinary,
    reference_sample_size = 500,
    overlap_intercepts = 1)
  expect_identical(names(fit$matrices$categories), c("baseline", "coding"))
  expect_identical(names(fit$matrices$component_covariance),
    c("baseline", "coding"))
  expect_equal(unname(fit$matrices$categories$baseline$genetic_correlation),
    matrix(1, 2, 2), tolerance = 1e-10)
  expect_true(all(c("h2", "cov", "rg", "component_h2",
    "component_cov") %in% fit$estimates$quantity))
  grouped <- gcorr_grouped_covariance(fit, continuous = TRUE,
    units = c(one = "u", two = "u"))
  expect_identical(grouped$group_names, c("baseline", "coding"))
  expect_identical(grouped$kind, "gnova_categories")
})

test_that("GNOVA requires explicit overlap and exact method contracts", {
  fixture <- gnova_fixture()
  statistics <- list(
    one = make_gnova_summary("one", fixture$z, fixture$markers),
    two = make_gnova_summary("two", fixture$z, fixture$markers))
  expect_error(gcorr_gnova(statistics, blocks = fixture$blocks,
    ld_scores = fixture$ordinary), "explicitly supply every")
  bad <- fixture$annotations
  bad[1, 2] <- 0.5
  expect_error(gcorr_gnova(statistics, blocks = fixture$blocks,
    annotation_ld_scores = fixture$annotation_ld_scores,
    annotations = bad, weight_ld_scores = fixture$ordinary,
    reference_sample_size = 500, overlap_intercepts = 1), "binary 0/1")
})
