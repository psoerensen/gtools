make_regional_summary <- function(trait, z, markers, n) {
    data.frame(rsids = markers, chr = rep("1", length(markers)),
      pos = seq_along(markers) * 100, ea = rep("A", length(markers)),
      nea = rep("G", length(markers)), z = z,
      n = rep(n, length(markers)), stringsAsFactors = FALSE)
}

regional_fixture <- function() {
  markers <- letters[1:4]
  basis <- matrix(c(.5,.5,.5,.5, .5,-.5,.5,-.5,
    .5,.5,-.5,-.5, .5,-.5,-.5,.5), 4, 4)
  eigenvalues <- c(2.4, 1, .5, .1)
  ld <- basis %*% diag(eigenvalues) %*% t(basis)
  dimnames(ld) <- list(markers, markers)
  b1 <- c(.068, .0284, -.0142, .00288)
  b2 <- c(.0832, -.0346, -.0174, .0035)
  z1 <- drop(100 * basis %*% b1)
  z2 <- drop(sqrt(12000) * basis %*% b2)
  list(markers = markers, basis = basis, eigenvalues = eigenvalues, ld = ld,
    z1 = z1, z2 = z2,
    one = make_regional_summary("one", z1, markers, 10000),
    two = make_regional_summary("two", z2, markers, 12000))
}

lava_multitrait_fixture <- function() {
  fixture <- regional_fixture()
  eigensystem <- eigen(fixture$ld, symmetric = TRUE)
  genetic_gram <- diag(c(.05, .06, .07, .08))
  genetic_gram[row(genetic_gram) != col(genetic_gram)] <- .008
  projected <- chol(genetic_gram)
  marginal <- eigensystem$vectors %*%
    (sqrt(eigensystem$values) * projected)
  traits <- LETTERS[1:4]
  sample_sizes <- c(3000, 3500, 4000, 4500)
  statistics <- lapply(seq_along(traits), function(index) {
    correlation <- marginal[, index]
    z <- correlation * sqrt((sample_sizes[index] - 2) /
      (1 - correlation^2))
    make_regional_summary(traits[index], z, fixture$markers,
      sample_sizes[index])
  })
  names(statistics) <- traits
  sampling <- matrix(.1, 4, 4, dimnames = list(traits, traits))
  diag(sampling) <- 1
  variance <- (1 - diag(genetic_gram)) / (sample_sizes - 5)
  expected <- genetic_gram - 4 * sampling * sqrt(outer(variance, variance))
  dimnames(expected) <- list(traits, traits)
  list(fixture = fixture, statistics = statistics, sampling = sampling,
    expected = expected)
}

test_that("regional preparation verifies and reuses one immutable spectrum", {
  fixture <- regional_fixture()
  regions <- gcorr_prepare_regions(list(locus = fixture$ld), 5000)
  expect_s3_class(regions, "gcorr_prepared_regions")
  expect_identical(regions$regions$locus$marker_ids, fixture$markers)
  expect_equal(regions$regions$locus$diagnostics$eigenvalues,
    fixture$eigenvalues, tolerance = 1e-12)
  expect_output(print(regions), "Prepared regional LD")
  bad <- fixture$ld
  bad[1, 2] <- .2
  expect_error(gcorr_prepare_regions(list(locus = bad), 5000), "symmetric")
})

test_that("Glist preparation uses one reader and matches explicit matrices", {
  fixture <- gcorr_sparse_glist_fixture()
  on.exit(fixture$cleanup(), add = TRUE)
  markers <- fixture$Glist$sparseLD$marker_metadata$marker_id
  selected <- list(full = markers, left = markers[1:2])
  from_glist <- gcorr_prepare_regions(fixture$Glist, regions = selected)
  matrices <- lapply(selected, function(region)
    gbase::ld_region(fixture$Glist, region))
  explicit <- gcorr_prepare_regions(matrices,
    stats::setNames(rep(fixture$Glist$sparseLD$n, 2L), names(selected)))

  expect_identical(from_glist$source, "glist_sparse_ld")
  expect_identical(explicit$source, "explicit_matrix")
  expect_equal(from_glist$reader_diagnostics$reader_opens, 1)
  expect_equal(from_glist$reader_diagnostics$regions_read, length(selected))
  expect_lte(from_glist$reader_diagnostics$index_builds, 1)
  expect_identical(names(from_glist$regions), names(selected))
  for (name in names(selected)) {
    expect_equal(from_glist$regions[[name]]$diagnostics$eigenvalues,
      explicit$regions[[name]]$diagnostics$eigenvalues, tolerance = 1e-12)
  }

  statistics <- make_regional_summary("trait", c(2, -1, 3, .5), markers, 5000)
  glist_fit <- gcorr_hess(statistics, from_glist, maximum_components = 0,
    minimum_eigenvalue = 0)
  matrix_fit <- gcorr_hess(statistics, explicit, maximum_components = 0,
    minimum_eigenvalue = 0)
  expect_equal(glist_fit$estimates, matrix_fit$estimates, tolerance = 1e-12)
  expect_error(gcorr_prepare_regions(fixture$Glist,
    regions = list(bad = rev(markers))), "reference order")
})

test_that("HESS and rho-HESS use the standalone regional preparation", {
  fixture <- regional_fixture()
  regions <- gcorr_prepare_regions(list(locus = fixture$ld), 5000)
  hess <- gcorr_hess(fixture$one, regions, maximum_components = 0,
    minimum_eigenvalue = 0)
  expect_s3_class(hess, "gcorr_hess_fit")
  expect_true(is.finite(hess$estimates$estimate))
  expect_true(hess$diagnostics$locus$eigensystem_reused)
  rho <- gcorr(list(one = fixture$one, two = fixture$two), regions = regions,
    shared_sample_size = 3000, phenotypic_correlation = .2,
    maximum_components = 0, minimum_eigenvalue = 0, method = "rho_hess")
  expect_s3_class(rho, "gcorr_rho_hess_fit")
  expect_identical(rho$estimates$quantity, c("h2", "h2", "cov", "rg"))
  expect_true(rho$diagnostics$locus$eigensystem_reused)
  expect_output(print(rho), "rho_hess")
})

test_that("joint HESS estimates totals across prepared disjoint regions", {
  fixture <- regional_fixture()
  regions <- gcorr_prepare_regions(list(
    left = fixture$ld[1:2, 1:2], right = fixture$ld[3:4, 3:4]),
    c(left = 5000, right = 5000))
  hess <- gcorr_hess(fixture$one, regions, maximum_components = 0,
    minimum_eigenvalue = 0, joint = TRUE)
  expect_equal(sum(hess$estimates$component == "region"), 2L)
  expect_equal(sum(hess$estimates$component == "total"), 1L)
  expect_identical(names(hess$diagnostics$regions), c("left", "right"))
  rho <- gcorr_rho_hess(list(one = fixture$one, two = fixture$two), regions,
    shared_sample_size = 3000, phenotypic_correlation = .2,
    maximum_components = 0, minimum_eigenvalue = 0, joint = TRUE)
  expect_equal(sum(rho$estimates$component == "total"), 4L)
  expect_true(all(c("cov", "rg") %in%
    rho$estimates$quantity[rho$estimates$component == "total"]))
})

test_that("SUPERGNOVA exposes regional covariance and rank candidates", {
  fixture <- regional_fixture()
  regions <- gcorr_prepare_regions(list(locus = fixture$ld), 5000)
  fit <- gcorr_supergnova(list(one = fixture$one, two = fixture$two), regions,
    overlap_intercept = .1, overlap_intercept_variance = .001,
    minimum_components = 2, maximum_components = 4)
  expect_s3_class(fit, "gcorr_supergnova_fit")
  expect_identical(fit$estimates$quantity, "cov")
  expect_true(nrow(fit$diagnostics$locus$candidates) >= 1)
  expect_true(fit$diagnostics$locus$eigensystem_reused)
})

test_that("LAVA returns regional h2 covariance and correlation matrices", {
  fixture <- regional_fixture()
  regions <- gcorr_prepare_regions(list(locus = fixture$ld), 5000)
  sampling <- matrix(c(1, .2, .2, 1), 2, 2,
    dimnames = list(c("one", "two"), c("one", "two")))
  fit <- gcorr_lava(list(one = fixture$one, two = fixture$two), regions,
    sampling_correlation = sampling, explained_ld_fraction = 1)
  expect_s3_class(fit, "gcorr_lava_fit")
  expect_true(all(c("h2", "cov", "rg") %in% fit$estimates$quantity))
  expect_equal(dim(fit$matrices$locus$genetic_covariance), c(2L, 2L))
  expect_true(fit$diagnostics$locus$eigensystem_reused)
  expect_error(gcorr_lava(list(one = fixture$one, two = fixture$two), regions),
    "explicit sampling_correlation")
})

test_that("LAVA simulation inference is deterministic and explicit", {
  fixture <- lava_multitrait_fixture()
  regions <- gcorr_prepare_regions(list(locus = fixture$fixture$ld), 5000)
  controls <- list(seed = 42, pvalue_draws = 100,
    interval_draws = 500)
  first <- gcorr_lava(fixture$statistics, regions,
    sampling_correlation = fixture$sampling, explained_ld_fraction = 1,
    inference = controls)
  second <- gcorr_lava(fixture$statistics, regions,
    sampling_correlation = fixture$sampling, explained_ld_fraction = 1,
    inference = controls)
  expect_identical(first$estimates, second$estimates)
  expect_equal(sum(first$estimates$quantity == "rg"), 6L)
  expect_equal(sum(first$estimates$quantity == "rg_squared"), 6L)
  expect_true(first$diagnostics$locus$inference$requested)
  expect_length(first$diagnostics$locus$inference$pairs, 6L)
  expect_true(all(is.na(first$estimates$standard_error[
    first$estimates$quantity == "rg"])))
})

test_that("LAVA partial correlation and regression match covariance algebra", {
  fixture <- lava_multitrait_fixture()
  regions <- gcorr_prepare_regions(list(locus = fixture$fixture$ld), 5000)
  partial <- gcorr(fixture$statistics, regions = regions,
    targets = c("B", "A"), conditioned_on = c("D", "C"),
    sampling_correlation = fixture$sampling, explained_ld_fraction = 1,
    method = "lava_partial")
  residual <- fixture$expected[c("B", "A"), c("B", "A")] -
    fixture$expected[c("B", "A"), c("D", "C")] %*%
    solve(fixture$expected[c("D", "C"), c("D", "C")],
      fixture$expected[c("D", "C"), c("B", "A")])
  expect_equal(partial$estimates$estimate[
    partial$estimates$quantity == "partial_rg"],
    unname(cov2cor(residual)[1, 2]), tolerance = 1e-9)

  predictors <- c("D", "B", "C")
  coefficients <- solve(fixture$expected[predictors, predictors],
    fixture$expected[predictors, "A"])
  regression <- gcorr_lava_regression(fixture$statistics, regions,
    outcome = "A", predictors = predictors,
    sampling_correlation = fixture$sampling, explained_ld_fraction = 1)
  expect_equal(regression$estimates$estimate[
    regression$estimates$quantity == "coefficient"],
    unname(coefficients), tolerance = 1e-9)
  expect_identical(regression$estimates$trait2[
    regression$estimates$quantity == "coefficient"], predictors)

  controls <- list(seed = 52, pvalue_draws = 100,
    interval_draws = 500)
  inferred <- gcorr_lava_regression(fixture$statistics, regions,
    outcome = "A", predictors = predictors,
    sampling_correlation = fixture$sampling, explained_ld_fraction = 1,
    inference = controls, omnibus = list(seed = 53, draws = 100))
  again <- gcorr_lava_regression(fixture$statistics, regions,
    outcome = "A", predictors = predictors,
    sampling_correlation = fixture$sampling, explained_ld_fraction = 1,
    inference = controls, omnibus = list(seed = 53, draws = 100))
  expect_identical(inferred$estimates, again$estimates)
  expect_true("omnibus" %in% inferred$estimates$quantity)
  expect_true(inferred$diagnostics$locus$inference$requested)
  expect_equal(inferred$diagnostics$locus$conditional$omnibus$draws, 100)
})

test_that("LAVA reconstructs binary traits on observed and liability scales", {
  fixture <- regional_fixture()
  disease <- make_regional_summary("disease", c(4, 3, 2, -1),
    fixture$markers, 10000)
  regions <- gcorr_prepare_regions(list(locus = fixture$ld), 5000)
  frequencies <- setNames(c(.2, .3, .4, .25), fixture$markers)
  fit <- gcorr_lava(list(disease = disease), regions,
    binary = list(disease = list(cases = 2000, controls = 8000,
      population_prevalence = .1)), allele_frequencies = frequencies,
    explained_ld_fraction = 1)
  expect_true(all(c("h2", "h2_liability") %in% fit$estimates$quantity))
  expect_identical(fit$diagnostics$locus$univariate$disease$trait_type,
    "binary")
  expect_equal(fit$diagnostics$locus$allele_frequencies,
    unname(frequencies))
  expect_error(gcorr_lava(list(disease = disease), regions,
    binary = list(disease = list(cases = 1000, controls = 8000,
      population_prevalence = .1)), allele_frequencies = frequencies),
    "cases \\+ controls")
})

test_that("HDL-L reproduces its deterministic native likelihood fixture", {
  fixture <- regional_fixture()
  regions <- gcorr_prepare_regions(list(locus = fixture$ld), 5000)
  fit <- gcorr_hdll(list(one = fixture$one, two = fixture$two), regions,
    shared_sample_size = 3000, explained_ld_fraction = 1,
    parameter_tolerance = 2e-8)
  expect_s3_class(fit, "gcorr_hdll_fit")
  expect_equal(fit$estimates$estimate[fit$estimates$quantity == "cov"],
    .0009978805342642, tolerance = 2e-6)
  expect_equal(fit$estimates$estimate[fit$estimates$quantity == "rg"],
    .254234715711194, tolerance = 2e-6)
  expect_true(fit$diagnostics$locus$eigensystem_reused)
})
