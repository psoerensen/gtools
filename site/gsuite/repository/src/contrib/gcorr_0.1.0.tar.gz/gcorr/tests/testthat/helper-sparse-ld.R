write_gcorr_bed <- function(genotype, path) {
  body <- raw()
  for (marker in seq_len(ncol(genotype))) {
    code <- c(3L, 2L, 0L)[genotype[, marker] + 1L]
    code <- c(code, rep(1L, (-length(code)) %% 4L))
    body <- c(body, as.raw(colSums(matrix(code, 4L) * c(1, 4, 16, 64))))
  }
  writeBin(c(as.raw(c(0x6c, 0x1b, 0x01)), body), path)
}

gcorr_sparse_glist_fixture <- function() {
  genotype <- matrix(c(
    0, 0, 1, 2, 0, 1, 1, 2,
    0, 1, 1, 2, 1, 1, 2, 0,
    2, 1, 0, 0, 2, 1, 0, 1,
    1, 2, 0, 1, 2, 0, 1, 0), nrow = 8L)
  prefix <- tempfile("gcorr-regional-")
  paths <- paste0(prefix, c(".bed", ".bim", ".fam"))
  write_gcorr_bed(genotype, paths[1L])
  write.table(data.frame("1", letters[1:4], 0, 100 * 1:4, "A", "G"),
    paths[2L], quote = FALSE, row.names = FALSE, col.names = FALSE)
  write.table(data.frame(paste0("F", 1:8), paste0("I", 1:8), 0, 0, 0, -9),
    paths[3L], quote = FALSE, row.names = FALSE, col.names = FALSE)
  ld <- tempfile("gcorr-regional-ld-")
  Glist <- gbase::gprep(bedfiles = paths[1L])
  Glist <- gbase::gprep(Glist = Glist, task = "sparseld", out_prefix = ld,
    max_distance_bp = 0, max_distance_variants = 4, r2 = 0, nthreads = 1)
  cleanup <- function() {
    unlink(paths)
    unlink(paste0(ld, c(".row_ptr.u64.bin", ".col_idx.u32.0based.bin",
      ".values.f32.bin", ".meta.txt", ".markers.tsv")))
  }
  list(Glist = Glist, cleanup = cleanup)
}
