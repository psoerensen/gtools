covariance_fixture <- function() {
  traits <- LETTERS[1:4]
  loadings <- c(.8, .7, .6, .5)
  specific <- c(.4, .5, .6, .7)
  covariance <- tcrossprod(loadings) + diag(specific)
  dimnames(covariance) <- list(traits, traits)
  labels <- unlist(lapply(seq_along(traits), function(column) {
    paste(traits[column:length(traits)], traits[column], sep = "|")
  }), use.names = FALSE)
  sampling <- .0004 * .3^abs(outer(seq_along(labels),
    seq_along(labels), "-"))
  dimnames(sampling) <- list(labels, labels)
  input <- gcorr_covariance(covariance, sampling, continuous = TRUE,
    units = setNames(rep("standardized genetic covariance", 4), traits),
    provenance = "deterministic covariance fixture")
  model <- list(variables = c(traits, "F"),
    parameters = data.frame(
      name = c(paste0("loading_", traits), paste0("specific_", traits)),
      start = c(rep(.5, 4), rep(.6, 4)),
      lower = c(rep(-Inf, 4), rep(1e-8, 4))),
    entries = data.frame(
      matrix = c(rep("directed", 4), rep("disturbance", 5)),
      row = c(traits, traits, "F"),
      column = c(rep("F", 4), traits, "F"),
      parameter = c(paste0("loading_", traits),
        paste0("specific_", traits), ""),
      value = c(rep(0, 8), 1), stringsAsFactors = FALSE))
  list(input = input, loadings = loadings, specific = specific,
    model = model)
}

test_that("standalone SEM fits covariance summaries and tests constraints", {
  fixture <- covariance_fixture()
  fit <- gcorr(fixture$input, model = fixture$model, method = "sem")
  expect_s3_class(fit, "gcorr_sem_fit")
  expect_true(fit$available && fit$converged && fit$identified)
  expect_true(fit$inference_available)
  expect_equal(fit$estimates$estimate,
    c(fixture$loadings, fixture$specific), tolerance = 1e-5)
  expect_equal(fit$fitted_covariance, fixture$input$covariance,
    tolerance = 1e-6)
  constraints <- matrix(0, 1, nrow(fit$estimates), dimnames = list(
    "first two loadings equal", fit$estimates$parameter))
  constraints[1, c("loading_A", "loading_B")] <- c(1, -1)
  tested <- gcorr_sem_test(fit, constraints)
  positions <- match(c("loading_A", "loading_B"),
    fit$estimates$parameter)
  contrast <- fit$estimates$estimate[positions] %*% c(1, -1)
  variance <- drop(constraints %*% fit$parameter_sampling_covariance %*%
    t(constraints))
  expect_true(tested$available)
  expect_equal(tested$statistic, drop(contrast^2 / variance),
    tolerance = 1e-10)
  expect_equal(tested$p_value,
    pchisq(tested$statistic, 1, lower.tail = FALSE), tolerance = 1e-12)
  expect_output(print(fit), "Structural covariance model")
})

test_that("standalone GGM exposes descriptive and fixed-graph models", {
  fixture <- covariance_fixture()
  expected_precision <- solve(fixture$input$covariance)
  expected_partial <- -cov2cor(expected_precision)
  diag(expected_partial) <- 1
  network <- gcorr_ggm_network(fixture$input)
  expect_s3_class(network, "gcorr_ggm_network")
  expect_true(network$available)
  expect_equal(network$precision, expected_precision, tolerance = 1e-10)
  expect_equal(network$partial_correlation, expected_partial,
    tolerance = 1e-10)

  edges <- t(combn(fixture$input$traits, 2))
  fit <- gcorr(fixture$input, edges = edges, method = "ggm")
  expect_s3_class(fit, "gcorr_ggm_fit")
  expect_true(fit$available && fit$converged && fit$inference_available)
  expect_equal(fit$fitted_covariance, fixture$input$covariance,
    tolerance = 1e-5)
  expect_equal(fit$network$partial_correlation, expected_partial,
    tolerance = 1e-5)
  expect_identical(fit$estimates$parameter[[1L]], "precision[A,A]")
  selected <- matrix(c("A", "B", "B", "C"), 2, 2, byrow = TRUE)
  tested <- gcorr_ggm_test(fit, selected)
  positions <- match(c("precision[A,B]", "precision[B,C]"),
    fit$estimates$parameter)
  delta <- fit$estimates$estimate[positions]
  variance <- fit$parameter_sampling_covariance[positions, positions]
  expect_true(tested$available)
  expect_equal(tested$statistic,
    drop(t(delta) %*% solve(variance, delta)), tolerance = 1e-10)
  expect_equal(tested$p_value,
    pchisq(tested$statistic, 2, lower.tail = FALSE), tolerance = 1e-12)
})

test_that("covariance interfaces reject incomplete or ambiguous inputs", {
  fixture <- covariance_fixture()
  expect_output(print(fixture$input), "Joint sampling covariance: available")
  bad <- fixture$input$covariance
  rownames(bad) <- rev(rownames(bad))
  expect_error(gcorr_covariance(bad, continuous = TRUE,
    units = fixture$input$units),
    "labelled")
  point_only <- gcorr_covariance(fixture$input$covariance, continuous = TRUE,
    units = fixture$input$units)
  expect_error(gcorr_covariance(fixture$input$covariance,
    units = fixture$input$units), "explicitly TRUE")
  expect_true(gcorr_ggm_network(point_only)$available)
  expect_error(gcorr_sem(point_only, fixture$model), "full joint")
  expect_error(gcorr_ggm(point_only, matrix(c("A", "B"), 1, 2)),
    "full joint")
  expect_error(gcorr_ggm(fixture$input, matrix(c("A", "A"), 1, 2)),
    "self edges")
  fit <- gcorr_sem(fixture$input, fixture$model)
  wrong <- matrix(0, 1, nrow(fit$estimates), dimnames = list("bad",
    rev(fit$estimates$parameter)))
  expect_error(gcorr_sem_test(fit, wrong), "exactly matching")
})
