grouped_covariance_fixture <- function(method = "gnova") {
  traits <- c("A", "B", "C")
  groups <- c("coding", "regulatory")
  make_covariance <- function(path) {
    directed <- matrix(0, 3, 3)
    directed[2, 1] <- path
    directed[3, 2] <- .25
    transform <- solve(diag(3) - directed)
    covariance <- transform %*% diag(c(1, .8, .7)) %*% t(transform)
    dimnames(covariance) <- list(traits, traits)
    covariance
  }
  covariance <- setNames(lapply(c(.35, .15), make_covariance), groups)
  moment_labels <- c("A|A", "B|A", "C|A", "B|B", "C|B", "C|C")
  labels <- unlist(lapply(groups, function(group) {
    paste(group, moment_labels, sep = "::")
  }), use.names = FALSE)
  sampling <- matrix(.00002, length(labels), length(labels),
    dimnames = list(labels, labels))
  diag(sampling) <- .0004
  parameters <- do.call(rbind, lapply(groups, function(group) {
    data.frame(quantity = c("category_heritability",
      "category_covariance", "category_covariance",
      "category_heritability", "category_covariance",
      "category_heritability"),
      trait1 = c("A", "B", "C", "B", "C", "C"),
      trait2 = c("", "A", "A", "", "B", ""),
      component = group, stringsAsFactors = FALSE)
  }))
  fit <- structure(list(method = method, traits = traits,
    matrices = list(categories = lapply(covariance, function(value) {
      list(genetic_covariance = value)
    })), diagnostics = list(joint_jackknife = list(
      parameters = parameters, sampling_covariance = sampling))),
    class = "gcorr_gnova_fit")
  model <- list(variables = traits,
    parameters = data.frame(name = c("ab", "bc", "vA", "vB", "vC"),
      start = c(.2, .2, 1, 1, 1)),
    entries = data.frame(matrix = c("directed", "directed",
      rep("disturbance", 3)), row = c("B", "C", traits),
      column = c("A", "B", traits),
      parameter = c("ab", "bc", "vA", "vB", "vC"), value = 0,
      stringsAsFactors = FALSE))
  list(fit = fit, model = model, traits = traits, groups = groups,
    sampling = sampling, covariance = covariance)
}

test_that("grouped GNOVA covariance retains cross-category SEM uncertainty", {
  fixture <- grouped_covariance_fixture()
  units <- setNames(rep("standardized genetic covariance", 3),
    fixture$traits)
  input <- gcorr_grouped_covariance(fixture$fit,
    continuous = TRUE, units = units)
  expect_s3_class(input, "gcorr_grouped_covariance")
  expect_identical(input$kind, "gnova_categories")
  expect_equal(input$joint_sampling_covariance, fixture$sampling)
  fit <- gcorr_grouped_sem(input, fixture$model)
  expect_s3_class(fit, "gcorr_grouped_sem_fit")
  expect_true(fit$inference_available)
  expect_equal(fit$estimates$estimate[fit$estimates$parameter == "ab"],
    c(.35, .15), tolerance = 1e-6)
  expect_identical(colnames(fit$parameter_sampling_covariance),
    fit$estimates$label)
  constraints <- matrix(0, 1, nrow(fit$estimates), dimnames = list(
    "coding minus regulatory ab", fit$estimates$label))
  constraints[1, c("coding::ab", "regulatory::ab")] <- c(1, -1)
  tested <- gcorr_grouped_sem_test(fit, constraints)
  delta <- drop(constraints %*% fit$estimates$estimate)
  variance <- drop(constraints %*% fit$parameter_sampling_covariance %*%
    t(constraints))
  expect_true(tested$available)
  expect_equal(tested$statistic, unname(delta^2 / variance),
    tolerance = 1e-10)
  expect_output(print(fit), "Joint inference: TRUE")
})

test_that("grouped fixed graphs expose cross-group partial contrasts", {
  fixture <- grouped_covariance_fixture()
  input <- gcorr_grouped_covariance(fixture$fit,
    continuous = TRUE, units = setNames(rep("u", 3), fixture$traits))
  edges <- matrix(c("A", "B", "B", "C"), 2, 2, byrow = TRUE)
  fit <- gcorr_grouped_ggm(input, edges)
  expect_s3_class(fit, "gcorr_grouped_ggm_fit")
  expect_true(fit$inference_available)
  partial <- fit$partial_correlations
  expect_true(partial$inference_available)
  expect_true(all(c("coding::partial[A,B]",
    "regulatory::partial[A,B]") %in% partial$estimates$label))
  constraints <- matrix(0, 1, nrow(partial$estimates), dimnames = list(
    "partial A-B difference", partial$estimates$label))
  constraints[1, c("coding::partial[A,B]",
    "regulatory::partial[A,B]")] <- c(1, -1)
  tested <- gcorr_grouped_ggm_test(fit, constraints)
  expect_true(tested$available)
  expect_identical(tested$quantity, "partial_correlation")
})

test_that("SumHer categories use their native transformed joint covariance", {
  fixture <- grouped_covariance_fixture()
  sumher <- structure(list(method = "sumher", traits = fixture$traits,
    matrices = list(category_genetic_covariance = fixture$covariance),
    diagnostics = list(category_joint_sampling_covariance =
      as.vector(t(fixture$sampling)))), class = "gcorr_sumher_fit")
  input <- gcorr_grouped_covariance(sumher, kind = "categories",
    continuous = TRUE, units = setNames(rep("u", 3), fixture$traits))
  expect_identical(input$kind, "sumher_categories")
  expect_equal(input$joint_sampling_covariance, fixture$sampling)
  expect_error(gcorr_grouped_covariance(sumher, kind = "components",
    continuous = TRUE, units = setNames(rep("u", 3), fixture$traits)),
    "no grouped covariance")
})

test_that("grouped covariance requires explicit scales and joint uncertainty", {
  fixture <- grouped_covariance_fixture()
  units <- setNames(rep("u", 3), fixture$traits)
  expect_error(gcorr_grouped_covariance(fixture$fit, units = units),
    "explicitly TRUE")
  incomplete <- fixture$fit
  incomplete$diagnostics$joint_jackknife <- NULL
  expect_error(gcorr_grouped_covariance(incomplete, continuous = TRUE,
    units = units), "joint block-jackknife")
  input <- gcorr_grouped_covariance(fixture$fit,
    continuous = TRUE, units = units)
  fit <- gcorr_grouped_sem(input, fixture$model)
  bad <- matrix(0, 1, nrow(fit$estimates), dimnames = list("bad",
    rev(fit$estimates$label)))
  expect_error(gcorr_grouped_sem_test(fit, bad), "exactly matching")
})
