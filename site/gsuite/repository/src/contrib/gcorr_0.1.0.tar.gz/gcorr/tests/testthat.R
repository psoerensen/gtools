library(testthat)
library(gcorr)

test_check("gcorr")
