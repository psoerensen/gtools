make_mr_summary <- function(trait, effect, standard_error, markers, n,
    p_value = NULL) {
  data <- data.frame(rsids = markers, chr = rep("1", length(markers)),
    pos = seq_along(markers) * 100, ea = rep("A", length(markers)),
    nea = rep("G", length(markers)), b = effect,
    seb = rep(standard_error, length(markers)), n = rep(n, length(markers)),
    stringsAsFactors = FALSE)
  if (!is.null(p_value)) data$p <- p_value
  data
}

mr_fixture <- function() {
  markers <- paste0("mr", seq_len(12))
  index <- 0:11
  sign <- ifelse(index %% 2, -1, 1)
  exposure_effect <- sign * (.06 + .01 * index)
  outcome_effect <- sign * (.3 * abs(exposure_effect) + .001 * sin(index))
  ld <- diag(12)
  dimnames(ld) <- list(markers, markers)
  list(markers = markers, ld = ld, statistics = list(
    exposure = make_mr_summary("exposure", exposure_effect, .004,
      markers, 100000),
    outcome = make_mr_summary("outcome", outcome_effect, .006,
      markers, 90000)))
}

prepare_mr_fixture <- function(fixture = mr_fixture(), preparation = "gsmr2") {
  gcorr_prepare_mr(fixture$statistics, fixture$ld,
    exposure = "exposure", outcome = "outcome",
    reference_sample_size = 1024,
    ancestry = c(exposure = "artificial", outcome = "artificial"),
    reference_ancestry = "artificial",
    effect_units = c(exposure = "SD", outcome = "SD"),
    non_overlapping_samples = TRUE,
    preparation = preparation)
}

test_that("MR preparation is explicit, labelled, and serializable", {
  fixture <- mr_fixture()
  prepared <- prepare_mr_fixture(fixture)
  expect_s3_class(prepared, "gcorr_mr_prepared")
  expect_true(prepared$available)
  expect_identical(prepared$original_indices, 1:12)
  expect_equal(unname(prepared$ld), diag(12))
  expect_true(all(prepared$decisions$decision == "retained"))
  expect_equal(nrow(prepared$ld_decisions), 66)
  expect_true(prepared$p_values_derived)
  path <- tempfile()
  saveRDS(prepared, path)
  expect_identical(readRDS(path), prepared)
  unlink(path)
  expect_output(print(prepared), "Prepared MR instruments")

  expect_error(gcorr_prepare_mr(fixture$statistics, fixture$ld,
    "exposure", "outcome", 1024,
    c(exposure = "artificial", outcome = "artificial"), "artificial",
    c(exposure = "SD", outcome = "SD")),
    "explicitly TRUE")
  misaligned <- fixture$statistics
  misaligned$outcome$ea[1] <- "T"
  expect_error(gcorr_prepare_mr(misaligned, fixture$ld,
    "exposure", "outcome", 1024,
    c(exposure = "artificial", outcome = "artificial"), "artificial",
    c(exposure = "SD", outcome = "SD"), TRUE),
    "allele orientation")
})

test_that("focused MR estimators preserve native labelled results", {
  prepared <- prepare_mr_fixture()
  data <- prepared$data
  variance <- data$outcome_se^2 / data$exposure_effect^2 +
    data$outcome_effect^2 * data$exposure_se^2 /
      data$exposure_effect^4 + 1e-6
  gsmr <- gcorr(prepared, method = "gsmr", apply_heidi = FALSE)
  expect_true(gsmr$available)
  expect_equal(gsmr$estimates$estimate,
    sum(data$outcome_effect / data$exposure_effect / variance) /
      sum(1 / variance), tolerance = 1e-12)
  expect_equal(gsmr$estimates$standard_error, sqrt(1 / sum(1 / variance)),
    tolerance = 1e-12)
  expect_identical(gsmr$details$retained_original_indices, 1:12)

  gsmr2 <- gcorr_gsmr2(prepared)
  expect_true(gsmr2$available)
  expect_true(gsmr2$details$heidi$filtering_complete)

  ivw <- gcorr_mr_ivw(prepared)
  expected_ivw <- sum(data$exposure_effect * data$outcome_effect /
    data$outcome_se^2) / sum(data$exposure_effect^2 / data$outcome_se^2)
  expect_equal(ivw$estimates$estimate, expected_ivw, tolerance = 1e-12)

  egger <- gcorr_mr_egger(prepared)
  orientation <- sign(data$exposure_effect)
  expected_egger <- lm.wfit(cbind(1, abs(data$exposure_effect)),
    data$outcome_effect * orientation, 1 / data$outcome_se^2)
  expect_equal(egger$estimates$estimate,
    unname(expected_egger$coefficients[c(2, 1)]), tolerance = 1e-12)

  median <- gcorr_mr_weighted_median(prepared, bootstrap_replicates = 100,
    seed = 19)
  again <- gcorr(prepared, method = "weighted_median",
    bootstrap_replicates = 100, seed = 19)
  expect_true(median$available)
  expect_equal(median$details$bootstrap_completed, 100)
  expect_identical(median$details, again$details)
  expect_error(gcorr_mr_weighted_median(prepared), "explicit")
  expect_output(print(gsmr), "Mendelian randomisation")
  expect_identical(summary(gsmr), gsmr)
})

test_that("sensitivity estimators reject correlated prepared instruments", {
  prepared <- prepare_mr_fixture()
  prepared$ld[1, 2] <- prepared$ld[2, 1] <- .1
  fit <- gcorr_mr_ivw(prepared)
  expect_false(fit$available)
  expect_match(fit$reason, "Correlated instruments")
})
