#' Fit a genetic-correlation method
#'
#' Thin package-owned dispatcher for migrated standalone gcorr methods. Each
#' method delegates to its focused public function and returns all quantities
#' defined by that fit; there is no `task` selector.
#'
#' @param statistics One ordinary qgg-style data frame, a named aligned list, a
#'   covariance object, or a prepared MR instrument object as required by the
#'   selected method.
#' @param ... Arguments for the selected focused method.
#' @param method Migrated method name.
#' @return The result from the selected focused gcorr function.
#' @export
gcorr <- function(statistics, ..., method) {
  method <- match.arg(method, c("ldsc", "gnova", "sumher", "hess",
    "rho_hess", "supergnova", "lava", "lava_partial", "lava_regression",
    "hdll", "sem", "ggm", "gsmr", "gsmr2", "ivw", "egger",
    "weighted_median"))
  mr <- list(gsmr = gcorr_gsmr, gsmr2 = gcorr_gsmr2,
    ivw = gcorr_mr_ivw, egger = gcorr_mr_egger,
    weighted_median = gcorr_mr_weighted_median)
  if (method %in% names(mr)) {
    return(do.call(mr[[method]], c(list(instruments = statistics), list(...))))
  }
  if (method == "sem") {
    return(do.call(gcorr_sem, c(list(covariance = statistics), list(...))))
  }
  if (method == "ggm") {
    return(do.call(gcorr_ggm, c(list(covariance = statistics), list(...))))
  }
  arguments <- list(statistics = statistics, ...)
  regional <- list(hess = gcorr_hess, rho_hess = gcorr_rho_hess,
    supergnova = gcorr_supergnova, lava = gcorr_lava,
    lava_partial = gcorr_lava_partial,
    lava_regression = gcorr_lava_regression, hdll = gcorr_hdll)
  if (method %in% names(regional)) return(do.call(regional[[method]], arguments))
  if (method == "sumher") return(do.call(gcorr_sumher, arguments))
  if (method == "gnova") {
    return(do.call(gcorr_gnova, arguments))
  }
  if ("annotation_ld_scores" %in% names(arguments)) {
    return(do.call(gcorr_ldsc_partitioned, arguments))
  }
  do.call(gcorr_ldsc, arguments)
}
