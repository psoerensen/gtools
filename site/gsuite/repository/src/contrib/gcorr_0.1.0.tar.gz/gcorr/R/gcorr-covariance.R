.gcorr_covariance_matrix <- function(x, labels, name) {
  if (!is.matrix(x) || !is.numeric(x) ||
      !identical(dim(x), rep(length(labels), 2L)) ||
      any(!is.finite(x)) || !identical(rownames(x), labels) ||
      !identical(colnames(x), labels)) {
    .gcorr_stop(paste(name,
      "must be a finite square matrix labelled in the required order."))
  }
  if (max(abs(x - t(x))) > 1e-10 * max(1, abs(x))) {
    .gcorr_stop(paste(name, "must be symmetric."))
  }
  x
}

#' Prepare continuous-trait covariance summaries
#'
#' Validates a labelled genetic covariance matrix and its optional full joint
#' sampling covariance. Sampling moments use lower-column order: each diagonal
#' followed by entries below it.
#'
#' @param covariance Finite symmetric trait-labelled genetic covariance matrix.
#' @param sampling_covariance Optional finite symmetric sampling covariance of
#'   the lower-column covariance moments.
#' @param continuous Must be explicitly `TRUE`; binary and mixed-scale
#'   covariance models are not exposed.
#' @param units Character vector named exactly by trait, documenting compatible
#'   continuous response units.
#' @param provenance Nonempty description of the covariance source.
#' @return A validated `gcorr_covariance` object.
#' @export
gcorr_covariance <- function(covariance, sampling_covariance = NULL, continuous = NULL,
    units,
    provenance = "User-supplied covariance summaries") {
  if (!isTRUE(continuous)) {
    .gcorr_stop("continuous must be explicitly TRUE; binary and mixed covariance models are not exposed.")
  }
  traits <- rownames(covariance)
  if (is.null(traits) || length(traits) < 2L || anyNA(traits) ||
      any(!nzchar(traits)) || anyDuplicated(traits) ||
      any(grepl("|", traits, fixed = TRUE))) {
    .gcorr_stop("covariance requires at least two unique trait names without '|'.")
  }
  covariance <- .gcorr_covariance_matrix(covariance, traits,
    "covariance")
  if (!is.character(units) || !identical(names(units), traits) ||
      anyNA(units) || any(!nzchar(units))) {
    .gcorr_stop("units must name every continuous trait in covariance order.")
  }
  if (!is.character(provenance) || length(provenance) != 1L ||
      is.na(provenance) || !nzchar(provenance)) {
    .gcorr_stop("provenance must be one nonempty string.")
  }
  moment_labels <- unlist(lapply(seq_along(traits), function(column) {
    paste(traits[column:length(traits)], traits[column], sep = "|")
  }), use.names = FALSE)
  if (!is.null(sampling_covariance)) {
    sampling_covariance <- .gcorr_covariance_matrix(sampling_covariance,
      moment_labels, "sampling_covariance")
  }
  structure(list(covariance = covariance,
    sampling_covariance = sampling_covariance, traits = traits,
    moment_labels = moment_labels, units = units, provenance = provenance),
    class = "gcorr_covariance")
}

.gcorr_validate_covariance <- function(x, require_sampling = FALSE) {
  if (!inherits(x, "gcorr_covariance") || !is.list(x)) {
    .gcorr_stop("covariance must be prepared by gcorr_covariance().")
  }
  checked <- gcorr_covariance(x$covariance, x$sampling_covariance, TRUE,
    x$units, x$provenance)
  if (require_sampling && is.null(checked$sampling_covariance)) {
    .gcorr_stop(paste("Model fitting requires the full joint sampling",
      "covariance; marginal standard errors are insufficient."))
  }
  checked
}

.gcorr_covariance_controls <- function(maximum_iterations = 1000L,
    gradient_tolerance = 1e-8, relative_rank_tolerance = 1e-8,
    boundary_tolerance = 1e-6) {
  list(maximum_iterations = .gcorr_regional_number(maximum_iterations,
      "maximum_iterations", 1, whole = TRUE),
    gradient_tolerance = .gcorr_regional_number(gradient_tolerance,
      "gradient_tolerance", .Machine$double.eps),
    relative_rank_tolerance = .gcorr_regional_number(
      relative_rank_tolerance, "relative_rank_tolerance",
      .Machine$double.eps),
    boundary_tolerance = .gcorr_regional_number(boundary_tolerance,
      "boundary_tolerance", .Machine$double.eps))
}

.gcorr_sem_model <- function(model) {
  if (!is.list(model) ||
      !setequal(names(model), c("variables", "parameters", "entries"))) {
    .gcorr_stop("model requires variables, parameters, and entries.")
  }
  if (!is.character(model$variables) || !length(model$variables) ||
      anyNA(model$variables) || any(!nzchar(model$variables)) ||
      anyDuplicated(model$variables)) {
    .gcorr_stop("model variables must be unique nonempty names.")
  }
  parameters <- model$parameters
  if (!is.data.frame(parameters) ||
      !all(c("name", "start") %in% names(parameters))) {
    .gcorr_stop("model parameters require name and start columns.")
  }
  if (!"lower" %in% names(parameters)) parameters$lower <- -Inf
  if (!"upper" %in% names(parameters)) parameters$upper <- Inf
  if (!is.character(parameters$name) || anyNA(parameters$name) ||
      any(!nzchar(parameters$name)) || anyDuplicated(parameters$name) ||
      !is.numeric(parameters$start) || any(!is.finite(parameters$start)) ||
      !is.numeric(parameters$lower) || anyNA(parameters$lower) ||
      !is.numeric(parameters$upper) || anyNA(parameters$upper) ||
      any(parameters$lower > parameters$upper) ||
      any(parameters$start < parameters$lower |
          parameters$start > parameters$upper)) {
    .gcorr_stop("model parameters have invalid names, starts, or bounds.")
  }
  entries <- model$entries
  required <- c("matrix", "row", "column", "parameter", "value")
  if (!is.data.frame(entries) || !all(required %in% names(entries)) ||
      !all(entries$matrix %in% c("directed", "disturbance")) ||
      anyNA(entries[, required]) ||
      any(!entries$row %in% model$variables) ||
      any(!entries$column %in% model$variables) ||
      any(!entries$parameter %in% c("", parameters$name)) ||
      !is.numeric(entries$value) || any(!is.finite(entries$value)) ||
      any(entries$parameter != "" & entries$value != 0)) {
    .gcorr_stop("model entries contain invalid matrices, variables, parameters, or values.")
  }
  model$parameters <- parameters
  model
}

#' Fit a structural model to genetic covariance summaries
#'
#' @param covariance A `gcorr_covariance` object with full joint sampling
#'   covariance.
#' @param model Explicit recursive SEM specification with `variables`,
#'   `parameters`, and `entries`.
#' @param maximum_iterations,gradient_tolerance,relative_rank_tolerance,boundary_tolerance
#'   Positive native fitting controls.
#' @return A `gcorr_sem_fit` object.
#' @export
gcorr_sem <- function(covariance, model, maximum_iterations = 1000L,
    gradient_tolerance = 1e-8, relative_rank_tolerance = 1e-8,
    boundary_tolerance = 1e-6) {
  input <- .gcorr_validate_covariance(covariance, require_sampling = TRUE)
  model <- .gcorr_sem_model(model)
  if (any(!input$traits %in% model$variables)) {
    .gcorr_stop("Every observed covariance trait must occur in model variables.")
  }
  controls <- .gcorr_covariance_controls(maximum_iterations,
    gradient_tolerance, relative_rank_tolerance, boundary_tolerance)
  result <- cpp_gcorr_sem_fit(input, model, controls)
  result$input <- input
  result$model <- model
  result$controls <- controls
  structure(result, class = c("gcorr_sem_fit", "gcorr_covariance_fit"))
}

#' Test linear constraints on a fitted structural model
#' @param fit A regular `gcorr_sem_fit` result.
#' @param constraints Finite matrix whose columns exactly match fitted
#'   parameter names.
#' @param target Finite target value per constraint; defaults to zero.
#' @return A `gcorr_covariance_test` object.
#' @export
gcorr_sem_test <- function(fit, constraints, target = NULL) {
  if (!inherits(fit, "gcorr_sem_fit")) {
    .gcorr_stop("fit must be returned by gcorr_sem().")
  }
  parameters <- fit$estimates$parameter
  if (!is.matrix(constraints) || !is.numeric(constraints) ||
      !nrow(constraints) || any(!is.finite(constraints)) ||
      !identical(colnames(constraints), parameters)) {
    .gcorr_stop("constraints must be finite with columns exactly matching fitted parameters.")
  }
  if (is.null(rownames(constraints))) {
    rownames(constraints) <- paste0("constraint_", seq_len(nrow(constraints)))
  }
  if (anyNA(rownames(constraints)) || any(!nzchar(rownames(constraints))) ||
      anyDuplicated(rownames(constraints))) {
    .gcorr_stop("constraint row names must be unique and nonempty.")
  }
  if (is.null(target)) target <- rep(0, nrow(constraints))
  if (!is.numeric(target) || length(target) != nrow(constraints) ||
      any(!is.finite(target))) {
    .gcorr_stop("target must contain one finite value per constraint.")
  }
  result <- cpp_gcorr_sem_test(fit, constraints, target)
  result$hypotheses <- rownames(constraints)
  result$constraints <- constraints
  result$target <- target
  structure(result, class = "gcorr_covariance_test")
}

.gcorr_edges <- function(edges, traits, allow_empty = TRUE) {
  if (!is.matrix(edges) || !is.character(edges) || ncol(edges) != 2L ||
      (!allow_empty && !nrow(edges)) || anyNA(edges) || any(!nzchar(edges)) ||
      any(!edges %in% traits) || any(edges[, 1L] == edges[, 2L])) {
    .gcorr_stop("edges must be a two-column trait-name matrix without self edges.")
  }
  canonical <- if (nrow(edges)) apply(edges, 1L, function(x) {
    paste(sort(x), collapse = "|")
  }) else character()
  if (anyDuplicated(canonical)) .gcorr_stop("edges must be distinct.")
  edges
}

#' Describe the all-trait conditional genetic-correlation network
#' @param covariance A `gcorr_covariance` object; sampling covariance is not
#'   required or used.
#' @param relative_rank_tolerance Positive native rank tolerance.
#' @return A `gcorr_ggm_network` object.
#' @export
gcorr_ggm_network <- function(covariance, relative_rank_tolerance = 1e-8) {
  input <- .gcorr_validate_covariance(covariance)
  relative_rank_tolerance <- .gcorr_regional_number(
    relative_rank_tolerance, "relative_rank_tolerance",
    .Machine$double.eps)
  result <- cpp_gcorr_covariance_network(input, relative_rank_tolerance)
  result$input <- input
  structure(result, class = "gcorr_ggm_network")
}

#' Fit a fixed-graph Gaussian graphical model
#' @param covariance A `gcorr_covariance` object with full joint sampling
#'   covariance.
#' @param edges Two-column character matrix of explicitly allowed undirected
#'   edges. Omitted edges are fixed to zero precision.
#' @param start Optional finite native parameter start in canonical order.
#' @inheritParams gcorr_sem
#' @return A `gcorr_ggm_fit` object.
#' @export
gcorr_ggm <- function(covariance, edges, start = NULL,
    maximum_iterations = 1000L, gradient_tolerance = 1e-8,
    relative_rank_tolerance = 1e-8, boundary_tolerance = 1e-6) {
  input <- .gcorr_validate_covariance(covariance, require_sampling = TRUE)
  edges <- .gcorr_edges(edges, input$traits)
  if (!is.null(start) && (!is.numeric(start) || any(!is.finite(start)))) {
    .gcorr_stop("start must be a finite numeric vector.")
  }
  controls <- .gcorr_covariance_controls(maximum_iterations,
    gradient_tolerance, relative_rank_tolerance, boundary_tolerance)
  result <- cpp_gcorr_ggm_fit(input, edges, start, controls)
  public_names <- c(paste0("precision[", input$traits, ",",
      input$traits, "]"),
    if (nrow(result$edges)) paste0("precision[", result$edges$trait1,
      ",", result$edges$trait2, "]") else character())
  if (length(public_names) == nrow(result$estimates)) {
    result$native_parameter_names <- result$estimates$parameter
    result$estimates$parameter <- public_names
    if (!is.null(result$parameter_sampling_covariance)) {
      dimnames(result$parameter_sampling_covariance) <-
        list(public_names, public_names)
    }
  }
  result$input <- input
  result$requested_edges <- edges
  result$controls <- controls
  structure(result, class = c("gcorr_ggm_fit", "gcorr_covariance_fit"))
}

#' Test free edges in a fitted graphical model
#' @param fit A regular `gcorr_ggm_fit` result.
#' @param edges Nonempty two-column matrix selecting fitted free edges.
#' @return A `gcorr_covariance_test` object.
#' @export
gcorr_ggm_test <- function(fit, edges) {
  if (!inherits(fit, "gcorr_ggm_fit")) {
    .gcorr_stop("fit must be returned by gcorr_ggm().")
  }
  edges <- .gcorr_edges(edges, fit$input$traits, allow_empty = FALSE)
  canonical <- function(x) paste(sort(x), collapse = "|")
  requested <- apply(edges, 1L, canonical)
  available <- if (nrow(fit$edges)) apply(cbind(fit$edges$trait1,
    fit$edges$trait2), 1L, canonical) else character()
  if (any(!requested %in% available)) {
    .gcorr_stop("Every tested edge must be free in the fitted graph.")
  }
  result <- cpp_gcorr_ggm_test(fit, edges)
  result$edges <- edges
  structure(result, class = "gcorr_covariance_test")
}

#' @export
print.gcorr_covariance <- function(x, ...) {
  cat("Genetic covariance summaries\n")
  cat("  Traits:  ", paste(x$traits, collapse = " / "), "\n", sep = "")
  cat("  Joint sampling covariance: ",
    if (is.null(x$sampling_covariance)) "absent" else "available", "\n",
    sep = "")
  invisible(x)
}

#' @export
print.gcorr_covariance_fit <- function(x, ...) {
  cat(if (inherits(x, "gcorr_sem_fit")) "Structural covariance model"
    else "Fixed-graph covariance model", "\n")
  cat("  Available: ", x$available, "; converged: ", x$converged,
    "; identified: ", x$identified, "\n", sep = "")
  invisible(x)
}

#' @export
print.gcorr_ggm_network <- function(x, ...) {
  cat("Descriptive conditional genetic-correlation network\n")
  cat("  Available: ", x$available, "\n", sep = "")
  invisible(x)
}

#' @export
print.gcorr_covariance_test <- function(x, ...) {
  cat("Covariance-model test\n")
  cat("  Available: ", x$available, "; df: ", x$degrees_of_freedom,
    "; p: ", format(x$p_value), "\n", sep = "")
  invisible(x)
}
