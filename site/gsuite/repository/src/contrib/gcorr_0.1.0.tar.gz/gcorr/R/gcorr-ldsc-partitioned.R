#' Fit partitioned single-trait or multivariate LD-score regression
#'
#' Fits stratified LDSC from caller-supplied annotation LD scores. Inputs must
#' already share marker order, allele orientation, and annotation definitions;
#' this function validates those identities but does not harmonize them.
#'
#' @param statistics One ordinary qgg-style summary-statistics data frame, or a
#'   uniquely named list of two or more aligned data frames.
#' @param annotation_ld_scores Finite marker-by-annotation numeric matrix with
#'   marker row names and unique, nonempty annotation column names.
#' @param weight_ld_scores Positive, uniquely named ordinary LD scores for every
#'   marker, used only for regression weighting.
#' @param annotation_sums Positive, uniquely named annotation marker counts in
#'   exactly the annotation-column universe.
#' @param blocks Nonempty, uniquely named delete-block labels for every marker.
#' @param annotation_overlap Optional symmetric annotation-by-annotation matrix
#'   of binary annotation overlap counts. Its diagonal must equal
#'   `annotation_sums`.
#' @param reference_sample_size Positive sample size used when the supplied LD
#'   scores carry finite-reference correction metadata.
#' @param reference_marker_count Positive reference-universe marker count.
#'   Required when `annotation_overlap` is supplied.
#' @param corrected Whether the supplied annotation LD scores are already
#'   finite-reference corrected.
#' @param overlap_intercept Optional finite common cross-trait LDSC intercept;
#'   no sample-overlap conversion is inferred.
#' @param marginal_intercept Whether marginal LDSC intercepts are fixed to one
#'   or estimated.
#' @param maximum_chi_square Optional inclusive squared-Z filtering threshold.
#' @return A `gcorr_ldsc_partitioned_fit` containing annotation coefficients,
#'   derived totals and categories when identifiable, diagnostics, assumptions,
#'   and software provenance.
#' @export
gcorr_ldsc_partitioned <- function(statistics, annotation_ld_scores,
    weight_ld_scores, annotation_sums, blocks, annotation_overlap = NULL,
    reference_sample_size, reference_marker_count = NULL, corrected = FALSE,
    overlap_intercept = NULL,
    marginal_intercept = c("fixed_one", "free"),
    maximum_chi_square = NULL) {
  marginal_intercept <- match.arg(marginal_intercept)
  inputs <- .gcorr_prepare_statistics(statistics)
  statistics <- inputs$statistics
  prepared <- inputs$prepared
  first <- inputs$first
  annotation_ld_scores <- .gcorr_marker_matrix(annotation_ld_scores,
    first$marker, "annotation_ld_scores")
  annotations <- colnames(annotation_ld_scores)
  weight_ld_scores <- .gcorr_named_marker_vector(weight_ld_scores,
    first$marker, "weight_ld_scores")
  blocks <- .gcorr_blocks(blocks, first$marker)
  if (!is.numeric(annotation_sums) || length(annotation_sums) != length(annotations) ||
      is.null(names(annotation_sums)) || anyNA(names(annotation_sums)) ||
      any(!nzchar(names(annotation_sums))) || anyDuplicated(names(annotation_sums)) ||
      !setequal(names(annotation_sums), annotations) ||
      any(!is.finite(annotation_sums)) || any(annotation_sums <= 0)) {
    .gcorr_stop("annotation_sums must be positive uniquely named values matching annotations.")
  }
  annotation_sums <- unname(annotation_sums[annotations])

  if (!is.logical(corrected) || length(corrected) != 1L || is.na(corrected)) {
    .gcorr_stop("corrected must be one non-missing logical value.")
  }
  reference_sample_size <- .gcorr_scalar_number(reference_sample_size,
    "reference_sample_size", 1)
  if (!is.null(reference_marker_count)) {
    reference_marker_count <- .gcorr_scalar_number(reference_marker_count,
      "reference_marker_count", 1, TRUE)
  }
  if (!is.null(annotation_overlap)) {
    if (is.null(reference_marker_count)) {
      .gcorr_stop("reference_marker_count is required with annotation_overlap.")
    }
    if (!is.matrix(annotation_overlap) || !is.numeric(annotation_overlap) ||
        !identical(dim(annotation_overlap), rep(length(annotations), 2L)) ||
        !identical(rownames(annotation_overlap), annotations) ||
        !identical(colnames(annotation_overlap), annotations) ||
        any(!is.finite(annotation_overlap)) || any(annotation_overlap < 0) ||
        !isTRUE(all.equal(annotation_overlap, t(annotation_overlap), tolerance = 1e-12)) ||
        !isTRUE(all.equal(unname(diag(annotation_overlap)), annotation_sums,
          tolerance = 1e-12))) {
      .gcorr_stop(paste("annotation_overlap must be a finite nonnegative symmetric",
        "matrix in annotation order with diagonal equal to annotation_sums."))
    }
    if (reference_marker_count < max(annotation_overlap)) {
      .gcorr_stop("reference_marker_count cannot be smaller than an overlap count.")
    }
  }
  if (length(prepared) == 1L && !is.null(overlap_intercept)) {
    .gcorr_stop("overlap_intercept applies only to multivariate partitioned LDSC.")
  }
  if (!is.null(overlap_intercept)) {
    overlap_intercept <- .gcorr_scalar_number(overlap_intercept,
      "overlap_intercept")
  }
  if (!is.null(maximum_chi_square)) {
    maximum_chi_square <- .gcorr_scalar_number(maximum_chi_square,
      "maximum_chi_square", 0)
  }

  native <- cpp_gcorr_ldsc_partitioned(
    prepared, annotation_ld_scores, as.numeric(weight_ld_scores),
    annotation_sums, annotation_overlap, as.character(blocks),
    reference_sample_size, if (is.null(reference_marker_count)) 0 else reference_marker_count,
    corrected, overlap_intercept, marginal_intercept, maximum_chi_square
  )
  structure(c(native, list(
    method = "partitioned_ldsc",
    traits = names(statistics),
    annotations = annotations,
    assumptions = list(
      marginal_intercept = marginal_intercept,
      overlap_intercept = overlap_intercept,
      corrected_ld_scores = corrected,
      reference_sample_size = reference_sample_size,
      reference_marker_count = reference_marker_count,
      allele_alignment = "caller supplied; exact equality checked",
      annotation_alignment = "caller supplied; exact names and order checked"
    ),
    software = gcorr_native_info()
  )), class = c("gcorr_ldsc_partitioned_fit", "gcorr_ldsc_fit"))
}
