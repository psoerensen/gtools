.gcorr_named_list <- function(x, name) {
  if (!is.list(x) || !length(x) || is.null(names(x)) || anyNA(names(x)) ||
      any(!nzchar(names(x))) || anyDuplicated(names(x))) {
    .gcorr_stop(paste(name, "must be a nonempty uniquely named list."))
  }
  x
}

.gcorr_validate_regions <- function(regions) {
  if (!inherits(regions, "gcorr_prepared_regions") ||
      !is.list(regions$regions) || !length(regions$regions)) {
    .gcorr_stop("regions must be created by gcorr_prepare_regions().")
  }
  if (any(!vapply(regions$regions, function(x) {
    is.list(x) && is.character(x$marker_ids) && length(x$marker_ids) &&
      typeof(x$pointer) == "externalptr"
  }, logical(1)))) {
    .gcorr_stop("The prepared regional object is invalid or no longer live.")
  }
  regions
}

.gcorr_regional_statistics <- function(statistics, regions) {
  inputs <- .gcorr_prepare_statistics(statistics, scalar_sample_size = TRUE)
  sizes <- lengths(lapply(regions$regions, `[[`, "marker_ids"))
  indices <- match(unlist(lapply(regions$regions, `[[`, "marker_ids"),
    use.names = FALSE), inputs$first$marker)
  if (anyNA(indices)) {
    .gcorr_stop("Every prepared regional marker must occur in statistics.")
  }
  indices <- split(indices, rep.int(seq_along(sizes), sizes))
  names(indices) <- names(regions$regions)
  slices <- lapply(indices, function(index) {
    lapply(inputs$prepared, function(x) lapply(x, function(value) {
      if (length(value) == length(inputs$first$marker)) value[index] else value
    }))
  })
  list(statistics = inputs$statistics, traits = names(inputs$statistics),
    slices = slices)
}

.gcorr_regional_number <- function(x, name, lower = -Inf, upper = Inf,
    whole = FALSE) {
  x <- .gcorr_scalar_number(x, name, lower, whole)
  if (x > upper) .gcorr_stop(paste(name, "must be <=", upper))
  x
}

.gcorr_lava_inference <- function(x) {
  if (is.null(x)) return(NULL)
  defaults <- list(seed = NULL, pvalue_draws = c(10000L, 100000L, 1000000L),
    escalation_thresholds = c(1e-4, 1e-6), interval_draws = 10000L,
    relative_pvalue_mc_tolerance = .1,
    interval_endpoint_mc_tolerance = .05,
    maximum_abs_correlation = 1.25)
  x <- .gcorr_named_list(x, "inference")
  if (any(!names(x) %in% names(defaults))) .gcorr_stop("Unknown inference control.")
  defaults[names(x)] <- x
  if (is.null(defaults$seed)) .gcorr_stop("inference requires an explicit seed.")
  defaults$seed <- .gcorr_regional_number(defaults$seed, "inference seed", 0,
    2^53 - 1, whole = TRUE)
  draws <- defaults$pvalue_draws
  if (!is.numeric(draws) || !length(draws) || any(!is.finite(draws)) ||
      any(draws < 4 | draws > 1e7 | draws %% 2 != 0) || any(diff(draws) <= 0)) {
    .gcorr_stop("pvalue_draws must be increasing even counts from 4 to 10000000.")
  }
  if (length(draws) == 1L && !"escalation_thresholds" %in% names(x)) {
    defaults$escalation_thresholds <- numeric()
  }
  thresholds <- defaults$escalation_thresholds
  if (!is.numeric(thresholds) || any(!is.finite(thresholds)) ||
      length(thresholds) != length(draws) - 1L ||
      any(thresholds <= 0 | thresholds >= 1) || any(diff(thresholds) >= 0)) {
    .gcorr_stop("escalation_thresholds must decrease within (0,1), with one fewer value than pvalue_draws.")
  }
  defaults$interval_draws <- .gcorr_regional_number(defaults$interval_draws,
    "interval_draws", 100, 1e7, whole = TRUE)
  for (name in c("relative_pvalue_mc_tolerance",
      "interval_endpoint_mc_tolerance")) {
    defaults[[name]] <- .gcorr_regional_number(defaults[[name]], name,
      .Machine$double.eps)
  }
  defaults$maximum_abs_correlation <- .gcorr_regional_number(
    defaults$maximum_abs_correlation, "maximum_abs_correlation", 1)
  defaults
}

.gcorr_lava_binary <- function(binary, allele_frequencies, inputs) {
  if (is.null(binary)) {
    if (!is.null(allele_frequencies)) {
      .gcorr_stop("allele_frequencies applies only when binary traits are supplied.")
    }
    return(list(binary = NULL, allele_frequencies = NULL))
  }
  binary <- .gcorr_named_list(binary, "binary")
  if (any(!names(binary) %in% names(inputs$statistics))) {
    .gcorr_stop("binary names must identify supplied traits.")
  }
  for (name in names(binary)) {
    value <- binary[[name]]
    if (!is.list(value) || !setequal(names(value),
        c("cases", "controls", "population_prevalence"))) {
      .gcorr_stop("Each binary trait requires cases, controls, and population_prevalence.")
    }
    value$cases <- .gcorr_regional_number(value$cases, "binary cases",
      .Machine$double.eps)
    value$controls <- .gcorr_regional_number(value$controls, "binary controls",
      .Machine$double.eps)
    value$population_prevalence <- .gcorr_regional_number(
      value$population_prevalence, "population_prevalence",
      .Machine$double.eps, 1 - .Machine$double.eps)
    if (value$cases + value$controls != inputs$prepared[[name]]$n[[1L]]) {
      .gcorr_stop("Binary cases + controls must equal the trait sample size.")
    }
    binary[[name]] <- value
  }
  markers <- inputs$first$marker
  allele_frequencies <- .gcorr_named_marker_vector(allele_frequencies,
    markers, "allele_frequencies", numeric = TRUE, positive = TRUE)
  names(allele_frequencies) <- markers
  if (any(allele_frequencies >= 1)) {
    .gcorr_stop("allele_frequencies must lie strictly between zero and one.")
  }
  list(binary = binary, allele_frequencies = allele_frequencies)
}

.gcorr_regional_run <- function(method, statistics, regions, options, class) {
  regions <- .gcorr_validate_regions(regions)
  inputs <- .gcorr_regional_statistics(statistics, regions)
  if (method %in% c("hess", "rho_hess") && isTRUE(options$joint)) {
    native <- cpp_gcorr_joint_hess_fit(method, inputs$slices,
      lapply(regions$regions, `[[`, "pointer"), options)
    return(structure(list(method = method, traits = inputs$traits,
      estimates = native$estimates, matrices = NULL,
      diagnostics = native$diagnostics,
      preparation = list(region_names = names(regions$regions),
        reference_sample_sizes = regions$reference_sample_sizes),
      software = gcorr_native_info()), class = c(class, "gcorr_regional_fit")))
  }
  fit_options <- lapply(regions$regions, function(region) {
    local_options <- options
    if (!is.null(options$allele_frequencies)) {
      local_options$allele_frequencies <- unname(
        options$allele_frequencies[region$marker_ids])
    }
    local_options
  })
  fits <- cpp_gcorr_regional_fit_batch(method, inputs$slices,
    lapply(regions$regions, `[[`, "pointer"), fit_options)
  names(fits) <- names(regions$regions)
  estimates <- do.call(rbind, Map(function(fit, region) {
    data.frame(region = region, fit$estimates, row.names = NULL,
      check.names = FALSE, stringsAsFactors = FALSE)
  }, fits, names(fits)))
  matrices <- lapply(fits, `[[`, "matrices")
  if (all(vapply(matrices, is.null, logical(1)))) matrices <- NULL
  structure(list(method = method, traits = inputs$traits, estimates = estimates,
    matrices = matrices, diagnostics = lapply(fits, `[[`, "diagnostics"),
    preparation = list(region_names = names(regions$regions),
      reference_sample_sizes = regions$reference_sample_sizes),
    software = gcorr_native_info()), class = c(class, "gcorr_regional_fit"))
}

#' Prepare reusable regional LD
#'
#' Reads named regions from one sparse-LD Glist through one native reader, or
#' imports explicit signed correlation matrices. Each complete eigensystem is
#' verified once and reused across regional methods during the R session.
#'
#' @param regional_ld A Glist with sparse LD, or a nonempty named list of finite
#'   symmetric correlation matrices with identical unique marker names.
#' @param reference_sample_size A positive whole scalar applied to all regions,
#'   or a positive region-named vector. Omit for a Glist.
#' @param regions For a Glist, a uniquely named list of marker vectors in
#'   sparse-LD reference order. Omit for explicit matrices.
#' @return A session-bound `gcorr_prepared_regions` object.
#' @export
gcorr_prepare_regions <- function(regional_ld, reference_sample_size = NULL,
    regions = NULL) {
  if (inherits(regional_ld, "Glist")) {
    if (!is.null(reference_sample_size))
      .gcorr_stop("reference_sample_size is read from the Glist sparse-LD resource.")
    gbase::validate_Glist(regional_ld)
    resource <- regional_ld$sparseLD
    if (is.null(resource))
      .gcorr_stop("Glist has no sparse LD; use gprep(Glist, task = 'sparseld').")
    regions <- .gcorr_named_list(regions, "regions")
    marker_ids <- resource$marker_metadata$marker_id
    indices <- lapply(regions, function(markers) {
      if (!is.character(markers) || !length(markers) || anyNA(markers) ||
          any(!nzchar(markers)) || anyDuplicated(markers))
        .gcorr_stop("Region markers must be nonempty and unique.")
      index <- match(markers, marker_ids)
      if (anyNA(index) || is.unsorted(index, strictly = TRUE))
        .gcorr_stop("Region markers must exist and follow sparse-LD reference order.")
      as.double(index - 1L)
    })
    native <- cpp_gcorr_prepare_regions_from_reference(resource$prefix, indices)
    reference_sample_size <- stats::setNames(
      rep(as.double(resource$n), length(regions)), names(regions))
    source <- "glist_sparse_ld"
  } else {
    if (!is.null(regions))
      .gcorr_stop("regions is used only when regional_ld is a Glist.")
    regional_ld <- .gcorr_named_list(regional_ld, "regional_ld")
    for (name in names(regional_ld)) {
      matrix <- regional_ld[[name]]
      if (!is.matrix(matrix) || !is.numeric(matrix) || !length(matrix) ||
          nrow(matrix) != ncol(matrix) || any(!is.finite(matrix)) ||
          is.null(rownames(matrix)) || is.null(colnames(matrix)) ||
          !identical(rownames(matrix), colnames(matrix)) ||
          anyNA(rownames(matrix)) || any(!nzchar(rownames(matrix))) ||
          anyDuplicated(rownames(matrix))) {
        .gcorr_stop(paste("regional_ld", name,
          "must be a finite square matrix with identical unique marker names."))
      }
      if (max(abs(matrix - t(matrix))) > 1e-12 ||
          any(abs(diag(matrix) - 1) > 1e-12)) {
        .gcorr_stop(paste("regional_ld", name,
          "must be symmetric with an exact unit diagonal."))
      }
    }
    if (length(reference_sample_size) == 1L) {
      reference_sample_size <- rep(reference_sample_size, length(regional_ld))
      names(reference_sample_size) <- names(regional_ld)
    }
    if (!is.numeric(reference_sample_size) ||
        !identical(names(reference_sample_size), names(regional_ld)) ||
        any(!is.finite(reference_sample_size)) ||
        any(reference_sample_size < 2) ||
        any(reference_sample_size != floor(reference_sample_size))) {
      .gcorr_stop(paste("reference_sample_size must be a positive whole scalar",
        "or a vector named exactly in region order."))
    }
    native <- cpp_gcorr_prepare_regions(regional_ld,
      unname(reference_sample_size))
    source <- "explicit_matrix"
  }
  regions <- Map(function(pointer, diagnostic) list(
    marker_ids = diagnostic$marker_ids,
    pointer = pointer,
    reference_sample_size = diagnostic$reference_sample_size,
    diagnostics = diagnostic), native$pointers, native$diagnostics)
  structure(list(regions = regions,
    reference_sample_sizes = reference_sample_size,
    source = source,
    reader_diagnostics = native$reader_diagnostics,
    software = gcorr_native_info()), class = "gcorr_prepared_regions")
}

#' @export
print.gcorr_prepared_regions <- function(x, ...) {
  cat("Prepared regional LD\n")
  cat("  Source: ", x$source, "\n", sep = "")
  cat("  Regions: ", length(x$regions), "\n", sep = "")
  cat("  Markers: ", paste(vapply(x$regions,
    function(region) length(region$marker_ids), integer(1)), collapse = ", "),
    "\n", sep = "")
  invisible(x)
}

#' Fit regional HESS heritability
#' @export
gcorr_hess <- function(statistics, regions, maximum_components = 50L,
    minimum_eigenvalue = 1, relative_eigenvalue_tolerance = 1e-10,
    outside_heritability = 0, joint = FALSE,
    minimum_correction_denominator = 1e-8) {
  inputs <- .gcorr_prepare_statistics(statistics, scalar_sample_size = TRUE)
  if (length(inputs$statistics) != 1L) {
    .gcorr_stop("gcorr_hess() requires exactly one trait; use gcorr_rho_hess() for two.")
  }
  if (!is.logical(joint) || length(joint) != 1L || is.na(joint)) {
    .gcorr_stop("joint must be TRUE or FALSE.")
  }
  if (joint && outside_heritability != 0) {
    .gcorr_stop("Joint HESS estimates outside heritability; omit outside_heritability.")
  }
  options <- list(
    maximum_components = .gcorr_regional_number(maximum_components,
      "maximum_components", 0, whole = TRUE),
    minimum_eigenvalue = .gcorr_regional_number(minimum_eigenvalue,
      "minimum_eigenvalue", 0),
    relative_eigenvalue_tolerance = .gcorr_regional_number(
      relative_eigenvalue_tolerance, "relative_eigenvalue_tolerance", 0),
    outside_heritability = .gcorr_regional_number(outside_heritability,
      "outside_heritability"), joint = joint,
    minimum_correction_denominator = .gcorr_regional_number(
      minimum_correction_denominator, "minimum_correction_denominator",
      .Machine$double.eps))
  .gcorr_regional_run("hess", inputs, regions, options,
    "gcorr_hess_fit")
}

#' Fit regional rho-HESS covariance and correlation
#' @export
gcorr_rho_hess <- function(statistics, regions, shared_sample_size,
    phenotypic_correlation, maximum_components = 50L,
    minimum_eigenvalue = 1, relative_eigenvalue_tolerance = 1e-10,
    outside_heritability1 = 0, outside_heritability2 = 0,
    outside_genetic_covariance = 0, joint = FALSE,
    minimum_correction_denominator = 1e-8) {
  inputs <- .gcorr_prepare_statistics(statistics, scalar_sample_size = TRUE)
  if (length(inputs$statistics) != 2L) {
    .gcorr_stop("gcorr_rho_hess() requires exactly two traits.")
  }
  if (!is.logical(joint) || length(joint) != 1L || is.na(joint)) {
    .gcorr_stop("joint must be TRUE or FALSE.")
  }
  if (joint && any(c(outside_heritability1, outside_heritability2,
      outside_genetic_covariance) != 0)) {
    .gcorr_stop("Joint rho-HESS estimates outside contributions; omit outside values.")
  }
  sample_sizes <- vapply(inputs$prepared, function(x) x$n[[1L]], numeric(1))
  options <- list(
    shared_sample_size = .gcorr_regional_number(shared_sample_size,
      "shared_sample_size", 0, min(sample_sizes)),
    phenotypic_correlation = .gcorr_regional_number(phenotypic_correlation,
      "phenotypic_correlation", -1, 1),
    maximum_components = .gcorr_regional_number(maximum_components,
      "maximum_components", 0, whole = TRUE),
    minimum_eigenvalue = .gcorr_regional_number(minimum_eigenvalue,
      "minimum_eigenvalue", 0),
    relative_eigenvalue_tolerance = .gcorr_regional_number(
      relative_eigenvalue_tolerance, "relative_eigenvalue_tolerance", 0),
    outside_heritability1 = .gcorr_regional_number(outside_heritability1,
      "outside_heritability1"),
    outside_heritability2 = .gcorr_regional_number(outside_heritability2,
      "outside_heritability2"),
    outside_genetic_covariance = .gcorr_regional_number(
      outside_genetic_covariance, "outside_genetic_covariance"),
    joint = joint,
    minimum_correction_denominator = .gcorr_regional_number(
      minimum_correction_denominator, "minimum_correction_denominator",
      .Machine$double.eps))
  .gcorr_regional_run("rho_hess", inputs, regions, options,
    "gcorr_rho_hess_fit")
}

#' Fit regional SUPERGNOVA covariance
#' @export
gcorr_supergnova <- function(statistics, regions, overlap_intercept,
    overlap_intercept_variance = 0, minimum_components = 10L,
    maximum_components = 0L, relative_eigenvalue_tolerance = 1e-10) {
  inputs <- .gcorr_prepare_statistics(statistics, scalar_sample_size = TRUE)
  if (length(inputs$statistics) != 2L) {
    .gcorr_stop("gcorr_supergnova() requires exactly two traits.")
  }
  options <- list(
    overlap_intercept = .gcorr_regional_number(overlap_intercept,
      "overlap_intercept"),
    overlap_intercept_variance = .gcorr_regional_number(
      overlap_intercept_variance, "overlap_intercept_variance", 0),
    minimum_components = .gcorr_regional_number(minimum_components,
      "minimum_components", 2, whole = TRUE),
    maximum_components = .gcorr_regional_number(maximum_components,
      "maximum_components", 0, whole = TRUE),
    relative_eigenvalue_tolerance = .gcorr_regional_number(
      relative_eigenvalue_tolerance, "relative_eigenvalue_tolerance", 0))
  .gcorr_regional_run("supergnova", inputs, regions, options,
    "gcorr_supergnova_fit")
}

.gcorr_lava_options <- function(statistics, sampling_correlation,
    explained_ld_fraction, minimum_components, maximum_sample_fraction,
    relative_eigenvalue_tolerance, univariate_threshold, binary,
    allele_frequencies, inference, analysis = "marginal", selection = list(),
    minimum_relative_eigenvalue = 1e-4,
    residual_variance_tolerance = 1e-8, maximum_traits = 32L,
    omnibus = NULL) {
  inputs <- .gcorr_prepare_statistics(statistics, scalar_sample_size = TRUE)
  traits <- names(inputs$statistics)
  if (length(traits) > 1L && is.null(sampling_correlation)) {
    .gcorr_stop("Multivariate LAVA requires an explicit sampling_correlation matrix.")
  }
  if (length(traits) == 1L) sampling_correlation <- matrix(1, 1, 1,
    dimnames = list(traits, traits))
  if (!is.matrix(sampling_correlation) || !is.numeric(sampling_correlation) ||
      !identical(rownames(sampling_correlation), traits) ||
      !identical(colnames(sampling_correlation), traits) ||
      any(!is.finite(sampling_correlation)) ||
      max(abs(sampling_correlation - t(sampling_correlation))) > 1e-12 ||
      any(abs(diag(sampling_correlation) - 1) > 1e-12) ||
      any(abs(sampling_correlation) > 1)) {
    .gcorr_stop("sampling_correlation must be a symmetric trait-named correlation matrix.")
  }
  binary_values <- .gcorr_lava_binary(binary, allele_frequencies, inputs)
  options <- list(sampling_correlation = sampling_correlation,
    explained_ld_fraction = .gcorr_regional_number(explained_ld_fraction,
      "explained_ld_fraction", .Machine$double.eps, 1),
    minimum_components = .gcorr_regional_number(minimum_components,
      "minimum_components", 2, whole = TRUE),
    maximum_sample_fraction = .gcorr_regional_number(maximum_sample_fraction,
      "maximum_sample_fraction", .Machine$double.eps, 1),
    relative_eigenvalue_tolerance = .gcorr_regional_number(
      relative_eigenvalue_tolerance, "relative_eigenvalue_tolerance", 0),
    univariate_threshold = .gcorr_regional_number(univariate_threshold,
      "univariate_threshold", 0, 1), binary = binary_values$binary,
    allele_frequencies = binary_values$allele_frequencies,
    inference = .gcorr_lava_inference(inference), analysis = analysis,
    maximum_traits = .gcorr_regional_number(maximum_traits,
      "maximum_traits", 2, 32, whole = TRUE),
    minimum_relative_eigenvalue = .gcorr_regional_number(
      minimum_relative_eigenvalue, "minimum_relative_eigenvalue",
      .Machine$double.eps, 1 - .Machine$double.eps),
    residual_variance_tolerance = .gcorr_regional_number(
      residual_variance_tolerance, "residual_variance_tolerance",
      .Machine$double.eps, 1 - .Machine$double.eps))
  options[names(selection)] <- selection
  if (!is.null(omnibus)) {
    omnibus <- .gcorr_named_list(omnibus, "omnibus")
    if (any(!names(omnibus) %in% c("seed", "draws",
        "relative_pvalue_mc_tolerance")) || is.null(omnibus$seed)) {
      .gcorr_stop("omnibus requires an explicit seed and known controls.")
    }
    options$omnibus <- list(
      seed = .gcorr_regional_number(omnibus$seed, "omnibus seed", 0,
        2^53 - 1, whole = TRUE),
      draws = .gcorr_regional_number(if (is.null(omnibus$draws)) 10000L else omnibus$draws,
        "omnibus draws", 100, 1e7, whole = TRUE),
      relative_pvalue_mc_tolerance = .gcorr_regional_number(
        if (is.null(omnibus$relative_pvalue_mc_tolerance)) .1 else omnibus$relative_pvalue_mc_tolerance,
        "omnibus relative_pvalue_mc_tolerance", .Machine$double.eps))
  }
  list(statistics = inputs, options = options)
}

#' Fit regional LAVA covariance models
#' @export
gcorr_lava <- function(statistics, regions, sampling_correlation = NULL,
    explained_ld_fraction = .99, minimum_components = 2L,
    maximum_sample_fraction = .75, relative_eigenvalue_tolerance = 1e-10,
    univariate_threshold = .05, binary = NULL, allele_frequencies = NULL,
    inference = NULL) {
  prepared <- .gcorr_lava_options(statistics, sampling_correlation,
    explained_ld_fraction, minimum_components, maximum_sample_fraction,
    relative_eigenvalue_tolerance, univariate_threshold, binary,
    allele_frequencies, inference)
  .gcorr_regional_run("lava", prepared$statistics, regions, prepared$options,
    "gcorr_lava_fit")
}

#' Fit regional LAVA partial genetic correlation
#' @export
gcorr_lava_partial <- function(statistics, regions, targets, conditioned_on,
    sampling_correlation, explained_ld_fraction = .99,
    minimum_components = 2L, maximum_sample_fraction = .75,
    relative_eigenvalue_tolerance = 1e-10, univariate_threshold = .05,
    binary = NULL, allele_frequencies = NULL, inference = NULL,
    maximum_conditioning_r_squared = .95,
    minimum_relative_eigenvalue = 1e-4,
    residual_variance_tolerance = 1e-8, maximum_traits = 32L) {
  traits <- if (identical(class(statistics), "data.frame")) "trait" else names(statistics)
  if (!is.character(targets) || length(targets) != 2L || anyNA(targets) ||
      anyDuplicated(targets) || any(!targets %in% traits) ||
      !is.character(conditioned_on) || !length(conditioned_on) ||
      anyNA(conditioned_on) || anyDuplicated(conditioned_on) ||
      any(!conditioned_on %in% traits) || length(intersect(targets, conditioned_on))) {
    .gcorr_stop("targets must name two traits disjoint from distinct conditioned_on traits.")
  }
  selection <- list(targets = match(targets, traits) - 1L,
    conditioned_on = match(conditioned_on, traits) - 1L,
    maximum_conditioning_r_squared = .gcorr_regional_number(
      maximum_conditioning_r_squared, "maximum_conditioning_r_squared",
      .Machine$double.eps, 1 - .Machine$double.eps))
  prepared <- .gcorr_lava_options(statistics, sampling_correlation,
    explained_ld_fraction, minimum_components, maximum_sample_fraction,
    relative_eigenvalue_tolerance, univariate_threshold, binary,
    allele_frequencies, inference, "partial", selection,
    minimum_relative_eigenvalue, residual_variance_tolerance, maximum_traits)
  .gcorr_regional_run("lava", prepared$statistics, regions, prepared$options,
    "gcorr_lava_partial_fit")
}

#' Fit regional LAVA genetic regression
#' @export
gcorr_lava_regression <- function(statistics, regions, outcome, predictors,
    sampling_correlation, explained_ld_fraction = .99,
    minimum_components = 2L, maximum_sample_fraction = .75,
    relative_eigenvalue_tolerance = 1e-10, univariate_threshold = .05,
    binary = NULL, allele_frequencies = NULL, inference = NULL,
    omnibus = NULL, minimum_relative_eigenvalue = 1e-4,
    residual_variance_tolerance = 1e-8, maximum_traits = 32L) {
  traits <- if (identical(class(statistics), "data.frame")) "trait" else names(statistics)
  if (!is.character(outcome) || length(outcome) != 1L || is.na(outcome) ||
      !outcome %in% traits || !is.character(predictors) || !length(predictors) ||
      anyNA(predictors) || anyDuplicated(predictors) ||
      any(!predictors %in% traits) || outcome %in% predictors) {
    .gcorr_stop("outcome must name one trait disjoint from distinct predictors.")
  }
  selection <- list(outcome = match(outcome, traits) - 1L,
    predictors = match(predictors, traits) - 1L)
  prepared <- .gcorr_lava_options(statistics, sampling_correlation,
    explained_ld_fraction, minimum_components, maximum_sample_fraction,
    relative_eigenvalue_tolerance, univariate_threshold, binary,
    allele_frequencies, inference, "regression", selection,
    minimum_relative_eigenvalue, residual_variance_tolerance, maximum_traits,
    omnibus)
  .gcorr_regional_run("lava", prepared$statistics, regions, prepared$options,
    "gcorr_lava_regression_fit")
}

#' Fit regional HDL-L likelihood models
#' @export
gcorr_hdll <- function(statistics, regions, shared_sample_size,
    explained_ld_fraction = .99, relative_eigenvalue_tolerance = 1e-10,
    variance_floor = exp(-18), alpha = .05, parameter_tolerance = 1e-8,
    maximum_iterations = 400L) {
  inputs <- .gcorr_prepare_statistics(statistics, scalar_sample_size = TRUE)
  if (length(inputs$statistics) != 2L) {
    .gcorr_stop("gcorr_hdll() requires exactly two traits.")
  }
  sample_sizes <- vapply(inputs$prepared, function(x) x$n[[1L]], numeric(1))
  options <- list(
    shared_sample_size = .gcorr_regional_number(shared_sample_size,
      "shared_sample_size", 0, min(sample_sizes)),
    explained_ld_fraction = .gcorr_regional_number(explained_ld_fraction,
      "explained_ld_fraction", .Machine$double.eps, 1),
    relative_eigenvalue_tolerance = .gcorr_regional_number(
      relative_eigenvalue_tolerance, "relative_eigenvalue_tolerance", 0),
    variance_floor = .gcorr_regional_number(variance_floor,
      "variance_floor", .Machine$double.eps),
    alpha = .gcorr_regional_number(alpha, "alpha", .Machine$double.eps,
      1 - .Machine$double.eps),
    parameter_tolerance = .gcorr_regional_number(parameter_tolerance,
      "parameter_tolerance", .Machine$double.eps, 1 - .Machine$double.eps),
    maximum_iterations = .gcorr_regional_number(maximum_iterations,
      "maximum_iterations", 1, whole = TRUE))
  .gcorr_regional_run("hdll", inputs, regions, options,
    "gcorr_hdll_fit")
}

#' @export
print.gcorr_regional_fit <- function(x, ...) {
  cat("Regional ", x$method, " fit\n", sep = "")
  cat("  Traits:  ", paste(x$traits, collapse = " / "), "\n", sep = "")
  cat("  Regions: ", length(x$preparation$region_names), "\n", sep = "")
  invisible(x)
}
