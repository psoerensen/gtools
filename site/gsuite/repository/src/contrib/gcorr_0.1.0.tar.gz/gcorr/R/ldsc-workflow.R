.gcorr_ldsc_reference <- function(Glist, prepared) {
  gbase::validate_Glist(Glist)
  if (!is.list(Glist$sparseLD)) {
    .gcorr_stop("Glist must be augmented with gprep(task = 'sparseld').")
  }
  metadata <- Glist$sparseLD$marker_metadata
  index <- match(prepared$marker, metadata$marker_id)
  if (anyNA(index) || is.unsorted(index, strictly = TRUE)) {
    .gcorr_stop("Statistics must follow the retained sparse-LD marker order.")
  }
  selected <- metadata[index, , drop = FALSE]
  if (!identical(as.character(prepared$chromosome),
        as.character(selected$chromosome)) ||
      !identical(as.numeric(prepared$position),
        as.numeric(selected$base_pair_position)) ||
      !identical(as.character(prepared$effect_allele),
        as.character(selected$allele1)) ||
      !identical(as.character(prepared$other_allele),
        as.character(selected$allele2))) {
    .gcorr_stop("Statistics must match Glist marker coordinates and allele orientation exactly.")
  }
  list(metadata = metadata, index = index)
}

.gcorr_ldsc_scores <- function(ldscores, markers) {
  if (!is.numeric(ldscores) || !length(ldscores) || is.null(names(ldscores)) ||
      anyNA(names(ldscores)) || any(!nzchar(names(ldscores))) ||
      anyDuplicated(names(ldscores)) || any(!is.finite(ldscores)) ||
      any(ldscores <= 0) || any(!markers %in% names(ldscores))) {
    .gcorr_stop("ldscores must be positive finite uniquely named values containing every statistic marker.")
  }
  stats::setNames(as.numeric(ldscores[markers]), markers)
}

.gcorr_ldsc_blocks <- function(blocks, prepared, block_count) {
  markers <- prepared$marker
  if (is.null(blocks)) {
    block_count <- .gcorr_scalar_number(block_count, "block_count", 2, TRUE)
    if (length(markers) < 2L) {
      .gcorr_stop("At least two markers are required to form delete blocks.")
    }
    width <- ceiling(length(markers) / min(block_count, length(markers)))
    chunk <- (seq_along(markers) - 1L) %/% width + 1L
    blocks <- paste(as.character(prepared$chromosome), chunk, sep = ":")
    return(stats::setNames(blocks, markers))
  }
  if (!is.character(blocks) || anyNA(blocks) || any(!nzchar(blocks))) {
    .gcorr_stop("blocks must contain nonempty delete-block labels.")
  }
  if (is.null(names(blocks))) {
    if (length(blocks) != length(markers)) {
      .gcorr_stop("Unnamed blocks must follow the statistic marker order.")
    }
    return(stats::setNames(blocks, markers))
  }
  if (anyNA(names(blocks)) || any(!nzchar(names(blocks))) ||
      anyDuplicated(names(blocks)) || any(!markers %in% names(blocks))) {
    .gcorr_stop("Named blocks must contain every statistic marker exactly once.")
  }
  stats::setNames(as.character(blocks[markers]), markers)
}

.gcorr_ldsc_annotations <- function(sets, marker_ids, residual) {
  if (!is.list(sets) || !length(sets) || is.object(sets) ||
      is.null(names(sets)) || anyNA(names(sets)) ||
      any(!nzchar(names(sets))) || anyDuplicated(names(sets))) {
    .gcorr_stop("sets must be a nonempty uniquely named ordinary list.")
  }
  sets <- lapply(sets, function(ids) {
    if (!is.character(ids) || !length(ids) || anyNA(ids) ||
        any(!nzchar(ids)) || anyDuplicated(ids)) {
      .gcorr_stop("Every set must contain unique nonempty marker IDs.")
    }
    if (any(!ids %in% marker_ids)) {
      .gcorr_stop("Every set marker must exist in the Glist sparse-LD reference.")
    }
    ids
  })
  if (!is.logical(residual) || length(residual) != 1L || is.na(residual)) {
    .gcorr_stop("residual must be TRUE or FALSE.")
  }
  if (residual) {
    if ("Residual" %in% names(sets)) {
      .gcorr_stop("sets cannot contain a set named Residual when residual = TRUE.")
    }
    remaining <- setdiff(marker_ids, unique(unlist(sets, use.names = FALSE)))
    if (!length(remaining)) {
      .gcorr_stop("The residual marker set is empty; use residual = FALSE.")
    }
    sets$Residual <- remaining
  }
  annotation <- matrix(0, nrow = length(marker_ids), ncol = length(sets),
    dimnames = list(marker_ids, names(sets)))
  for (column in seq_along(sets)) {
    annotation[match(sets[[column]], marker_ids), column] <- 1
  }
  list(sets = sets, annotation = annotation)
}

.gcorr_ldsc_views <- function(fit, what) {
  estimates <- fit$estimates
  rows <- estimates$quantity == "h2" & is.na(estimates$trait2)
  h2 <- estimates[rows, , drop = FALSE]
  components <- if ("component" %in% names(h2)) h2$component else rep("all", nrow(h2))
  component_names <- unique(components)
  values <- matrix(NA_real_, nrow = length(component_names),
    ncol = length(fit$traits), dimnames = list(component_names, fit$traits))
  if (nrow(h2)) {
    values[cbind(match(components, component_names),
      match(h2$trait1, fit$traits))] <- h2$estimate
  }
  correlation <- if (!is.null(fit$matrices$total_genetic_correlation)) {
    fit$matrices$total_genetic_correlation
  } else if (!is.null(fit$matrices$genetic_correlation)) {
    fit$matrices$genetic_correlation
  } else {
    matrix(1, 1L, 1L, dimnames = list(fit$traits, fit$traits))
  }
  fit$h2 <- values
  fit$rg <- correlation
  fit$requested <- what
  fit
}

.gcorr_grouped_estimates <- function(fit, marker_counts) {
  source <- fit$estimates$quantity %in% c("tau", "tau_cov")
  grouped <- fit$estimates[source, , drop = FALSE]
  if (!nrow(grouped)) return(fit)
  scale <- unname(marker_counts[match(grouped$component,
    names(marker_counts))])
  grouped$quantity <- ifelse(grouped$quantity == "tau", "h2", "cov")
  grouped$estimate <- grouped$estimate * scale
  grouped$standard_error <- grouped$standard_error * scale
  fit$estimates <- rbind(fit$estimates, grouped)
  fit$group_marker_counts <- marker_counts
  fit
}

#' Fit LD-score regression from checked summary statistics
#'
#' Convenience interface for ordinary, stratified, or grouped LD-score
#' regression. The
#' `stat` contract is shared with `glma::vegas()`: supply one checked ordinary
#' summary-statistics data frame or a uniquely named list for multiple traits.
#'
#' @param stat One checked summary-statistics data frame, or a uniquely named
#'   list of aligned data frames. Each entry must contain marker identity,
#'   alleles, sample size, and a supported signed statistic.
#' @param Glist Optional prepared Glist containing sparse LD. Required when
#'   `sets` is supplied; otherwise it supplies ordinary LD scores and reference
#'   metadata.
#' @param ldscores Optional positive named ordinary LD-score vector. When both
#'   `Glist` and `ldscores` are supplied, this vector is used for regression
#'   weighting while Glist supplies annotation LD scores.
#' @param sets Optional uniquely named list of marker-ID vectors. Sets may
#'   overlap. Annotation LD scores are computed from Glist.
#' @param set_model How supplied marker sets enter the regression. `stratified`
#'   computes standard annotation-specific LD scores from sparse LD;
#'   `grouped` masks the stored ordinary LD-score vector by set membership,
#'   matching the qgg grouped-set construction without scanning sparse LD.
#' @param residual Whether to add markers outside every supplied set as a
#'   `Residual` annotation.
#' @param what Requested convenient result view: heritability or genetic
#'   correlation. The complete fit is always retained.
#' @param blocks Optional character delete-block labels, either in statistic
#'   order or uniquely named by marker.
#' @param block_count Target number of deterministic contiguous delete blocks
#'   when `blocks` is omitted.
#' @param marginal_intercept Whether marginal LDSC intercepts are estimated or
#'   fixed to one.
#' @param overlap_intercept Optional finite cross-trait LDSC intercept.
#' @param maximum_chi_square Optional inclusive squared-Z filtering threshold.
#' @param corrected Whether annotation LD scores use finite-reference
#'   correction.
#' @return A `gcorr_ldsc_fit` containing the complete focused fit plus convenient
#'   `h2`, `rg`, and `requested` components.
#' @export
ldsc <- function(stat, Glist = NULL, ldscores = NULL, sets = NULL,
    residual = FALSE, what = c("h2", "rg"), blocks = NULL,
    block_count = 200L, marginal_intercept = c("free", "fixed_one"),
    overlap_intercept = NULL, maximum_chi_square = NULL,
    corrected = FALSE, set_model = c("stratified", "grouped")) {
  what <- match.arg(what)
  marginal_intercept <- match.arg(marginal_intercept)
  set_model <- match.arg(set_model)
  if (!is.logical(residual) || length(residual) != 1L || is.na(residual)) {
    .gcorr_stop("residual must be TRUE or FALSE.")
  }
  if (is.null(sets) && residual) {
    .gcorr_stop("residual = TRUE requires sets.")
  }
  if (is.null(sets) && set_model != "stratified") {
    .gcorr_stop("set_model applies only when sets are supplied.")
  }
  inputs <- .gcorr_prepare_statistics(stat)
  prepared <- inputs$first
  reference <- if (is.null(Glist)) NULL else
    .gcorr_ldsc_reference(Glist, prepared)

  if (is.null(ldscores)) {
    if (is.null(reference)) {
      .gcorr_stop("Supply either Glist or named ordinary ldscores.")
    }
    ldscores <- gbase::ld_scores(Glist, corrected = FALSE)
  }
  marker_count <- if (is.null(reference)) length(ldscores) else
    nrow(reference$metadata)
  ldscores <- .gcorr_ldsc_scores(ldscores, prepared$marker)
  blocks <- .gcorr_ldsc_blocks(blocks, prepared, block_count)

  if (is.null(sets)) {
    fit <- gcorr_ldsc(inputs, ldscores, blocks,
      overlap_intercept = overlap_intercept, marker_count = marker_count,
      marginal_intercept = marginal_intercept,
      maximum_chi_square = maximum_chi_square)
    return(.gcorr_ldsc_views(fit, what))
  }
  if (is.null(reference)) {
    .gcorr_stop("Glist is required when sets are supplied.")
  }
  annotation_markers <- if (set_model == "grouped") prepared$marker else
    reference$metadata$marker_id
  parsed <- .gcorr_ldsc_annotations(sets, annotation_markers, residual)
  if (set_model == "stratified") {
    annotation_scores <- gbase::ld_scores(Glist,
      annotation = parsed$annotation, corrected = corrected)
    annotation_scores <- annotation_scores[prepared$marker, , drop = FALSE]
  } else {
    if (corrected) {
      .gcorr_stop("corrected = TRUE is available only for stratified set scores.")
    }
    annotation_scores <- sweep(parsed$annotation, 1L,
      unname(ldscores), `*`)
  }
  annotation_sums <- stats::setNames(colSums(parsed$annotation),
    colnames(parsed$annotation))
  annotation_overlap <- crossprod(parsed$annotation)
  fit <- gcorr_ldsc_partitioned(inputs, annotation_scores, ldscores,
    annotation_sums, blocks,
    annotation_overlap = if (set_model == "stratified")
      annotation_overlap else NULL,
    reference_sample_size = Glist$sparseLD$n,
    reference_marker_count = length(annotation_markers), corrected = corrected,
    overlap_intercept = overlap_intercept,
    marginal_intercept = marginal_intercept,
    maximum_chi_square = maximum_chi_square)
  if (set_model == "grouped") {
    fit <- .gcorr_grouped_estimates(fit, annotation_sums)
    fit$set_overlap <- annotation_overlap
  }
  fit$sets <- parsed$sets
  fit$set_model <- set_model
  fit$method <- paste0(set_model, "_ldsc")
  fit$assumptions$set_model <- set_model
  fit$assumptions$set_score_construction <- if (set_model == "stratified")
    "annotation-specific squared-LD sums" else
    "ordinary LD scores masked by focal-marker set membership"
  if (set_model == "grouped") {
    class(fit) <- c("gcorr_ldsc_grouped_fit", class(fit))
  }
  .gcorr_ldsc_views(fit, what)
}
