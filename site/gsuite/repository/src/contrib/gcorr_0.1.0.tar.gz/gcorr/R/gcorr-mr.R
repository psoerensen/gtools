.gcorr_mr_summary <- function(x, label) {
  required <- c("rsids", "chr", "pos", "ea", "nea", "b", "seb", "n")
  if (!identical(class(x), "data.frame") || !nrow(x) ||
      length(setdiff(required, names(x))))
    .gcorr_stop(paste(label, "must be an ordinary effect/SE data frame."))
  list(trait = label, marker = x$rsids,
    chromosome = x$chr, position = x$pos,
    effect_allele = x$ea, other_allele = x$nea,
    effect = x$b, standard_error = x$seb,
    sample_size = x$n,
    p_value = if ("p" %in% names(x)) x$p else numeric())
}

.gcorr_mr_positive <- function(x, name, lower = .Machine$double.eps,
    whole = FALSE) {
  .gcorr_regional_number(x, name, lower = lower, whole = whole)
}

#' Prepare instruments for Mendelian randomisation
#'
#' Selects instruments from two already aligned effect/standard-error data
#' frames and a signed reference-LD matrix. Alignment and allele changes are
#' deliberately outside this function.
#'
#' @param statistics Uniquely named list containing exposure and outcome
#'   ordinary effect/standard-error data frames.
#' @param signed_ld Finite symmetric correlation matrix with row and column
#'   names exactly matching the candidate marker order and allele orientation.
#' @param exposure,outcome Trait names in `statistics`.
#' @param reference_sample_size Positive whole reference-panel sample count.
#' @param ancestry Character vector named by exposure and outcome.
#' @param reference_ancestry Ancestry label for the LD reference.
#' @param effect_units Character vector named by exposure and outcome.
#' @param non_overlapping_samples Must be explicitly `TRUE`.
#' @param preparation Instrument-selection convention, `"gsmr"` or `"gsmr2"`.
#' @param exposure_p_threshold,ld_r2_threshold,ld_fdr_threshold,
#'   minimum_standard_error,minimum_instruments,relative_rank_tolerance Native
#'   preparation controls. The LD threshold defaults to the selected convention.
#' @param provenance Nonempty description of the aligned candidates and LD.
#' @return A serializable `gcorr_mr_prepared` object.
#' @export
gcorr_prepare_mr <- function(statistics, signed_ld, exposure, outcome,
    reference_sample_size, ancestry, reference_ancestry, effect_units,
    non_overlapping_samples = NULL,
    preparation = c("gsmr", "gsmr2"), exposure_p_threshold = 5e-8,
    ld_r2_threshold = NULL, ld_fdr_threshold = .05,
    minimum_standard_error = 1e-6, minimum_instruments = 10L,
    relative_rank_tolerance = 1e-10,
    provenance = "User-supplied aligned candidates and signed LD") {
  preparation <- match.arg(preparation)
  if (!isTRUE(non_overlapping_samples)) {
    .gcorr_stop("non_overlapping_samples must be explicitly TRUE.")
  }
  statistics <- .gcorr_named_list(statistics, "statistics")
  for (name in c(exposure, outcome)) {
    if (!is.character(name) || length(name) != 1L || is.na(name) ||
        !nzchar(name) || !name %in% names(statistics)) {
      .gcorr_stop("exposure and outcome must identify supplied statistics.")
    }
  }
  if (identical(exposure, outcome)) .gcorr_stop("exposure and outcome must differ.")
  selected <- statistics[c(exposure, outcome)]
  summaries <- Map(.gcorr_mr_summary, selected, names(selected))
  identity <- c("marker", "chromosome", "position", "effect_allele", "other_allele")
  if (!all(vapply(identity, function(field) {
    identical(summaries[[1L]][[field]], summaries[[2L]][[field]])
  }, logical(1)))) {
    .gcorr_stop("Exposure and outcome must have identical marker order and allele orientation.")
  }
  markers <- summaries[[1L]]$marker
  if (!is.matrix(signed_ld) || !is.numeric(signed_ld) ||
      !identical(dim(signed_ld), rep(length(markers), 2L)) ||
      any(!is.finite(signed_ld)) || !identical(rownames(signed_ld), markers) ||
      !identical(colnames(signed_ld), markers)) {
    .gcorr_stop("signed_ld must be a finite square matrix labelled in candidate marker order.")
  }
  if (max(abs(signed_ld - t(signed_ld))) > 1e-10 ||
      any(abs(diag(signed_ld) - 1) > 1e-10) || any(abs(signed_ld) > 1 + 1e-10)) {
    .gcorr_stop("signed_ld must be a symmetric correlation matrix.")
  }
  traits <- c(exposure, outcome)
  if (!is.character(ancestry) || !identical(names(ancestry), traits) ||
      anyNA(ancestry) || any(!nzchar(ancestry))) {
    .gcorr_stop("ancestry must contain nonempty values named in exposure/outcome order.")
  }
  if (!is.character(reference_ancestry) || length(reference_ancestry) != 1L ||
      is.na(reference_ancestry) || !nzchar(reference_ancestry) ||
      any(ancestry != reference_ancestry)) {
    .gcorr_stop("Both traits must explicitly match reference_ancestry.")
  }
  if (!is.character(effect_units) || !identical(names(effect_units), traits) ||
      anyNA(effect_units) || any(!nzchar(effect_units))) {
    .gcorr_stop("effect_units must contain nonempty values named in exposure/outcome order.")
  }
  if (!is.character(provenance) || length(provenance) != 1L ||
      is.na(provenance) || !nzchar(provenance)) {
    .gcorr_stop("provenance must be one nonempty string.")
  }
  reference_sample_size <- .gcorr_mr_positive(reference_sample_size,
    "reference_sample_size", 2, whole = TRUE)
  if (is.null(ld_r2_threshold)) ld_r2_threshold <- if (preparation == "gsmr2") .05 else .1
  controls <- list(
    exposure_p_threshold = .gcorr_mr_positive(exposure_p_threshold,
      "exposure_p_threshold"),
    ld_r2_threshold = .gcorr_mr_positive(ld_r2_threshold, "ld_r2_threshold"),
    ld_fdr_threshold = .gcorr_mr_positive(ld_fdr_threshold, "ld_fdr_threshold"),
    minimum_standard_error = .gcorr_mr_positive(minimum_standard_error,
      "minimum_standard_error"),
    minimum_instruments = .gcorr_mr_positive(minimum_instruments,
      "minimum_instruments", 2, whole = TRUE),
    relative_rank_tolerance = .gcorr_mr_positive(relative_rank_tolerance,
      "relative_rank_tolerance"))
  if (controls$exposure_p_threshold > 1 || controls$ld_r2_threshold > 1 ||
      controls$ld_fdr_threshold > 1) {
    .gcorr_stop("Probability and LD thresholds must not exceed one.")
  }
  data <- data.frame(marker = markers,
    effect_allele = summaries[[1L]]$effect_allele,
    other_allele = summaries[[1L]]$other_allele,
    exposure_effect = summaries[[1L]]$effect,
    exposure_se = summaries[[1L]]$standard_error,
    outcome_effect = summaries[[2L]]$effect,
    outcome_se = summaries[[2L]]$standard_error,
    exposure_sample_size = summaries[[1L]]$sample_size,
    outcome_sample_size = summaries[[2L]]$sample_size,
    stringsAsFactors = FALSE)
  p_values <- summaries[[1L]]$p_value
  if (preparation == "gsmr2" && length(p_values)) {
    .gcorr_stop("GSMR2 preparation derives p-values from effects and SEs; omit exposure p_value.")
  }
  metadata <- list(exposure = exposure, outcome = outcome,
    effect_units = unname(effect_units), ancestry = unname(ancestry),
    reference_sample_size = reference_sample_size,
    reference_ancestry = reference_ancestry,
    non_overlapping_samples = TRUE, provenance = provenance)
  result <- cpp_gcorr_mr_prepare(data, signed_ld, metadata, p_values, controls)
  result$metadata <- metadata
  result$controls <- controls
  result$preparation <- preparation
  result$candidate_statistics <- selected
  result$schema_version <- 1L
  structure(result, class = "gcorr_mr_prepared")
}

.gcorr_validate_mr <- function(x) {
  if (!inherits(x, "gcorr_mr_prepared") || !identical(x$schema_version, 1L)) {
    .gcorr_stop("instruments must be returned by gcorr_prepare_mr().")
  }
  x
}

.gcorr_mr_fit <- function(instruments, method, apply_heidi = TRUE,
    minimum_instruments = instruments$controls$minimum_instruments,
    relative_rank_tolerance = instruments$controls$relative_rank_tolerance,
    minimum_abs_exposure_z = 1e-8, ratio_variance_ridge = 1e-6,
    heidi_threshold = .01, difference_variance_ridge = 1e-6,
    maximum_global_iterations = 1000L, maximum_abs_ld = 1e-8,
    bootstrap_replicates = 1000L, seed = NULL) {
  instruments <- .gcorr_validate_mr(instruments)
  gsmr <- method %in% c("gsmr", "gsmr2")
  controls <- list(
    apply_heidi = isTRUE(apply_heidi),
    minimum_instruments = .gcorr_mr_positive(minimum_instruments,
      "minimum_instruments", 2, whole = TRUE),
    relative_rank_tolerance = .gcorr_mr_positive(relative_rank_tolerance,
      "relative_rank_tolerance"),
    minimum_abs_exposure_z = .gcorr_mr_positive(minimum_abs_exposure_z,
      "minimum_abs_exposure_z"),
    ratio_variance_ridge = .gcorr_mr_positive(ratio_variance_ridge,
      "ratio_variance_ridge", 0),
    heidi_threshold = .gcorr_mr_positive(heidi_threshold, "heidi_threshold"),
    difference_variance_ridge = .gcorr_mr_positive(difference_variance_ridge,
      "difference_variance_ridge", 0),
    maximum_global_iterations = .gcorr_mr_positive(maximum_global_iterations,
      "maximum_global_iterations", 1, whole = TRUE),
    maximum_abs_ld = .gcorr_mr_positive(maximum_abs_ld, "maximum_abs_ld", 0),
    bootstrap_replicates = .gcorr_mr_positive(bootstrap_replicates,
      "bootstrap_replicates", 0, whole = TRUE), seed = seed)
  if (gsmr && (!is.logical(apply_heidi) || length(apply_heidi) != 1L ||
      is.na(apply_heidi))) {
    .gcorr_stop("apply_heidi must be TRUE or FALSE.")
  }
  if (method == "gsmr2" && !isTRUE(instruments$p_values_derived)) {
    .gcorr_stop("GSMR2 requires beta/SE-derived preparation p-values.")
  }
  if (method == "weighted_median") {
    if (!is.numeric(seed) || length(seed) != 1L || !is.finite(seed) ||
        seed < 0 || seed > 2^53 - 1 || seed != floor(seed)) {
      .gcorr_stop("Weighted median requires an explicit nonnegative whole-number seed.")
    }
    controls$seed <- as.numeric(seed)
  } else controls$seed <- 0
  details <- if (isTRUE(instruments$available)) {
    cpp_gcorr_mr_fit(instruments$data, instruments$ld, instruments$metadata,
      instruments$exposure_p_values, method, controls)
  } else list(available = FALSE,
    reason = paste("Preparation unavailable:", instruments$reason),
    retained_indices = integer(), effect = list(estimate = NA_real_,
      standard_error = NA_real_, z = NA_real_, p_value = NA_real_))
  estimate_row <- function(value, quantity) data.frame(method = method,
    exposure = instruments$metadata$exposure,
    outcome = instruments$metadata$outcome, quantity = quantity,
    estimate = value$estimate, standard_error = value$standard_error,
    z = value$z, p_value = value$p_value, stringsAsFactors = FALSE)
  estimates <- estimate_row(details$effect, "effect")
  if (method == "egger") estimates <- rbind(estimates,
    estimate_row(details$intercept, "intercept"))
  details$retained_original_indices <- instruments$original_indices[
    details$retained_indices]
  structure(list(method = method, estimates = estimates,
    available = details$available, reason = details$reason, details = details,
    instruments = instruments, controls = controls), class = "gcorr_mr_fit")
}

#' Fit original GSMR to prepared instruments
#' @param instruments A `gcorr_mr_prepared` object.
#' @param apply_heidi Whether to apply original HEIDI filtering.
#' @param minimum_instruments,relative_rank_tolerance,minimum_abs_exposure_z,
#' ratio_variance_ridge,heidi_threshold,difference_variance_ridge Native controls.
#' @return A `gcorr_mr_fit` object.
#' @export
gcorr_gsmr <- function(instruments, apply_heidi = TRUE,
    minimum_instruments = instruments$controls$minimum_instruments,
    relative_rank_tolerance = instruments$controls$relative_rank_tolerance,
    minimum_abs_exposure_z = 1e-8, ratio_variance_ridge = 1e-6,
    heidi_threshold = .01, difference_variance_ridge = 1e-6) {
  .gcorr_mr_fit(instruments, "gsmr", apply_heidi, minimum_instruments,
    relative_rank_tolerance, minimum_abs_exposure_z, ratio_variance_ridge,
    heidi_threshold, difference_variance_ridge)
}

#' Fit GSMR2 to prepared instruments
#' @inheritParams gcorr_gsmr
#' @param maximum_global_iterations Maximum global-HEIDI iterations.
#' @export
gcorr_gsmr2 <- function(instruments, apply_heidi = TRUE,
    minimum_instruments = instruments$controls$minimum_instruments,
    relative_rank_tolerance = instruments$controls$relative_rank_tolerance,
    minimum_abs_exposure_z = 1e-8, ratio_variance_ridge = 1e-6,
    heidi_threshold = .01, maximum_global_iterations = 1000L) {
  .gcorr_mr_fit(instruments, "gsmr2", apply_heidi, minimum_instruments,
    relative_rank_tolerance, minimum_abs_exposure_z, ratio_variance_ridge,
    heidi_threshold, maximum_global_iterations = maximum_global_iterations)
}

#' Fit inverse-variance weighted MR
#' @param instruments A `gcorr_mr_prepared` object.
#' @param maximum_abs_ld Maximum permitted absolute off-diagonal LD.
#' @param relative_rank_tolerance,minimum_abs_exposure_z Native controls.
#' @export
gcorr_mr_ivw <- function(instruments, maximum_abs_ld = 1e-8,
    relative_rank_tolerance = instruments$controls$relative_rank_tolerance,
    minimum_abs_exposure_z = 1e-8) {
  .gcorr_mr_fit(instruments, "ivw", maximum_abs_ld = maximum_abs_ld,
    relative_rank_tolerance = relative_rank_tolerance,
    minimum_abs_exposure_z = minimum_abs_exposure_z)
}

#' Fit MR-Egger
#' @inheritParams gcorr_mr_ivw
#' @export
gcorr_mr_egger <- function(instruments, maximum_abs_ld = 1e-8,
    relative_rank_tolerance = instruments$controls$relative_rank_tolerance,
    minimum_abs_exposure_z = 1e-8) {
  .gcorr_mr_fit(instruments, "egger", maximum_abs_ld = maximum_abs_ld,
    relative_rank_tolerance = relative_rank_tolerance,
    minimum_abs_exposure_z = minimum_abs_exposure_z)
}

#' Fit weighted-median MR
#' @inheritParams gcorr_mr_ivw
#' @param bootstrap_replicates Number of parametric bootstrap replicates.
#' @param seed Explicit reproducibility seed.
#' @export
gcorr_mr_weighted_median <- function(instruments, bootstrap_replicates = 1000L,
    seed = NULL, maximum_abs_ld = 1e-8,
    relative_rank_tolerance = instruments$controls$relative_rank_tolerance,
    minimum_abs_exposure_z = 1e-8) {
  .gcorr_mr_fit(instruments, "weighted_median", maximum_abs_ld = maximum_abs_ld,
    relative_rank_tolerance = relative_rank_tolerance,
    minimum_abs_exposure_z = minimum_abs_exposure_z,
    bootstrap_replicates = bootstrap_replicates, seed = seed)
}

#' @export
print.gcorr_mr_prepared <- function(x, ...) {
  cat("Prepared MR instruments\n")
  cat("  ", x$metadata$exposure, " -> ", x$metadata$outcome,
    "; available: ", x$available, "; retained: ", nrow(x$data), "\n", sep = "")
  invisible(x)
}

#' @export
print.gcorr_mr_fit <- function(x, ...) {
  cat("Mendelian randomisation: ", x$method, "\n", sep = "")
  print(x$estimates, row.names = FALSE)
  if (!x$available) cat("  Unavailable: ", x$reason, "\n", sep = "")
  invisible(x)
}

#' @export
summary.gcorr_mr_fit <- function(object, ...) object

#' @export
plot.gcorr_mr_fit <- function(x, ...) {
  data <- x$instruments$data
  if (!nrow(data)) .gcorr_stop("No prepared instruments to plot.")
  graphics::plot(data$exposure_effect, data$outcome_effect,
    xlab = x$instruments$metadata$exposure,
    ylab = x$instruments$metadata$outcome, pch = 1, ...)
  used <- x$details$retained_indices
  if (length(used)) graphics::points(data$exposure_effect[used],
    data$outcome_effect[used], pch = 19)
  slope <- x$estimates$estimate[x$estimates$quantity == "effect"]
  if (x$available && length(slope) == 1L && is.finite(slope) &&
      x$method != "egger") graphics::abline(a = 0, b = slope)
  invisible(x)
}
