.gcorr_overlap_matrix <- function(x, traits) {
  count <- length(traits)
  if (count == 1L) {
    if (!is.null(x)) .gcorr_stop("overlap_intercepts applies only to multiple traits.")
    return(NULL)
  }
  if (is.null(x)) {
    .gcorr_stop(paste("overlap_intercepts must explicitly supply every",
      "cross-trait Z-product intercept; use zero only when justified."))
  }
  if (is.numeric(x) && length(x) == 1L && is.finite(x)) {
    result <- matrix(as.numeric(x), count, count,
      dimnames = list(traits, traits))
    diag(result) <- NA_real_
    return(result)
  }
  if (!is.matrix(x) || !is.numeric(x) ||
      !identical(dim(x), rep(count, 2L)) ||
      !identical(rownames(x), traits) || !identical(colnames(x), traits)) {
    .gcorr_stop("overlap_intercepts must be a scalar or a trait-named square matrix.")
  }
  off_diagonal <- row(x) != col(x)
  if (any(!is.finite(x[off_diagonal])) ||
      !isTRUE(all.equal(x[lower.tri(x)], t(x)[lower.tri(x)], tolerance = 1e-12))) {
    .gcorr_stop("Off-diagonal overlap_intercepts must be finite and symmetric.")
  }
  x
}

#' Fit ordinary or annotation-aware GNOVA
#'
#' Fits GNOVA for one or more exactly aligned ordinary summary-statistics data
#' frames. Ordinary GNOVA uses one named LD-score vector. Annotation-aware
#' GNOVA instead uses caller-supplied binary annotations, matching annotation
#' LD scores, and ordinary weighting LD scores.
#'
#' @param statistics One ordinary qgg-style summary-statistics data frame, or a
#'   uniquely named list of two or more aligned data frames. GNOVA requires one
#'   constant sample size per trait.
#' @param blocks Uniquely named delete-block labels for every marker.
#' @param ld_scores Positive named ordinary LD scores. Required only for the
#'   ordinary route.
#' @param annotation_ld_scores Optional finite marker-by-annotation LD-score
#'   matrix with exact marker row names.
#' @param annotations Optional binary marker-by-annotation matrix with names and
#'   order identical to `annotation_ld_scores`.
#' @param weight_ld_scores Positive named ordinary LD scores used for annotated
#'   marginal regression weighting.
#' @param reference_sample_size Positive whole reference-panel sample size for
#'   imported annotation LD-score metadata.
#' @param corrected Whether supplied annotation LD scores are already
#'   finite-reference corrected.
#' @param overlap_intercepts For multiple traits, either one finite value shared
#'   by every pair or a symmetric trait-named matrix. These are cross-trait
#'   Z-product intercepts, not phenotypic correlations or overlap counts.
#' @return A `gcorr_gnova_fit` with category and component estimates,
#'   coordinated uncertainty, diagnostics, assumptions, and provenance.
#' @export
gcorr_gnova <- function(statistics, blocks, ld_scores = NULL,
    annotation_ld_scores = NULL, annotations = NULL,
    weight_ld_scores = NULL, reference_sample_size = NULL,
    corrected = FALSE, overlap_intercepts = NULL) {
  inputs <- .gcorr_prepare_statistics(statistics, scalar_sample_size = TRUE)
  statistics <- inputs$statistics
  prepared <- inputs$prepared
  first <- inputs$first
  blocks <- .gcorr_blocks(blocks, first$marker)
  overlap_intercepts <- .gcorr_overlap_matrix(overlap_intercepts,
    names(statistics))
  annotated <- !is.null(annotation_ld_scores) || !is.null(annotations) ||
    !is.null(weight_ld_scores)

  if (annotated) {
    if (is.null(annotation_ld_scores) || is.null(annotations) ||
        is.null(weight_ld_scores)) {
      .gcorr_stop(paste("Annotated GNOVA requires annotation_ld_scores,",
        "annotations, and weight_ld_scores together."))
    }
    if (!is.null(ld_scores)) {
      .gcorr_stop("ld_scores is only used by ordinary GNOVA.")
    }
    annotation_ld_scores <- .gcorr_marker_matrix(annotation_ld_scores,
      first$marker, "annotation_ld_scores")
    annotations <- .gcorr_marker_matrix(annotations, first$marker,
      "annotations", binary = TRUE)
    if (!identical(colnames(annotation_ld_scores), colnames(annotations))) {
      .gcorr_stop("Annotation LD-score and binary-annotation names must match exactly.")
    }
    if (any(colSums(annotations) == 0)) {
      .gcorr_stop("annotations cannot contain an empty category.")
    }
    weight_ld_scores <- .gcorr_named_marker_vector(weight_ld_scores,
      first$marker, "weight_ld_scores")
    reference_sample_size <- .gcorr_scalar_number(reference_sample_size,
      "reference_sample_size", 1, whole = TRUE)
  } else {
    if (is.null(ld_scores)) {
      .gcorr_stop("Ordinary GNOVA requires ld_scores.")
    }
    ld_scores <- .gcorr_named_marker_vector(ld_scores, first$marker,
      "ld_scores")
    if (!is.null(reference_sample_size) || !identical(corrected, FALSE)) {
      .gcorr_stop(paste("reference_sample_size and corrected apply only to",
        "annotation-aware GNOVA."))
    }
    reference_sample_size <- 0
  }
  if (!is.logical(corrected) || length(corrected) != 1L || is.na(corrected)) {
    .gcorr_stop("corrected must be one non-missing logical value.")
  }

  native <- cpp_gcorr_gnova(prepared, ld_scores, as.character(blocks),
    annotation_ld_scores, annotations, weight_ld_scores,
    reference_sample_size, corrected, overlap_intercepts)
  structure(c(native, list(
    method = "gnova",
    traits = names(statistics),
    annotations = if (annotated) colnames(annotations) else "all",
    assumptions = list(
      route = if (annotated) "binary_annotation" else "ordinary",
      overlap_intercepts = overlap_intercepts,
      corrected_ld_scores = if (annotated) corrected else NULL,
      reference_sample_size = if (annotated) reference_sample_size else NULL,
      allele_alignment = "caller supplied; exact equality checked",
      annotation_alignment = if (annotated) {
        "caller supplied binary annotations; exact names and order checked"
      } else NULL
    ),
    software = gcorr_native_info()
  )), class = "gcorr_gnova_fit")
}

#' @export
print.gcorr_gnova_fit <- function(x, ...) {
  cat(if (length(x$traits) == 1L) "Single-trait GNOVA\n" else "Multivariate GNOVA\n")
  cat("  Traits:      ", paste(x$traits, collapse = " / "), "\n", sep = "")
  cat("  Annotations: ", paste(x$annotations, collapse = ", "), "\n", sep = "")
  invisible(x)
}
