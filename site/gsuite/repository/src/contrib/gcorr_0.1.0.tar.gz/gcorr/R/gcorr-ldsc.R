#' Fit ordinary single-trait or multivariate LD-score regression
#'
#' Fits ordinary LDSC using one or more exactly aligned, allele-labelled
#' ordinary summary-statistics data frames. This function does not
#' harmonize alleles or prepare LD scores.
#'
#' @param statistics One ordinary qgg-style summary-statistics data frame, or a
#'   uniquely named list of two or more aligned data frames.
#' @param ld_scores Positive, uniquely named LD scores for every marker.
#' @param blocks Nonempty, uniquely named delete-block labels for every marker.
#' @param overlap_intercept Finite cross-trait LDSC intercept supplied by the
#'   caller; no overlap conversion is inferred.
#' @param marker_count Positive reference-universe marker count.
#' @param marginal_intercept Whether both marginal LDSC intercepts are fixed to
#'   one or estimated.
#' @param maximum_chi_square Optional inclusive squared-Z filtering threshold.
#' @return A `gcorr_ldsc_fit` with covariance, correlation, heritabilities,
#'   intercepts, native diagnostics, assumptions, and software provenance.
#' @export
gcorr_ldsc <- function(statistics, ld_scores, blocks, overlap_intercept = NULL,
    marker_count = length(ld_scores),
    marginal_intercept = c("fixed_one", "free"),
    maximum_chi_square = NULL) {
  marginal_intercept <- match.arg(marginal_intercept)
  inputs <- .gcorr_prepare_statistics(statistics)
  statistics <- inputs$statistics
  prepared <- inputs$prepared
  first <- inputs$first
  ld_scores <- .gcorr_named_marker_vector(ld_scores, first$marker, "ld_scores")
  blocks <- .gcorr_blocks(blocks, first$marker)
  if (length(prepared) == 1L && !is.null(overlap_intercept))
    .gcorr_stop("overlap_intercept applies only to multivariate LDSC.")
  if (!is.null(overlap_intercept)) overlap_intercept <- .gcorr_scalar_number(overlap_intercept, "overlap_intercept")
  marker_count <- .gcorr_scalar_number(marker_count, "marker_count", 1, TRUE)
  if (!is.null(maximum_chi_square)) {
    maximum_chi_square <- .gcorr_scalar_number(maximum_chi_square,
      "maximum_chi_square", 0)
  }

  native <- cpp_gcorr_ldsc(
    prepared, as.numeric(ld_scores), as.character(blocks),
    overlap_intercept, marker_count, marginal_intercept,
    maximum_chi_square
  )
  structure(c(native, list(
    method = "ordinary_ldsc",
    traits = names(statistics),
    assumptions = list(
      marginal_intercept = marginal_intercept,
      overlap_intercept = overlap_intercept,
      reference_marker_count = marker_count,
      allele_alignment = "caller supplied; exact equality checked"
    ),
    software = gcorr_native_info()
  )), class = "gcorr_ldsc_fit")
}

#' @export
print.gcorr_ldsc_fit <- function(x, ...) {
  cat(if (length(x$traits) == 1L) "Single-trait LD-score regression\n" else "Multivariate LD-score regression\n")
  cat("  Traits:  ", paste(x$traits, collapse = " / "), "\n", sep = "")
  rows <- x$estimates[x$estimates$quantity %in% c("h2", "rg", "cov"), , drop = FALSE]
  for (index in seq_len(nrow(rows))) {
    value <- if (is.na(rows$estimate[[index]])) "unavailable" else {
      format(rows$estimate[[index]], digits = 6)
    }
    cat("  ", rows$quantity[[index]], ": ", value, "\n", sep = "")
  }
  invisible(x)
}
