.gcorr_sumher_overlap_matrix <- function(x, traits) {
  count <- length(traits)
  if (count == 1L) {
    if (!is.null(x)) .gcorr_stop("overlap_intercepts applies only to multiple traits.")
    return(NULL)
  }
  if (is.null(x)) {
    return(matrix(NA_real_, count, count, dimnames = list(traits, traits)))
  }
  if (is.numeric(x) && length(x) == 1L && is.finite(x)) {
    result <- matrix(as.numeric(x), count, count, dimnames = list(traits, traits))
    diag(result) <- NA_real_
    return(result)
  }
  if (!is.matrix(x) || !is.numeric(x) ||
      !identical(dim(x), rep(count, 2L)) ||
      !identical(rownames(x), traits) || !identical(colnames(x), traits)) {
    .gcorr_stop("overlap_intercepts must be NULL, a scalar, or a trait-named square matrix.")
  }
  off_diagonal <- row(x) != col(x)
  if (any(!is.na(x[off_diagonal]) & !is.finite(x[off_diagonal]))) {
    .gcorr_stop("Off-diagonal overlap_intercepts must be finite or NA.")
  }
  lower <- x[lower.tri(x)]
  upper <- t(x)[lower.tri(x)]
  if (!identical(is.na(lower), is.na(upper)) ||
      any(abs(lower[!is.na(lower)] - upper[!is.na(upper)]) > 1e-12)) {
    .gcorr_stop("overlap_intercepts must be symmetric, including its NA pattern.")
  }
  x
}

#' Fit SumHer architecture models
#'
#' Fits single-trait or coordinated multivariate SumHer models from explicit
#' uncorrected architecture LD scores, component weight sums, and tagging
#' values. Optional full-reference architecture weights and binary categories
#' activate native category, enrichment, contrast, and category-covariance
#' summaries without a hidden refit.
#'
#' @param statistics One ordinary qgg-style summary-statistics data frame, or a
#'   uniquely named aligned list of data frames. Scalar and per-marker sample sizes are
#'   supported.
#' @param architecture_ld_scores Finite nonnegative marker-by-component matrix
#'   of uncorrected model-weighted LD scores.
#' @param weight_sums Positive named causal-marker architecture-weight sums in
#'   exactly the component order.
#' @param tagging Positive named LD-redundancy values for every regression
#'   marker; these are distinct from architecture LD scores.
#' @param blocks Uniquely named delete-block labels for every marker.
#' @param reference_sample_size Positive whole reference-panel sample size
#'   recorded with the imported LD-score matrix.
#' @param inflation Explicit marginal inflation model.
#' @param overlap_intercepts For multiple traits, `NULL` estimates every pair
#'   intercept; a finite scalar fixes all pairs; a symmetric trait-named matrix
#'   uses finite fixed values and `NA` for estimated pairs.
#' @param maximum_iterations Maximum marginal IRWLS iterations.
#' @param tolerance Positive marginal IRWLS relative tolerance.
#' @param cross_maximum_iterations Maximum cross-trait IRWLS iterations.
#' @param cross_tolerance Positive cross-trait IRWLS relative tolerance.
#' @param architecture_weights Optional nonnegative marker-by-component causal
#'   architecture weights whose column sums equal `weight_sums`.
#' @param categories Optional binary marker-by-category matrix. Must be supplied
#'   together with `architecture_weights`.
#' @param expected_proportions Optional nonnegative category-named proportions
#'   for enrichment contrasts. The default uses marker-count proportions.
#' @return A `gcorr_sumher_fit` with component and total estimates, optional
#'   category/enrichment summaries, joint uncertainty, assumptions, and
#'   software provenance.
#' @export
gcorr_sumher <- function(statistics, architecture_ld_scores, weight_sums,
    tagging, blocks, reference_sample_size,
    inflation = c("none", "multiplicative", "additive_sample_size"),
    overlap_intercepts = NULL, maximum_iterations = 200L,
    tolerance = 1e-10, cross_maximum_iterations = 200L,
    cross_tolerance = 1e-10, architecture_weights = NULL,
    categories = NULL, expected_proportions = NULL) {
  inflation <- match.arg(inflation)
  inputs <- .gcorr_prepare_statistics(statistics)
  statistics <- inputs$statistics
  prepared <- inputs$prepared
  first <- inputs$first
  architecture_ld_scores <- .gcorr_marker_matrix(architecture_ld_scores,
    first$marker, "architecture_ld_scores")
  if (any(architecture_ld_scores < 0)) {
    .gcorr_stop("architecture_ld_scores must be uncorrected and nonnegative.")
  }
  components <- colnames(architecture_ld_scores)
  if (!is.numeric(weight_sums) || length(weight_sums) != length(components) ||
      is.null(names(weight_sums)) || anyNA(names(weight_sums)) ||
      any(!nzchar(names(weight_sums))) || anyDuplicated(names(weight_sums)) ||
      !setequal(names(weight_sums), components) || any(!is.finite(weight_sums)) ||
      any(weight_sums <= 0)) {
    .gcorr_stop("weight_sums must be positive uniquely named values matching components.")
  }
  weight_sums <- unname(weight_sums[components])
  tagging <- .gcorr_named_marker_vector(tagging, first$marker, "tagging")
  blocks <- .gcorr_blocks(blocks, first$marker)
  reference_sample_size <- .gcorr_scalar_number(reference_sample_size,
    "reference_sample_size", 1, whole = TRUE)
  maximum_iterations <- .gcorr_scalar_number(maximum_iterations,
    "maximum_iterations", 1, whole = TRUE)
  cross_maximum_iterations <- .gcorr_scalar_number(cross_maximum_iterations,
    "cross_maximum_iterations", 1, whole = TRUE)
  tolerance <- .gcorr_scalar_number(tolerance, "tolerance", 0)
  cross_tolerance <- .gcorr_scalar_number(cross_tolerance,
    "cross_tolerance", 0)
  if (tolerance == 0 || cross_tolerance == 0) {
    .gcorr_stop("tolerance and cross_tolerance must be positive.")
  }
  overlap_intercepts <- .gcorr_sumher_overlap_matrix(overlap_intercepts,
    names(statistics))

  category_mode <- !is.null(architecture_weights) || !is.null(categories) ||
    !is.null(expected_proportions)
  if (category_mode) {
    if (is.null(architecture_weights) || is.null(categories)) {
      .gcorr_stop("architecture_weights and categories must be supplied together.")
    }
    architecture_weights <- .gcorr_marker_matrix(architecture_weights,
      first$marker, "architecture_weights")
    if (!identical(colnames(architecture_weights), components) ||
        any(architecture_weights < 0)) {
      .gcorr_stop(paste("architecture_weights must be nonnegative and have",
        "the exact fitted component names and order."))
    }
    if (!isTRUE(all.equal(unname(colSums(architecture_weights)), weight_sums,
      tolerance = 1e-10))) {
      .gcorr_stop("architecture_weights column sums must equal weight_sums.")
    }
    categories <- .gcorr_marker_matrix(categories, first$marker,
      "categories", binary = TRUE)
    if (!is.null(expected_proportions)) {
      category_names <- colnames(categories)
      if (!is.numeric(expected_proportions) ||
          length(expected_proportions) != length(category_names) ||
          is.null(names(expected_proportions)) ||
          anyNA(names(expected_proportions)) ||
          any(!nzchar(names(expected_proportions))) ||
          anyDuplicated(names(expected_proportions)) ||
          !setequal(names(expected_proportions), category_names) ||
          any(!is.finite(expected_proportions)) ||
          any(expected_proportions < 0) || any(expected_proportions > 1)) {
        .gcorr_stop(paste("expected_proportions must be finite values in [0,1]",
          "uniquely named for every category."))
      }
      expected_proportions <- unname(expected_proportions[category_names])
    }
  }

  native <- cpp_gcorr_sumher(prepared, architecture_ld_scores, weight_sums,
    as.numeric(tagging), as.character(blocks), reference_sample_size,
    inflation, maximum_iterations, tolerance, cross_maximum_iterations,
    cross_tolerance, overlap_intercepts, architecture_weights, categories,
    expected_proportions)
  structure(c(native, list(
    method = "sumher",
    traits = names(statistics),
    components = components,
    assumptions = list(
      architecture_ld_scores = "caller supplied; uncorrected",
      overlap_intercepts = overlap_intercepts,
      inflation = inflation,
      reference_sample_size = reference_sample_size,
      allele_alignment = "caller supplied; exact equality checked",
      category_null = if (category_mode && is.null(expected_proportions)) {
        "marker-count proportion"
      } else if (category_mode) "caller supplied expected proportions" else NULL
    ),
    software = gcorr_native_info()
  )), class = "gcorr_sumher_fit")
}

#' @export
print.gcorr_sumher_fit <- function(x, ...) {
  cat(if (length(x$traits) == 1L) "Single-trait SumHer\n" else "Multivariate SumHer\n")
  cat("  Traits:     ", paste(x$traits, collapse = " / "), "\n", sep = "")
  cat("  Components: ", paste(x$components, collapse = ", "), "\n", sep = "")
  invisible(x)
}
