.gcorr_group_moment_indices <- function(parameters, traits, groups,
    heritability_quantity, covariance_quantity) {
  indices <- integer()
  for (group in groups) {
    for (column in seq_along(traits)) {
      for (row in column:length(traits)) {
        hit <- !is.na(parameters$component) &
          parameters$component == group
        if (row == column) {
          hit <- hit & parameters$quantity == heritability_quantity &
            parameters$trait1 == traits[row]
        } else {
          hit <- hit & parameters$quantity == covariance_quantity &
            ((parameters$trait1 == traits[row] &
                parameters$trait2 == traits[column]) |
             (parameters$trait1 == traits[column] &
                parameters$trait2 == traits[row]))
        }
        found <- which(hit)
        if (length(found) != 1L) {
          .gcorr_stop("Grouped joint uncertainty labels are missing or ambiguous.")
        }
        indices <- c(indices, found)
      }
    }
  }
  indices
}

#' Prepare grouped covariance summaries from GNOVA or SumHer
#'
#' Extracts category or architecture-component covariance matrices together
#' with their complete cross-group jackknife sampling covariance. Marginal
#' standard errors are never substituted for joint uncertainty.
#'
#' @param fit A multivariate standalone `gcorr_gnova_fit` or
#'   `gcorr_sumher_fit`.
#' @param groups Optional distinct group names in the requested order.
#' @param kind For SumHer, either architecture `"components"` or transformed
#'   `"categories"`. GNOVA supports categories only.
#' @param continuous Must be explicitly `TRUE`.
#' @param units Character vector named exactly by source trait, documenting
#'   compatible continuous response units.
#' @return A validated `gcorr_grouped_covariance` object.
#' @export
gcorr_grouped_covariance <- function(fit, groups = NULL,
    kind = c("components", "categories"), continuous = NULL, units) {
  if (!isTRUE(continuous)) {
    .gcorr_stop("continuous must be explicitly TRUE for grouped covariance models.")
  }
  if (!inherits(fit, "gcorr_gnova_fit") &&
      !inherits(fit, "gcorr_sumher_fit")) {
    .gcorr_stop("fit must be a standalone multivariate GNOVA or SumHer result.")
  }
  traits <- fit$traits
  if (length(traits) < 2L || anyDuplicated(traits) ||
      any(grepl("::", traits, fixed = TRUE))) {
    .gcorr_stop("Grouped covariance requires at least two valid source traits.")
  }
  if (!is.character(units) || !identical(names(units), traits) ||
      anyNA(units) || any(!nzchar(units))) {
    .gcorr_stop("units must name every continuous source trait in order.")
  }

  if (inherits(fit, "gcorr_gnova_fit")) {
    if (!missing(kind) && !identical(match.arg(kind), "categories")) {
      .gcorr_stop("GNOVA grouped covariance supports categories only.")
    }
    kind <- "categories"
    available <- fit$matrices$categories
    matrices <- lapply(available, `[[`, "genetic_covariance")
    native_kind <- "gnova_categories"
    heritability_quantity <- "category_heritability"
    covariance_quantity <- "category_covariance"
  } else {
    kind <- match.arg(kind)
    if (kind == "components") {
      available <- fit$matrices$components
      matrices <- lapply(available, `[[`, "genetic_covariance")
      native_kind <- "sumher_components"
      heritability_quantity <- "component_heritability"
      covariance_quantity <- "component_covariance"
    } else {
      matrices <- fit$matrices$category_genetic_covariance
      available <- matrices
      native_kind <- "sumher_categories"
    }
  }
  if (is.null(available) || !length(available)) {
    .gcorr_stop("The source fit has no grouped covariance matrices of the requested kind.")
  }
  if (is.null(groups)) groups <- names(available)
  if (!is.character(groups) || !length(groups) || anyNA(groups) ||
      any(!nzchar(groups)) || anyDuplicated(groups) ||
      any(!groups %in% names(available)) ||
      any(grepl("::", groups, fixed = TRUE))) {
    .gcorr_stop("groups must select distinct available names without '::'.")
  }
  matrices <- matrices[groups]
  moments <- length(traits) * (length(traits) + 1L) / 2L

  if (inherits(fit, "gcorr_sumher_fit") && kind == "categories") {
    joint <- fit$diagnostics$category_joint_sampling_covariance
    total_groups <- length(available)
    expected <- total_groups * moments
    if (!is.numeric(joint) || length(joint) != expected^2L ||
        any(!is.finite(joint))) {
      .gcorr_stop("SumHer category joint sampling covariance is unavailable.")
    }
    joint <- matrix(joint, expected, expected, byrow = TRUE)
    selected <- unlist(lapply(match(groups, names(available)), function(index) {
      seq_len(moments) + (index - 1L) * moments
    }), use.names = FALSE)
    joint <- joint[selected, selected, drop = FALSE]
  } else {
    jackknife <- fit$diagnostics$joint_jackknife
    if (!is.list(jackknife) || !is.data.frame(jackknife$parameters) ||
        !is.matrix(jackknife$sampling_covariance)) {
      .gcorr_stop("The source fit lacks complete joint block-jackknife uncertainty.")
    }
    selected <- .gcorr_group_moment_indices(jackknife$parameters, traits,
      groups, heritability_quantity, covariance_quantity)
    joint <- jackknife$sampling_covariance[selected, selected, drop = FALSE]
  }

  moment_labels <- unlist(lapply(seq_along(traits), function(column) {
    paste(traits[column:length(traits)], traits[column], sep = "|")
  }), use.names = FALSE)
  labels <- unlist(lapply(groups, function(group) {
    paste(group, moment_labels, sep = "::")
  }), use.names = FALSE)
  dimnames(joint) <- list(labels, labels)
  joint <- .gcorr_covariance_matrix(joint, labels,
    "joint grouped sampling covariance")
  prepared_groups <- lapply(seq_along(groups), function(index) {
    range <- seq_len(moments) + (index - 1L) * moments
    block <- joint[range, range, drop = FALSE]
    dimnames(block) <- list(moment_labels, moment_labels)
    gcorr_covariance(matrices[[index]], block,
      continuous = TRUE, units = units,
      provenance = paste(fit$method, kind, groups[index]))
  })
  names(prepared_groups) <- groups
  structure(list(kind = native_kind, group_names = groups,
    groups = prepared_groups, joint_sampling_covariance = joint,
    traits = traits, units = units,
    source = list(method = fit$method, kind = kind,
      selected_indices = selected)), class = "gcorr_grouped_covariance")
}

.gcorr_validate_grouped_covariance <- function(x) {
  if (!inherits(x, "gcorr_grouped_covariance") || !is.list(x) ||
      !x$kind %in% c("gnova_categories", "sumher_components",
        "sumher_categories") || !is.character(x$group_names) ||
      !length(x$group_names) || !identical(names(x$groups), x$group_names)) {
    .gcorr_stop("covariance must be prepared by gcorr_grouped_covariance().")
  }
  groups <- lapply(x$groups, .gcorr_validate_covariance,
    require_sampling = TRUE)
  moments <- length(x$traits) * (length(x$traits) + 1L) / 2L
  labels <- unlist(lapply(x$group_names, function(group) {
    paste(group, groups[[1L]]$moment_labels, sep = "::")
  }), use.names = FALSE)
  joint <- .gcorr_covariance_matrix(x$joint_sampling_covariance, labels,
    "joint grouped sampling covariance")
  x$groups <- groups
  x$joint_sampling_covariance <- joint
  x
}

.gcorr_grouped_result <- function(native, input, method, specification,
    controls) {
  native$estimates <- native$parameters$estimates
  native$parameter_sampling_covariance <-
    native$parameters$sampling_covariance
  native$inference_available <- native$parameters$inference_available
  native$inference_reason <- native$parameters$inference_reason
  native$diagnostics <- data.frame(group = native$groups,
    available = vapply(native$fits, `[[`, logical(1), "available"),
    reason = vapply(native$fits, `[[`, character(1), "reason"),
    converged = vapply(native$fits, `[[`, logical(1), "converged"),
    identified = vapply(native$fits, `[[`, logical(1), "identified"),
    boundary = vapply(native$fits, `[[`, logical(1), "boundary"),
    inference_available = vapply(native$fits, `[[`, logical(1),
      "inference_available"), stringsAsFactors = FALSE)
  native$input <- input
  native$method <- method
  native$specification <- specification
  native$controls <- controls
  structure(native, class = c(paste0("gcorr_grouped_", method, "_fit"),
    "gcorr_grouped_covariance_fit"))
}

#' Fit one structural model across covariance groups
#' @inheritParams gcorr_sem
#' @param covariance A `gcorr_grouped_covariance` object.
#' @return A `gcorr_grouped_sem_fit` retaining cross-group uncertainty.
#' @export
gcorr_grouped_sem <- function(covariance, model,
    maximum_iterations = 1000L, gradient_tolerance = 1e-8,
    relative_rank_tolerance = 1e-8, boundary_tolerance = 1e-6) {
  input <- .gcorr_validate_grouped_covariance(covariance)
  model <- .gcorr_sem_model(model)
  if (any(!input$traits %in% model$variables)) {
    .gcorr_stop("Every grouped covariance trait must occur in model variables.")
  }
  controls <- .gcorr_covariance_controls(maximum_iterations,
    gradient_tolerance, relative_rank_tolerance, boundary_tolerance)
  .gcorr_grouped_result(cpp_gcorr_grouped_fit(input, "sem", model,
    controls), input, "sem", model, controls)
}

#' Fit one fixed graph across covariance groups
#' @inheritParams gcorr_ggm
#' @param covariance A `gcorr_grouped_covariance` object.
#' @return A `gcorr_grouped_ggm_fit` retaining cross-group uncertainty.
#' @export
gcorr_grouped_ggm <- function(covariance, edges,
    maximum_iterations = 1000L, gradient_tolerance = 1e-8,
    relative_rank_tolerance = 1e-8, boundary_tolerance = 1e-6) {
  input <- .gcorr_validate_grouped_covariance(covariance)
  edges <- .gcorr_edges(edges, input$traits)
  controls <- .gcorr_covariance_controls(maximum_iterations,
    gradient_tolerance, relative_rank_tolerance, boundary_tolerance)
  .gcorr_grouped_result(cpp_gcorr_grouped_fit(input, "ggm",
    list(edges = edges), controls), input, "ggm", edges, controls)
}

.gcorr_grouped_test <- function(fit, constraints, target, values,
    quantity) {
  labels <- values$estimates$label
  if (!is.matrix(constraints) || !is.numeric(constraints) ||
      !nrow(constraints) || any(!is.finite(constraints)) ||
      !identical(colnames(constraints), labels)) {
    .gcorr_stop("constraints must be finite with columns exactly matching grouped fitted labels.")
  }
  if (is.null(rownames(constraints))) {
    rownames(constraints) <- paste0("constraint_", seq_len(nrow(constraints)))
  }
  if (anyNA(rownames(constraints)) || any(!nzchar(rownames(constraints))) ||
      anyDuplicated(rownames(constraints))) {
    .gcorr_stop("constraint row names must be unique and nonempty.")
  }
  if (is.null(target)) target <- rep(0, nrow(constraints))
  if (!is.numeric(target) || length(target) != nrow(constraints) ||
      any(!is.finite(target))) {
    .gcorr_stop("target must contain one finite value per constraint.")
  }
  result <- cpp_gcorr_grouped_test(fit, constraints, target,
    identical(quantity, "partial_correlation"))
  result$quantity <- quantity
  result$hypotheses <- rownames(constraints)
  result$constraints <- constraints
  result$target <- target
  structure(result, class = "gcorr_grouped_covariance_test")
}

#' Test named cross-group SEM parameter contrasts
#' @param fit A `gcorr_grouped_sem_fit`.
#' @inheritParams gcorr_sem_test
#' @return A grouped covariance test result.
#' @export
gcorr_grouped_sem_test <- function(fit, constraints, target = NULL) {
  if (!inherits(fit, "gcorr_grouped_sem_fit")) {
    .gcorr_stop("fit must be returned by gcorr_grouped_sem().")
  }
  .gcorr_grouped_test(fit, constraints, target, fit$parameters,
    "parameter")
}

#' Test named cross-group GGM contrasts
#' @param fit A `gcorr_grouped_ggm_fit`.
#' @inheritParams gcorr_sem_test
#' @param quantity Either fitted precision parameters or free-edge partial
#'   correlations.
#' @return A grouped covariance test result.
#' @export
gcorr_grouped_ggm_test <- function(fit, constraints, target = NULL,
    quantity = c("partial_correlation", "precision")) {
  if (!inherits(fit, "gcorr_grouped_ggm_fit")) {
    .gcorr_stop("fit must be returned by gcorr_grouped_ggm().")
  }
  quantity <- match.arg(quantity)
  values <- if (quantity == "partial_correlation") {
    fit$partial_correlations
  } else fit$parameters
  .gcorr_grouped_test(fit, constraints, target, values, quantity)
}

#' @export
print.gcorr_grouped_covariance <- function(x, ...) {
  cat("Grouped genetic covariance summaries\n")
  cat("  Kind:   ", x$kind, "\n", sep = "")
  cat("  Groups: ", paste(x$group_names, collapse = ", "), "\n", sep = "")
  invisible(x)
}

#' @export
print.gcorr_grouped_covariance_fit <- function(x, ...) {
  cat("Grouped genetic covariance model: ", x$method, "\n", sep = "")
  cat("  Groups: ", paste(x$groups, collapse = ", "), "\n", sep = "")
  cat("  Joint inference: ", x$inference_available, "\n", sep = "")
  invisible(x)
}

#' @export
print.gcorr_grouped_covariance_test <- function(x, ...) {
  cat("Grouped covariance contrast test\n")
  cat("  Available: ", x$available, "; df: ", x$degrees_of_freedom,
    "; p: ", format(x$p_value), "\n", sep = "")
  invisible(x)
}
