#include <Rcpp.h>
#include <gcorr/gsmr.hpp>
#include <gcorr/mr_sensitivity.hpp>
#include <numeric>

namespace {
using namespace Rcpp;

double optional_value(const std::optional<double>& value) {
  return value ? *value : NA_REAL;
}

IntegerVector one_based(const std::vector<std::size_t>& values) {
  IntegerVector result(values.size());
  for (std::size_t i = 0; i < values.size(); ++i)
    result[i] = static_cast<int>(values[i] + 1);
  return result;
}

List estimate(const gcorr::EstimateSummary& value) {
  return List::create(_["estimate"] = optional_value(value.estimate),
    _["standard_error"] = optional_value(value.standard_error),
    _["z"] = optional_value(value.z_score),
    _["p_value"] = optional_value(value.p_value),
    _["undefined_reason"] = value.undefined_reason,
    _["uncertainty_reason"] = value.uncertainty_undefined_reason);
}

gcorr::MrInstrumentData instrument_data(DataFrame statistics, NumericMatrix ld,
    List metadata) {
  gcorr::MrInstrumentData result;
  CharacterVector units = metadata["effect_units"];
  CharacterVector ancestry = metadata["ancestry"];
  if (units.size() != 2 || ancestry.size() != 2)
    stop("MR trait metadata dimensions differ.");
  result.exposure = {as<std::string>(metadata["exposure"]),
    as<std::string>(units[0]), as<std::string>(ancestry[0]), {}};
  result.outcome = {as<std::string>(metadata["outcome"]),
    as<std::string>(units[1]), as<std::string>(ancestry[1]), {}};
  const double reference_n = as<double>(metadata["reference_sample_size"]);
  if (!std::isfinite(reference_n) || reference_n < 2 ||
      reference_n != std::floor(reference_n) || reference_n > 9007199254740991.0)
    stop("Invalid MR reference sample count.");
  result.reference_sample_size = static_cast<std::size_t>(reference_n);
  result.reference_ancestry = as<std::string>(metadata["reference_ancestry"]);
  result.sample_overlap = as<bool>(metadata["non_overlapping_samples"])
    ? gcorr::MrSampleOverlap::non_overlapping
    : gcorr::MrSampleOverlap::unspecified;
  result.provenance = as<std::string>(metadata["provenance"]);

  CharacterVector ids = statistics["marker"];
  CharacterVector effect_allele = statistics["effect_allele"];
  CharacterVector other_allele = statistics["other_allele"];
  NumericVector bx = statistics["exposure_effect"];
  NumericVector sx = statistics["exposure_se"];
  NumericVector by = statistics["outcome_effect"];
  NumericVector sy = statistics["outcome_se"];
  NumericVector nx = statistics["exposure_sample_size"];
  NumericVector ny = statistics["outcome_sample_size"];
  if (ld.nrow() != statistics.nrows() || ld.ncol() != statistics.nrows() ||
      !ld.hasAttribute("dimnames")) stop("MR LD dimensions or names differ.");
  List names = ld.attr("dimnames");
  if (names.size() != 2 || Rf_isNull(names[0]) || Rf_isNull(names[1]))
    stop("MR LD requires row and column names.");
  result.signed_ld.names = as<std::vector<std::string>>(names[0]);
  if (result.signed_ld.names != as<std::vector<std::string>>(names[1]))
    stop("MR LD row and column names differ.");
  for (int i = 0; i < statistics.nrows(); ++i) {
    result.instruments.push_back({{as<std::string>(ids[i]),
      as<std::string>(effect_allele[i]), as<std::string>(other_allele[i])},
      bx[i], sx[i], by[i], sy[i], nx[i], ny[i]});
    for (int j = 0; j < ld.ncol(); ++j) result.signed_ld.values.push_back(ld(i, j));
  }
  return result;
}

DataFrame instrument_frame(const gcorr::MrInstrumentData& input) {
  CharacterVector ids, effect_allele, other_allele;
  NumericVector bx, sx, by, sy, nx, ny;
  for (const auto& row : input.instruments) {
    ids.push_back(row.marker.marker_id);
    effect_allele.push_back(row.marker.effect_allele);
    other_allele.push_back(row.marker.other_allele);
    bx.push_back(row.exposure_effect); sx.push_back(row.exposure_se);
    by.push_back(row.outcome_effect); sy.push_back(row.outcome_se);
    nx.push_back(optional_value(row.exposure_sample_size));
    ny.push_back(optional_value(row.outcome_sample_size));
  }
  return DataFrame::create(_["marker"] = ids,
    _["effect_allele"] = effect_allele, _["other_allele"] = other_allele,
    _["exposure_effect"] = bx, _["exposure_se"] = sx,
    _["outcome_effect"] = by, _["outcome_se"] = sy,
    _["exposure_sample_size"] = nx, _["outcome_sample_size"] = ny);
}

NumericMatrix named_matrix(const gcorr::NamedSymmetricMatrix& input) {
  const auto n = input.names.size();
  NumericMatrix result(n, n);
  if (input.values.size() != n * n) stop("Invalid native MR matrix dimensions.");
  for (std::size_t i = 0; i < n; ++i)
    for (std::size_t j = 0; j < n; ++j) result(i, j) = input.values[i * n + j];
  result.attr("dimnames") = List::create(input.names, input.names);
  return result;
}

const char* exclusion_name(gcorr::MrExclusion value) {
  switch (value) {
    case gcorr::MrExclusion::retained: return "retained";
    case gcorr::MrExclusion::missing_estimate: return "missing_estimate";
    case gcorr::MrExclusion::small_standard_error: return "small_standard_error";
    case gcorr::MrExclusion::exposure_association: return "exposure_association";
    case gcorr::MrExclusion::high_ld: return "high_ld";
  }
  stop("Unknown MR selection decision.");
  return "";
}
}

// [[Rcpp::export]]
Rcpp::List cpp_gcorr_mr_prepare(Rcpp::DataFrame data, Rcpp::NumericMatrix ld,
    Rcpp::List metadata, Rcpp::NumericVector p_values, Rcpp::List controls) {
  using namespace Rcpp;
  const auto input = instrument_data(data, ld, metadata);
  gcorr::MrPreparationOptions options;
  options.exposure_p_threshold = as<double>(controls["exposure_p_threshold"]);
  options.ld_r2_threshold = as<double>(controls["ld_r2_threshold"]);
  options.ld_fdr_threshold = as<double>(controls["ld_fdr_threshold"]);
  options.minimum_standard_error = as<double>(controls["minimum_standard_error"]);
  options.minimum_instruments = as<int>(controls["minimum_instruments"]);
  options.relative_rank_tolerance = as<double>(controls["relative_rank_tolerance"]);
  const auto prepared = gcorr::prepare_mr_instruments(input,
    as<std::vector<double>>(p_values), options);
  IntegerVector index, first, second;
  CharacterVector ids, decision;
  NumericVector p, correlation, ld_p, q;
  LogicalVector zeroed;
  for (const auto& value : prepared.decisions) {
    index.push_back(value.original_index + 1);
    ids.push_back(value.marker_id);
    decision.push_back(exclusion_name(value.outcome));
    p.push_back(optional_value(value.exposure_p_value));
  }
  for (const auto& value : prepared.ld_decisions) {
    first.push_back(value.first_index + 1); second.push_back(value.second_index + 1);
    correlation.push_back(value.original_correlation);
    ld_p.push_back(value.p_value); q.push_back(value.q_value);
    zeroed.push_back(value.zeroed);
  }
  return List::create(_["available"] = prepared.available,
    _["reason"] = prepared.unavailable_reason,
    _["data"] = instrument_frame(prepared.prepared),
    _["ld"] = named_matrix(prepared.prepared.signed_ld),
    _["original_indices"] = one_based(prepared.original_indices),
    _["exposure_p_values"] = prepared.exposure_p_values,
    _["p_values_derived"] = prepared.p_values_derived,
    _["ld_relative_eigenvalue"] = optional_value(
      prepared.prepared_check.ld_relative_eigenvalue),
    _["decisions"] = DataFrame::create(_["original_index"] = index,
      _["marker"] = ids, _["decision"] = decision,
      _["exposure_p_value"] = p),
    _["ld_decisions"] = DataFrame::create(_["first_index"] = first,
      _["second_index"] = second, _["correlation"] = correlation,
      _["p_value"] = ld_p, _["q_value"] = q, _["zeroed"] = zeroed));
}

// [[Rcpp::export]]
Rcpp::List cpp_gcorr_mr_fit(Rcpp::DataFrame data, Rcpp::NumericMatrix ld,
    Rcpp::List metadata, Rcpp::NumericVector p_values, std::string method,
    Rcpp::List controls) {
  using namespace Rcpp;
  auto input = instrument_data(data, ld, metadata);
  std::vector<std::size_t> kept(input.instruments.size());
  std::iota(kept.begin(), kept.end(), 0);
  List output = List::create(_["available"] = false, _["reason"] = "",
    _["effect"] = estimate({}), _["retained_indices"] = one_based(kept));
  if (method == "gsmr" || method == "gsmr2") {
    gcorr::GsmrOptions options;
    options.minimum_instruments = as<int>(controls["minimum_instruments"]);
    options.relative_rank_tolerance = as<double>(controls["relative_rank_tolerance"]);
    options.minimum_abs_exposure_z = as<double>(controls["minimum_abs_exposure_z"]);
    options.ratio_variance_ridge = as<double>(controls["ratio_variance_ridge"]);
    if (as<bool>(controls["apply_heidi"])) {
      if (method == "gsmr") {
        gcorr::OriginalHeidiOptions heidi_options;
        heidi_options.p_threshold = as<double>(controls["heidi_threshold"]);
        heidi_options.difference_variance_ridge =
          as<double>(controls["difference_variance_ridge"]);
        const auto heidi = gcorr::filter_original_heidi(input,
          as<std::vector<double>>(p_values), heidi_options, options);
        NumericVector heidi_p(heidi.p_values.size());
        for (std::size_t i = 0; i < heidi.p_values.size(); ++i)
          heidi_p[i] = optional_value(heidi.p_values[i]);
        output["heidi"] = List::create(
          _["reference_index"] = heidi.reference_index
            ? double(*heidi.reference_index + 1) : NA_REAL,
          _["p_value"] = heidi_p,
          _["filtering_complete"] = heidi.filtering_complete);
        if (heidi.filtering_complete) {
          kept = heidi.retained_indices;
          output["retained_indices"] = one_based(kept);
        }
        if (!heidi.available) {
          output["reason"] = heidi.unavailable_reason;
          return output;
        }
        input = heidi.retained;
      } else {
        const auto heidi = gcorr::filter_global_heidi(input, options,
          as<double>(controls["heidi_threshold"]),
          as<int>(controls["maximum_global_iterations"]));
        List rounds(heidi.rounds.size());
        for (std::size_t i = 0; i < heidi.rounds.size(); ++i) {
          const auto& round = heidi.rounds[i];
          rounds[i] = List::create(_["indices"] = one_based(round.indices),
            _["p_value"] = round.p_values,
            _["excluded_index"] = round.excluded_index
              ? double(*round.excluded_index + 1) : NA_REAL);
        }
        kept = heidi.retained_indices;
        output["retained_indices"] = one_based(kept);
        output["heidi"] = List::create(_["rounds"] = rounds,
          _["filtering_complete"] = heidi.available);
        if (!heidi.available) {
          output["reason"] = heidi.unavailable_reason;
          return output;
        }
        input = heidi.retained;
      }
    }
    const auto fit = gcorr::fit_gsmr(input, options);
    output["available"] = fit.available;
    output["reason"] = fit.unavailable_reason;
    output["effect"] = estimate(fit.effect);
    output["weights"] = fit.weights;
    output["ratios"] = fit.ratio_model.ratios;
    output["ratio_covariance"] = named_matrix(fit.ratio_model.sampling_covariance);
    output["ratio_covariance_relative_eigenvalue"] =
      optional_value(fit.ratio_covariance_relative_eigenvalue);
  } else {
    gcorr::MrSensitivityOptions options;
    options.maximum_abs_ld = as<double>(controls["maximum_abs_ld"]);
    options.relative_rank_tolerance = as<double>(controls["relative_rank_tolerance"]);
    options.minimum_abs_exposure_z = as<double>(controls["minimum_abs_exposure_z"]);
    gcorr::MrSensitivityResult fit;
    if (method == "ivw") fit = gcorr::fit_mr_ivw(input, options);
    else if (method == "egger") fit = gcorr::fit_mr_egger(input, options);
    else if (method == "weighted_median") {
      options.bootstrap_replicates = as<int>(controls["bootstrap_replicates"]);
      options.seed = static_cast<std::uint64_t>(as<double>(controls["seed"]));
      fit = gcorr::fit_mr_weighted_median(input, options);
    } else stop("Unknown MR method.");
    output["available"] = fit.available;
    output["reason"] = fit.unavailable_reason;
    output["effect"] = estimate(fit.effect);
    output["intercept"] = estimate(fit.intercept);
    output["inference_available"] = fit.inference_available;
    output["heterogeneity_q"] = optional_value(fit.heterogeneity_q);
    output["heterogeneity_p_value"] = optional_value(fit.heterogeneity_p);
    output["heterogeneity_df"] = double(fit.heterogeneity_df);
    output["dispersion"] = fit.dispersion;
    output["mean_exposure_chisq"] = optional_value(fit.mean_exposure_chisq);
    output["exposure_i_squared"] = optional_value(fit.exposure_i_squared);
    output["maximum_observed_abs_ld"] = fit.maximum_observed_abs_ld;
    output["bootstrap_completed"] = double(fit.bootstrap_completed);
  }
  return output;
}
