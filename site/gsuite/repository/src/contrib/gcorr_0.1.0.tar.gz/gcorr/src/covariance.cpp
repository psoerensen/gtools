#include <Rcpp.h>

#include <algorithm>
#include <cmath>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include <gcorr/ggm.hpp>
#include <gcorr/annotation_models.hpp>
#include <gcorr/structural_sem.hpp>

namespace {

using Rcpp::CharacterMatrix;
using Rcpp::CharacterVector;
using Rcpp::DataFrame;
using Rcpp::List;
using Rcpp::Named;
using Rcpp::NumericMatrix;
using Rcpp::NumericVector;

std::vector<double> row_major(const NumericMatrix& matrix) {
  std::vector<double> values;
  values.reserve(matrix.size());
  for (R_xlen_t row = 0; row < matrix.nrow(); ++row)
    for (R_xlen_t column = 0; column < matrix.ncol(); ++column)
      values.push_back(matrix(row, column));
  return values;
}

NumericMatrix matrix_from(const std::vector<double>& values,
                          const CharacterVector& rows,
                          const CharacterVector& columns) {
  NumericMatrix matrix(rows.size(), columns.size());
  std::fill(matrix.begin(), matrix.end(), NA_REAL);
  if (values.size() == static_cast<std::size_t>(matrix.size()))
    for (R_xlen_t row = 0; row < matrix.nrow(); ++row)
      for (R_xlen_t column = 0; column < matrix.ncol(); ++column)
        matrix(row, column) = values[row * matrix.ncol() + column];
  matrix.attr("dimnames") = List::create(rows, columns);
  return matrix;
}

double optional_value(const std::optional<double>& value) {
  return value ? *value : NA_REAL;
}

gcorr::CovarianceFitInput covariance_input(const List& input,
                                            bool require_sampling) {
  gcorr::CovarianceFitInput result;
  result.trait_names = Rcpp::as<std::vector<std::string>>(input["traits"]);
  result.genetic_covariance = row_major(Rcpp::as<NumericMatrix>(input["covariance"]));
  result.provenance = Rcpp::as<std::string>(input["provenance"]);
  if (require_sampling)
    result.sampling_covariance =
      row_major(Rcpp::as<NumericMatrix>(input["sampling_covariance"]));
  return result;
}

gcorr::CovarianceFitOptions fit_options(const List& controls) {
  gcorr::CovarianceFitOptions result;
  result.maximum_iterations = static_cast<std::size_t>(
    Rcpp::as<double>(controls["maximum_iterations"]));
  result.gradient_tolerance = Rcpp::as<double>(controls["gradient_tolerance"]);
  result.relative_rank_tolerance =
    Rcpp::as<double>(controls["relative_rank_tolerance"]);
  result.boundary_tolerance = Rcpp::as<double>(controls["boundary_tolerance"]);
  return result;
}

gcorr::StructuralSemModel sem_model(const List& model) {
  gcorr::StructuralSemModel result;
  result.variables = Rcpp::as<std::vector<std::string>>(model["variables"]);
  const DataFrame parameters = model["parameters"], entries = model["entries"];
  const CharacterVector names = parameters["name"], matrices = entries["matrix"];
  const CharacterVector rows = entries["row"], columns = entries["column"];
  const CharacterVector entry_parameters = entries["parameter"];
  const NumericVector starts = parameters["start"], lower = parameters["lower"];
  const NumericVector upper = parameters["upper"], values = entries["value"];
  for (R_xlen_t index = 0; index < parameters.nrows(); ++index)
    result.parameters.push_back({Rcpp::as<std::string>(names[index]),
      starts[index], lower[index], upper[index]});
  for (R_xlen_t index = 0; index < entries.nrows(); ++index) {
    const auto matrix = Rcpp::as<std::string>(matrices[index]);
    if (matrix != "directed" && matrix != "disturbance")
      Rcpp::stop("SEM matrix must be directed or disturbance.");
    result.entries.push_back({matrix == "directed" ?
      gcorr::SemMatrix::directed : gcorr::SemMatrix::disturbance,
      Rcpp::as<std::string>(rows[index]),
      Rcpp::as<std::string>(columns[index]),
      Rcpp::as<std::string>(entry_parameters[index]), values[index]});
  }
  return result;
}

gcorr::FixedGraph fixed_graph(const CharacterVector& traits,
                              const CharacterMatrix& edges) {
  gcorr::FixedGraph result;
  result.trait_names = Rcpp::as<std::vector<std::string>>(traits);
  for (R_xlen_t index = 0; index < edges.nrow(); ++index)
    result.edges.emplace_back(Rcpp::as<std::string>(edges(index, 0)),
      Rcpp::as<std::string>(edges(index, 1)));
  return result;
}

List network_result(const gcorr::CovarianceNetwork& result) {
  const CharacterVector traits = Rcpp::wrap(result.trait_names);
  return List::create(Named("available") = result.available,
    Named("reason") = result.unavailable_reason,
    Named("precision") = matrix_from(result.precision, traits, traits),
    Named("partial_correlation") =
      matrix_from(result.partial_correlation, traits, traits));
}

List fit_result(const gcorr::CovarianceFitResult& result) {
  const CharacterVector traits = Rcpp::wrap(result.trait_names);
  const CharacterVector parameters = Rcpp::wrap(result.parameter_names);
  NumericVector estimates(parameters.size(), NA_REAL), standard_errors(parameters.size(), NA_REAL);
  if (result.available) estimates = Rcpp::wrap(result.parameters);
  if (result.standard_errors) standard_errors = Rcpp::wrap(*result.standard_errors);
  return List::create(Named("available") = result.available,
    Named("reason") = result.unavailable_reason,
    Named("converged") = result.converged,
    Named("identified") = result.identified,
    Named("boundary") = result.boundary,
    Named("inference_available") = result.inference_available,
    Named("inference_reason") = result.inference_unavailable_reason,
    Named("estimates") = DataFrame::create(Named("parameter") = parameters,
      Named("estimate") = estimates, Named("standard_error") = standard_errors),
    Named("fitted_covariance") = matrix_from(result.fitted_covariance, traits, traits),
    Named("residual_covariance") = matrix_from(result.residual_covariance, traits, traits),
    Named("parameter_sampling_covariance") = result.parameter_sampling_covariance ?
      Rcpp::RObject(matrix_from(*result.parameter_sampling_covariance,
        parameters, parameters)) : Rcpp::RObject(R_NilValue),
    Named("diagnostics") = List::create(
      Named("dwls_objective") = result.dwls_objective,
      Named("gradient_norm") = result.gradient_norm,
      Named("jacobian_condition") = result.jacobian_condition,
      Named("iterations") = static_cast<double>(result.iterations),
      Named("fit_degrees_of_freedom") =
        static_cast<double>(result.fit_degrees_of_freedom),
      Named("fit_statistic") = optional_value(result.fit_statistic),
      Named("fit_p_value") = optional_value(result.fit_p_value),
      Named("full_weight_residual_statistic") =
        optional_value(result.full_weight_residual_statistic)));
}

gcorr::CovarianceFitResult restore_fit(const List& fit) {
  gcorr::CovarianceFitResult result;
  const List input = fit["input"];
  const DataFrame estimates = fit["estimates"];
  result.trait_names = Rcpp::as<std::vector<std::string>>(input["traits"]);
  result.parameter_names =
    Rcpp::as<std::vector<std::string>>(estimates["parameter"]);
  result.available = Rcpp::as<bool>(fit["available"]);
  result.inference_available = Rcpp::as<bool>(fit["inference_available"]);
  result.boundary = Rcpp::as<bool>(fit["boundary"]);
  result.parameters = Rcpp::as<std::vector<double>>(estimates["estimate"]);
  if (!Rf_isNull(fit["parameter_sampling_covariance"]))
    result.parameter_sampling_covariance = row_major(
      Rcpp::as<NumericMatrix>(fit["parameter_sampling_covariance"]));
  return result;
}

List constraint_result(const gcorr::CovarianceConstraintTest& result) {
  return List::create(Named("available") = result.available,
    Named("reason") = result.unavailable_reason,
    Named("degrees_of_freedom") = static_cast<double>(result.degrees_of_freedom),
    Named("statistic") = optional_value(result.statistic),
    Named("p_value") = optional_value(result.p_value));
}

gcorr::AnnotationCovarianceKind annotation_kind(const std::string& kind) {
  if (kind == "gnova_categories")
    return gcorr::AnnotationCovarianceKind::gnova_categories;
  if (kind == "sumher_components")
    return gcorr::AnnotationCovarianceKind::sumher_components;
  if (kind == "sumher_categories")
    return gcorr::AnnotationCovarianceKind::sumher_categories;
  Rcpp::stop("Unknown grouped covariance kind.");
}

gcorr::AnnotationCovarianceInput annotation_input(const List& input) {
  gcorr::AnnotationCovarianceInput result;
  result.kind = annotation_kind(Rcpp::as<std::string>(input["kind"]));
  result.group_names =
    Rcpp::as<std::vector<std::string>>(input["group_names"]);
  const auto traits = Rcpp::as<std::vector<std::string>>(input["traits"]);
  const List groups = input["groups"];
  for (R_xlen_t index = 0; index < groups.size(); ++index) {
    const List group = groups[index];
    gcorr::CovarianceFitInput prepared;
    prepared.trait_names = traits;
    prepared.genetic_covariance =
      row_major(Rcpp::as<NumericMatrix>(group["covariance"]));
    prepared.sampling_covariance =
      row_major(Rcpp::as<NumericMatrix>(group["sampling_covariance"]));
    prepared.provenance = Rcpp::as<std::string>(group["provenance"]);
    result.groups.push_back(std::move(prepared));
  }
  result.joint_sampling_covariance = row_major(
    Rcpp::as<NumericMatrix>(input["joint_sampling_covariance"]));
  return result;
}

List annotation_parameters(const gcorr::AnnotationParameterEstimates& result,
                           const std::vector<std::string>& public_names = {}) {
  CharacterVector group, parameter, label;
  NumericVector estimate, standard_error;
  for (std::size_t index = 0; index < result.labels.size(); ++index) {
    const auto name = public_names.empty() ? result.labels[index].parameter :
      public_names[index % public_names.size()];
    group.push_back(result.labels[index].group);
    parameter.push_back(name);
    label.push_back(result.labels[index].group + "::" + name);
    estimate.push_back(index < result.estimates.size() ?
      result.estimates[index] : NA_REAL);
    double variance = NA_REAL;
    if (result.inference_available &&
        result.sampling_covariance.size() ==
          result.labels.size() * result.labels.size())
      variance = result.sampling_covariance[index * result.labels.size() + index];
    standard_error.push_back(std::isfinite(variance) && variance >= 0 ?
      std::sqrt(variance) : NA_REAL);
  }
  return List::create(
    Named("inference_available") = result.inference_available,
    Named("inference_reason") = result.inference_unavailable_reason,
    Named("estimates") = DataFrame::create(Named("group") = group,
      Named("parameter") = parameter, Named("label") = label,
      Named("estimate") = estimate,
      Named("standard_error") = standard_error),
    Named("sampling_covariance") = result.inference_available ?
      Rcpp::RObject(matrix_from(result.sampling_covariance, label, label)) :
      Rcpp::RObject(R_NilValue));
}

std::vector<std::string> graph_parameter_names(
    const std::vector<std::string>& traits, const CharacterMatrix& input) {
  std::vector<std::string> result;
  for (const auto& trait : traits)
    result.push_back("precision[" + trait + "," + trait + "]");
  std::vector<std::pair<std::size_t, std::size_t>> edges;
  for (R_xlen_t index = 0; index < input.nrow(); ++index) {
    const auto first = std::find(traits.begin(), traits.end(),
      Rcpp::as<std::string>(input(index, 0)));
    const auto second = std::find(traits.begin(), traits.end(),
      Rcpp::as<std::string>(input(index, 1)));
    auto i = static_cast<std::size_t>(first - traits.begin());
    auto j = static_cast<std::size_t>(second - traits.begin());
    if (i > j) std::swap(i, j);
    edges.emplace_back(i, j);
  }
  std::sort(edges.begin(), edges.end());
  for (const auto& edge : edges)
    result.push_back("precision[" + traits[edge.first] + "," +
      traits[edge.second] + "]");
  return result;
}

}  // namespace

// [[Rcpp::export]]
Rcpp::List cpp_gcorr_covariance_network(Rcpp::List input,
                                        double relative_rank_tolerance) {
  const auto prepared = covariance_input(input, false);
  return network_result(gcorr::covariance_network(gcorr::NamedSymmetricMatrix{
    prepared.trait_names, prepared.genetic_covariance}, relative_rank_tolerance));
}

// [[Rcpp::export]]
Rcpp::List cpp_gcorr_sem_fit(Rcpp::List input, Rcpp::List model,
                             Rcpp::List controls) {
  return fit_result(gcorr::fit_structural_sem(covariance_input(input, true),
    sem_model(model), fit_options(controls)));
}

// [[Rcpp::export]]
Rcpp::List cpp_gcorr_sem_test(Rcpp::List fit, Rcpp::NumericMatrix constraints,
                              Rcpp::NumericVector target) {
  return constraint_result(gcorr::test_sem_constraints(restore_fit(fit),
    row_major(constraints), Rcpp::as<std::vector<double>>(target)));
}

// [[Rcpp::export]]
Rcpp::List cpp_gcorr_ggm_fit(Rcpp::List input, Rcpp::CharacterMatrix edges,
                             Rcpp::Nullable<Rcpp::NumericVector> start,
                             Rcpp::List controls) {
  const auto prepared = covariance_input(input, true);
  const auto graph = fixed_graph(Rcpp::wrap(prepared.trait_names), edges);
  std::optional<std::vector<double>> initial;
  if (start.isNotNull()) initial = Rcpp::as<std::vector<double>>(start);
  const auto result = gcorr::fit_fixed_ggm(prepared, graph,
    fit_options(controls), initial);
  List output = fit_result(result.fit);
  output["network"] = network_result(result.network);
  CharacterVector trait1, trait2;
  NumericVector precision, precision_se, partial, partial_se;
  for (const auto& edge : result.edges) {
    trait1.push_back(edge.trait1); trait2.push_back(edge.trait2);
    precision.push_back(optional_value(edge.precision.estimate));
    precision_se.push_back(optional_value(edge.precision.standard_error));
    partial.push_back(optional_value(edge.partial_correlation.estimate));
    partial_se.push_back(optional_value(edge.partial_correlation.standard_error));
  }
  output["edges"] = DataFrame::create(Named("trait1") = trait1,
    Named("trait2") = trait2, Named("precision") = precision,
    Named("precision_standard_error") = precision_se,
    Named("partial_correlation") = partial,
    Named("partial_correlation_standard_error") = partial_se);
  CharacterVector labels(trait1.size());
  for (R_xlen_t index = 0; index < trait1.size(); ++index)
    labels[index] = Rcpp::as<std::string>(trait1[index]) + "|" +
      Rcpp::as<std::string>(trait2[index]);
  output["partial_correlation_sampling_covariance"] =
    result.partial_correlation_sampling_covariance ?
      Rcpp::RObject(matrix_from(*result.partial_correlation_sampling_covariance,
        labels, labels)) : Rcpp::RObject(R_NilValue);
  return output;
}

// [[Rcpp::export]]
Rcpp::List cpp_gcorr_ggm_test(Rcpp::List fit,
                              Rcpp::CharacterMatrix selected_edges) {
  gcorr::GraphicalModelResult restored;
  restored.fit = restore_fit(fit);
  const DataFrame fitted = fit["edges"];
  const CharacterVector trait1 = fitted["trait1"], trait2 = fitted["trait2"];
  for (R_xlen_t index = 0; index < fitted.nrows(); ++index) {
    gcorr::GraphEdgeEstimate edge;
    edge.trait1 = Rcpp::as<std::string>(trait1[index]);
    edge.trait2 = Rcpp::as<std::string>(trait2[index]);
    restored.edges.push_back(std::move(edge));
  }
  std::vector<std::pair<std::string, std::string>> selected;
  for (R_xlen_t index = 0; index < selected_edges.nrow(); ++index)
    selected.emplace_back(Rcpp::as<std::string>(selected_edges(index, 0)),
      Rcpp::as<std::string>(selected_edges(index, 1)));
  return constraint_result(gcorr::test_ggm_edges(restored, selected));
}

// [[Rcpp::export]]
Rcpp::List cpp_gcorr_grouped_fit(Rcpp::List input, std::string method,
                                 Rcpp::List specification,
                                 Rcpp::List controls) {
  const auto prepared = annotation_input(input);
  const auto traits = prepared.groups.front().trait_names;
  gcorr::AnnotationModelResult result;
  std::vector<std::string> public_parameters;
  List output;
  if (method == "sem") {
    result = gcorr::fit_annotation_sem(prepared, sem_model(specification),
      fit_options(controls));
  } else {
    const CharacterMatrix edges = specification["edges"];
    const auto graph = fixed_graph(Rcpp::wrap(traits), edges);
    result = gcorr::fit_annotation_ggm(prepared, graph, fit_options(controls));
    public_parameters = graph_parameter_names(traits, edges);
    output["partial_correlations"] = annotation_parameters(
      gcorr::annotation_ggm_partial_correlations(result, graph));
  }
  List fits;
  for (std::size_t index = 0; index < result.fits.size(); ++index) {
    List fit = fit_result(result.fits[index]);
    if (!public_parameters.empty()) {
      DataFrame estimates = fit["estimates"];
      estimates["parameter"] = Rcpp::wrap(public_parameters);
      fit["estimates"] = estimates;
      if (!Rf_isNull(fit["parameter_sampling_covariance"])) {
        NumericMatrix covariance = fit["parameter_sampling_covariance"];
        covariance.attr("dimnames") =
          List::create(public_parameters, public_parameters);
        fit["parameter_sampling_covariance"] = covariance;
      }
    }
    fits.push_back(fit, result.group_names[index]);
  }
  output["fits"] = fits;
  output["parameters"] = annotation_parameters(result.parameters,
    public_parameters);
  output["groups"] = result.group_names;
  output["traits"] = traits;
  output["kind"] = Rcpp::as<std::string>(input["kind"]);
  return output;
}

// [[Rcpp::export]]
Rcpp::List cpp_gcorr_grouped_test(Rcpp::List fit,
                                  Rcpp::NumericMatrix constraints,
                                  Rcpp::NumericVector target,
                                  bool partial_correlations) {
  const List values = partial_correlations ?
    Rcpp::as<List>(fit["partial_correlations"]) :
    Rcpp::as<List>(fit["parameters"]);
  const DataFrame estimates = values["estimates"];
  const CharacterVector groups = estimates["group"];
  const CharacterVector parameters = estimates["parameter"];
  const NumericVector estimate = estimates["estimate"];
  gcorr::AnnotationParameterEstimates input;
  input.kind = annotation_kind(Rcpp::as<std::string>(fit["kind"]));
  input.inference_available = Rcpp::as<bool>(values["inference_available"]);
  input.inference_unavailable_reason =
    Rcpp::as<std::string>(values["inference_reason"]);
  for (R_xlen_t index = 0; index < estimates.nrows(); ++index) {
    input.labels.push_back({Rcpp::as<std::string>(groups[index]),
      Rcpp::as<std::string>(parameters[index])});
    input.estimates.push_back(estimate[index]);
  }
  if (input.inference_available)
    input.sampling_covariance = row_major(
      Rcpp::as<NumericMatrix>(values["sampling_covariance"]));
  std::vector<std::vector<gcorr::AnnotationContrastTerm>> terms(
    constraints.nrow());
  for (R_xlen_t row = 0; row < constraints.nrow(); ++row)
    for (R_xlen_t column = 0; column < constraints.ncol(); ++column)
      if (constraints(row, column) != 0)
        terms[row].push_back({Rcpp::as<std::string>(groups[column]),
          Rcpp::as<std::string>(parameters[column]),
          constraints(row, column)});
  return constraint_result(gcorr::test_annotation_constraints(input, terms,
    Rcpp::as<std::vector<double>>(target)));
}
