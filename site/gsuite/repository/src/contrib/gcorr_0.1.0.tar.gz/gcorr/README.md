# gcorr

`gcorr` provides focused genetic-correlation workflows in the gsuite R-package
decomposition. It imports the task-neutral `gbase` package and does not import
the root `gsuite` package.

`ldsc()` is the recommended LD-score regression workflow. It accepts the same
checked `stat` contract as `glma::vegas()`: one ordinary summary-statistics data
frame or a uniquely named list for multiple traits. A sparse-LD Glist supplies
marker identity, ordinary and annotation LD scores, reference metadata and the
reference ordering used for default delete blocks. Optional `sets` are named
marker-ID vectors and may overlap; `set_model = "stratified"` computes standard
annotation-specific LD scores, whereas `set_model = "grouped"` masks and
reuses the stored ordinary scores without scanning sparse LD. `residual = TRUE`
adds the marker complement. The returned fit includes
convenient `h2` and `rg` views as well as the complete estimates, uncertainty,
diagnostics and provenance.

The explicit functions remain `gcorr_ldsc()` for ordinary LDSC,
`gcorr_ldsc_partitioned()` for partitioned LDSC, `gcorr_gnova()` for ordinary
or binary-annotation GNOVA, and `gcorr_sumher()` for architecture-component
SumHer. Annotation and architecture routes accept explicit named score,
annotation, weight, tagging, and block inputs; they never infer annotation or
allele alignment. SumHer optionally
returns native category, enrichment, contrast, and multivariate category-
covariance summaries from full-reference architecture weights.

Regional workflows use `gcorr_prepare_regions()` with a sparse-LD Glist and
named marker regions, or with explicit signed LD matrices. The Glist route
opens one native reader for all requested regions, and each full eigensystem is
verified once. The same session-bound preparation is accepted by `gcorr_hess()`,
`gcorr_rho_hess()`, `gcorr_supergnova()`, `gcorr_lava()`, and `gcorr_hdll()`.
HESS and rho-HESS provide both independent regional fits and native joint
multi-region correction. LAVA exposes continuous and binary-trait regional
heritability, covariance, correlation, univariate screening, seeded bivariate
simulation inference, partial correlation, genetic regression, and supported
conditional and omnibus inference through `gcorr_lava_partial()` and
`gcorr_lava_regression()`.

Continuous-trait covariance summaries use `gcorr_covariance()` to validate
trait units, provenance, and the full joint sampling covariance. `gcorr_sem()`
fits an explicit recursive structural model; `gcorr_ggm()` fits an explicitly
allowed fixed graph; and `gcorr_ggm_network()` reports the descriptive
all-trait conditional network without fitting or edge selection. Linear SEM
constraints and selected free GGM edges have separate native Wald-test
functions. No covariance repair, graph search, or reconstruction from marginal
standard errors is performed.

`gcorr_grouped_covariance()` extracts GNOVA categories, SumHer architecture
components, or transformed SumHer categories together with their full
cross-group block-jackknife covariance. `gcorr_grouped_sem()` and
`gcorr_grouped_ggm()` apply one prespecified model across the selected groups;
their explicit contrast functions propagate cross-group uncertainty for SEM
parameters, precision terms, and free-edge partial correlations.

Prepared-instrument MR starts with `gcorr_prepare_mr()`. It requires two
already aligned `gbase` effect/standard-error summaries, an exactly labelled
signed-LD matrix, matching trait/reference ancestry, the reference sample
count, and an explicit non-overlapping-sample assertion. It records instrument
and pairwise LD decisions in a serializable package-owned object. That object is
accepted by `gcorr_gsmr()`, `gcorr_gsmr2()`, `gcorr_mr_ivw()`,
`gcorr_mr_egger()`, and `gcorr_mr_weighted_median()`. Sensitivity estimators
require approximately independent instruments, and weighted median requires
an explicit seed.

`gcorr()` is the new thin package-owned dispatcher. It delegates
`method = "ldsc"`, `method = "gnova"`, `method = "sumher"`, focused regional
and covariance-fit names, and `method = "gsmr"`, `"gsmr2"`, `"ivw"`,
`"egger"`, or `"weighted_median"` to those functions. It has no `task` selector
and never forwards to the root gsuite package.

The adapters use installed public gcorr and gmat interfaces. No native
implementation is copied or exposed here.

Release source archives are published through the gsuite R package repository
and compile the required native implementation with the package.
