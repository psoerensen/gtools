#' Write a PLINK BED/BIM/FAM subset
#'
#' Copy selected packed markers and optionally retain only selected samples.
#' Output rows follow source BIM and FAM order. Output files must be new.
#' @param bedRead,bimRead,famRead Input PLINK paths. BIM and FAM are inferred from
#'   the input BED path when omitted.
#' @param bedWrite,bimWrite,famWrite Output PLINK paths. BIM and FAM are inferred
#'   from the output BED path when omitted. Parent directories must exist.
#' @param rsids Unique marker rsids to select.
#' @param ids Optional unique FAM individual IDs. NULL keeps all samples.
#'   Unknown sample IDs are errors.
#' @return A list with paths, marker and sample counts, and `missing_rsids` in
#'   request order. If no requested marker is found, no files are written and
#'   `paths` is NULL.
#' @md
#' @export
writeBED <- function(bedRead, bimRead = NULL, famRead = NULL,
    bedWrite, bimWrite = NULL, famWrite = NULL, rsids, ids = NULL) {
  .write_bed(bedRead, bimRead, famRead, bedWrite, bimWrite, famWrite, rsids, ids, TRUE)
}

.write_bed <- function(bedRead, bimRead, famRead, bedWrite, bimWrite, famWrite,
    rsids, ids, report_missing) {
  one_path <- function(path, name) {
    if (!is.character(path) || length(path) != 1L || is.na(path) || !nzchar(path))
      .gbase_stop("`", name, "` must name one file.")
    path.expand(path)
  }
  bedRead <- one_path(bedRead, "bedRead")
  bedWrite <- one_path(bedWrite, "bedWrite")
  if (is.null(bimRead)) bimRead <- .gprep_companion(bedRead, "bim")
  if (is.null(famRead)) famRead <- .gprep_companion(bedRead, "fam")
  if (is.null(bimWrite)) bimWrite <- .gprep_companion(bedWrite, "bim")
  if (is.null(famWrite)) famWrite <- .gprep_companion(bedWrite, "fam")
  bimRead <- .gprep_path(one_path(bimRead, "bimRead"), "bimRead")
  famRead <- .gprep_path(one_path(famRead, "famRead"), "famRead")
  bedRead <- .gprep_path(bedRead, "bedRead")
  outputs <- list(bed = .gprep_prefix(bedWrite),
    bim = .gprep_prefix(one_path(bimWrite, "bimWrite")),
    fam = .gprep_prefix(one_path(famWrite, "famWrite")))
  if (!is.character(rsids) || !length(rsids))
    .gbase_stop("`rsids` must be a nonempty character vector.")
  if (!is.null(ids) && (!is.character(ids) || !length(ids)))
    .gbase_stop("`ids` must be NULL or a nonempty character vector.")
  result <- cpp_gbase_write_bed_subset(bedRead, bimRead, famRead,
    outputs$bed, outputs$bim, outputs$fam, rsids, if (is.null(ids)) character() else ids)
  if (report_missing) .report_missing_rsids(result$missing_rsids, "BIM")
  c(list(paths = if (result$n_markers) outputs), result)
}

.report_missing_rsids <- function(rsids, source) {
  if (length(rsids))
    message(sprintf("Requested rsids absent from %s: %s", source, length(rsids)))
}

.gprep_recode <- function(Glist, allele_reference, out_prefix, nthreads, study, mapped_dir, companion) {
  if (!inherits(Glist, "Glist") || !length(Glist$bedfiles) ||
      length(Glist$rsids) != length(Glist$bedfiles) ||
      length(Glist$physical_marker_counts) != length(Glist$bedfiles) ||
      !isTRUE(all(lengths(Glist$rsids) == Glist$physical_marker_counts)) ||
      length(Glist$bimfiles) != length(Glist$bedfiles) ||
      length(Glist$famfiles) != length(Glist$bedfiles) ||
      length(Glist$ids) != Glist$n ||
      length(Glist$sample_source_indices_0based) != Glist$n ||
      !isTRUE(all(Glist$sample_source_indices_0based == seq_len(Glist$n) - 1L)))
    .gbase_stop("Recode requires a Glist describing all physical BED markers and samples.")
  reference <- .gprep_path(allele_reference, "allele_reference")
  if (length(reference) != 1L) .gbase_stop("Supply one allele catalog file.")
  nthreads <- .gprep_count(nthreads, "nthreads")
  nfiles <- length(Glist$bedfiles)
  if (is.null(out_prefix))
    out_prefix <- paste0(tools::file_path_sans_ext(Glist$bedfiles[[1L]]), ".aligned")
  prefix <- .gprep_prefix(out_prefix)
  paths <- list(bed = Glist$bedfiles, bim = Glist$bimfiles, fam = Glist$famfiles)
  created <- character()
  finished <- FALSE
  on.exit(if (!finished) unlink(created), add = TRUE)
  for (i in seq_len(nfiles)) {
    stem <- if (nfiles == 1L) prefix else paste0(prefix, ".", i)
    output <- paste0(stem, c(".bed", ".bim", ".fam"))
    ext <- paste0(stem, ".ext")
    if (file.exists(ext)) .gbase_stop("Recode output already exists: ", ext)
    n <- cpp_gbase_recode_plink(paths$bed[i], paths$bim[i], paths$fam[i],
      output[1L], output[2L], output[3L], reference)
    if (n == 0) next
    created <- c(created, output, ext)
    paths$bed[i] <- output[1L]
    paths$bim[i] <- output[2L]
    paths$fam[i] <- output[3L]
  }
  if (!length(created)) return(Glist)
  prepared <- gprep(study = if (is.null(study)) Glist$study else study,
    bedfiles = paths$bed, bimfiles = paths$bim, famfiles = paths$fam,
    nthreads = nthreads, mapped_dir = mapped_dir, companion = companion)
  prepared$reference_groups <- Glist$reference_groups
  finished <- TRUE
  prepared
}

.gprep_subset <- function(Glist, rsids, ids, out_prefix, nthreads, study, mapped_dir, companion) {
  if (!inherits(Glist, "Glist")) .gbase_stop("Supply a prepared Glist for task = 'subset'.")
  rsids <- .gprep_selection(rsids, "rsids")
  if (is.null(rsids)) .gbase_stop("`rsids` must select at least one marker.")
  ids <- .gprep_selection(ids, "ids")
  nthreads <- .gprep_count(nthreads, "nthreads")
  if (is.null(study)) study <- Glist$study
  if (!is.null(study) && (!is.character(study) || length(study) != 1L || is.na(study)))
    .gbase_stop("`study` must be NULL or one string.")
  if (!is.null(mapped_dir)) {
    mapped_dir <- .mapped_glist_path(mapped_dir)
    if (file.exists(mapped_dir)) .gbase_stop("Mapped output already exists.")
    if (nthreads != 1L) .gbase_stop("Mapped preparation currently uses one thread.")
  }
  if (is.null(out_prefix))
    out_prefix <- paste0(tools::file_path_sans_ext(Glist$bedfiles[1L]), ".subset")
  prefix <- .gprep_prefix(out_prefix)
  nfiles <- length(Glist$bedfiles)
  if (!nfiles || !identical(nfiles, length(Glist$rsids)) ||
      length(Glist$bimfiles) != nfiles || length(Glist$famfiles) != nfiles)
    .gbase_stop("Glist paths and rsids must describe the same files.")

  outputs <- vector("list", nfiles)
  found <- logical(length(rsids))
  finished <- FALSE
  on.exit(if (!finished) unlink(unlist(outputs, use.names = FALSE)), add = TRUE)
  full_single_file <- nfiles == 1L &&
    isTRUE(length(Glist$rsids[[1L]]) == Glist$physical_marker_counts[1L])
  for (i in seq_len(nfiles)) {
    selected <- if (full_single_file) seq_along(rsids) else which(rsids %in% Glist$rsids[[i]])
    if (!length(selected)) next
    file_prefix <- if (nfiles == 1L) prefix else paste0(prefix, ".", i)
    result <- .write_bed(Glist$bedfiles[i], Glist$bimfiles[i], Glist$famfiles[i],
      paste0(file_prefix, ".bed"), NULL, NULL, rsids[selected], ids, FALSE)
    outputs[i] <- list(result$paths)
    if (!length(result$missing_rsids)) found[selected] <- TRUE
    else found[selected[!rsids[selected] %in% result$missing_rsids]] <- TRUE
  }
  missing_rsids <- rsids[!found]
  .report_missing_rsids(missing_rsids, "Glist")
  active <- which(lengths(outputs) > 0L)
  if (!length(active))
    stop(structure(list(message = "No requested rsids were found in Glist.",
      call = NULL, missing_rsids = missing_rsids), class = c("gbase_empty_subset", "error", "condition")))
  paths <- function(name) vapply(outputs[active], `[[`, character(1), name)
  prepared <- gprep(study = study, bedfiles = paths("bed"), bimfiles = paths("bim"),
    famfiles = paths("fam"), nthreads = nthreads, mapped_dir = mapped_dir, companion = companion)
  prepared$missing_rsids <- missing_rsids
  finished <- TRUE
  prepared
}
