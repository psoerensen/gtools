.ld_metadata_fields <- c("marker_id", "chromosome", "base_pair_position",
  "allele1", "allele2", "component_index_0based", "source_marker_index_0based",
  "allele_frequency")

# Install an immutable sidecar. Use hard links to publish an entire file
# atomically on filesystems that support them, including concurrent conversion.
.ld_sidecar <- function(path, write, content_addressed = TRUE) {
  tmp <- tempfile(".ld-meta-", tmpdir = dirname(path))
  on.exit(unlink(tmp))
  write(tmp)
  hash <- unname(tools::md5sum(tmp))
  if (is.na(hash)) .gbase_stop("Cannot hash sparse-LD metadata sidecar.")
  if (content_addressed) path <- paste0(path, ".", hash)
  if (!file.exists(path) && !suppressWarnings(file.link(tmp, path)) &&
      !file.exists(path)) {
    .gbase_stop("Cannot publish sparse-LD metadata sidecar: ", path)
  }
  if (!identical(unname(tools::md5sum(path)), hash))
    .gbase_stop("Sparse-LD metadata sidecar differs: ", path)
  list(path = path, md5 = hash)
}

.ld_metadata_spec <- function(Glist, saved) {
  index <- saved$metadata_storage$index
  af <- saved$metadata_storage$af
  list(saved$paths$markers, index$path,
    if (is.null(af)) "" else af$path,
    if (is.null(af)) Glist$path else character(), as.integer(saved$chr),
    as.integer(saved$m))
}

.ld_column_views <- function(Glist, saved) {
  spec <- .ld_metadata_spec(Glist, saved)
  sizes <- lengths(saved$rsids)
  ends <- cumsum(sizes)
  starts <- ends - sizes
  fields <- seq_along(.ld_metadata_fields) - 1L
  metadata <- stats::setNames(lapply(fields, function(field)
    cpp_gbase_ld_column(spec, field, 0L, as.integer(saved$m))), .ld_metadata_fields)
  if (length(saved$rsids) == 1L) metadata$marker_id <- saved$rsids[[1L]]
  attr(metadata, "row.names") <- c(NA_integer_, -as.integer(saved$m))
  class(metadata) <- "data.frame"
  parts <- function(field) Map(function(start, size)
    cpp_gbase_ld_column(spec, field, as.integer(start), as.integer(size)),
    starts, sizes)
  list(marker_metadata = metadata, marker_indices_0based = parts(6L),
    af = parts(7L), cls = parts(8L))
}

.ld_bind_metadata <- function(Glist, saved, frequencies, mapped_af) {
  marker_path <- saved$paths$markers
  index_path <- paste0(marker_path, ".", saved$checksums[["markers"]], ".idx.u64.bin")
  index <- .ld_sidecar(index_path,
    function(path) cpp_gbase_index_ld_markers(marker_path, path, as.integer(saved$m)),
    content_addressed = FALSE)
  af <- if (mapped_af) NULL else .ld_sidecar(paste0(saved$prefix, ".af.f64.bin"),
    function(path) writeBin(as.double(frequencies), path, size = 8L, endian = .Platform$endian))
  saved$metadata_storage <- list(index = index, af = af)
  # Reuse the resident physical IDs when the LD selection covers the same rows.
  for (i in seq_along(saved$chr)) {
    component <- saved$chr[i]
    if (identical(saved$rsids[[i]], Glist$rsids[[component]])) {
      saved$rsids[[i]] <- Glist$rsids[[component]]
      Glist$rsidsLD[[component]] <- Glist$rsids[[component]]
    }
  }
  saved$provenance$requested_marker_order <- NULL
  for (name in c("marker_metadata", "marker_indices_0based", "af", "cls"))
    saved[[name]] <- NULL
  views <- .ld_column_views(Glist, saved)
  Glist$sparseLD <- c(saved, views)
  Glist
}

.ld_check_metadata_storage <- function(Glist, saved) {
  fail <- function() .gbase_stop("Glist sparse-LD marker mappings do not match the disk metadata.")
  storage <- saved$metadata_storage
  check_file <- function(spec, bytes) {
    is.list(spec) && is.character(spec$path) && length(spec$path) == 1L &&
      !is.na(spec$path) && is.character(spec$md5) && length(spec$md5) == 1L &&
      isTRUE(file.size(spec$path) == bytes)
  }
  if (!is.list(storage) || !check_file(storage$index, 8 * ceiling(saved$m / 256)) ||
      (!is.null(storage$af) && !check_file(storage$af, 8 * saved$m)) ||
      (is.null(storage$af) && (!inherits(Glist, "gs_mapped_genotypes") ||
          !identical(saved$sample_ids, Glist$ids)))) fail()
  views <- .ld_column_views(Glist, saved)
  for (name in names(views)) {
    actual <- saved[[name]]
    expected <- views[[name]]
    if (!identical(names(actual), names(expected)) ||
        !identical(class(actual), class(expected)) ||
        !identical(dim(actual), dim(expected)) ||
        length(actual) != length(expected)) fail()
    for (i in seq_along(expected)) {
      if (name == "marker_metadata" && i == 1L && length(saved$rsids) == 1L) {
        if (!identical(actual[[i]], expected[[i]])) fail()
      } else if (!cpp_gbase_same_mapped_column(actual[[i]], expected[[i]])) {
        x <- actual[[i]]
        y <- expected[[i]]
        if (length(x) != length(y) || !identical(x[seq_along(x)], y[seq_along(y)]))
          fail()
      }
    }
  }
  if (!identical(unname(lengths(saved$rsids)), unname(lengths(Glist$rsidsLD)[saved$chr])) ||
      sum(lengths(saved$rsids)) != saved$m) fail()
}

#' Read sparse LD marker metadata
#' @param Glist A Glist with sparse LD.
#' @param rows One-based CSR rows in the order requested. NULL selects all rows.
#' @param fields Column names. NULL selects all fields.
#' @return A data frame in the requested row and column order.
#' @export
read_ld_metadata <- function(Glist, rows = NULL, fields = NULL) {
  saved <- Glist$sparseLD
  if (is.null(saved)) .gbase_stop("Glist has no sparse LD.")
  if (is.null(rows)) rows <- seq_len(saved$m)
  if (!is.numeric(rows) || anyNA(rows) || any(!is.finite(rows)) ||
      any(rows != floor(rows) | rows < 1 | rows > saved$m))
    .gbase_stop("Sparse-LD rows must be one-based indices within the resource.")
  if (is.null(fields)) fields <- .ld_metadata_fields
  if (!is.character(fields) || anyDuplicated(fields) ||
      any(!fields %in% .ld_metadata_fields))
    .gbase_stop("Unknown or repeated sparse-LD metadata fields.")
  if (!is.null(saved$metadata_storage) && !is.data.frame(saved$marker_metadata))
    .gbase_stop("Glist sparse-LD marker metadata is invalid.")
  structure(lapply(saved$marker_metadata[fields], function(column) column[rows]),
    class = "data.frame", row.names = if (length(rows)) c(NA_integer_, -length(rows)) else integer())
}

#' Move existing sparse LD marker metadata to disk
#' @param Glist A Glist with sparse LD.
#' @return A Glist referencing the original CSR and disk-backed metadata.
#'   Save the returned object to persist the conversion.
#' @details Reuses the original LD files and scores. Writes an index alongside
#'   the marker table, plus a frequency sidecar when frequencies are specific
#'   to the LD reference samples or the source panel has no disk-backed fields.
#' @export
compact_ld_Glist <- function(Glist) {
  saved <- .gprep_validate_sparse_ld(Glist)
  if (!is.null(saved$metadata_storage)) return(Glist)
  if (!identical(unname(tools::md5sum(saved$paths$markers)),
                 unname(saved$checksums[["markers"]])))
    .gbase_stop("Sparse-LD marker table changed after preparation.")
  resource <- cpp_gbase_sparse_ld_identity(saved$prefix)
  if (!identical(saved$marker_metadata[names(resource$markers)], resource$markers))
    .gbase_stop("Glist sparse-LD metadata does not match its native resource.")
  mapped_af <- inherits(Glist, "gs_mapped_genotypes") &&
    identical(saved$sample_ids, Glist$ids) &&
    identical(saved$provenance$allele_frequency_source, "mapped Glist allele frequencies")
  .ld_bind_metadata(Glist, saved, saved$marker_metadata$allele_frequency, mapped_af)
}
