#include <Rcpp.h>
#include <R_ext/Altrep.h>
#include "plink_resource.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <limits>
#include <unordered_map>
#include <vector>

#include <fstream>
#include <charconv>

namespace {

using Text = gmat::PlinkTextField;
using Number = gmat::PlinkNumberField;

SEXP r_string(std::string_view value) {
  if (value.size() > static_cast<std::size_t>(std::numeric_limits<int>::max()))
    Rcpp::stop("Mapped text exceeds R's string length limit.");
  return Rf_mkCharLen(value.data(), static_cast<int>(value.size()));
}

// Each vector stores a compact, serializable reference. The reader and any
// materialized character data are session-local and created on demand.
R_altrep_class_t mapped_text_class, mapped_number_class;
constexpr int source_row_field = -1;
constexpr int ld_disk_field = -2;

SEXP mapped_text_vector(SEXP state) {
  Rcpp::Shield<SEXP> held(state);
  return R_new_altrep(mapped_text_class, held, R_NilValue);
}

R_xlen_t mapped_vector_length(SEXP x) {
  const auto state = R_altrep_data1(x);
  return state == R_NilValue ? XLENGTH(R_altrep_data2(x))
      : INTEGER_ELT(VECTOR_ELT(state, 3), 0);
}

// An R write detaches the vector from its immutable on-disk reference.
SEXP mapped_vector_state(SEXP x) {
  const auto state = R_altrep_data1(x);
  return state == R_NilValue ? R_altrep_data2(x) : state;
}

SEXP mapped_text_restore(SEXP, SEXP state) {
  return TYPEOF(state) == STRSXP ? state : mapped_text_vector(state);
}

SEXP mapped_number_restore(SEXP, SEXP state) {
  if (TYPEOF(state) == REALSXP) return state;
  Rcpp::Shield<SEXP> held(state);
  return R_new_altrep(mapped_number_class, held, R_NilValue);
}

const gmat::MappedPlinkPanel& mapped_panel(SEXP x) {
  SEXP cached = R_altrep_data2(x);
  if (cached == R_NilValue) {
    const auto state = R_altrep_data1(x);
    const Rcpp::CharacterVector path(VECTOR_ELT(state, 0));
    auto panel = gbase_plink_panel(path);
    Rcpp::XPtr<gmat::MappedPlinkPanel> reader(panel.release(), true);
    const auto part = INTEGER_ELT(VECTOR_ELT(state, 1), 0);
    if (reader->components().at(part).marker_count != static_cast<std::uint64_t>(mapped_vector_length(x)))
      Rcpp::stop("Mapped text reference no longer matches the panel dimensions.");
    R_set_altrep_data2(x, reader);
    cached = reader;
  }
  return *static_cast<const gmat::MappedPlinkPanel*>(R_ExternalPtrAddr(cached));
}

constexpr std::uint64_t ld_page_rows = 256;
constexpr int ld_id = 0, ld_chr = 1, ld_a1 = 3, ld_a2 = 4,
    ld_component = 5, ld_source = 6, ld_af = 7, ld_cls = 8;

void ld_read(std::ifstream& input, std::uint64_t offset, void* out, std::size_t bytes) {
  input.seekg(static_cast<std::streamoff>(offset));
  if (!input.read(static_cast<char*>(out), static_cast<std::streamsize>(bytes)))
    Rcpp::stop("Cannot read sparse-LD marker metadata.");
}

std::ifstream ld_open(const std::string& path) {
  std::ifstream input(std::filesystem::u8path(path), std::ios::binary);
  if (!input) Rcpp::stop("Cannot open sparse-LD marker metadata: " + path);
  return input;
}

class LdMetadataReader {
  using Row = std::array<std::string_view, 8>;
 public:
  explicit LdMetadataReader(SEXP spec)
      : markers(ld_open(Rcpp::as<std::string>(VECTOR_ELT(spec, 0)))),
        index(ld_open(Rcpp::as<std::string>(VECTOR_ELT(spec, 1)))),
        paths(VECTOR_ELT(spec, 3)), active(VECTOR_ELT(spec, 4)),
        size(INTEGER_ELT(VECTOR_ELT(spec, 5), 0)) {
    const auto af = Rcpp::as<std::string>(VECTOR_ELT(spec, 2));
    if (!af.empty()) frequency = ld_open(af);
  }

  std::string_view field(std::uint64_t row, int column) {
    const auto first = row / ld_page_rows * ld_page_rows;
    if (first != page_start) load(first);
    return records[row - first][column + 1];
  }

  double number(std::uint64_t row, int column) {
    if (column == ld_af) {
      if (frequency.is_open()) {
        const auto first = row / ld_page_rows * ld_page_rows;
        if (first != af_start) {
          ld_read(frequency, first * sizeof(double), af_page.data(),
                  std::min(ld_page_rows, size - first) * sizeof(double));
          af_start = first;
        }
        return af_page[row - first];
      }
      if (!panel) panel = gbase_plink_panel(paths);
      const auto component = integer(row, ld_component);
      if (component >= static_cast<std::uint64_t>(active.size()))
        Rcpp::stop("Sparse-LD marker component is out of range.");
      return panel->number(active[component] - 1, Number::af, integer(row, ld_source));
    }
    return static_cast<double>(integer(row, column == ld_cls ? ld_source : column)) +
        (column == ld_cls ? 1.0 : 0.0);
  }

 private:
  std::uint64_t integer(std::uint64_t row, int column) {
    auto value = field(row, column);
    std::uint64_t parsed = 0;
    const auto end = value.data() + value.size();
    const auto result = std::from_chars(value.data(), end, parsed);
    if (result.ec != std::errc{} || result.ptr != end)
      Rcpp::stop("Invalid numeric field in sparse-LD marker metadata.");
    return parsed;
  }

  void load(std::uint64_t first) {
    std::uint64_t offset;
    ld_read(index, (first / ld_page_rows) * sizeof(offset), &offset, sizeof(offset));
    markers.seekg(static_cast<std::streamoff>(offset));
    const auto count = std::min(ld_page_rows, size - first);
    for (std::uint64_t i = 0; i < count; ++i) {
      auto& line = lines[i];
      if (!std::getline(markers, line)) Rcpp::stop("Truncated sparse-LD marker table.");
      if (!line.empty() && line.back() == '\r') line.pop_back();
      std::string_view remaining(line);
      for (std::size_t j = 0; j < records[i].size() - 1; ++j) {
        const auto tab = remaining.find('\t');
        if (tab == std::string_view::npos) Rcpp::stop("Invalid sparse-LD marker row.");
        records[i][j] = remaining.substr(0, tab);
        remaining.remove_prefix(tab + 1);
      }
      if (remaining.find('\t') != std::string_view::npos)
        Rcpp::stop("Invalid sparse-LD marker row.");
      records[i].back() = remaining;
    }
    page_start = first;
  }

  std::ifstream markers, index, frequency;
  Rcpp::CharacterVector paths;
  Rcpp::IntegerVector active;
  std::uint64_t size;
  std::uint64_t page_start = UINT64_MAX, af_start = UINT64_MAX;
  std::array<std::string, ld_page_rows> lines;
  std::array<Row, ld_page_rows> records;
  std::array<double, ld_page_rows> af_page;
  std::unique_ptr<gmat::MappedPlinkPanel> panel;
};



LdMetadataReader& ld_metadata_reader(SEXP x) {
  SEXP cached = R_altrep_data2(x);
  if (cached == R_NilValue) {
    const auto state = R_altrep_data1(x);
    auto reader = std::make_unique<LdMetadataReader>(VECTOR_ELT(state, 0));
    Rcpp::XPtr<LdMetadataReader> pointer(reader.release(), true);
    R_set_altrep_data2(x, pointer);
    cached = pointer;
  }
  return *static_cast<LdMetadataReader*>(R_ExternalPtrAddr(cached));
}

SEXP read_mapped_text(SEXP x, R_xlen_t row) {
  const auto state = R_altrep_data1(x);
  const auto part = INTEGER_ELT(VECTOR_ELT(state, 1), 0);
  const auto field = INTEGER_ELT(VECTOR_ELT(state, 2), 0);
  if (field == ld_disk_field)
    return r_string(ld_metadata_reader(x).field(row + part,
        INTEGER_ELT(VECTOR_ELT(state, 4), 0)));
  return r_string(mapped_panel(x).text(part, static_cast<Text>(field), row));
}

SEXP mapped_text_elt(SEXP x, R_xlen_t row) {
  BEGIN_RCPP
  const auto cached = R_altrep_data2(x);
  return TYPEOF(cached) == STRSXP ? STRING_ELT(cached, row) : read_mapped_text(x, row);
  END_RCPP
}

SEXP materialize_mapped_text(SEXP x) {
  const auto cached = R_altrep_data2(x);
  if (TYPEOF(cached) == STRSXP) return cached;
  const auto size = mapped_vector_length(x);
  Rcpp::Shield<SEXP> values(Rf_allocVector(STRSXP, size));
  for (R_xlen_t i = 0; i < size; ++i) {
    if (i % 65536 == 0) Rcpp::checkUserInterrupt();
    SET_STRING_ELT(values, i, read_mapped_text(x, i));
  }
  R_set_altrep_data2(x, values);
  return values;
}

void* mapped_text_dataptr(SEXP x, Rboolean writable) {
  void* result = nullptr;
  BEGIN_RCPP
  const auto data = materialize_mapped_text(x);
  if (writable) R_set_altrep_data1(x, R_NilValue);
  result = writable ? DATAPTR(data) : const_cast<void*>(DATAPTR_RO(data));
  VOID_END_RCPP
  return result;
}

const void* mapped_text_dataptr_or_null(SEXP x) {
  const auto cached = R_altrep_data2(x);
  return TYPEOF(cached) == STRSXP ? DATAPTR_RO(cached) : nullptr;
}

void mapped_text_set_elt(SEXP x, R_xlen_t row, SEXP value) {
  BEGIN_RCPP
  SET_STRING_ELT(materialize_mapped_text(x), row, value);
  R_set_altrep_data1(x, R_NilValue);
  VOID_END_RCPP
}

SEXP mapped_vector_duplicate(SEXP x, Rboolean) {
  BEGIN_RCPP
  const auto state = R_altrep_data1(x);
  const auto aclass = TYPEOF(x) == STRSXP ? mapped_text_class : mapped_number_class;
  const auto cached = R_altrep_data2(x);
  Rcpp::Shield<SEXP> copy(state == R_NilValue ? Rf_duplicate(cached)
      : R_new_altrep(aclass, state, R_NilValue));
  SHALLOW_DUPLICATE_ATTRIB(copy, x);
  return copy;
  END_RCPP
}

double read_mapped_number(SEXP x, R_xlen_t row) {
  const auto state = R_altrep_data1(x);
  const auto part = INTEGER_ELT(VECTOR_ELT(state, 1), 0);
  const auto field = INTEGER_ELT(VECTOR_ELT(state, 2), 0);
  if (field == source_row_field) return static_cast<double>(row);
  if (field == ld_disk_field)
    return ld_metadata_reader(x).number(row + part, INTEGER_ELT(VECTOR_ELT(state, 4), 0));
  return mapped_panel(x).number(part, static_cast<Number>(field), row);
}

double mapped_number_elt(SEXP x, R_xlen_t row) {
  double value = NA_REAL;
  BEGIN_RCPP
  const auto cached = R_altrep_data2(x);
  value = TYPEOF(cached) == REALSXP ? REAL_ELT(cached, row) : read_mapped_number(x, row);
  VOID_END_RCPP
  return value;
}

R_xlen_t mapped_number_region(SEXP x, R_xlen_t start, R_xlen_t count, double* out) {
  const auto size = std::min(count, mapped_vector_length(x) - start);
  if (size <= 0) return 0;
  BEGIN_RCPP
  const auto cached = R_altrep_data2(x);
  if (TYPEOF(cached) == REALSXP) std::copy_n(REAL_RO(cached) + start, size, out);
  else for (R_xlen_t i = 0; i < size; ++i) out[i] = read_mapped_number(x, start + i);
  VOID_END_RCPP
  return size;
}

void* mapped_number_dataptr(SEXP x, Rboolean writable) {
  void* result = nullptr;
  BEGIN_RCPP
  SEXP data = R_altrep_data2(x);
  if (TYPEOF(data) != REALSXP) {
    const auto size = mapped_vector_length(x);
    Rcpp::Shield<SEXP> values(Rf_allocVector(REALSXP, size));
    for (R_xlen_t i = 0; i < size; ++i) {
      if (i % 65536 == 0) Rcpp::checkUserInterrupt();
      REAL(values)[i] = read_mapped_number(x, i);
    }
    R_set_altrep_data2(x, values);
    data = values;
  }
  if (writable) R_set_altrep_data1(x, R_NilValue);
  result = writable ? DATAPTR(data) : const_cast<void*>(DATAPTR_RO(data));
  VOID_END_RCPP
  return result;
}

const void* mapped_number_dataptr_or_null(SEXP x) {
  const auto cached = R_altrep_data2(x);
  return TYPEOF(cached) == REALSXP ? DATAPTR_RO(cached) : nullptr;
}

SEXP mapped_subset(SEXP x, SEXP indices, SEXP) {
  BEGIN_RCPP
  if (TYPEOF(indices) != INTSXP && TYPEOF(indices) != REALSXP) return nullptr;
  const auto n = XLENGTH(indices);
  const auto size = mapped_vector_length(x);
  const auto index_at = [&](R_xlen_t i) -> double {
    if (TYPEOF(indices) == REALSXP) return REAL_ELT(indices, i);
    const auto value = INTEGER_ELT(indices, i);
    return value == NA_INTEGER ? NA_REAL : static_cast<double>(value);
  };
  const auto type = TYPEOF(x);
  Rcpp::Shield<SEXP> result(Rf_allocVector(type, n));
  const auto cached = R_altrep_data2(x);
  for (R_xlen_t i = 0; i < n; ++i) {
    if (i % 65536 == 0) Rcpp::checkUserInterrupt();
    const auto index = index_at(i);
    if (std::isfinite(index) && index < 1) return nullptr;
    const bool valid = std::isfinite(index) && index >= 1 && index <= size;
    const auto row = valid ? static_cast<R_xlen_t>(index) - 1 : 0;
    if (type == STRSXP) {
      SET_STRING_ELT(result, i, !valid ? NA_STRING :
          TYPEOF(cached) == STRSXP ? STRING_ELT(cached, row) : read_mapped_text(x, row));
    } else {
      REAL(result)[i] = !valid ? NA_REAL :
          TYPEOF(cached) == REALSXP ? REAL_ELT(cached, row) : read_mapped_number(x, row);
    }
  }
  return result;
  END_RCPP
}

std::uint64_t index_value(double value) {
  if (!std::isfinite(value) || value < 0 || value > 9007199254740992.0 ||
      value != std::floor(value))
    Rcpp::stop("Mapped indices must be nonnegative exact integers.");
  return static_cast<std::uint64_t>(value);
}

const std::array<std::string_view, 5> text_fields{"rsids", "chr", "a1", "a2", "cpra"};
const std::array<std::string_view, 12> number_fields{
  "pos", "map", "nmiss", "af", "af1", "af2", "maf", "hom", "het", "n0", "n1", "n2"};

Rcpp::List mapped_column(SEXP path, const Rcpp::IntegerVector& counts,
    R_altrep_class_t type, int field) {
  Rcpp::List result(counts.size());
  for (R_xlen_t i = 0; i < counts.size(); ++i) {
    const int size = counts[i];
    const auto state = Rcpp::List::create(path, static_cast<int>(i), field, size);
    Rcpp::Shield<SEXP> column(R_new_altrep(type, state, R_NilValue));
    result[i] = column;
  }
  return result;
}

Rcpp::CharacterVector read_text_slice(const gmat::MappedPlinkPanel& panel, std::size_t part,
    Text field, std::uint64_t begin, std::uint64_t count) {
  Rcpp::CharacterVector result(count);
  for (std::uint64_t i = 0; i < count; ++i) {
    if (i % 65536 == 0) Rcpp::checkUserInterrupt();
    SET_STRING_ELT(result, i, r_string(panel.text(part, field, begin + i)));
  }
  return result;
}

Rcpp::List describe(const gmat::MappedPlinkPanel& panel, const Rcpp::CharacterVector& path,
    bool resident_rsids) {
  const auto& components = panel.components();
  Rcpp::CharacterVector bed(components.size()), bim(components.size()), fam(components.size());
  Rcpp::IntegerVector mchr(components.size());
  for (std::size_t i = 0; i < components.size(); ++i) {
    bed[i] = components[i].source.bed;
    bim[i] = components[i].source.bim;
    fam[i] = components[i].source.fam;
    if (components[i].marker_count > static_cast<std::uint64_t>(std::numeric_limits<int>::max()))
      Rcpp::stop("Component marker count exceeds gbase's integer range.");
    mchr[i] = static_cast<int>(components[i].marker_count);
  }
  Rcpp::CharacterVector ids(panel.samples().size());
  for (std::size_t i = 0; i < panel.samples().size(); ++i)
    ids[i] = panel.samples()[i].individual_id;
  SEXP path_ref = path;
  auto result = Rcpp::List::create(
    Rcpp::_["study"] = panel.study() ? Rcpp::wrap(*panel.study()) : R_NilValue,
    Rcpp::_["bedfiles"] = bed, Rcpp::_["bimfiles"] = bim, Rcpp::_["famfiles"] = fam,
    Rcpp::_["ids"] = ids, Rcpp::_["n"] = static_cast<double>(ids.size()),
    Rcpp::_["mchr"] = mchr, Rcpp::_["nchr"] = static_cast<int>(components.size()),
    Rcpp::_["path"] = path);
  if (resident_rsids) {
    Rcpp::List rsids(components.size());
    for (std::size_t i = 0; i < components.size(); ++i)
      rsids[i] = read_text_slice(panel, i, Text::rsids, 0, components[i].marker_count);
    result.push_back(rsids, "rsids");
  }
  for (std::size_t i = 0; i < text_fields.size(); ++i) {
    if (resident_rsids && text_fields[i] == "rsids") continue;
    result.push_back(mapped_column(path_ref, mchr, mapped_text_class, static_cast<int>(i)),
                     std::string(text_fields[i]));
  }
  for (std::size_t i = 0; i < number_fields.size(); ++i)
    result.push_back(mapped_column(path_ref, mchr, mapped_number_class, static_cast<int>(i)),
                     std::string(number_fields[i]));
  result.push_back(mapped_column(path_ref, mchr, mapped_number_class, source_row_field),
                   "source_marker_indices_0based");
  return result;
}

class ExactHwe {
 public:
  explicit ExactHwe(std::uint64_t samples) : base_(samples + 1), scratch_(samples + 1) {}

  double operator()(std::uint64_t n0, std::uint64_t n1, std::uint64_t n2) {
    const auto rare = std::min(n0, n2);
    const auto common = std::max(n0, n2);
    if (rare == 0 && n1 == 0) return 1;
    if (base_ > (std::uint64_t{1} << 21)) return compute(rare, n1, common);
    const auto key = (rare * base_ + n1) * base_ + common;
    const auto found = cache_.find(key);
    if (found != cache_.end()) return found->second;
    const auto value = compute(rare, n1, common);
    if (cache_.size() < 262144) cache_.emplace(key, value);
    return value;
  }

 private:
  // Same two-sided conditional test and relative tie tolerance as gfilter.R.
  double compute(std::uint64_t rare, std::uint64_t het, std::uint64_t common) {
    const double total = static_cast<double>(rare + het + common);
    const auto copies = 2 * rare + het;
    auto midpoint = static_cast<std::uint64_t>(copies * (2 * total - copies) / (2 * total));
    midpoint += (copies - midpoint) % 2;
    scratch_[midpoint] = 1;
    auto r = (copies - midpoint) / 2;
    auto c = static_cast<std::uint64_t>(total) - midpoint - r;
    for (auto h = midpoint; h >= 2; h -= 2, ++r, ++c)
      scratch_[h - 2] = scratch_[h] * h * (h - 1) / (4.0 * (r + 1) * (c + 1));
    r = (copies - midpoint) / 2;
    c = static_cast<std::uint64_t>(total) - midpoint - r;
    for (auto h = midpoint; h + 2 <= copies; h += 2, --r, --c)
      scratch_[h + 2] = scratch_[h] * 4 * r * c / ((h + 2.0) * (h + 1));
    long double sum = 0;
    for (auto h = copies % 2; h <= copies; h += 2) sum += scratch_[h];
    const double normalizer = static_cast<double>(sum);
    const double cutoff = (scratch_[het] / normalizer) * (1 + 1e-12);
    long double p = 0;
    for (auto h = copies % 2; h <= copies; h += 2) {
      const auto probability = scratch_[h] / normalizer;
      if (probability <= cutoff) p += probability;
    }
    return std::min(1.0, static_cast<double>(p));
  }

  std::uint64_t base_;
  std::vector<double> scratch_;
  std::unordered_map<std::uint64_t, double> cache_;
};

bool nucleotide(std::string_view allele) {
  return allele.size() == 1 && std::string_view("ACGT").find(allele.front()) != std::string_view::npos;
}

bool ambiguous_snp(char a, char b) {
  return (a == 'A' && b == 'T') || (a == 'T' && b == 'A') ||
         (a == 'C' && b == 'G') || (a == 'G' && b == 'C');
}

} // namespace

// [[Rcpp::init]]
void init_mapped_text(DllInfo* dll) {
  mapped_text_class = R_make_altstring_class("mapped_text", "gbase", dll);
  R_set_altrep_Length_method(mapped_text_class, mapped_vector_length);
  R_set_altrep_Serialized_state_method(mapped_text_class, mapped_vector_state);
  R_set_altrep_Unserialize_method(mapped_text_class, mapped_text_restore);
  R_set_altrep_Duplicate_method(mapped_text_class, mapped_vector_duplicate);
  R_set_altvec_Dataptr_method(mapped_text_class, mapped_text_dataptr);
  R_set_altvec_Dataptr_or_null_method(mapped_text_class, mapped_text_dataptr_or_null);
  R_set_altvec_Extract_subset_method(mapped_text_class, mapped_subset);
  R_set_altstring_Elt_method(mapped_text_class, mapped_text_elt);
  R_set_altstring_Set_elt_method(mapped_text_class, mapped_text_set_elt);

  mapped_number_class = R_make_altreal_class("mapped_number", "gbase", dll);
  R_set_altrep_Length_method(mapped_number_class, mapped_vector_length);
  R_set_altrep_Serialized_state_method(mapped_number_class, mapped_vector_state);
  R_set_altrep_Unserialize_method(mapped_number_class, mapped_number_restore);
  R_set_altrep_Duplicate_method(mapped_number_class, mapped_vector_duplicate);
  R_set_altvec_Dataptr_method(mapped_number_class, mapped_number_dataptr);
  R_set_altvec_Dataptr_or_null_method(mapped_number_class, mapped_number_dataptr_or_null);
  R_set_altvec_Extract_subset_method(mapped_number_class, mapped_subset);
  R_set_altreal_Elt_method(mapped_number_class, mapped_number_elt);
  R_set_altreal_Get_region_method(mapped_number_class, mapped_number_region);
}

// Compare references without touching any marker data. Ordinary vectors and
// writable/materialized copies are checked by the caller when necessary.
// [[Rcpp::export]]
bool cpp_gbase_same_mapped_column(SEXP a, SEXP b) {
  if (TYPEOF(a) != TYPEOF(b)) return false;
  const auto type = TYPEOF(a) == STRSXP ? mapped_text_class : mapped_number_class;
  if (!ALTREP(a) || !ALTREP(b) || !R_altrep_inherits(a, type) ||
      !R_altrep_inherits(b, type) || ATTRIB(a) != R_NilValue) return false;
  const auto left = R_altrep_data1(a), right = R_altrep_data1(b);
  if (left == R_NilValue || right == R_NilValue) return false;
  // Older companion references carried a fifth element for read mode.
  for (int i = 0; i < 4; ++i)
    if (!R_compute_identical(VECTOR_ELT(left, i), VECTOR_ELT(right, i), 0)) return false;
  if (INTEGER_ELT(VECTOR_ELT(left, 2), 0) == ld_disk_field)
    return INTEGER_ELT(VECTOR_ELT(left, 4), 0) == INTEGER_ELT(VECTOR_ELT(right, 4), 0);
  return true;
}

// [[Rcpp::export]]
Rcpp::List cpp_gbase_mapped_prepare(Rcpp::CharacterVector path, Rcpp::CharacterVector bed,
    Rcpp::CharacterVector bim, Rcpp::CharacterVector fam, SEXP study) {
  if (bed.size() != bim.size() || bed.size() != fam.size())
    Rcpp::stop("PLINK path vectors must have equal lengths.");
  std::vector<gmat::MappedPlinkSource> sources;
  sources.reserve(bed.size());
  for (R_xlen_t i = 0; i < bed.size(); ++i)
    sources.push_back({Rcpp::as<std::string>(bed[i]), Rcpp::as<std::string>(bim[i]),
                       Rcpp::as<std::string>(fam[i])});
  std::optional<std::string> label;
  if (study != R_NilValue) label = Rcpp::as<std::string>(study);
  if (path.size() == 0) path = Rcpp::wrap(gmat::write_plink_companions(sources, label));
  else gmat::write_mapped_plink_panel(Rcpp::as<std::string>(path[0]), sources, label);
  return describe(*gbase_plink_panel(path), path, true);
}

// [[Rcpp::export]]
Rcpp::List cpp_gbase_mapped_source_resources(Rcpp::CharacterVector path) {
  const auto holder = gbase_plink_panel(path);
  const auto& panel = *holder;
  Rcpp::List result(panel.components().size());
  for (std::size_t i = 0; i < panel.components().size(); ++i) {
    const auto& component = panel.components()[i];
    const auto& source = component.source;
    const auto fam = gmat::read_plink_fam(source.fam);
    if (fam.size() != panel.samples().size() ||
        !std::equal(fam.begin(), fam.end(), panel.samples().begin(), [](const auto& a, const auto& b) {
          return a.family_id == b.family_id && a.individual_id == b.individual_id;
        }))
      Rcpp::stop("Source FAM no longer matches mapped panel order.");
    Rcpp::CharacterVector families(fam.size());
    for (std::size_t row = 0; row < fam.size(); ++row) families[row] = fam[row].family_id;
    result[i] = Rcpp::List::create(
      Rcpp::_["paths"] = Rcpp::List::create(Rcpp::_["bed"] = source.bed,
        Rcpp::_["bim"] = source.bim, Rcpp::_["fam"] = source.fam),
      Rcpp::_["samples"] = Rcpp::List::create(Rcpp::_["family_id"] = families));
  }
  return result;
}

// [[Rcpp::export]]
Rcpp::List cpp_gbase_mapped_open(Rcpp::CharacterVector path, bool resident_rsids) {
  return describe(*gbase_plink_panel(path), path, resident_rsids);
}

// [[Rcpp::export]]
Rcpp::List cpp_gbase_mapped_read(Rcpp::CharacterVector path, Rcpp::CharacterVector fields,
    double component, double start, double count) {
  const auto holder = gbase_plink_panel(path);
  const auto& panel = *holder;
  const auto part = index_value(component);
  const auto begin = index_value(start);
  const auto size = index_value(count);
  if (part >= panel.components().size()) Rcpp::stop("Invalid mapped component.");
  const auto markers = panel.components()[part].marker_count;
  if (begin > markers || size > markers - begin || size > R_XLEN_T_MAX)
    Rcpp::stop("Requested mapped rows are out of range.");
  Rcpp::List result(fields.size());
  result.attr("names") = fields;
  for (R_xlen_t j = 0; j < fields.size(); ++j) {
    const auto name = Rcpp::as<std::string>(fields[j]);
    const auto text = std::find(text_fields.begin(), text_fields.end(), name);
    if (text != text_fields.end()) {
      result[j] = read_text_slice(panel, part, static_cast<Text>(text - text_fields.begin()), begin, size);
    } else {
      const auto numeric = std::find(number_fields.begin(), number_fields.end(), name);
      if (numeric == number_fields.end()) Rcpp::stop("Unknown mapped marker field: " + name);
      Rcpp::NumericVector out(size);
      for (std::uint64_t i = 0; i < size; ++i) {
        if (i % 65536 == 0) Rcpp::checkUserInterrupt();
        out[i] = panel.number(part, static_cast<Number>(numeric - number_fields.begin()), begin + i);
      }
      result[j] = out;
    }
  }
  return result;
}

// [[Rcpp::export]]
Rcpp::List cpp_gbase_mapped_filter(Rcpp::CharacterVector path, Rcpp::NumericVector thresholds,
    bool ambiguous, bool indels, Rcpp::NumericVector mhc, Rcpp::NumericVector info) {
  const auto holder = gbase_plink_panel(path);
  const auto& panel = *holder;
  const auto n = panel.samples().size();
  const double maf_limit = thresholds[0], missing_limit = thresholds[1], hwe_limit = thresholds[2];
  const double info_limit = thresholds[3];
  const bool use_hwe = !std::isnan(hwe_limit), use_info = !std::isnan(info_limit);
  ExactHwe exact(use_hwe ? n : 0);
  std::uint64_t total = 0;
  for (const auto& part : panel.components()) total += part.marker_count;
  if (use_info && static_cast<std::uint64_t>(info.size()) != total)
    Rcpp::stop("Mapped INFO does not cover all markers.");
  std::vector<std::uint64_t> retained((total + 63) / 64, 0);
  std::array<std::uint64_t, 7> exclusions{};
  std::uint64_t kept = 0, row = 0;
  for (std::size_t c = 0; c < panel.components().size(); ++c) {
    for (std::uint64_t i = 0; i < panel.components()[c].marker_count; ++i, ++row) {
      if (i % 65536 == 0) Rcpp::checkUserInterrupt();
      const auto number = [&](Number field) { return panel.number(c, field, i); };
      const double missing = number(Number::nmiss);
      if (missing == n) Rcpp::stop("A marker has no observed summary genotypes.");
      std::array<bool, 7> exclude{};
      exclude[0] = !std::isnan(maf_limit) && number(Number::maf) <= maf_limit;
      exclude[1] = missing / n > missing_limit;
      if (use_hwe) {
        const auto n0 = static_cast<std::uint64_t>(number(Number::n0));
        const auto n1 = static_cast<std::uint64_t>(number(Number::n1));
        const auto n2 = static_cast<std::uint64_t>(number(Number::n2));
        if (n0 + n1 + n2 + missing != n)
          Rcpp::stop("Mapped genotype counts do not equal the recorded sample count.");
        exclude[2] = exact(n0, n1, n2) < hwe_limit;
      }
      exclude[3] = use_info && info[row] < info_limit;
      if (ambiguous || indels) {
        const auto a = panel.text(c, Text::a1, i), b = panel.text(c, Text::a2, i);
        const bool snp = nucleotide(a) && nucleotide(b);
        exclude[4] = ambiguous && snp && ambiguous_snp(a.front(), b.front());
        exclude[5] = indels && !snp;
      }
      if (mhc.size()) {
        const auto chr = panel.text(c, Text::chr, i);
        const auto pos = number(Number::pos);
        exclude[6] = (chr == "6" || chr == "chr6") && pos >= mhc[0] && pos <= mhc[1];
      }
      bool any = false;
      for (std::size_t k = 0; k < exclude.size(); ++k) {
        exclusions[k] += exclude[k];
        any |= exclude[k];
      }
      if (!any) {
        retained[row / 64] |= std::uint64_t{1} << (row % 64);
        ++kept;
      }
    }
  }
  Rcpp::CharacterVector rsids(kept);
  std::uint64_t out = 0;
  row = 0;
  for (std::size_t c = 0; c < panel.components().size(); ++c) {
    for (std::uint64_t i = 0; i < panel.components()[c].marker_count; ++i, ++row) {
      if (i % 65536 == 0) Rcpp::checkUserInterrupt();
      if ((retained[row / 64] >> (row % 64)) & 1u)
        SET_STRING_ELT(rsids, out++, r_string(panel.text(c, Text::rsids, i)));
    }
  }
  return Rcpp::List::create(Rcpp::_["rsids"] = rsids,
      Rcpp::_["evaluated"] = static_cast<double>(total),
      Rcpp::_["counts"] = Rcpp::NumericVector(exclusions.begin(), exclusions.end()));
}


// [[Rcpp::export]]
void cpp_gbase_index_ld_markers(std::string path, std::string output, int size) {
  auto input = ld_open(path);
  std::ofstream index(std::filesystem::u8path(output), std::ios::binary);
  std::string line;
  if (!index || !std::getline(input, line)) Rcpp::stop("Cannot index sparse-LD marker metadata.");
  if (!line.empty() && line.back() == '\r') line.pop_back();
  if (line != "index\tmarker_id\tchromosome\tposition_bp\tallele1\tallele2\tcomponent_index\tsource_marker_index")
    Rcpp::stop("Invalid sparse-LD marker table header.");
  for (int row = 0; row < size; ++row) {
    if (row % ld_page_rows == 0) {
      const auto offset = static_cast<std::uint64_t>(input.tellg());
      index.write(reinterpret_cast<const char*>(&offset), sizeof(offset));
      if (row % 65536 == 0) Rcpp::checkUserInterrupt();
    }
    if (!std::getline(input, line)) Rcpp::stop("Truncated sparse-LD marker table.");
  }
  if (std::getline(input, line) || !input.eof()) Rcpp::stop("Sparse-LD marker table size changed.");
  index.close();
  if (!index) Rcpp::stop("Cannot write sparse-LD marker index.");
}

// [[Rcpp::export]]
SEXP cpp_gbase_ld_column(Rcpp::List spec, int field, int start, int size) {
  const auto type = field == ld_id || field == ld_chr || field == ld_a1 || field == ld_a2
    ? mapped_text_class : mapped_number_class;
  const auto state = Rcpp::List::create(spec, start, ld_disk_field, size, field);
  return R_new_altrep(type, state, R_NilValue);
}
