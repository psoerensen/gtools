#include <Rcpp.h>
#include <gmat/plink_subset.hpp>
#include <zlib.h>

#include <array>
#include <filesystem>
#include <istream>
#include <stdexcept>

namespace {
class CatalogBuffer : public std::streambuf {
 public:
  explicit CatalogBuffer(const std::string& path) {
#ifdef _WIN32
    file_ = gzopen_w(std::filesystem::u8path(path).c_str(), "rb");
#else
    file_ = gzopen(path.c_str(), "rb");
#endif
    if (!file_) throw std::runtime_error("Cannot open allele catalog: " + path);
  }

  ~CatalogBuffer() override { gzclose(file_); }

 protected:
  int_type underflow() override {
    if (gptr() && gptr() < egptr()) return traits_type::to_int_type(*gptr());
    const int n = gzread(file_, buffer_.data(), buffer_.size());
    if (n <= 0) {
      int status = Z_OK;
      const char* message = gzerror(file_, &status);
      if (n < 0 || (status != Z_OK && status != Z_STREAM_END))
        throw std::runtime_error(std::string("Cannot read allele catalog: ") + message);
      return traits_type::eof();
    }
    setg(buffer_.data(), buffer_.data(), buffer_.data() + n);
    return traits_type::to_int_type(*gptr());
  }

 private:
  gzFile file_;
  std::array<char, 65536> buffer_;
};

std::vector<std::string_view> views(const Rcpp::CharacterVector& values, const char* name) {
  std::vector<std::string_view> result;
  result.reserve(values.size());
  // A mapped character vector can generate strings on demand. Materialize
  // that input once so all borrowed string bytes stay rooted during the call.
  const auto strings = static_cast<const SEXP*>(DATAPTR_RO(values));
  for (R_xlen_t i = 0; i < values.size(); ++i) {
    const auto value = strings[i];
    if (value == NA_STRING) Rcpp::stop("%s contains NA", name);
    result.emplace_back(CHAR(value), LENGTH(value));
  }
  return result;
}
} // namespace

// [[Rcpp::export]]
Rcpp::List cpp_gbase_write_bed_subset(std::string bed, std::string bim, std::string fam,
    std::string bed_out, std::string bim_out, std::string fam_out,
    Rcpp::CharacterVector rsids, Rcpp::CharacterVector ids) {
  const auto result = gmat::write_plink_subset({bed, bim, fam}, {bed_out, bim_out, fam_out},
      views(rsids, "rsids"), views(ids, "ids"));
  return Rcpp::List::create(Rcpp::_["n_markers"] = static_cast<double>(result.marker_count),
      Rcpp::_["n_samples"] = static_cast<double>(result.sample_count),
      Rcpp::_["missing_rsids"] = result.missing_rsids);
}

// [[Rcpp::export]]
double cpp_gbase_recode_plink(std::string bed, std::string bim, std::string fam,
    std::string bed_out, std::string bim_out, std::string fam_out, std::string reference) {
  CatalogBuffer buffer(reference);
  std::istream catalog(&buffer);
  catalog.exceptions(std::ios::badbit);
  const auto result = gmat::recode_plink({bed, bim, fam}, {bed_out, bim_out, fam_out}, catalog);
  return static_cast<double>(result.swapped_count);
}
