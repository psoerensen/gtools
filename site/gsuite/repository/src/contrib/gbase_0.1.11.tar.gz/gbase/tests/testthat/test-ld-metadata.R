test_that("legacy sparse-LD metadata can be moved to disk without rebuilding", {
  fixture <- write_tiny_plink(cbind(c(0, 1, 0, 2), c(2, 0, 1, 1)), c("a", "b"))
  bed <- fixture$paths[["bed"]]
  prefix <- tools::file_path_sans_ext(bed)
  on.exit({unlink_sparse_ld(prefix); unlink_tiny_plink(fixture)})
  panel <- gprep(bedfiles = bed)
  prepared <- gprep(panel, task = "sparseld", progress = FALSE)
  legacy <- prepared
  legacy$sparseLD$marker_metadata <- read_ld_metadata(prepared)
  for (field in c("marker_indices_0based", "af", "cls"))
    legacy$sparseLD[[field]] <- lapply(prepared$sparseLD[[field]], function(x) x[seq_along(x)])
  legacy$sparseLD$metadata_storage <- NULL
  old <- unserialize(serialize(legacy, NULL))
  files <- unlist(old$ldfiles, use.names = FALSE)
  hashes <- tools::md5sum(files)
  timestamps <- file.info(files)$mtime
  compact <- compact_ld_Glist(old)
  saved <- unserialize(serialize(compact, NULL))
  expect_identical(tools::md5sum(files), hashes)
  expect_identical(file.info(files)$mtime, timestamps)
  expect_identical(saved$rsids, old$rsids)
  expect_identical(saved$rsidsLD, old$rsidsLD)
  expect_identical(saved$ldscores, old$ldscores)
  expect_identical(saved$ldfiles, old$ldfiles)
  expect_null(saved$sparseLD$metadata_storage$af)
  expect_identical(read_ld_metadata(saved, c(2L, 1L), c("allele1", "base_pair_position")),
    data.frame(allele1 = c("A", "A"), base_pair_position = c(200, 100)))
  expect_identical(read_ld_metadata(saved), old$sparseLD$marker_metadata)
  expect_silent(verify_ld(saved))
})
