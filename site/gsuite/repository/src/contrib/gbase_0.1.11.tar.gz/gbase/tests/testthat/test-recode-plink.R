test_that("recode swaps only reversed BED records and preserves physical order", {
  input <- matrix(c(0, 1, 2, NA, 0, 2, NA, 0, 2, 1), nrow = 5)
  panel <- write_tiny_plink(input, c("rs2", "rs1"))
  root <- tempfile("plink-recode-")
  dir.create(root)
  on.exit({
    unlink_tiny_plink(panel)
    unlink(root, recursive = TRUE)
  })
  gl <- gprep(bedfiles = panel$paths[["bed"]])
  reference <- file.path(root, "markers.csv.gz")
  write_catalog <- function(pos, alleles = c("G", "A")) {
    conn <- gzfile(reference, "wt")
    on.exit(close(conn))
    writeLines(c("rsids,chr,pos,ea,nea", paste("rs2,1,100,A,G"),
      paste("rs1", "chr1", pos, alleles[1], alleles[2], sep = ",")), conn)
  }
  prefix <- file.path(root, "aligned")
  write_catalog(201L)
  expect_error(gprep(gl, task = "recode", allele_reference = reference,
    out_prefix = prefix), "coordinate mismatch for rs1")
  expect_false(file.exists(paste0(prefix, ".bed")))
  write_catalog(200L, c("C", "G"))
  expect_error(gprep(gl, task = "recode", allele_reference = reference,
    out_prefix = prefix), "allele mismatch for rs1")
  write_catalog(200L)
  aligned <- gprep(gl, task = "recode", allele_reference = reference, out_prefix = prefix)
  expect_identical(aligned$rsids, gl$rsids)
  expect_identical(aligned$ids, gl$ids)
  expect_identical(readLines(aligned$famfiles), readLines(gl$famfiles))
  expect_identical(as.character(aligned$a1[[1]]), c("A", "G"))
  expect_identical(as.character(aligned$a2[[1]]), c("G", "A"))
  expect_true(all(file.exists(aligned$gstatfiles)))
  input[, 2L] <- 2 - input[, 2L]
  expected <- write_tiny_bed(input, file.path(root, "expected.bed"))
  expect_identical(readBin(aligned$bedfiles, "raw", n = 7L),
    readBin(expected, "raw", n = 7L))
  expect_identical(gprep(aligned, task = "recode", allele_reference = reference), aligned)
  expect_false(file.exists(file.path(root, "aligned.aligned.bed")))
})
