test_that("same-stem companions preserve Glist and use ordinary binary reads", {
  a <- write_tiny_plink(cbind(c(0, 1, 2, NA, 2), c(0, 1, 1, 2, 0),
    c(2, 0, 1, 0, 2)), c("z", "b", "a"), "1")
  b <- write_tiny_plink(cbind(c(0, 1, 2, 0, 1), c(2, 1, 0, 2, 0)),
    c("y", "c"), "2")
  bed <- c(a$paths[["bed"]], b$paths[["bed"]])
  companions <- sub("\\.bed$", ".ext", bed)
  legacy <- sub("\\.bed$", ".gstat.bin", bed)
  prefix <- tempfile("gstat-ld-")
  on.exit({
    unlink_tiny_plink(a)
    unlink_tiny_plink(b)
    unlink(c(companions, legacy))
    unlink_sparse_ld(prefix)
  })
  plain <- gprep(bedfiles = bed, companion = NULL, study = "fixture")
  Glist <- gprep(bedfiles = bed, study = plain$study)
  expect_identical(Glist$gstatfiles, normalizePath(companions, winslash = "/"))
  expect_identical(Glist$rsids, plain$rsids)
  expect_identical(Glist$ids, plain$ids)
  expect_null(Glist$access)
  expect_identical(Glist$bedfiles, plain$bedfiles)
  expect_identical(gfilter(Glist, verbose = FALSE), gfilter(plain, verbose = FALSE))
  expect_silent(validate_Glist(Glist))
  fields <- c("rsids", "cpra", "chr", "a1", "a2", "pos", "map", "af", "af1",
    "af2", "maf", "hom", "het", "nmiss", "n0", "n1", "n2")
  for (i in 1:2) {
    expected <- lapply(plain[fields], `[[`, i)
    expect_identical(read_mapped_Glist(Glist, fields, i), expected)
    expect_identical(lapply(Glist[fields], function(x) x[[i]][seq_along(expected$rsids)]), expected)
  }
  reloaded <- unserialize(serialize(Glist, NULL))
  expect_identical(reloaded$cpra[[2]][1], plain$cpra[[2]][1])
  reopened <- open_mapped_Glist(companions)
  expect_identical(reopened$rsids, plain$rsids)
  expect_identical(reopened$af[[1]][2:3], plain$af[[1]][2:3])
  expect_true(all(file.copy(companions, legacy)))
  older <- open_mapped_Glist(legacy)
  expect_identical(older$rsids, plain$rsids)
  expect_identical(read_mapped_Glist(older, "maf"), list(maf = plain$maf[[1]]))
  expect_error(gprep(Glist, task = "sparseld", rsids = c("a", "z")),
    "multiple BED files requires")
  messages <- capture.output(
    ld <- gprep(Glist, task = "sparseld", rsids = c("a", "z", "c"),
      out_prefix = prefix, block_size = 1L),
    type = "message")
  expect_match(messages[1L], "Computing LD for 3 markers")
  expect_match(messages[2L], "Chr 1 complete.*2 / 3 rows written")
  expect_match(messages[3L], "Chr 2 complete.*3 / 3 rows written")
  expect_match(messages[4L], "Validating CSR files and computing LD scores")
  expect_match(messages[5L], "Done")
  expect_length(messages, 5L)
  expect_true(file.exists(paste0(prefix, ".meta.txt")))
  expect_identical(ld$rsidsLD, list(c("z", "a"), "c"))
  expect_silent(verify_ld(ld))
  expected_ld <- getLD(plain, c("a", "z"))
  observed_ld <- getLD(Glist, c("a", "z"))
  attr(expected_ld, "timings_seconds") <- attr(observed_ld, "timings_seconds") <- NULL
  expect_equal(observed_ld, expected_ld, tolerance = 1e-14)
  expect_error(gprep(bedfiles = bed, companion = "mmap"), "binary")
  expect_identical(gprep(bedfiles = bed), Glist)
  expect_identical(gprep(bedfiles = bed, companion = "binary"), Glist)
  expect_error(gprep(bedfiles = bed, study = "different"), "supplied study")
  expect_error(open_mapped_Glist(companions, access = "mmap"), "unused argument")
  expect_error(read_mapped_Glist(Glist, "maf", count = 1, access = "mmap"), "unused argument")
  previous <- Glist
  previous$access <- "mmap"
  expect_silent(validate_Glist(unserialize(serialize(previous, NULL))))
  cat("\n", file = a$paths[["bim"]], append = TRUE)
  expect_error(read_mapped_Glist(Glist, "maf", count = 1), "companion source changed")
  expect_identical(match("a", Glist$rsids[[1]]), 3L)
  expect_identical(read_mapped_Glist(Glist, "rsids", count = 1), list(rsids = "z"))
})

test_that("binary companion preparation rejects duplicate rsids across buffers", {
  m <- 8200L
  rsids <- paste0("marker", seq_len(m))
  rsids[m] <- rsids[1]
  # Three samples use one packed byte per marker.
  bed <- tempfile(fileext = ".bed")
  bim <- sub("\\.bed$", ".bim", bed)
  fam <- sub("\\.bed$", ".fam", bed)
  companion <- sub("\\.bed$", ".ext", bed)
  on.exit(unlink(c(bed, bim, fam, companion)))
  writeBin(as.raw(c(0x6c, 0x1b, 0x01, rep(0, m))), bed)
  writeLines(paste(1L, rsids, 0L, seq_len(m), "A", "G"), bim)
  writeLines(paste("F", 1:3, 0L, 0L, 0L, -9L), fam)
  expect_error(gprep(bedfiles = bed, companion = "binary"), "globally unique")
  expect_false(file.exists(companion))
})
