test_that("integer set scores preserve dense estimates and jackknife uncertainty", {
  markers <- paste0("m", seq_len(90))
  sets <- split(markers, rep(c("chr1", "chr2", "chr3"), each = 30))
  ld <- setNames(1 + seq_len(90) %% 13 / 5, markers)
  compact <- gcorr_set_scores(markers, ld[rev(markers)], lapply(sets, rev))
  expect_identical(compact$group, rep(1:3, each = 30))
  expect_identical(compact$scores, unname(ld))
  dense <- matrix(0, length(markers), 3, dimnames = list(markers, names(sets)))
  dense[cbind(seq_along(markers), compact$group)] <- compact$scores
  n <- 900 + seq_len(90)
  z <- sqrt(1.1 + n * ld * rep(c(1e-5, 2e-5, 3e-5), each = 30))
  summary <- function(z) data.frame(rsids = markers, chr = "1",
    pos = seq_along(markers), ea = "A", nea = "G", z = unname(z), n = n)
  statistics <- list(first = summary(z), second = summary(z * 1.02))
  statistics$first$z[1] <- statistics$second$z[1] <- 10
  blocks <- setNames(rep(paste0("b", 1:6), 15), markers)
  counts <- setNames(rep(3000, 3), names(sets))
  overlap <- diag(unname(counts)); dimnames(overlap) <- list(names(sets), names(sets))
  for (stat in list(statistics$first, statistics)) {
    for (intercept in c("free", "fixed_one")) {
      fit <- function(scores) gcorr_ldsc_partitioned(stat, scores, ld, counts, blocks,
        annotation_overlap = overlap, reference_sample_size = 503,
        reference_marker_count = sum(counts), marginal_intercept = intercept,
        overlap_intercept = if (is.list(stat) && !is.data.frame(stat)) 0 else NULL,
        maximum_chi_square = 5)
      expected <- fit(dense); actual <- fit(compact)
      expect_equal(actual$estimates, expected$estimates, tolerance = 1e-10)
      expect_equal(actual$matrices, expected$matrices, tolerance = 1e-10)
      expect_identical(actual$diagnostics, expected$diagnostics)
      expect_identical(actual$diagnostics$used_marker_ids, markers[-1])
    }
  }
})

test_that("compact scores reject ambiguous membership and shifted marker order", {
  markers <- paste0("m", 1:8)
  ld <- setNames(seq(1, 2, length.out = 8), markers)
  sets <- list(a = markers[1:4], b = markers[5:8])
  expect_error(gcorr_set_scores(markers, ld, list(a = markers[1:5], b = markers[5:8])), "disjoint")
  expect_error(gcorr_set_scores(markers, ld, list(a = markers[1:4])), "covering")
  expect_error(gcorr_set_scores(markers, ld, list(a = c(markers, "missing"))), "exist")
  scores <- gcorr_set_scores(markers, ld, sets)
  expect_error(gcorr:::.gcorr_partitioned_scores(scores, rev(markers)), "matching marker order")
  scores$group[1] <- 0L
  expect_error(gcorr:::.gcorr_partitioned_scores(scores, markers), "valid integer groups")
})
