make_summary <- function(trait, z, markers) {
    data.frame(
      rsids = markers,
      chr = rep("1", length(markers)),
      pos = seq_along(markers) * 100,
      ea = rep("A", length(markers)),
      nea = rep("G", length(markers)),
      z = z,
      n = rep(1000, length(markers)),
      stringsAsFactors = FALSE
    )
}

test_that("focused LDSC returns deterministic genetic correlation", {
  markers <- paste0("rs", seq_len(20))
  scores <- setNames(seq(1, 2.9, length.out = 20), markers)
  z <- sqrt(1 + 1000 * 0.2 / 20000 * scores)
  blocks <- setNames(rep(paste0("b", 1:5), each = 4), markers)
  fit <- gcorr_ldsc(list(
    `trait-a` = make_summary("trait-a", z, markers),
    `trait-b` = make_summary("trait-b", z, markers)),
    scores, blocks, overlap_intercept = 1, marker_count = 20000)
  expect_s3_class(fit, "gcorr_ldsc_fit")
  expect_equal(fit$estimates$estimate[fit$estimates$quantity == "rg"], 1,
    tolerance = 1e-10)
  expect_equal(fit$estimates$estimate[fit$estimates$quantity == "cov"], 0.2,
    tolerance = 1e-10)
  expect_identical(fit$diagnostics$used_marker_ids, markers)
  expect_equal(fit$diagnostics$blocks_used, 5)
  expect_output(print(fit), "rg: 1")
})

test_that("focused LDSC rejects implicit alignment and incomplete blocks", {
  markers <- paste0("rs", seq_len(8))
  scores <- setNames(seq(1, 2, length.out = 8), markers)
  blocks <- setNames(rep(c("a", "b"), each = 4), markers)
  first <- make_summary("trait-a", rep(2, 8), markers)
  second <- make_summary("trait-b", rep(2, 8), markers)
  second$ea[[1L]] <- "T"
  expect_error(gcorr_ldsc(list(`trait-a`=first,`trait-b`=second), scores, blocks, 0), "allele orientation")
  expect_error(gcorr_ldsc(list(`trait-a`=first,`trait-b`=make_summary("trait-b", rep(2, 8), markers)),
    scores, setNames(rep("one", 8), markers), 0), "at least two")
})

test_that("ordinary LDSC supports one or more traits through one contract", {
  markers <- paste0("rs", seq_len(20))
  scores <- setNames(seq(1, 2.9, length.out = 20), markers)
  z <- sqrt(1 + 1000 * 0.2 / 20000 * scores)
  blocks <- setNames(rep(paste0("b", 1:5), each = 4), markers)
  one <- gcorr_ldsc(make_summary("one", z, markers), scores, blocks,
    marker_count = 20000)
  expect_equal(one$estimates$estimate[one$estimates$quantity == "h2"], .2,
    tolerance = 1e-10)
  three <- gcorr_ldsc(list(
    one = make_summary("one", z, markers),
    two = make_summary("two", z, markers),
    three = make_summary("three", z, markers)), scores, blocks,
    overlap_intercept = 1, marker_count = 20000)
  expect_equal(dim(three$matrices$genetic_correlation), c(3L, 3L))
  expect_equal(unname(three$matrices$genetic_correlation), matrix(1, 3, 3),
    tolerance = 1e-10)
})

partitioned_fixture <- function() {
  markers <- paste0("rs", seq_len(30))
  index <- seq_len(30)
  annotation_ld_scores <- cbind(
    baseline = 1 + index / 30,
    coding = 0.25 + ((index * 7) %% 17) / 20
  )
  rownames(annotation_ld_scores) <- markers
  tau <- c(1e-5, 2e-5)
  z <- sqrt(1 + 1000 * drop(annotation_ld_scores %*% tau))
  list(
    markers = markers,
    annotation_ld_scores = annotation_ld_scores,
    weight_ld_scores = setNames(rowSums(annotation_ld_scores), markers),
    annotation_sums = c(baseline = 10000, coding = 5000),
    blocks = setNames(rep(paste0("b", 1:5), each = 6), markers),
    z = z
  )
}

test_that("partitioned LDSC exposes annotation effects for one trait", {
  fixture <- partitioned_fixture()
  fit <- gcorr_ldsc_partitioned(
    make_summary("one", fixture$z, fixture$markers),
    fixture$annotation_ld_scores, fixture$weight_ld_scores,
    fixture$annotation_sums, fixture$blocks,
    reference_sample_size = 500)
  expect_s3_class(fit, "gcorr_ldsc_partitioned_fit")
  tau <- fit$estimates[fit$estimates$quantity == "tau", ]
  expect_identical(tau$component, c("baseline", "coding"))
  expect_equal(tau$estimate, c(1e-5, 2e-5), tolerance = 1e-10)
  expect_equal(fit$estimates$estimate[fit$estimates$quantity == "h2"], .2,
    tolerance = 1e-10)
  expect_identical(fit$diagnostics$used_marker_ids, fixture$markers)
})

test_that("partitioned LDSC handles multiple traits and overlap metadata", {
  fixture <- partitioned_fixture()
  overlap <- matrix(c(10000, 3000, 3000, 5000), 2, 2,
    dimnames = list(names(fixture$annotation_sums), names(fixture$annotation_sums)))
  statistics <- list(
    one = make_summary("one", fixture$z, fixture$markers),
    two = make_summary("two", fixture$z, fixture$markers),
    three = make_summary("three", fixture$z, fixture$markers))
  fit <- gcorr_ldsc_partitioned(
    statistics, fixture$annotation_ld_scores, fixture$weight_ld_scores,
    fixture$annotation_sums, fixture$blocks, annotation_overlap = overlap,
    reference_sample_size = 500, reference_marker_count = 20000,
    overlap_intercept = 1)
  expect_equal(length(fit$matrices$annotation_tau), 2L)
  expect_equal(unname(fit$matrices$annotation_tau$baseline),
    matrix(1e-5, 3, 3), tolerance = 1e-10)
  expect_equal(unname(fit$matrices$annotation_tau$coding),
    matrix(2e-5, 3, 3), tolerance = 1e-10)
  expect_equal(unname(fit$matrices$total_genetic_correlation),
    matrix(1, 3, 3), tolerance = 1e-10)
  expect_equal(unname(fit$matrices$ldsc_intercept),
    matrix(1, 3, 3), tolerance = 1e-10)
  expect_equal(length(fit$matrices$category_genetic_covariance), 2L)
  expect_equal(sum(fit$estimates$quantity == "cross_trait_intercept"), 3L)
  expect_true(all(c("all", "baseline", "coding") %in%
    fit$estimates$component))
})

test_that("partitioned LDSC rejects ambiguous annotation metadata", {
  fixture <- partitioned_fixture()
  summary <- make_summary("one", fixture$z, fixture$markers)
  bad <- fixture$annotation_ld_scores
  rownames(bad) <- rev(rownames(bad))
  expect_error(gcorr_ldsc_partitioned(summary, bad, fixture$weight_ld_scores,
    fixture$annotation_sums, fixture$blocks, reference_sample_size = 500),
    "row names exactly match")
  overlap <- diag(fixture$annotation_sums)
  dimnames(overlap) <- list(names(fixture$annotation_sums),
    names(fixture$annotation_sums))
  expect_error(gcorr_ldsc_partitioned(summary, fixture$annotation_ld_scores,
    fixture$weight_ld_scores, fixture$annotation_sums, fixture$blocks,
    annotation_overlap = overlap, reference_sample_size = 500),
    "reference_marker_count is required")
})

test_that("ldsc convenience interface accepts the VEGAS stat contract", {
  markers <- paste0("rs", seq_len(20))
  scores <- setNames(seq(1, 2.9, length.out = 20), markers)
  z <- sqrt(1 + 1000 * 0.2 / length(markers) * scores)
  statistics <- list(
    first = make_summary("first", z, markers),
    second = make_summary("second", z, markers))
  fit <- ldsc(statistics, ldscores = scores, what = "rg",
    block_count = 5, overlap_intercept = 1)

  expect_s3_class(fit, "gcorr_ldsc_fit")
  expect_identical(fit$requested, "rg")
  expect_equal(unname(fit$h2["all", ]), c(.2, .2), tolerance = 1e-10)
  expect_equal(unname(fit$rg), matrix(1, 2, 2), tolerance = 1e-10)
  expect_equal(fit$diagnostics$blocks_used, 5)
  expect_error(ldsc(statistics, ldscores = scores, residual = TRUE),
    "requires sets")
})

test_that("ldsc resolves overlapping marker-name sets through Glist", {
  fixture <- gcorr_sparse_glist_fixture()
  on.exit(fixture$cleanup(), add = TRUE)
  metadata <- fixture$Glist$sparseLD$marker_metadata
  markers <- metadata$marker_id
  annotation <- cbind(
    left = as.numeric(markers %in% markers[1:2]),
    overlap = as.numeric(markers %in% markers[2:3]),
    Residual = as.numeric(markers %in% markers[4]))
  rownames(annotation) <- markers
  scores <- gbase::ld_scores(fixture$Glist, annotation = annotation)
  z <- sqrt(1 + 1000 * drop(scores %*% c(.02, .03, .01)))
  stat <- data.frame(rsids = markers, chr = metadata$chromosome,
    pos = metadata$base_pair_position, ea = metadata$allele1,
    nea = metadata$allele2, z = z, n = 1000,
    stringsAsFactors = FALSE)
  fit <- ldsc(stat, fixture$Glist, sets = list(
      left = markers[1:2], overlap = markers[2:3]),
    residual = TRUE, block_count = 4, marginal_intercept = "fixed_one")

  expect_s3_class(fit, "gcorr_ldsc_partitioned_fit")
  expect_identical(names(fit$sets), c("left", "overlap", "Residual"))
  expect_true(all(c("all", "left", "overlap", "Residual") %in%
    rownames(fit$h2)))
  expect_identical(fit$requested, "h2")
  expect_equal(fit$diagnostics$blocks_used, 4)
})

test_that("ldsc grouped sets reuse ordinary Glist LD scores", {
  fixture <- gcorr_sparse_glist_fixture()
  on.exit(fixture$cleanup(), add = TRUE)
  metadata <- fixture$Glist$sparseLD$marker_metadata
  markers <- metadata$marker_id
  sets <- list(first = markers[1:3], second = markers[2:4])
  annotation <- cbind(
    first = as.numeric(markers %in% sets$first),
    second = as.numeric(markers %in% sets$second))
  rownames(annotation) <- markers
  ordinary <- gbase::ld_scores(fixture$Glist)[markers]
  grouped_scores <- sweep(annotation, 1L, unname(ordinary), `*`)
  tau <- c(first = .01, second = .02)
  z <- sqrt(1 + 1000 * drop(grouped_scores %*% tau))
  one <- data.frame(rsids = markers, chr = metadata$chromosome,
    pos = metadata$base_pair_position, ea = metadata$allele1,
    nea = metadata$allele2, z = z, n = 1000,
    stringsAsFactors = FALSE)
  fit <- ldsc(list(one = one, two = one), fixture$Glist, sets = sets,
    set_model = "grouped", what = "rg", block_count = 2,
    overlap_intercept = 1, marginal_intercept = "fixed_one")

  expect_s3_class(fit, "gcorr_ldsc_grouped_fit")
  expect_identical(fit$set_model, "grouped")
  expect_identical(fit$method, "grouped_ldsc")
  expect_equal(unname(fit$h2[c("first", "second"), "one"]),
    unname(tau * colSums(annotation)), tolerance = 1e-10)
  expect_equal(unname(fit$rg), matrix(1, 2, 2), tolerance = 1e-10)
  expect_equal(unname(fit$set_overlap), unname(crossprod(annotation)))
  expect_match(fit$assumptions$set_score_construction,
    "masked by focal-marker")
  expect_error(ldsc(one, fixture$Glist, sets = sets,
    set_model = "grouped", corrected = TRUE), "only for stratified")
  expect_error(ldsc(one, fixture$Glist, set_model = "grouped"),
    "only when sets")
})

test_that("numeric LDSC filtering preserves marker identity and variable sample sizes", {
  markers <- paste0("rs", seq_len(20))
  scores <- setNames(seq(1, 2.9, length.out = 20), markers)
  n <- seq(800, 1200, length.out = 20)
  z <- sqrt(1 + n * .2 / 20000 * scores)
  one <- make_summary("one", z, markers)
  one$n <- n
  one$z[3] <- 20
  blocks <- setNames(rep(paste0("b", 1:5), each = 4), markers)
  fit <- gcorr_ldsc(one, scores, blocks, marker_count = 20000,
    marginal_intercept = "fixed_one", maximum_chi_square = 10)
  expect_identical(fit$diagnostics$used_marker_ids, markers[-3])
  expect_equal(fit$diagnostics$markers_used, 19)
  expect_equal(fit$estimates$estimate[fit$estimates$quantity == "h2"], .2,
    tolerance = 1e-10)
})

test_that("loaded native versions and ABIs match compiled headers", {
  info <- gcorr_native_info()
  expect_identical(info$gcorr$runtime_version, "0.1.4")
  expect_equal(info$gcorr$runtime_abi, 0)
  expect_true(info$gcorr$headers_match_runtime)
  expect_true(info$gcorr$linked_gmat_matches_runtime)
  expect_true(info$gmat$headers_match_runtime)
  expect_true(info$gsolve$headers_match_runtime)
})
