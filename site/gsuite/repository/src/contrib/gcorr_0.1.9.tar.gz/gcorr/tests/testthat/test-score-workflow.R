score_workflow_fixture <- function() {
  ids <- paste0("m", seq_len(60))
  scores <- setNames(seq(1, 4, length.out = 60), ids)
  z <- sqrt(1.1 + 1000 * .2 / 60 * scores)
  values <- cbind(first = z, second = z * 1.02)
  rownames(values) <- ids
  n <- matrix(1000, 60, 2, dimnames = dimnames(values))
  frames <- lapply(seq_len(2), function(j) data.frame(rsids = ids,
    chr = "1", pos = seq_len(60), ea = "A", nea = "G",
    z = values[, j], n = n[, j]))
  names(frames) <- colnames(values)
  list(stat = list(z = values, n = n), frames = frames, scores = scores,
    Glist = list(bedfiles = "unused.bed", rsids = list(ids),
      ldscores = list(unname(scores)), n = 503),
    blocks = setNames(rep(paste0("b", 1:5), each = 12), ids))
}

test_that("direct Z/N inputs match explicit LDSC including variable sample sizes", {
  x <- score_workflow_fixture()
  x$stat$n[, 1] <- seq(900, 1100, length.out = 60)
  x$frames$first$n <- x$stat$n[, 1]
  explicit <- gcorr_ldsc(x$frames, x$scores, x$blocks,
    marginal_intercept = "free")
  direct <- ldsc(z = x$stat$z, n = x$stat$n, ldscores = x$scores,
    blocks = x$blocks)
  expect_equal(direct$estimates, explicit$estimates, tolerance = 1e-12)
  expect_identical(direct$traits, c("first", "second"))
  shuffled <- ldsc(stat = list(z = x$stat$z[60:1, ],
    n = x$stat$n[60:1, 2:1]), ldscores = x$scores, blocks = x$blocks)
  expect_equal(shuffled$estimates, direct$estimates, tolerance = 1e-12)
  expect_identical(shuffled$diagnostics$used_marker_ids, names(x$scores))
  old <- gcorr(x$frames, ld_scores = x$scores, blocks = x$blocks,
    marginal_intercept = "free", method = "ldsc")
  expect_equal(old$estimates, explicit$estimates, tolerance = 1e-12)
  partial <- ldsc(lapply(x$frames, function(stat) stat[1:36, ]),
    Glist = x$Glist, ldscores = x$scores[1:36], blocks = x$blocks[1:36])
  expect_equal(partial$assumptions$reference_marker_count, 60)
})

test_that("Glist dispatcher supplies the same three ordinary score fits", {
  x <- score_workflow_fixture()
  short <- gcorr(x$Glist, x$stat, method = "ldsc", blocks = x$blocks)
  explicit <- gcorr_ldsc(x$frames, x$scores, x$blocks,
    marginal_intercept = "free", maximum_chi_square = 80)
  expect_equal(short$estimates, explicit$estimates, tolerance = 1e-12)
  named <- gcorr(Glist = x$Glist, stat = x$stat, method = "ldsc",
    blocks = x$blocks)
  expect_equal(named$estimates, short$estimates, tolerance = 1e-12)
  gnova <- gcorr(x$Glist, x$stat, method = "gnova", blocks = x$blocks)
  expected <- gcorr_gnova(x$frames, x$blocks, x$scores,
    overlap_intercepts = explicit$matrices$ldsc_intercept)
  expect_equal(gnova$estimates, expected$estimates, tolerance = 1e-12)
  fixed <- gcorr(x$Glist, x$stat, method = "gnova", blocks = x$blocks,
    overlap_intercepts = 0)
  expected <- gcorr_gnova(x$frames, x$blocks, x$scores, overlap_intercepts = 0)
  expect_equal(fixed$estimates, expected$estimates, tolerance = 1e-12)
  architecture <- matrix(unname(x$scores), ncol = 1,
    dimnames = list(names(x$scores), "baseline"))
  sumher <- gcorr(x$Glist, x$stat, method = "sumher", blocks = x$blocks)
  expected <- gcorr_sumher(x$frames, architecture, c(baseline = 60),
    x$scores, x$blocks, reference_sample_size = 503,
    inflation = "multiplicative")
  expect_equal(sumher$estimates, expected$estimates, tolerance = 1e-12)
})

test_that("matrix matching retains common reference markers and compact set scores", {
  x <- score_workflow_fixture()
  x$stat$n <- x$stat$n[-1, , drop = FALSE]
  x$stat$z <- rbind(x$stat$z, absent = c(2, 2))
  ordinary <- ldsc(z = x$stat$z, n = x$stat$n, ldscores = x$scores,
    blocks = x$blocks)
  expect_identical(ordinary$diagnostics$used_marker_ids, names(x$scores)[-1])
  x <- score_workflow_fixture()
  sets <- list(first = c(names(x$scores)[1:30], "not-in-reference"),
    second = names(x$scores)[31:60])
  grouped <- gcorr(x$Glist, x$stat, method = "ldsc", sets = sets,
    set_model = "grouped", blocks = x$blocks, overlap_intercept = 0)
  scores <- gcorr_set_scores(names(x$scores), x$scores,
    lapply(sets, function(ids) intersect(ids, names(x$scores))))
  expected <- gcorr_ldsc_partitioned(x$frames, scores, x$scores,
    c(first = 30, second = 30), x$blocks, reference_sample_size = 503,
    annotation_overlap = matrix(c(30, 0, 0, 30), 2, 2,
      dimnames = list(c("first", "second"), c("first", "second"))),
    reference_marker_count = 60, marginal_intercept = "free",
    overlap_intercept = 0, maximum_chi_square = 80)
  actual <- grouped$estimates
  expected <- expected$estimates
  rownames(actual) <- rownames(expected) <- NULL
  expect_equal(actual, expected, tolerance = 1e-12)
  expect_true(all(c("first", "second") %in%
    grouped$estimates$component[grouped$estimates$quantity == "rg"]))
  expect_identical(lengths(grouped$sets), c(first = 30L, second = 30L))
})

test_that("score convenience inputs validate names, values and method boundaries", {
  x <- score_workflow_fixture()
  one <- ldsc(z = setNames(x$stat$z[, 1], rownames(x$stat$z)), n = 1000,
    ldscores = x$scores, blocks = x$blocks)
  expect_s3_class(one, "gcorr_ldsc_fit")
  expect_error(ldsc(stat = x$stat, z = x$stat$z, n = x$stat$n,
    ldscores = x$scores), "not both")
  bad <- x$stat; rownames(bad$z)[1] <- rownames(bad$z)[2]
  expect_error(ldsc(bad, ldscores = x$scores), "unique nonempty")
  bad <- x$stat; bad$n[1, 1] <- 0
  expect_error(ldsc(bad, ldscores = x$scores), "positive sample sizes")
  bad <- x$stat; bad$n[1, 1] <- 999
  expect_error(gcorr(x$Glist, bad, method = "gnova"), "constant sample size")
  expect_error(gcorr(x$Glist, x$stat, method = "hess"), "task='eigen'")
  expect_error(gcorr_prepare_hess(x$stat, x$Glist, list(all = names(x$scores))),
    "prepared gs_genotypes/Glist")
})
