hess_projection_summary <- function(z,markers,n) data.frame(rsids=markers,
  chr="1",pos=seq_along(markers)*100,ea="A",nea="G",z=z,n=n,
  stringsAsFactors=FALSE)

test_that("HESS uses physical BED rows for selected markers across chromosomes", {
  fixture <- gcorr_sparse_glist_fixture()
  on.exit(fixture$cleanup(),add=TRUE)
  original <- fixture$Glist
  second <- paste0(tempfile("gcorr-second-chromosome-"),c(".bed",".bim",".fam"))
  on.exit(unlink(second),add=TRUE)
  file.copy(original$bedfiles,second[1])
  file.copy(original$famfiles,second[3])
  write.table(data.frame("2",paste0("second-",letters[1:4]),0,100*1:4,"A","G"),
    second[2],quote=FALSE,row.names=FALSE,col.names=FALSE)
  g <- gbase::gprep(bedfiles=c(original$bedfiles,second[1]),
    rsids=c("b","d","second-a","second-c"))
  ids <- unlist(g$rsids,use.names=FALSE)
  one <- hess_projection_summary(c(4,3,2,5),ids,10000)
  one$chr <- unlist(g$chr,use.names=FALSE)
  one$pos <- unlist(g$pos,use.names=FALSE)
  two <- one; two$z <- c(2,4,5,3); two$n <- 12000
  stat <- list(one=one,two=two)
  # Deliberately request chromosome 2 first and reverse physical row order.
  sets <- list(second=rev(ids[3:4]),first=rev(ids[1:2]))
  projected <- gcorr_prepare_hess(stat,g,sets,minimum_eigenvalue=0)
  expect_identical(names(projected$regions),names(sets))
  dense <- gcorr_prepare_regions(lapply(sets,function(x)gbase::getLD(g,x)),8)
  expect_equal(gcorr_fit_hess(projected,shared_sample_size=0,
    phenotypic_correlation=0,uncertainty="strict")$estimates,
    gcorr_rho_hess(stat,dense,0,0,minimum_eigenvalue=0,joint=TRUE)$estimates,
    tolerance=2e-10)
})

test_that("BED projections reproduce dense joint HESS and survive RDS", {
  fixture <- gcorr_sparse_glist_fixture()
  on.exit(fixture$cleanup(),add=TRUE)
  g <- fixture$Glist
  ids <- unlist(g$rsids,use.names=FALSE)
  sets <- list(left=ids[1:2],right=ids[3:4])
  one <- hess_projection_summary(c(4,3,2,5),ids,10000)
  two <- hess_projection_summary(c(2,4,5,3),ids,12000)
  stat <- list(one=one,two=two)
  compact <- gcorr_prepare_hess(stat,g,sets,minimum_eigenvalue=0)
  expect_null(compact$regions[[1]]$marker_ids)
  dense <- gcorr_prepare_regions(lapply(sets,function(x)gbase::getLD(g,x)),8)
  fit <- gcorr_fit_hess(compact,shared_sample_size=0,phenotypic_correlation=0,uncertainty="strict")
  oracle <- gcorr_rho_hess(stat,dense,0,0,minimum_eigenvalue=0,joint=TRUE)
  expect_equal(fit$estimates,oracle$estimates,tolerance=2e-10)
  expect_equal(gcorr_fit_hess(compact,"one",uncertainty="strict")$estimates,
    gcorr_hess(list(one=one),dense,minimum_eigenvalue=0,joint=TRUE)$estimates,
    tolerance=2e-10)
  path <- tempfile(fileext=".rds");on.exit(unlink(path),add=TRUE)
  saveRDS(compact,path)
  expect_equal(gcorr_fit_hess(readRDS(path),shared_sample_size=0,
    phenotypic_correlation=0,uncertainty="strict")$estimates,fit$estimates)
  legacy <- compact; legacy$schema_version <- 1L
  for(i in seq_along(sets)) legacy$regions[[i]]$marker_ids <- sets[[i]]
  expect_equal(gcorr_fit_hess(legacy,shared_sample_size=0,
    phenotypic_correlation=0,uncertainty="strict")$estimates,fit$estimates)
  overlapping <- compact
  overlapping$regions[[2]]$bed_marker_indices_0based[1] <-
    overlapping$regions[[1]]$bed_marker_indices_0based[1]
  expect_error(gcorr_fit_hess(overlapping,shared_sample_size=0,
    phenotypic_correlation=0),"disjoint physical BED indices")
  flipped <- two;flipped$ea <- "G";flipped$nea <- "A";flipped$z <- -flipped$z
  both_flipped <- one;both_flipped$ea <- "G";both_flipped$nea <- "A";both_flipped$z <- -both_flipped$z
  reoriented <- gcorr_prepare_hess(list(one=both_flipped,two=flipped),g,sets,
    minimum_eigenvalue=0)
  expect_equal(gcorr_fit_hess(reoriented,shared_sample_size=0,
    phenotypic_correlation=0,uncertainty="strict")$estimates,fit$estimates,tolerance=2e-10)
  interleaved <- list(right=rev(ids[c(2,4)]),left=rev(ids[c(1,3)]))
  remapped <- gcorr_prepare_hess(stat,g,interleaved,minimum_eigenvalue=0)
  remapped_dense <- gcorr_prepare_regions(lapply(interleaved,function(x)gbase::getLD(g,x)),8)
  expect_equal(gcorr_fit_hess(remapped,shared_sample_size=0,
    phenotypic_correlation=0,uncertainty="strict")$estimates,
    gcorr_rho_hess(stat,remapped_dense,0,0,minimum_eigenvalue=0,joint=TRUE)$estimates,
    tolerance=2e-10)
  expect_equal(gcorr_fit_hess(compact)$estimates,
    gcorr_fit_hess(compact,shared_sample_size=0,phenotypic_correlation=0)$estimates)
  expect_error(gcorr_prepare_hess(stat,g,list(a=ids,b=ids[1])),"disjoint")
  expect_error(gcorr_prepare_hess(stat,g,sets,memory_limit_bytes=1),"memory_limit_bytes")
  duplicate <- rbind(one,one[1,,drop=FALSE])
  expect_error(gcorr_prepare_hess(list(one=duplicate),g,sets),"unique.*nonempty marker IDs")
  missing <- one;missing$ea[1] <- NA_character_
  expect_error(gcorr_prepare_hess(list(one=missing),g,sets),"nonmissing and nonempty")
})

test_that("the HESS workflow uses stored regions and eigen reference samples", {
  fixture <- gcorr_sparse_glist_fixture()
  on.exit(fixture$cleanup(),add=TRUE)
  g <- fixture$Glist
  markers <- unlist(g$rsids,use.names=FALSE)
  sets <- list(left=markers[1:2],right=markers[3:4])
  samples <- g$ids[c(8,2,5,1,6,3)]
  g <- gbase::gprep(g,task="eigen",sets=sets,ids=samples)
  z <- matrix(c(4,3,2,5,2,4,5,3),4,2,
    dimnames=list(markers,c("one","two")))
  n <- matrix(rep(c(10000,12000),each=4),4,2,dimnames=dimnames(z))
  # Different Z/N row order and N column order must still identify the same fit.
  stat <- list(z=z[4:1,,drop=FALSE],n=n[c(2,4,1,3),2:1,drop=FALSE])
  default <- gcorr(g,stat,method="hess",nthreads=4)
  expect_equal(default$estimates,gcorr_fit_hess(default$projection)$estimates)
  expect_identical(default$diagnostics$uncertainty_policy,"hess")
  fit <- gcorr(g,stat,method="hess",nthreads=4,minimum_eigenvalue=0,
    uncertainty="strict")
  frames <- list(one=hess_projection_summary(z[,1],markers,10000),
    two=hess_projection_summary(z[,2],markers,12000))
  dense <- gcorr_prepare_regions(lapply(sets,function(x)
    gbase::getLD(g,x,ids=samples)),length(samples))
  oracle <- gcorr_rho_hess(frames,dense,0,0,minimum_eigenvalue=0,joint=TRUE)
  expect_equal(fit$estimates,oracle$estimates,tolerance=2e-10)
  expect_s3_class(fit$projection,"gcorr_hess_projection")
  expect_identical(fit$projection$reference_selection$source,"Glist$eigen")
  expect_identical(fit$projection$reference_selection$sample_count,6L)
  expect_identical(fit$projection$nthreads,4)
  expect_identical(names(fit$projection$regions),names(sets))
  expect_null(fit$projection$regions[[1]]$eigenvectors)
  expect_null(fit$projection$regions[[1]]$marker_ids)
  expect_equal(gcorr_fit_hess(fit$projection,"one",uncertainty="strict")$estimates,
    gcorr_hess(list(one=frames$one),dense,minimum_eigenvalue=0,joint=TRUE)$estimates,
    tolerance=2e-10)
  expect_equal(gcorr(Glist=g,stat=stat,method="hess",minimum_eigenvalue=0,
    uncertainty="strict",shared_sample_size=500,phenotypic_correlation=.2)$estimates,
    gcorr_rho_hess(frames,dense,500,.2,minimum_eigenvalue=0,joint=TRUE)$estimates,
    tolerance=2e-10)
  # Stored values are spectra only; altered values cannot change BED projections.
  g$eigen$values <- lapply(g$eigen$values,function(x)x*2)
  expect_equal(gcorr(g,stat,method="hess",minimum_eigenvalue=0,
    uncertainty="strict")$estimates,fit$estimates)
  bad <- stat; bad$n[1,1] <- 9000
  expect_error(gcorr(g,bad,method="hess"),"constant sample size")
  expect_error(gcorr(fixture$Glist,stat,method="hess"),"task='eigen'")
  expect_error(gcorr_fit_hess(fit$projection,"one",shared_sample_size=1),
    "only to two traits")
  three <- list(z=cbind(z,three=z[,1]),n=cbind(n,three=n[,1]))
  expect_error(gcorr(g,three,method="hess"),"one or two traits")
})

test_that("stored HESS sets select common markers and discard empty regions", {
  fixture <- gcorr_sparse_glist_fixture()
  on.exit(fixture$cleanup(),add=TRUE)
  g <- fixture$Glist
  markers <- unlist(g$rsids,use.names=FALSE)
  g <- gbase::gprep(g,task="eigen",sets=list(left=markers[1:2],right=markers[3:4]))
  stat <- list(z=matrix(c(4,3),2,1,dimnames=list(markers[2:1],"one")),n=10000)
  fit <- gcorr(g,stat,method="hess",minimum_eigenvalue=0,uncertainty="strict")
  expect_identical(names(fit$projection$regions),"left")
  expect_identical(fit$projection$reference_selection$omitted_regions,"right")
  expect_equal(fit$projection$reference_selection$retained_marker_count,2)
  frame <- hess_projection_summary(c(3,4),markers[1:2],10000)
  dense <- gcorr_prepare_regions(list(left=gbase::getLD(g,markers[1:2])),8)
  expect_equal(fit$estimates,gcorr_hess(list(one=frame),dense,
    minimum_eigenvalue=0,joint=TRUE)$estimates,tolerance=2e-10)
})

test_that("automatic HESS rank controls joint conditioning before projection", {
  fixture <- gcorr_sparse_glist_fixture()
  on.exit(fixture$cleanup(),add=TRUE)
  g <- fixture$Glist
  ids <- unlist(g$rsids,use.names=FALSE)
  sets <- list(left=ids[1:2],right=ids[3:4])
  stat <- list(one=hess_projection_summary(c(2,1,1,2),ids,6),
    two=hess_projection_summary(c(1,2,2,1),ids,8))
  compact <- gcorr_prepare_hess(stat,g,sets,minimum_eigenvalue=0)
  expect_identical(compact$rank_policy$mode,"automatic_half_sample")
  expect_equal(compact$options$maximum_components,1)
  dense <- gcorr_prepare_regions(lapply(sets,function(x)gbase::getLD(g,x)),8)
  fit <- gcorr_fit_hess(compact,shared_sample_size=0,phenotypic_correlation=0,uncertainty="strict")
  expect_equal(fit$estimates,gcorr_rho_hess(stat,dense,0,0,
    maximum_components=1,minimum_eigenvalue=0,joint=TRUE)$estimates,tolerance=2e-10)
  expect_true(all(fit$diagnostics$conditioning$correction_denominator>=0.5))
  expect_error(gcorr_prepare_hess(list(one=transform(stat$one,n=3)),g,sets),
    "within half the smallest sample size")
  expect_warning(explicit <- gcorr_prepare_hess(stat,g,sets,
    maximum_components=2,minimum_eigenvalue=0),"conservative total-rank bound")
  expect_warning(gcorr_fit_hess(explicit,shared_sample_size=0,
    phenotypic_correlation=0),"more than half")
})

test_that("explicit genomic control agrees with scaling Z and preserves raw moments", {
  fixture <- gcorr_sparse_glist_fixture()
  on.exit(fixture$cleanup(),add=TRUE)
  g <- fixture$Glist
  ids <- unlist(g$rsids,use.names=FALSE)
  sets <- list(left=ids[1:2],right=ids[3:4])
  stat <- list(one=hess_projection_summary(c(4,3,2,5),ids,10000),
    two=hess_projection_summary(c(2,4,5,3),ids,12000))
  compact <- gcorr_prepare_hess(stat,g,sets,minimum_eigenvalue=0)
  raw <- serialize(compact,NULL)
  factors <- c(two=1.10,one=1.05)
  source <- c(two="Sensitivity only: 1.10",one="Sensitivity only: 1.05")
  adjusted <- stat
  for(trait in names(stat)) adjusted[[trait]]$z <- stat[[trait]]$z*sqrt(factors[trait])
  dense <- gcorr_prepare_regions(lapply(sets,function(x)gbase::getLD(g,x)),8)
  oracle <- gcorr_rho_hess(adjusted,dense,0,0,minimum_eigenvalue=0,joint=TRUE)
  fit <- gcorr_fit_hess(compact,shared_sample_size=0,phenotypic_correlation=0,
    genomic_control=factors,genomic_control_provenance=source,uncertainty="strict")
  expect_equal(fit$estimates,oracle$estimates,tolerance=2e-10)
  expect_identical(fit$input_scaling$z_squared_multiplier,factors[names(stat)])
  expect_identical(serialize(compact,NULL),raw)
  expect_equal(gcorr_fit_hess(compact,shared_sample_size=0,phenotypic_correlation=0,
    genomic_control=factors,genomic_control_provenance=source,uncertainty="strict")$estimates,fit$estimates)
  expect_error(gcorr_fit_hess(compact,"one",genomic_control=c(one=1.18)),
    "requires genomic_control_provenance")
  expect_error(gcorr_fit_hess(compact,"one",genomic_control=c(unknown=1)),
    "named exactly")
  expect_error(gcorr_fit_hess(compact,"one",genomic_control=c(one=0)),
    "positive finite")
  expect_error(gcorr_fit_hess(compact,"one",genomic_control=c(one=1.18),
    genomic_control_provenance=c(one=" ")),"nonempty sources")
})

test_that("moment uncertainty localizes invalid variances and keeps signed points", {
  fixture <- gcorr_sparse_glist_fixture()
  on.exit(fixture$cleanup(),add=TRUE)
  g <- fixture$Glist
  ids <- unlist(g$rsids,use.names=FALSE)
  stat <- list(one=hess_projection_summary(rep(2,4),ids,100),
    two=hess_projection_summary(rep(2,4),ids,160))
  projection <- gcorr_prepare_hess(stat,g,list(left=ids[1:2],right=ids[3:4]),
    minimum_eigenvalue=0)
  observed <- function(h1) {
    h2 <- c(.15,.22);cov <- c(0,.02)
    for(i in 1:2) {
      k <- projection$regions[[i]]$retained_components
      projection$regions[[i]]$quadratic_forms[,] <- matrix(c(
        h1[i]+k*(1-sum(h1))/100,cov[i],cov[i],
        h2[i]+k*(1-sum(h2))/160),2,2)
    }
    projection
  }
  mild <- observed(c(-.001,.18))
  strict <- gcorr_fit_hess(mild,shared_sample_size=0,phenotypic_correlation=0,
    uncertainty="strict")
  moment <- gcorr_fit_hess(mild,shared_sample_size=0,phenotypic_correlation=0,uncertainty="moment")
  expect_identical(moment$diagnostics$uncertainty_policy,"moment")
  expect_identical(moment$diagnostics$inference$model,"unconstrained_gaussian_moment_estimate")
  expect_equal(moment$estimates$estimate,strict$estimates$estimate)
  one <- moment$estimates[moment$estimates$quantity=="h2" & moment$estimates$trait1=="one",]
  expect_true(all(is.finite(one$standard_error)))
  expect_true(one$estimate[1]<0 && one$p_value[1]>.5)
  expect_true(all(is.na(strict$estimates$standard_error[strict$estimates$quantity=="h2" &
    strict$estimates$trait1=="one"])))
  weak <- gcorr_fit_hess(observed(c(-.012,.18)),shared_sample_size=0,
    phenotypic_correlation=0,uncertainty="moment")
  one <- weak$estimates[weak$estimates$quantity=="h2" & weak$estimates$trait1=="one",]
  expect_true(is.na(one$standard_error[1]))
  expect_true(all(is.finite(one$standard_error[-1])))
  expect_identical(one$uncertainty_reason[1],"Estimated HESS sampling variance is negative")
  expect_true("left" %in% weak$diagnostics$inference$negative_sampling_variances$region)
})

test_that("HESS inference diagnostics identify the regional blockers", {
  fixture <- gcorr_sparse_glist_fixture()
  on.exit(fixture$cleanup(),add=TRUE)
  g <- fixture$Glist
  ids <- unlist(g$rsids,use.names=FALSE)
  stat <- list(one=hess_projection_summary(rep(0,4),ids,10000),
    two=hess_projection_summary(c(2,4,5,3),ids,12000))
  projection <- gcorr_prepare_hess(stat,g,list(left=ids[1:2],right=ids[3:4]),
    minimum_eigenvalue=0)
  # A missing rank_policy field is allowed in pre-policy schema-1 RDS files.
  projection$rank_policy <- NULL
  fit <- gcorr_fit_hess(projection,shared_sample_size=0,phenotypic_correlation=0,
    uncertainty="strict")
  report <- fit$diagnostics$inference
  expect_identical(report$model,"strict_conditional_gaussian")
  expect_setequal(report$negative_regions$one,c("left","right"))
  expect_equal(report$traits$negative_region_count,c(2L,0L))
  expect_equal(report$traits$total_outside_unit_interval,c(TRUE,FALSE))
  expect_setequal(report$indefinite_genetic_regions,c("left","right"))
  expect_true(all(is.na(fit$estimates$standard_error[fit$estimates$trait1=="one"])))
  expect_true(all(is.finite(fit$estimates$standard_error[fit$estimates$trait1=="two"])))
  expect_true(all(fit$estimates$estimate[fit$estimates$quantity=="h2" &
    fit$estimates$trait1=="one"]<0))
})

test_that("original HESS uncertainty is the compact default and preserves points", {
  fixture <- gcorr_sparse_glist_fixture()
  on.exit(fixture$cleanup(),add=TRUE)
  g <- fixture$Glist
  ids <- unlist(g$rsids,use.names=FALSE)
  p <- gcorr_prepare_hess(list(one=hess_projection_summary(c(4,3,2,5),ids,100),
    two=hess_projection_summary(c(2,4,5,3),ids,160)),g,
    list(left=ids[1:2],right=ids[3:4]),minimum_eigenvalue=0)
  fit <- gcorr_fit_hess(p,shared_sample_size=0,phenotypic_correlation=0)
  moment <- gcorr_fit_hess(p,shared_sample_size=0,phenotypic_correlation=0,
    uncertainty="moment")
  expect_identical(fit$diagnostics$uncertainty_policy,"hess")
  expect_identical(fit$diagnostics$inference$model,"hess_software_variance")
  expect_equal(fit$estimates$estimate,moment$estimates$estimate)
  expect_length(fit$diagnostics$genome_rg_jackknife$delete_region_correlations,2)
  local_rg <- fit$estimates$component=="region" & fit$estimates$quantity=="rg"
  expect_true(all(is.na(fit$estimates$standard_error[local_rg])))
  expect_match(fit$estimates$uncertainty_reason[local_rg][1],"not regional")
  expect_equal(gcorr_fit_hess(p,"one")$estimates$estimate,
    moment$estimates$estimate[moment$estimates$quantity=="h2" & moment$estimates$trait1=="one"])
})
