#include <Rcpp.h>
#include <gcorr/hess.hpp>
#include <gmat/bed_region.hpp>
#include <chrono>
#include <cmath>
#include <algorithm>
#include <numeric>

// [[Rcpp::export]]
Rcpp::List cpp_gcorr_project_bed(Rcpp::List paths, Rcpp::IntegerVector sample_indices,
    Rcpp::List regions, Rcpp::List statistics,
    Rcpp::List options, int threads, double memory_limit_bytes) {
  using Clock=std::chrono::steady_clock;
  auto seconds=[](Clock::time_point start) { return std::chrono::duration<double>(Clock::now()-start).count(); };
  auto exact=[](double v) {
    if(!std::isfinite(v)||v<0||v!=std::floor(v)||v>9007199254740992.)Rcpp::stop("Invalid regional index");
    return static_cast<std::uint64_t>(v);
  };
  if(threads<1 || !std::isfinite(memory_limit_bytes) || memory_limit_bytes<=0)
    Rcpp::stop("Invalid HESS thread or workspace controls");
  if(!paths.size()) Rcpp::stop("Invalid BED component selection");
  std::vector<std::uint64_t> sample_rows;
  sample_rows.reserve(sample_indices.size());
  for(int row:sample_indices) {
    if(row==NA_INTEGER || row<0) Rcpp::stop("Invalid physical FAM row");
    sample_rows.push_back(static_cast<std::uint64_t>(row));
  }
  std::vector<int> component_ids(regions.size());
  std::vector<std::size_t> order(regions.size());
  std::iota(order.begin(),order.end(),0);
  for(R_xlen_t i=0;i<regions.size();++i) {
    const Rcpp::List region=regions[i];
    const int component=Rcpp::as<int>(region["component"]);
    if(component<0 || component>=paths.size()) Rcpp::stop("Invalid HESS component index");
    component_ids[i]=component;
  }
  std::stable_sort(order.begin(),order.end(),[&](std::size_t a,std::size_t b){return component_ids[a]<component_ids[b];});
  gcorr::HessOptions controls;
  controls.maximum_components=exact(Rcpp::as<double>(options["maximum_components"]));
  controls.minimum_eigenvalue=Rcpp::as<double>(options["minimum_eigenvalue"]);
  controls.relative_eigenvalue_tolerance=Rcpp::as<double>(options["relative_eigenvalue_tolerance"]);
  controls.eigensystem.maximum_dimension=exact(Rcpp::as<double>(options["maximum_dimension"]));
  std::vector<double> ns;
  for(R_xlen_t j=0;j<statistics.size();++j) {
    const Rcpp::List stat=statistics[j];const Rcpp::NumericVector n=stat["n"];
    ns.push_back(n[0]);
  }
  Rcpp::List out(regions.size());const Rcpp::CharacterVector names=regions.names();
  for(const auto r:order) {
    Rcpp::checkUserInterrupt();
    const Rcpp::List path=paths[component_ids[r]];
    const Rcpp::List region=regions[r];
    const Rcpp::IntegerVector indices=region["panel"],stat_indices=region["statistics"],sign=region["sign"];
    std::vector<std::uint64_t> selected; selected.reserve(indices.size());
    for(int value:indices) {
      if(value==NA_INTEGER || value<0) Rcpp::stop("Invalid regional BED index");
      selected.push_back(static_cast<std::uint64_t>(value));
    }
    const auto n=static_cast<std::uint64_t>(sample_rows.size()),m=static_cast<std::uint64_t>(selected.size()),d=std::min(n,m),t=static_cast<std::uint64_t>(ns.size());
    // Conservative per-region numerical workspace admission (not total RSS).
    const long double workspace=8.L*(2.L*n*m+12.L*d*d+2.L*m*t+2.L*n*t+d*t);
    if(d>controls.eigensystem.maximum_dimension || workspace>memory_limit_bytes)
      Rcpp::stop("HESS region exceeds solver dimension or memory_limit_bytes: "+Rcpp::as<std::string>(names[r]));
    if(stat_indices.size()!=static_cast<R_xlen_t>(m) || sign.size()!=static_cast<R_xlen_t>(m))Rcpp::stop("Invalid HESS statistic indices");
    std::vector<double> z(m*t);
    for(std::size_t j=0;j<t;++j) {
      const Rcpp::List stat=statistics[j];const Rcpp::NumericVector values=stat["z"];
      for(std::size_t i=0;i<m;++i) {
        const int index=stat_indices[i];
        if(index==NA_INTEGER || index<0 || index>=values.size() || (sign[i]!=1 && sign[i]!=-1)) Rcpp::stop("Statistic index or orientation out of range");
        z[i+j*m]=values[index]*sign[i];
      }
    }
    const auto start=Clock::now();
    auto w=gmat::read_standardized_bed_region(Rcpp::as<std::string>(path["bed"]),
      exact(Rcpp::as<double>(path["source_sample_count"])),
      exact(Rcpp::as<double>(path["source_marker_count"])),sample_rows,selected,
      static_cast<std::uint32_t>(threads));
    const double decode=seconds(start);
    const auto result=gcorr::project_hess_genotypes({w.values.data(),n,m,n},
      {z.data(),m,t,m},ns,controls,static_cast<std::uint32_t>(threads));
    const auto& diag=result.diagnostics;
    out[r]=Rcpp::List::create(Rcpp::_["marker_count"]=static_cast<double>(m),
      Rcpp::_["bed_component"]=component_ids[r],
      Rcpp::_["bed_marker_indices_0based"]=indices,
      Rcpp::_["sample_sizes"]=ns,
      Rcpp::_["quadratic_forms"]=Rcpp::NumericMatrix(t,t,result.quadratic_forms.begin()),
      Rcpp::_["retained_components"]=static_cast<double>(diag.retained_components),
      Rcpp::_["numerical_rank"]=static_cast<double>(diag.numerical_rank),
      Rcpp::_["eigenvalues"]=diag.eigenvalues,
      Rcpp::_["reference_sample_size"]=static_cast<double>(n),
      Rcpp::_["matrix_space"]=result.matrix_space,
      Rcpp::_["solver_dimension"]=static_cast<double>(d),
      Rcpp::_["backend"]=diag.eigensystem.backend,
      Rcpp::_["relative_residual"]=diag.eigensystem.relative_residual,
      Rcpp::_["retained_positive_eigenvalue_fraction"]=diag.retained_positive_eigenvalue_fraction,
      Rcpp::_["workspace_bytes"]=static_cast<double>(workspace),
      Rcpp::_["timings_seconds"]=Rcpp::NumericVector::create(
        Rcpp::_["decode"]=decode,Rcpp::_["product"]=result.product_seconds,
        Rcpp::_["eigen"]=result.eigen_seconds,Rcpp::_["projection"]=result.projection_seconds));
  }
  out.attr("names")=names;out.attr("panel_setup_seconds")=0.;return out;
}
