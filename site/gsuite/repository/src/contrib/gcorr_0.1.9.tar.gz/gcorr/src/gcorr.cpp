#include <Rcpp.h>

#include <cmath>
#include <optional>
#include <string>
#include <vector>
#include <unordered_map>
#include <utility>

#include <gcorr/ldsc.hpp>
#include <gcorr/gnova.hpp>
#include <gcorr/sumher.hpp>
#include <gcorr/annotation_models.hpp>
#include <gcorr/ld_reference.hpp>
#include <gcorr/hess.hpp>
#include <gcorr/supergnova.hpp>
#include <gcorr/lava.hpp>
#include <gcorr/lava_binary.hpp>
#include <gcorr/lava_bivariate.hpp>
#include <gcorr/lava_multivariate.hpp>
#include <gcorr/lava_partial.hpp>
#include <gcorr/lava_regression.hpp>
#include <gcorr/hdll.hpp>
#include <gcorr/version.hpp>
#include <gmat/sparse_ld_disk.hpp>
#include <gmat/version.hpp>
#include <gsolve/version.hpp>

namespace {

using Rcpp::DataFrame;
using Rcpp::List;
using Rcpp::Named;
using Rcpp::NumericMatrix;
using Rcpp::NumericVector;
using Rcpp::CharacterVector;

void append_prepared_region(List& pointers, List& diagnostics,
                            const std::string& region_name,
                            gcorr::PreparedRegionalLd prepared) {
  const auto& eigen=prepared.eigensystem();
  diagnostics.push_back(List::create(
    Named("marker_ids")=prepared.marker_ids(),
    Named("reference_sample_size")=static_cast<double>(prepared.reference_sample_count()),
    Named("eigenvalues")=eigen.eigenvalues,
    Named("eigensystem_backend")=eigen.diagnostics.backend,
    Named("relative_residual")=eigen.diagnostics.relative_residual,
    Named("relative_reconstruction_error")=eigen.diagnostics.relative_reconstruction_error,
    Named("orthogonality_error")=eigen.diagnostics.orthogonality_error),region_name);
  pointers.push_back(Rcpp::XPtr<gcorr::PreparedRegionalLd>(
    new gcorr::PreparedRegionalLd(std::move(prepared)),true),region_name);
}

gcorr::AlignedSummaryInput numeric_input(const List& statistics,
    const CharacterVector& blocks) {
  const CharacterVector trait_names=statistics.names();
  gcorr::AlignedSummaryInput input;
  for (R_xlen_t i = 0; i < statistics.size(); ++i) {
    const List stat = statistics[i];
    const NumericVector n = stat["n"];
    bool scalar = true;
    for (R_xlen_t j = 1; j < n.size(); ++j) if (n[j] != n[0]) { scalar = false; break; }
    input.traits.push_back({Rcpp::as<std::string>(trait_names[i]),
      Rcpp::as<std::vector<double>>(stat["z"]),
      scalar ? std::vector<double>{n[0]} : Rcpp::as<std::vector<double>>(n)});
  }
  std::unordered_map<std::string, std::uint32_t> block_index;
  input.block_indices.reserve(blocks.size());
  for (R_xlen_t row = 0; row < blocks.size(); ++row) {
    if (STRING_ELT(blocks,row) == NA_STRING) Rcpp::stop("Block labels must not be missing.");
    const auto name = Rcpp::as<std::string>(blocks[row]);
    const auto entry = block_index.emplace(name, static_cast<std::uint32_t>(input.block_names.size()));
    if (entry.second) input.block_names.push_back(name);
    input.block_indices.push_back(entry.first->second);
  }
  return input;
}
gcorr::AlignedScoreMatrix numeric_scores(const NumericMatrix& values) {
  gcorr::AlignedScoreMatrix out;
  out.rows=values.nrow();
  out.annotations=Rcpp::as<std::vector<std::string>>(Rcpp::colnames(values));
  out.values.reserve(values.size());
  for(R_xlen_t row=0;row<values.nrow();++row)
    for(R_xlen_t col=0;col<values.ncol();++col) out.values.push_back(values(row,col));
  return out;
}
CharacterVector retained_markers(const CharacterVector& markers,
    const std::vector<std::size_t>& rows) {
  if(rows.empty()) return markers;
  CharacterVector out(rows.size());
  for(std::size_t i=0;i<rows.size();++i) out[i]=markers[rows[i]];
  return out;
}

double optional_value(const std::optional<double>& value) {
  return value ? *value : NA_REAL;
}

gcorr::NamedValues named_values(const List& input, const char* field) {
  return {
    Rcpp::as<std::vector<std::string>>(input["marker"]),
    Rcpp::as<std::vector<double>>(input[field])
  };
}

void add_estimate(CharacterVector& quantity, NumericVector& estimate,
                  NumericVector& standard_error, NumericVector& z_score,
                  NumericVector& p_value, CharacterVector& undefined_reason,
                  CharacterVector& uncertainty_reason, const char* name,
                  const gcorr::EstimateSummary& value) {
  quantity.push_back(name);
  estimate.push_back(optional_value(value.estimate));
  standard_error.push_back(optional_value(value.standard_error));
  z_score.push_back(optional_value(value.z_score));
  p_value.push_back(optional_value(value.p_value));
  undefined_reason.push_back(value.undefined_reason);
  uncertainty_reason.push_back(value.uncertainty_undefined_reason);
}

gcorr::LavaBivariateOptions lava_simulation_options(const List& control) {
  gcorr::LavaBivariateOptions out;
  out.seed = static_cast<std::uint64_t>(Rcpp::as<double>(control["seed"]));
  out.pvalue_draws.clear();
  for (double value : Rcpp::as<NumericVector>(control["pvalue_draws"]))
    out.pvalue_draws.push_back(static_cast<std::size_t>(value));
  out.escalation_thresholds =
    Rcpp::as<std::vector<double>>(control["escalation_thresholds"]);
  out.interval_draws = static_cast<std::size_t>(
    Rcpp::as<double>(control["interval_draws"]));
  out.relative_pvalue_mc_tolerance =
    Rcpp::as<double>(control["relative_pvalue_mc_tolerance"]);
  out.interval_endpoint_mc_tolerance =
    Rcpp::as<double>(control["interval_endpoint_mc_tolerance"]);
  out.maximum_abs_correlation =
    Rcpp::as<double>(control["maximum_abs_correlation"]);
  return out;
}

List lava_interval(const gcorr::LavaSimulationInterval& value) {
  return List::create(
    Named("lower") = optional_value(value.lower),
    Named("upper") = optional_value(value.upper),
    Named("lower_mc_width") = value.lower_mc_width,
    Named("upper_mc_width") = value.upper_mc_width
  );
}

List lava_covariance_check(const gcorr::LavaCovarianceCheck& value) {
  return List::create(
    Named("minimum_relative_eigenvalue") = value.minimum_relative_eigenvalue,
    Named("condition_number") = value.condition_number,
    Named("acceptable") = value.acceptable,
    Named("reason") = value.reason
  );
}

gcorr::EstimateSummary lava_simulated_summary(
    gcorr::EstimateSummary value, std::optional<double> p_value,
    const std::string& reason) {
  value.p_value = p_value;
  value.standard_error.reset();
  value.z_score.reset();
  value.uncertainty_undefined_reason = reason.empty()
    ? "Simulation inference supplies no estimator SE or normal z score."
    : reason;
  return value;
}

List component_info(const char* header_version, std::uint32_t header_abi,
                    const char* runtime_version, std::uint32_t runtime_abi) {
  return List::create(
    Named("header_version") = header_version,
    Named("header_abi") = header_abi,
    Named("runtime_version") = runtime_version,
    Named("runtime_abi") = runtime_abi,
    Named("headers_match_runtime") =
      std::string(header_version) == runtime_version && header_abi == runtime_abi
  );
}

}  // namespace

// [[Rcpp::export]]
Rcpp::List cpp_gcorr_native_info() {
  auto gcorr_info = component_info("0.1.4", gcorr::experimental_abi,
                                   gcorr::version_string(), gcorr::abi_version());
  gcorr_info["linked_gmat_version"] = gcorr::linked_gmat_version();
  gcorr_info["linked_gmat_abi"] = gcorr::linked_gmat_abi();
  gcorr_info["linked_gmat_matches_runtime"] =
      gcorr::linked_gmat_abi() == gmat::abi_version();
  return List::create(
    Named("gcorr") = gcorr_info,
    Named("gmat") = component_info("0.6.0", gmat::experimental_abi,
                                    gmat::version_string(), gmat::abi_version()),
    Named("gsolve") = component_info((std::to_string(gsolve::version_major) + "." +
      std::to_string(gsolve::version_minor) + "." + std::to_string(gsolve::version_patch)).c_str(),
      gsolve::experimental_abi,
                                      gsolve::version_string(), gsolve::abi_version())
  );
}

// [[Rcpp::export]]
Rcpp::List cpp_gcorr_ldsc(Rcpp::List statistics,
                          Rcpp::NumericVector ld_scores,
                          Rcpp::CharacterVector blocks,
                          Rcpp::Nullable<double> overlap_intercept,
                          double marker_count,
                          std::string marginal_intercept,
                          Rcpp::Nullable<double> maximum_chi_square) {
  const Rcpp::CharacterVector trait_names = statistics.names();
  const Rcpp::List first = statistics[0];
  auto input=numeric_input(statistics,blocks);
  const CharacterVector markers=first["marker"];
  input.regression_ld=Rcpp::as<std::vector<double>>(ld_scores);
  input.heritability_marker_count=static_cast<std::uint64_t>(marker_count);
  gcorr::CrossTraitFitOptions options;
  options.single_trait_intercepts = marginal_intercept == "fixed_one" ? gcorr::InterceptMode::fixed_one : gcorr::InterceptMode::free;
  if (overlap_intercept.isNotNull()) options.fixed_cross_trait_intercept = Rcpp::as<double>(overlap_intercept);
  if (maximum_chi_square.isNotNull()) options.maximum_chi_square = Rcpp::as<double>(maximum_chi_square);
  const auto aligned = gcorr::fit_aligned_ldsc(std::move(input), options);
  const auto& result = aligned.fit;
  const auto used_markers=retained_markers(markers,aligned.used_marker_indices);
  CharacterVector quantity, undefined_reason, uncertainty_reason;
  CharacterVector output_trait1, output_trait2;
  NumericVector estimate, standard_error, z_score, p_value;
  auto append = [&](const char* name, const gcorr::EstimateSummary& value,
                    const std::string& trait1, const std::string& trait2 = "") {
    add_estimate(quantity, estimate, standard_error, z_score, p_value,
                 undefined_reason, uncertainty_reason, name, value);
    output_trait1.push_back(trait1);
    if (trait2.empty()) output_trait2.push_back(NA_STRING);
    else output_trait2.push_back(trait2);
  };

  List diagnostics, matrices;
  if (statistics.size() == 1) {
    const auto& fit = result.trait_fits.front();
    const auto name = Rcpp::as<std::string>(trait_names[0]);
    append("h2", fit.heritability_statistics, name);
    append("intercept", fit.intercept_statistics, name);
    diagnostics = List::create(Named("used_marker_ids")=used_markers,
      Named("markers_used")=static_cast<double>(result.accounting.markers_used),
      Named("blocks_used")=static_cast<double>(result.accounting.blocks_used),
      Named("floored_working_means")=static_cast<double>(fit.weight_diagnostics.floored_means));
  } else {
    for (std::size_t i=0;i<result.trait_fits.size();++i) {
      append("h2",result.trait_fits[i].heritability_statistics,result.trait_names[i]);
      append("intercept",result.trait_fits[i].intercept_statistics,result.trait_names[i]);
    }
    for (const auto& pair:result.pair_fits) {
      append("cov",pair.genetic_covariance_statistics,pair.trait_names[0],pair.trait_names[1]);
      append("rg",pair.genetic_correlation_statistics,pair.trait_names[0],pair.trait_names[1]);
      append("cross_trait_intercept",pair.cross_trait_intercept_statistics,pair.trait_names[0],pair.trait_names[1]);
    }
    auto matrix = [&](const gcorr::NamedSymmetricMatrix& source) {
      const int n=static_cast<int>(source.names.size()); Rcpp::NumericMatrix out(n,n);
      for(int i=0;i<n;++i) for(int j=0;j<n;++j) out(i,j)=source.values[i*n+j];
      out.attr("dimnames")=List::create(source.names,source.names); return out;
    };
    matrices=List::create(Named("genetic_covariance")=matrix(result.genetic_covariance),
      Named("genetic_correlation")=matrix(result.genetic_correlation),
      Named("ldsc_intercept")=matrix(result.ldsc_intercepts));
    diagnostics=List::create(Named("used_marker_ids")=used_markers,
      Named("markers_used")=static_cast<double>(result.accounting.markers_used),
      Named("blocks_used")=static_cast<double>(result.accounting.blocks_used));
  }

  const DataFrame estimates = DataFrame::create(
    Named("quantity") = quantity,
    Named("trait1") = output_trait1,
    Named("trait2") = output_trait2,
    Named("estimate") = estimate,
    Named("standard_error") = standard_error,
    Named("z") = z_score,
    Named("p_value") = p_value,
    Named("undefined_reason") = undefined_reason,
    Named("uncertainty_reason") = uncertainty_reason
  );
  return List::create(Named("estimates") = estimates,
                      Named("matrices") = matrices,
                      Named("diagnostics") = diagnostics);
}

// [[Rcpp::export]]
Rcpp::List cpp_gcorr_ldsc_partitioned(Rcpp::List statistics,
    SEXP annotation_ld_scores,
    Rcpp::NumericVector weight_ld_scores,
    Rcpp::NumericVector annotation_sums,
    Rcpp::Nullable<Rcpp::NumericMatrix> annotation_overlap,
    Rcpp::CharacterVector blocks, double reference_sample_size,
    double reference_marker_count, bool corrected,
    Rcpp::Nullable<double> overlap_intercept,
    std::string marginal_intercept,
    Rcpp::Nullable<double> maximum_chi_square) {
  const Rcpp::CharacterVector trait_names=statistics.names();
  const Rcpp::List first=statistics[0];
  const CharacterVector markers=first["marker"];
  auto input=numeric_input(statistics,blocks);
  input.weight_ld=Rcpp::as<std::vector<double>>(weight_ld_scores);
  gcorr::AlignedScoreMatrix scores;
  if(Rf_inherits(annotation_ld_scores,"gcorr_disjoint_ld_scores")) {
    List values(annotation_ld_scores);
    scores.rows=markers.size();
    scores.annotations=Rcpp::as<std::vector<std::string>>(values["annotation_names"]);
    const Rcpp::IntegerVector groups=values["group"];
    scores.groups.reserve(groups.size());
    for(int group:groups) {
      if(group==NA_INTEGER || group<1 || static_cast<std::size_t>(group)>scores.annotation_count()) Rcpp::stop("Invalid compact score group index.");
      scores.groups.push_back(static_cast<std::uint32_t>(group-1));
    }
    scores.values=Rcpp::as<std::vector<double>>(values["scores"]);
  } else scores=numeric_scores(NumericMatrix(annotation_ld_scores));
  gcorr::PartitionedMultivariateInput metadata;
  metadata.annotation_sums=gcorr::NamedAnnotationValues{scores.annotations,Rcpp::as<std::vector<double>>(annotation_sums)};
  if(annotation_overlap.isNotNull()) {
    NumericMatrix overlap(annotation_overlap.get());
    std::vector<double> values; values.reserve(overlap.size());
    for(R_xlen_t i=0;i<overlap.nrow();++i) for(R_xlen_t j=0;j<overlap.ncol();++j) values.push_back(overlap(i,j));
    metadata.overlap_summary=gcorr::BinaryAnnotationOverlapSummary{scores.annotations,
      Rcpp::as<std::vector<double>>(annotation_sums),std::move(values),reference_marker_count};
  }
  gcorr::CrossTraitFitOptions cross;
  cross.single_trait_intercepts=marginal_intercept=="fixed_one" ? gcorr::InterceptMode::fixed_one : gcorr::InterceptMode::free;
  if(overlap_intercept.isNotNull()) cross.fixed_cross_trait_intercept=Rcpp::as<double>(overlap_intercept);
  if(maximum_chi_square.isNotNull()) cross.maximum_chi_square=Rcpp::as<double>(maximum_chi_square);
  const auto aligned=gcorr::fit_aligned_partitioned_ldsc(std::move(input),scores,metadata,cross);
  const auto used_markers=retained_markers(markers,aligned.used_marker_indices);
  CharacterVector quantity,component,output_trait1,output_trait2,undefined_reason,uncertainty_reason;
  NumericVector estimate,standard_error,z_score,p_value;
  auto append=[&](const char* q,const std::string& c,const gcorr::EstimateSummary& value,
                  const std::string& trait1,const std::string& trait2=""){
    add_estimate(quantity,estimate,standard_error,z_score,p_value,undefined_reason,uncertainty_reason,q,value);
    component.push_back(c); output_trait1.push_back(trait1);
    if(trait2.empty()) output_trait2.push_back(NA_STRING); else output_trait2.push_back(trait2);
  };
  List diagnostics,matrices;
  if(statistics.size()==1) {
    const auto& result=aligned.fit.trait_fits.front();
    const auto name=Rcpp::as<std::string>(trait_names[0]);
    append("h2","all",result.total_heritability_statistics,name);
    append("intercept","all",result.intercept_statistics,name);
    for(std::size_t j=0;j<result.annotation_names.size();++j){
      append("tau",result.annotation_names[j],result.tau_statistics[j],name);
      if(result.category_summary){
        append("h2",result.annotation_names[j],result.category_summary->category_heritability[j],name);
        append("enrichment",result.annotation_names[j],result.category_summary->enrichment[j],name);
      }
    }
    diagnostics=List::create(Named("used_marker_ids")=used_markers,
      Named("markers_used")=static_cast<double>(result.accounting.markers_used),
      Named("blocks_used")=static_cast<double>(result.accounting.blocks_used));
  } else {
    const auto& result=aligned.fit;
    for(std::size_t i=0;i<result.trait_fits.size();++i){
      append("h2","all",result.trait_fits[i].total_heritability_statistics,result.trait_names[i]);
      append("intercept","all",result.trait_fits[i].intercept_statistics,result.trait_names[i]);
      for(std::size_t j=0;j<result.annotation_names.size();++j){
        append("tau",result.annotation_names[j],result.trait_fits[i].tau_statistics[j],result.trait_names[i]);
        if(result.trait_fits[i].category_summary){
          append("h2",result.annotation_names[j],result.trait_fits[i].category_summary->category_heritability[j],result.trait_names[i]);
          append("enrichment",result.annotation_names[j],result.trait_fits[i].category_summary->enrichment[j],result.trait_names[i]);
        }
      }
    }
    for(const auto& pair:result.pair_fits){
      append("cov","all",pair.total_genetic_covariance,pair.trait_names[0],pair.trait_names[1]);
      append("rg","all",pair.total_genetic_correlation,pair.trait_names[0],pair.trait_names[1]);
      append("cross_trait_intercept","all",pair.cross_trait_intercept_statistics,pair.trait_names[0],pair.trait_names[1]);
      for(std::size_t j=0;j<pair.annotation_names.size();++j){
        append("tau_cov",pair.annotation_names[j],pair.tau_statistics[j],pair.trait_names[0],pair.trait_names[1]);
        if(pair.category_summary){
          append("cov",pair.annotation_names[j],pair.category_summary->genetic_covariance[j],pair.trait_names[0],pair.trait_names[1]);
          append("rg",pair.annotation_names[j],pair.category_summary->genetic_correlation[j],pair.trait_names[0],pair.trait_names[1]);
        }
      }
    }
    List tau;
    for(std::size_t a=0;a<result.annotation_tau.size();++a){
      const int n=static_cast<int>(result.trait_names.size()); Rcpp::NumericMatrix matrix(n,n);
      for(int i=0;i<n;++i)for(int j=0;j<n;++j)matrix(i,j)=result.annotation_tau[a].values[i*n+j];
      matrix.attr("dimnames")=List::create(result.trait_names,result.trait_names);
      tau.push_back(matrix,result.annotation_names[a]);
    }
    auto symmetric_matrix=[&](const gcorr::NamedSymmetricMatrix& source){
      const int n=static_cast<int>(source.names.size()); Rcpp::NumericMatrix matrix(n,n);
      for(int i=0;i<n;++i)for(int j=0;j<n;++j)matrix(i,j)=source.values[i*n+j];
      matrix.attr("dimnames")=List::create(source.names,source.names); return matrix;
    };
    auto estimate_matrix=[&](const std::vector<gcorr::EstimateSummary>& source){
      const int n=static_cast<int>(result.trait_names.size()); Rcpp::NumericMatrix matrix(n,n);
      for(int i=0;i<n;++i)for(int j=0;j<n;++j)matrix(i,j)=optional_value(source[i*n+j].estimate);
      matrix.attr("dimnames")=List::create(result.trait_names,result.trait_names); return matrix;
    };
    List category_covariance,category_correlation;
    for(std::size_t a=0;a<result.categories.size();++a){
      category_covariance.push_back(estimate_matrix(result.categories[a].genetic_covariance),result.annotation_names[a]);
      category_correlation.push_back(estimate_matrix(result.categories[a].genetic_correlation),result.annotation_names[a]);
    }
    Rcpp::RObject total_covariance=R_NilValue,total_correlation=R_NilValue;
    if(result.total){
      total_covariance=estimate_matrix(result.total->genetic_covariance);
      total_correlation=estimate_matrix(result.total->genetic_correlation);
    }
    matrices=List::create(Named("annotation_tau")=tau,
      Named("ldsc_intercept")=symmetric_matrix(result.ldsc_intercepts),
      Named("total_genetic_covariance")=total_covariance,
      Named("total_genetic_correlation")=total_correlation,
      Named("category_genetic_covariance")=category_covariance,
      Named("category_genetic_correlation")=category_correlation);
    diagnostics=List::create(Named("used_marker_ids")=used_markers,
      Named("markers_used")=static_cast<double>(result.accounting.markers_used),
      Named("blocks_used")=static_cast<double>(result.accounting.blocks_used));
  }
  DataFrame estimates=DataFrame::create(Named("component")=component,Named("quantity")=quantity,
    Named("trait1")=output_trait1,Named("trait2")=output_trait2,Named("estimate")=estimate,
    Named("standard_error")=standard_error,Named("z")=z_score,Named("p_value")=p_value,
    Named("undefined_reason")=undefined_reason,Named("uncertainty_reason")=uncertainty_reason);
  return List::create(Named("estimates")=estimates,Named("matrices")=matrices,Named("diagnostics")=diagnostics);
}

// [[Rcpp::export]]
Rcpp::List cpp_gcorr_gnova(Rcpp::List statistics,
    Rcpp::Nullable<Rcpp::NumericVector> ordinary_ld_scores,
    Rcpp::CharacterVector blocks,
    Rcpp::Nullable<Rcpp::NumericMatrix> annotation_ld_scores,
    Rcpp::Nullable<Rcpp::NumericMatrix> annotations,
    Rcpp::Nullable<Rcpp::NumericVector> weight_ld_scores,
    double reference_sample_size, bool corrected,
    Rcpp::Nullable<Rcpp::NumericMatrix> overlap_intercepts) {
  const CharacterVector trait_names=statistics.names();
  const List first=statistics[0];
  const CharacterVector markers=first["marker"];
  auto input=numeric_input(statistics,blocks);
  std::optional<gcorr::AlignedScoreMatrix> scores,annotation_matrix;
  if(annotation_ld_scores.isNotNull()) {
    scores=numeric_scores(NumericMatrix(annotation_ld_scores.get()));
    annotation_matrix=numeric_scores(NumericMatrix(annotations.get()));
    input.weight_ld=Rcpp::as<std::vector<double>>(NumericVector(weight_ld_scores.get()));
  } else input.regression_ld=Rcpp::as<std::vector<double>>(NumericVector(ordinary_ld_scores.get()));
  std::vector<gcorr::GnovaPairOverlap> pairs;
  if(statistics.size()>1) {
    NumericMatrix overlaps(overlap_intercepts.get());
    for(R_xlen_t i=0;i<statistics.size();++i)for(R_xlen_t j=i+1;j<statistics.size();++j)
      pairs.push_back({Rcpp::as<std::string>(trait_names[i]),Rcpp::as<std::string>(trait_names[j]),overlaps(i,j),{}});
  }
  const auto fitted=gcorr::fit_aligned_gnova(std::move(input),pairs,scores,annotation_matrix);

  CharacterVector component,quantity,output_trait1,output_trait2;
  CharacterVector undefined_reason,uncertainty_reason;
  NumericVector estimate,standard_error,z_score,p_value;
  auto append=[&](const std::string& name,const char* q,
                  const gcorr::EstimateSummary& value,const std::string& trait1,
                  const std::string& trait2=""){
    add_estimate(quantity,estimate,standard_error,z_score,p_value,
      undefined_reason,uncertainty_reason,q,value);
    component.push_back(name); output_trait1.push_back(trait1);
    if(trait2.empty())output_trait2.push_back(NA_STRING); else output_trait2.push_back(trait2);
  };
  List matrices,diagnostics;
  if(statistics.size()==1){
    const auto& result=fitted.trait_fits.front();
    for(std::size_t a=0;a<result.annotation_names.size();++a){
      append(result.annotation_names[a],"h2",result.category_heritability[a],result.trait_name);
      append(result.annotation_names[a],"component_h2",result.component_heritability[a],result.trait_name);
    }
    append("all","intercept",result.intercept,result.trait_name);
    diagnostics=List::create(Named("used_marker_ids")=markers);
  } else {
    const auto& result=fitted;
    const int n=static_cast<int>(result.trait_names.size());
    auto estimate_matrix=[&](const std::vector<gcorr::EstimateSummary>& source){
      NumericMatrix matrix(n,n);
      for(int i=0;i<n;++i)for(int j=0;j<n;++j)matrix(i,j)=optional_value(source[i*n+j].estimate);
      matrix.attr("dimnames")=List::create(result.trait_names,result.trait_names); return matrix;
    };
    List categories,component_covariance;
    for(std::size_t a=0;a<result.categories.size();++a){
      const auto& category=result.categories[a];
      NumericMatrix flags(n,n);
      for(int i=0;i<n;++i)for(int j=0;j<n;++j)flags(i,j)=result.correlation_out_of_range[a][i*n+j];
      flags.attr("dimnames")=List::create(result.trait_names,result.trait_names);
      categories.push_back(List::create(
        Named("genetic_covariance")=estimate_matrix(category.genetic_covariance),
        Named("genetic_correlation")=estimate_matrix(category.genetic_correlation),
        Named("correlation_out_of_range")=flags),result.annotation_names[a]);
      for(int i=0;i<n;++i)
        append(result.annotation_names[a],"h2",category.genetic_covariance[i*n+i],result.trait_names[i]);
      for(int i=0;i<n;++i)for(int j=i+1;j<n;++j){
        append(result.annotation_names[a],"cov",category.genetic_covariance[i*n+j],result.trait_names[i],result.trait_names[j]);
        append(result.annotation_names[a],"rg",category.genetic_correlation[i*n+j],result.trait_names[i],result.trait_names[j]);
      }
    }
    for(std::size_t a=0;a<result.annotation_names.size();++a){
      NumericMatrix matrix(n,n); std::fill(matrix.begin(),matrix.end(),NA_REAL);
      for(int i=0;i<n;++i){
        matrix(i,i)=optional_value(result.trait_fits[i].component_heritability[a].estimate);
        append(result.annotation_names[a],"component_h2",result.trait_fits[i].component_heritability[a],result.trait_names[i]);
      }
      std::size_t pair_index=0;
      for(int i=0;i<n;++i)for(int j=i+1;j<n;++j){
        const auto& value=result.pair_fits[pair_index].component_covariance[a];
        matrix(i,j)=matrix(j,i)=optional_value(value.estimate);
        append(result.annotation_names[a],"component_cov",value,result.trait_names[i],result.trait_names[j]);
        ++pair_index;
      }
      matrix.attr("dimnames")=List::create(result.trait_names,result.trait_names);
      component_covariance.push_back(matrix,result.annotation_names[a]);
    }
    matrices=List::create(Named("categories")=categories,
      Named("component_covariance")=component_covariance);
    diagnostics=List::create(Named("used_marker_ids")=markers);
    if(result.joint_jackknife){
      const auto& jack=*result.joint_jackknife;
      CharacterVector jq,jt1,jt2,ja;
      for(const auto& parameter:jack.parameters){
        jq.push_back(parameter.quantity); jt1.push_back(parameter.trait1); jt2.push_back(parameter.trait2);
        if(parameter.annotation)ja.push_back(*parameter.annotation); else ja.push_back(NA_STRING);
      }
      NumericMatrix deletes(jack.block_labels.size(),jack.parameters.size());
      NumericMatrix covariance(jack.parameters.size(),jack.parameters.size());
      for(R_xlen_t i=0;i<deletes.nrow();++i)for(R_xlen_t j=0;j<deletes.ncol();++j)
        deletes(i,j)=jack.delete_estimates[i*deletes.ncol()+j];
      for(R_xlen_t i=0;i<covariance.nrow();++i)for(R_xlen_t j=0;j<covariance.ncol();++j)
        covariance(i,j)=jack.sampling_covariance[i*covariance.ncol()+j];
      diagnostics["joint_jackknife"]=List::create(
        Named("parameters")=DataFrame::create(Named("quantity")=jq,Named("trait1")=jt1,
          Named("trait2")=jt2,Named("component")=ja),
        Named("block_labels")=jack.block_labels,Named("delete_estimates")=deletes,
        Named("sampling_covariance")=covariance);
    }
  }
  DataFrame estimates=DataFrame::create(Named("component")=component,
    Named("quantity")=quantity,Named("trait1")=output_trait1,Named("trait2")=output_trait2,
    Named("estimate")=estimate,Named("standard_error")=standard_error,
    Named("z")=z_score,Named("p_value")=p_value,
    Named("undefined_reason")=undefined_reason,
    Named("uncertainty_reason")=uncertainty_reason);
  return List::create(Named("estimates")=estimates,Named("matrices")=matrices,
    Named("diagnostics")=diagnostics);
}

// [[Rcpp::export]]
Rcpp::List cpp_gcorr_sumher(Rcpp::List statistics,
    Rcpp::NumericMatrix architecture_ld_scores,
    Rcpp::NumericVector weight_sums, Rcpp::NumericVector tagging,
    Rcpp::CharacterVector blocks, double reference_sample_size,
    std::string inflation, double maximum_iterations, double tolerance,
    double cross_maximum_iterations, double cross_tolerance,
    Rcpp::Nullable<Rcpp::NumericMatrix> overlap_intercepts,
    Rcpp::Nullable<Rcpp::NumericMatrix> architecture_weights,
    Rcpp::Nullable<Rcpp::NumericMatrix> categories,
    Rcpp::Nullable<Rcpp::NumericVector> expected_proportions) {
  const CharacterVector trait_names=statistics.names();
  const List first=statistics[0];
  const CharacterVector markers=first["marker"];
  const auto scores=numeric_scores(architecture_ld_scores);
  const auto& components=scores.annotations;
  const gcorr::NamedAnnotationValues sums{components,Rcpp::as<std::vector<double>>(weight_sums)};
  gcorr::SumherOptions marginal_options;
  if(inflation=="multiplicative")marginal_options.inflation=gcorr::SumherInflation::multiplicative;
  else if(inflation=="additive_sample_size")marginal_options.inflation=gcorr::SumherInflation::additive_sample_size;
  marginal_options.maximum_iterations=static_cast<std::size_t>(maximum_iterations);
  marginal_options.tolerance=tolerance;

  CharacterVector component,quantity,output_trait1,output_trait2;
  CharacterVector undefined_reason,uncertainty_reason;
  NumericVector estimate,standard_error,z_score,p_value;
  auto append=[&](const std::string& name,const char* q,
                  const gcorr::EstimateSummary& value,const std::string& trait1,
                  const std::string& trait2=""){
    add_estimate(quantity,estimate,standard_error,z_score,p_value,
      undefined_reason,uncertainty_reason,q,value);
    component.push_back(name); output_trait1.push_back(trait1);
    if(trait2.empty())output_trait2.push_back(NA_STRING); else output_trait2.push_back(trait2);
  };
  auto append_marginal=[&](const gcorr::SumherResult& result,const std::string& trait){
    for(std::size_t a=0;a<result.component_names.size();++a)
      append(result.component_names[a],"h2",result.component_heritability[a],trait);
    append("all","h2",result.total_heritability,trait);
    if(result.inflation)append("all","inflation",*result.inflation,trait);
  };
  auto trait_matrices=[&](const gcorr::TraitMatrix& source,const std::vector<bool>& flags){
    const int n=static_cast<int>(source.trait_names.size());
    NumericMatrix covariance(n,n),correlation(n,n),covariance_se(n,n),correlation_se(n,n);
    Rcpp::LogicalMatrix out_of_range(n,n);
    for(int i=0;i<n;++i)for(int j=0;j<n;++j){
      const auto k=i*n+j;
      covariance(i,j)=optional_value(source.genetic_covariance[k].estimate);
      covariance_se(i,j)=optional_value(source.genetic_covariance[k].standard_error);
      correlation(i,j)=optional_value(source.genetic_correlation[k].estimate);
      correlation_se(i,j)=optional_value(source.genetic_correlation[k].standard_error);
      out_of_range(i,j)=flags.empty()?false:flags[k];
    }
    const auto names=List::create(source.trait_names,source.trait_names);
    covariance.attr("dimnames")=names; covariance_se.attr("dimnames")=names;
    correlation.attr("dimnames")=names; correlation_se.attr("dimnames")=names;
    out_of_range.attr("dimnames")=names;
    return List::create(Named("genetic_covariance")=covariance,
      Named("genetic_covariance_se")=covariance_se,
      Named("genetic_correlation")=correlation,
      Named("genetic_correlation_se")=correlation_se,
      Named("correlation_out_of_range")=out_of_range);
  };
  auto joint_output=[&](const gcorr::JointJackknife& jack){
    CharacterVector jq,jt1,jt2,ja;
    for(const auto& parameter:jack.parameters){
      jq.push_back(parameter.quantity); jt1.push_back(parameter.trait1); jt2.push_back(parameter.trait2);
      if(parameter.annotation)ja.push_back(*parameter.annotation); else ja.push_back(NA_STRING);
    }
    NumericMatrix deletes(jack.block_labels.size(),jack.parameters.size());
    NumericMatrix covariance(jack.parameters.size(),jack.parameters.size());
    for(R_xlen_t i=0;i<deletes.nrow();++i)for(R_xlen_t j=0;j<deletes.ncol();++j)
      deletes(i,j)=jack.delete_estimates[i*deletes.ncol()+j];
    for(R_xlen_t i=0;i<covariance.nrow();++i)for(R_xlen_t j=0;j<covariance.ncol();++j)
      covariance(i,j)=jack.sampling_covariance[i*covariance.ncol()+j];
    return List::create(Named("parameters")=DataFrame::create(
      Named("quantity")=jq,Named("trait1")=jt1,Named("trait2")=jt2,Named("component")=ja),
      Named("block_labels")=jack.block_labels,Named("delete_estimates")=deletes,
      Named("sampling_covariance")=covariance);
  };
  auto marginal_diagnostics=[&](const gcorr::SumherResult& result){
    List out=List::create(Named("iterations")=static_cast<double>(result.iterations),
      Named("weight_sums")=result.weight_sums);
    if(result.jackknife){
      const auto& jack=*result.jackknife;
      NumericMatrix deletes(jack.block_labels.size(),jack.parameter_names.size());
      NumericMatrix covariance(jack.parameter_names.size(),jack.parameter_names.size());
      for(R_xlen_t i=0;i<deletes.nrow();++i)for(R_xlen_t j=0;j<deletes.ncol();++j)
        deletes(i,j)=jack.delete_estimates[i*deletes.ncol()+j];
      for(R_xlen_t i=0;i<covariance.nrow();++i)for(R_xlen_t j=0;j<covariance.ncol();++j)
        covariance(i,j)=jack.sampling_covariance[i*covariance.ncol()+j];
      out["jackknife"]=List::create(Named("block_labels")=jack.block_labels,
        Named("parameter_names")=jack.parameter_names,Named("delete_estimates")=deletes,
        Named("sampling_covariance")=covariance);
    }
    return out;
  };

  const bool category_mode=architecture_weights.isNotNull();
  std::optional<gmat::AnnotationMatrix> architecture;
  std::optional<gmat::AnnotationMatrix> category_matrix;
  std::optional<gcorr::NamedAnnotationValues> expected;
  if(category_mode){
    NumericMatrix weights_matrix(architecture_weights.get()),category_values(categories.get());
    const auto category_names=Rcpp::as<std::vector<std::string>>(Rcpp::colnames(category_values));
    std::vector<double> weights_row_major,categories_row_major;
    weights_row_major.reserve(weights_matrix.size()); categories_row_major.reserve(category_values.size());
    for(R_xlen_t i=0;i<weights_matrix.nrow();++i)for(R_xlen_t j=0;j<weights_matrix.ncol();++j)
      weights_row_major.push_back(weights_matrix(i,j));
    for(R_xlen_t i=0;i<category_values.nrow();++i)for(R_xlen_t j=0;j<category_values.ncol();++j)
      categories_row_major.push_back(category_values(i,j));
    const auto native_markers=Rcpp::as<std::vector<std::string>>(markers);
    architecture.emplace(native_markers,components,std::move(weights_row_major));
    category_matrix.emplace(native_markers,category_names,std::move(categories_row_major));
    if(expected_proportions.isNotNull()){
      NumericVector values(expected_proportions.get());
      expected=gcorr::NamedAnnotationValues{category_names,Rcpp::as<std::vector<double>>(values)};
    }
  }
  auto category_output=[&](const gcorr::SumherResult& fit,const std::string& trait){
    List out;
    if(!category_mode)return out;
    const auto summary=gcorr::summarize_sumher_categories(fit,*architecture,*category_matrix);
    const auto tests=gcorr::test_sumher_enrichment(summary,expected);
    for(std::size_t a=0;a<summary.category_names.size();++a){
      append(summary.category_names[a],"category_h2",summary.category_heritability[a],trait);
      append(summary.category_names[a],"heritability_proportion",summary.heritability_proportion[a],trait);
      append(summary.category_names[a],"enrichment",summary.enrichment[a],trait);
      append(summary.category_names[a],"enrichment_contrast",tests.contrasts[a],trait);
    }
    out=List::create(Named("category_names")=summary.category_names,
      Named("category_marker_counts")=summary.category_marker_counts,
      Named("reference_proportions")=summary.reference_proportions,
      Named("expected_proportions")=tests.expected_proportions);
    if(summary.jackknife)out["category_jackknife"]=joint_output(*summary.jackknife);
    if(tests.jackknife)out["enrichment_jackknife"]=joint_output(*tests.jackknife);
    return out;
  };

  auto input=numeric_input(statistics,blocks);
  input.weight_ld=Rcpp::as<std::vector<double>>(tagging);
  std::vector<gcorr::SumherPairOverlap> pairs;
  if(statistics.size()>1) {
    NumericMatrix overlaps(overlap_intercepts.get());
    for(R_xlen_t i=0;i<statistics.size();++i)for(R_xlen_t j=i+1;j<statistics.size();++j)
      if(!NumericVector::is_na(overlaps(i,j)))
        pairs.push_back({Rcpp::as<std::string>(trait_names[i]),Rcpp::as<std::string>(trait_names[j]),overlaps(i,j)});
  }
  gcorr::SumherCrossOptions options; options.marginal=marginal_options;
  options.maximum_iterations=static_cast<std::size_t>(cross_maximum_iterations);
  options.tolerance=cross_tolerance;
  const auto fitted=gcorr::fit_aligned_sumher(std::move(input),scores,sums,pairs,options);

  List matrices,diagnostics=List::create(),category_diagnostics;
  if(statistics.size()==1){
    const auto& result=fitted.trait_fits.front();
    const auto trait=Rcpp::as<std::string>(trait_names[0]);
    append_marginal(result,trait); category_diagnostics=category_output(result,trait);
    diagnostics=marginal_diagnostics(result); diagnostics["used_marker_ids"]=markers;
  } else {
    const auto& result=fitted;
    List marginal_details,pair_details,component_matrices;
    for(std::size_t i=0;i<result.trait_fits.size();++i){
      append_marginal(result.trait_fits[i],result.trait_names[i]);
      marginal_details.push_back(marginal_diagnostics(result.trait_fits[i]),result.trait_names[i]);
      if(category_mode)category_diagnostics.push_back(category_output(result.trait_fits[i],result.trait_names[i]),result.trait_names[i]);
    }
    std::size_t pair_index=0;
    for(std::size_t i=0;i<result.trait_names.size();++i)for(std::size_t j=i+1;j<result.trait_names.size();++j){
      const auto& pair=result.pair_fits[pair_index]; const auto k=i*result.trait_names.size()+j;
      for(std::size_t a=0;a<result.component_names.size();++a){
        append(result.component_names[a],"cov",result.components[a].genetic_covariance[k],result.trait_names[i],result.trait_names[j]);
        append(result.component_names[a],"rg",result.components[a].genetic_correlation[k],result.trait_names[i],result.trait_names[j]);
      }
      append("all","cov",result.total.genetic_covariance[k],result.trait_names[i],result.trait_names[j]);
      append("all","rg",result.total.genetic_correlation[k],result.trait_names[i],result.trait_names[j]);
      append("all","overlap_intercept",pair.overlap_intercept,result.trait_names[i],result.trait_names[j]);
      List detail=List::create(Named("trait1")=pair.trait1,Named("trait2")=pair.trait2,
        Named("iterations")=static_cast<double>(pair.iterations),
        Named("overlap_intercept_fixed")=pair.overlap_intercept_fixed);
      if(pair.jackknife)detail["jackknife"]=joint_output(*pair.jackknife);
      pair_details.push_back(detail); ++pair_index;
    }
    for(std::size_t a=0;a<result.components.size();++a)
      component_matrices.push_back(trait_matrices(result.components[a],result.correlation_out_of_range[a]),result.component_names[a]);
    matrices=List::create(Named("components")=component_matrices,
      Named("total")=trait_matrices(result.total,result.correlation_out_of_range.back()));
    if(category_mode){
      const auto transformed=gcorr::prepare_annotation_covariance(result,*architecture,
        *category_matrix,result.trait_names);
      List category_covariance;
      for(std::size_t a=0;a<transformed.groups.size();++a){
        const int n=static_cast<int>(result.trait_names.size()); NumericMatrix matrix(n,n);
        for(int i=0;i<n;++i)for(int j=0;j<n;++j)matrix(i,j)=transformed.groups[a].genetic_covariance[i*n+j];
        matrix.attr("dimnames")=List::create(result.trait_names,result.trait_names);
        category_covariance.push_back(matrix,transformed.group_names[a]);
      }
      matrices["category_genetic_covariance"]=category_covariance;
      if(!transformed.joint_sampling_covariance.empty())
        diagnostics["category_joint_sampling_covariance"]=transformed.joint_sampling_covariance;
    }
    diagnostics["used_marker_ids"]=markers;
    diagnostics["marginals"]=marginal_details; diagnostics["pairs"]=pair_details;
    if(result.joint_jackknife)diagnostics["joint_jackknife"]=joint_output(*result.joint_jackknife);
  }
  diagnostics["category"]=category_diagnostics;
  diagnostics["architecture_weight_sums"]=weight_sums;
  diagnostics["tagging"]=tagging;
  DataFrame estimates=DataFrame::create(Named("component")=component,
    Named("quantity")=quantity,Named("trait1")=output_trait1,Named("trait2")=output_trait2,
    Named("estimate")=estimate,Named("standard_error")=standard_error,
    Named("z")=z_score,Named("p_value")=p_value,
    Named("undefined_reason")=undefined_reason,
    Named("uncertainty_reason")=uncertainty_reason);
  return List::create(Named("estimates")=estimates,Named("matrices")=matrices,
    Named("diagnostics")=diagnostics);
}

// [[Rcpp::export]]
Rcpp::List cpp_gcorr_prepare_regions(Rcpp::List regional_ld,
                                     Rcpp::NumericVector reference_sample_sizes) {
  const CharacterVector region_names=regional_ld.names();
  List pointers,diagnostics;
  for(R_xlen_t r=0;r<regional_ld.size();++r){
    const auto region_name=Rcpp::as<std::string>(region_names[r]);
    NumericMatrix matrix=regional_ld[r];
    const auto markers=Rcpp::as<std::vector<std::string>>(Rcpp::rownames(matrix));
    std::vector<double> values; values.reserve(matrix.size());
    for(R_xlen_t i=0;i<matrix.nrow();++i)for(R_xlen_t j=0;j<matrix.ncol();++j)
      values.push_back(matrix(i,j));
    auto prepared=gcorr::PreparedRegionalLd::from_matrix(markers,
      {values.data(),markers.size(),markers.size(),markers.size()},
      static_cast<std::uint64_t>(reference_sample_sizes[r]));
    append_prepared_region(pointers,diagnostics,region_name,std::move(prepared));
  }
  return List::create(Named("pointers")=pointers,Named("diagnostics")=diagnostics);
}

// [[Rcpp::export]]
Rcpp::List cpp_gcorr_prepare_regions_from_reference(
    std::string prefix,Rcpp::List region_indices) {
  const CharacterVector region_names=region_indices.names();
  List pointers,diagnostics;
  const gmat::SparseLdDiskReader reader(prefix);
  for(R_xlen_t r=0;r<region_indices.size();++r){
    const auto region_name=Rcpp::as<std::string>(region_names[r]);
    const NumericVector indices=region_indices[r];
    std::vector<std::uint64_t> selected;
    selected.reserve(indices.size());
    for(const double value:indices){
      if(!std::isfinite(value)||value<0||value!=std::floor(value))
        Rcpp::stop("Invalid sparse-LD regional index");
      selected.push_back(static_cast<std::uint64_t>(value));
    }
    const auto region=reader.read_region(selected,2048);
    std::vector<std::string> markers;
    markers.reserve(region.markers.size());
    for(const auto& marker:region.markers)markers.push_back(marker.marker_id);
    auto prepared=gcorr::PreparedRegionalLd::from_matrix(std::move(markers),
      {region.matrix.data(),region.markers.size(),region.markers.size(),
       region.markers.size()},region.reference_sample_count);
    append_prepared_region(pointers,diagnostics,region_name,std::move(prepared));
  }
  const auto read=reader.diagnostics();
  return List::create(Named("pointers")=pointers,
    Named("diagnostics")=diagnostics,
    Named("reader_diagnostics")=List::create(
      Named("reader_opens")=1.0,
      Named("regions_read")=static_cast<double>(region_indices.size()),
      Named("index_builds")=static_cast<double>(read.index_builds),
      Named("entries_scanned")=static_cast<double>(read.entries_scanned),
      Named("index_entries_scanned")=static_cast<double>(read.index_entries_scanned)));
}

// [[Rcpp::export]]
Rcpp::List cpp_gcorr_regional_fit(std::string method,Rcpp::List statistics,
                                  SEXP prepared_region,Rcpp::List options) {
  Rcpp::XPtr<gcorr::PreparedRegionalLd> region(prepared_region);
  const CharacterVector traits=statistics.names();
  auto number=[&](const char* name,double fallback){
    return options.containsElementNamed(name)?Rcpp::as<double>(options[name]):fallback;
  };
  CharacterVector component,quantity,trait1,trait2,undefined_reason,uncertainty_reason;
  NumericVector estimate,standard_error,z_score,p_value,lower,upper,p_value_mc_se;
  auto append=[&](const char* q,const gcorr::EstimateSummary& value,
                  const std::string& first,const std::string& second="",
                  double interval_lower=NA_REAL,double interval_upper=NA_REAL,
                  double mc_se=NA_REAL){
    add_estimate(quantity,estimate,standard_error,z_score,p_value,
      undefined_reason,uncertainty_reason,q,value);
    component.push_back("region"); trait1.push_back(first);
    if(second.empty())trait2.push_back(NA_STRING); else trait2.push_back(second);
    lower.push_back(interval_lower); upper.push_back(interval_upper);
    p_value_mc_se.push_back(mc_se);
  };
  auto frame=[&](){return DataFrame::create(Named("component")=component,
    Named("quantity")=quantity,Named("trait1")=trait1,Named("trait2")=trait2,
    Named("estimate")=estimate,Named("standard_error")=standard_error,
    Named("z")=z_score,Named("p_value")=p_value,
    Named("lower")=lower,Named("upper")=upper,
    Named("p_value_mc_se")=p_value_mc_se,
    Named("undefined_reason")=undefined_reason,
    Named("uncertainty_reason")=uncertainty_reason);};
  auto scalar_n=[&](const List& input){NumericVector n=input["n"];return n[0];};
  auto hess_options=[&](){gcorr::HessOptions out;
    out.maximum_components=static_cast<std::size_t>(number("maximum_components",50));
    out.minimum_eigenvalue=number("minimum_eigenvalue",1);
    out.relative_eigenvalue_tolerance=number("relative_eigenvalue_tolerance",1e-10);
    return out;};
  List diagnostics,matrices;
  const List first=statistics[0]; const auto first_name=Rcpp::as<std::string>(traits[0]);
  if(method=="hess"){
    gcorr::HessInput input{named_values(first,"z"),scalar_n(first),
      number("outside_heritability",0)};
    const auto result=gcorr::fit_hess(input,*region,hess_options());
    append("h2",result.heritability,first_name);
    diagnostics=List::create(Named("used_marker_ids")=result.diagnostics.used_marker_ids,
      Named("eigenvalues")=result.diagnostics.eigenvalues,
      Named("numerical_rank")=static_cast<double>(result.diagnostics.numerical_rank),
      Named("retained_components")=static_cast<double>(result.diagnostics.retained_components),
      Named("retained_positive_eigenvalue_fraction")=result.diagnostics.retained_positive_eigenvalue_fraction,
      Named("eigensystem_reused")=result.diagnostics.regional_eigensystem_reused,
      Named("outside_heritability")=result.outside_heritability,
      Named("total_heritability_outside_unit_interval")=result.total_heritability_outside_unit_interval);
  } else if(method=="rho_hess"){
    const List second=statistics[1]; const auto second_name=Rcpp::as<std::string>(traits[1]);
    gcorr::RhoHessInput input;
    input.trait1={named_values(first,"z"),scalar_n(first),number("outside_heritability1",0)};
    input.trait2={named_values(second,"z"),scalar_n(second),number("outside_heritability2",0)};
    input.shared_sample_size=number("shared_sample_size",0);
    input.phenotypic_correlation=number("phenotypic_correlation",0);
    input.outside_genetic_covariance=number("outside_genetic_covariance",0);
    const auto result=gcorr::fit_rho_hess(input,*region,hess_options());
    append("h2",result.heritability1,first_name); append("h2",result.heritability2,second_name);
    append("cov",result.genetic_covariance,first_name,second_name);
    append("rg",result.genetic_correlation,first_name,second_name);
    diagnostics=List::create(Named("used_marker_ids")=result.diagnostics.used_marker_ids,
      Named("eigenvalues")=result.diagnostics.eigenvalues,
      Named("numerical_rank")=static_cast<double>(result.diagnostics.numerical_rank),
      Named("retained_components")=static_cast<double>(result.diagnostics.retained_components),
      Named("eigensystem_reused")=result.diagnostics.regional_eigensystem_reused,
      Named("sampling_covariance")=result.sampling_covariance,
      Named("sampling_covariance_undefined_reason")=result.sampling_covariance_undefined_reason,
      Named("local_genetic_matrix_indefinite")=result.local_genetic_matrix_indefinite);
  } else if(method=="supergnova"){
    const List second=statistics[1]; const auto second_name=Rcpp::as<std::string>(traits[1]);
    gcorr::SupergnovaInput input;
    input.z1=named_values(first,"z"); input.z2=named_values(second,"z");
    input.sample_size1=scalar_n(first); input.sample_size2=scalar_n(second);
    input.reference_sample_size=region->reference_sample_count();
    input.overlap_intercept=number("overlap_intercept",0);
    input.overlap_intercept_variance=number("overlap_intercept_variance",0);
    gcorr::SupergnovaOptions fit_options;
    fit_options.minimum_components=static_cast<std::size_t>(number("minimum_components",10));
    fit_options.maximum_components=static_cast<std::size_t>(number("maximum_components",0));
    fit_options.relative_eigenvalue_tolerance=number("relative_eigenvalue_tolerance",1e-10);
    const auto result=gcorr::fit_supergnova(input,*region,fit_options);
    append("cov",result.genetic_covariance,first_name,second_name);
    NumericVector candidate_components,candidate_covariance,candidate_variance;
    for(const auto& candidate:result.candidates){
      candidate_components.push_back(static_cast<double>(candidate.components));
      candidate_covariance.push_back(candidate.covariance);
      candidate_variance.push_back(candidate.selection_variance);
    }
    diagnostics=List::create(Named("used_marker_ids")=result.used_marker_ids,
      Named("eigenvalues")=result.eigenvalues,
      Named("numerical_rank")=static_cast<double>(result.numerical_rank),
      Named("retained_components")=static_cast<double>(result.retained_components),
      Named("eigensystem_reused")=result.regional_eigensystem_reused,
      Named("conditional_variance")=result.conditional_variance,
      Named("overlap_variance_contribution")=result.overlap_variance_contribution,
      Named("candidates")=DataFrame::create(Named("components")=candidate_components,
        Named("covariance")=candidate_covariance,Named("selection_variance")=candidate_variance));
  } else if(method=="lava"){
    gcorr::LavaInput input;
    for(R_xlen_t t=0;t<statistics.size();++t){
      const List data=statistics[t];
      gcorr::LavaTraitInput trait{Rcpp::as<std::string>(traits[t]),
        named_values(data,"z"),scalar_n(data),{}};
      if(options.containsElementNamed("binary") && !Rf_isNull(options["binary"])){
        const List binary=options["binary"];
        if(binary.containsElementNamed(trait.name.c_str())){
          const List specification=binary[trait.name];
          trait.binary=gcorr::LavaBinaryTrait{
            Rcpp::as<double>(specification["cases"]),
            Rcpp::as<double>(specification["controls"]),
            Rcpp::as<double>(specification["population_prevalence"])};
        }
      }
      input.traits.push_back(std::move(trait));
    }
    if(options.containsElementNamed("allele_frequencies") &&
       !Rf_isNull(options["allele_frequencies"]))
      input.allele_frequencies=gcorr::NamedValues{
        input.traits[0].statistics.marker_ids,
        Rcpp::as<std::vector<double>>(options["allele_frequencies"])};
    if(statistics.size()>1){
      NumericMatrix correlation=options["sampling_correlation"];
      std::vector<double> values; values.reserve(correlation.size());
      for(R_xlen_t i=0;i<correlation.nrow();++i)for(R_xlen_t j=0;j<correlation.ncol();++j)
        values.push_back(correlation(i,j));
      input.sampling_correlation=gcorr::NamedSymmetricMatrix{
        Rcpp::as<std::vector<std::string>>(traits),std::move(values)};
    }
    gcorr::LavaOptions fit_options;
    fit_options.explained_ld_fraction=number("explained_ld_fraction",.99);
    fit_options.minimum_components=static_cast<std::size_t>(number("minimum_components",2));
    fit_options.maximum_sample_fraction=number("maximum_sample_fraction",.75);
    fit_options.relative_eigenvalue_tolerance=number("relative_eigenvalue_tolerance",1e-10);
    fit_options.univariate_threshold=number("univariate_threshold",.05);
    const auto result=gcorr::fit_lava(input,*region,fit_options);
    List univariate;
    for(std::size_t t=0;t<result.traits.size();++t){
      const auto& trait=result.traits[t]; const auto& test=trait.univariate;
      auto h2=trait.heritability; h2.p_value=test.p_value;
      append("h2",h2,trait.name);
      if(trait.liability_heritability)
        append("h2_liability",*trait.liability_heritability,trait.name);
      univariate.push_back(List::create(
        Named("p_value")=optional_value(test.p_value),
        Named("eligible")=test.eligible_for_bivariate,
        Named("screening_reason")=test.screening_reason,
        Named("processing_valid")=trait.processing_valid,
        Named("high_component_sample_ratio")=trait.high_component_sample_ratio,
        Named("negative_genetic_variance")=trait.negative_genetic_variance,
        Named("negative_sampling_variance")=trait.negative_sampling_variance,
        Named("trait_type")=trait.binary?"binary":"continuous",
        Named("heritability_scale")=trait.binary?"observed":"continuous",
        Named("sample_size")=trait.sample_size,
        Named("test_distribution")=test.distribution==gcorr::LavaUnivariateDistribution::chi_square?"chi_square":"F",
        Named("test_statistic")=optional_value(test.statistic),
        Named("numerator_df")=test.numerator_df,
        Named("denominator_df")=test.denominator_df,
        Named("test_undefined_reason")=test.undefined_reason,
        Named("binary_maximum_relative_statistic_error")=trait.binary_maximum_relative_statistic_error),trait.name);
    }
    const int count=static_cast<int>(result.traits.size());
    NumericMatrix covariance(count,count),correlation(count,count),sampling(count,count);
    const bool simulate=options.containsElementNamed("inference") &&
      !Rf_isNull(options["inference"]);
    const std::string analysis=options.containsElementNamed("analysis")?
      Rcpp::as<std::string>(options["analysis"]):"marginal";
    List inference=List::create(Named("requested")=false),pairs,conditional;
    for(int i=0;i<count;++i)for(int j=0;j<count;++j){const auto k=i*count+j;
      covariance(i,j)=optional_value(result.genetic_covariance[k].estimate);
      correlation(i,j)=optional_value(result.genetic_correlation[k].estimate);
      sampling(i,j)=optional_value(result.sampling_covariance[k].estimate);
      if(i<j){
        append("cov",result.genetic_covariance[k],result.traits[i].name,result.traits[j].name);
        auto rg=result.genetic_correlation[k];
        if(simulate && analysis=="marginal"){
          const auto x=gcorr::infer_lava_bivariate(result,i,j,
            lava_simulation_options(Rcpp::as<List>(options["inference"])));
          rg=lava_simulated_summary(rg,x.p_value,x.unavailable_reason);
          append("rg",rg,result.traits[i].name,result.traits[j].name,
            optional_value(x.correlation_interval.lower),
            optional_value(x.correlation_interval.upper),optional_value(x.p_value_mc_se));
          gcorr::EstimateSummary squared; squared.estimate=x.r_squared;
          if(!squared.estimate)squared.undefined_reason=x.unavailable_reason;
          squared.uncertainty_undefined_reason=rg.uncertainty_undefined_reason;
          append("rg_squared",squared,result.traits[i].name,result.traits[j].name,
            optional_value(x.r_squared_interval.lower),optional_value(x.r_squared_interval.upper));
          List pair=List::create(Named("trait1")=result.traits[i].name,
            Named("trait2")=result.traits[j].name,Named("seed")=static_cast<double>(x.seed),
            Named("screened_in")=x.screened_in,Named("out_of_range")=x.out_of_range,
            Named("p_value")=optional_value(x.p_value),Named("p_value_mc_se")=optional_value(x.p_value_mc_se),
            Named("pvalue_draws")=static_cast<double>(x.pvalue_draws),
            Named("pvalue_stages")=static_cast<double>(x.pvalue_stages),
            Named("pvalue_precision_met")=x.pvalue_precision_met,
            Named("pvalue_budget_exhausted")=x.pvalue_budget_exhausted,
            Named("correlation_interval")=lava_interval(x.correlation_interval),
            Named("r_squared_interval")=lava_interval(x.r_squared_interval),
            Named("interval_draws")=static_cast<double>(x.interval_draws),
            Named("interval_retained")=static_cast<double>(x.interval_retained),
            Named("interval_discarded")=static_cast<double>(x.interval_discarded),
            Named("interval_precision_met")=x.interval_precision_met,
            Named("interval_budget_exhausted")=x.interval_budget_exhausted,
            Named("unavailable_reason")=x.unavailable_reason,
            Named("interval_undefined_reason")=x.interval_undefined_reason);
          pairs.push_back(pair);
        } else append("rg",rg,result.traits[i].name,result.traits[j].name);
      }
    }
    if(simulate && analysis=="marginal")
      inference=List::create(Named("requested")=true,Named("pairs")=pairs);
    gcorr::LavaMultivariateOptions numerical;
    numerical.maximum_traits=static_cast<std::size_t>(number("maximum_traits",32));
    numerical.minimum_relative_eigenvalue=number("minimum_relative_eigenvalue",1e-4);
    numerical.residual_variance_tolerance=number("residual_variance_tolerance",1e-8);
    if(analysis=="partial"){
      Rcpp::IntegerVector target_indices=options["targets"];
      const std::array<std::size_t,2> targets{
        static_cast<std::size_t>(target_indices[0]),static_cast<std::size_t>(target_indices[1])};
      const auto conditioned=Rcpp::as<std::vector<std::size_t>>(options["conditioned_on"]);
      std::optional<gcorr::LavaPartialInferenceResult> simulated;
      gcorr::LavaPartialCorrelationResult point;
      if(simulate){
        gcorr::LavaPartialInferenceOptions controls; controls.numerical=numerical;
        controls.simulation=lava_simulation_options(Rcpp::as<List>(options["inference"]));
        controls.maximum_conditioning_r_squared=number("maximum_conditioning_r_squared",.95);
        simulated=gcorr::infer_lava_partial_correlation(result,targets,conditioned,controls);
        point=simulated->point;
      } else point=gcorr::estimate_lava_partial_correlation(result,targets,conditioned,numerical);
      auto partial=point.partial_correlation;
      if(simulated){const auto& x=*simulated;
        const auto reason=x.pvalue_undefined_reason.empty()?x.unavailable_reason:x.pvalue_undefined_reason;
        partial=lava_simulated_summary(partial,x.p_value,reason);
        append("partial_rg",partial,point.targets[0],point.targets[1],
          optional_value(x.correlation_interval.lower),optional_value(x.correlation_interval.upper),
          optional_value(x.p_value_mc_se));
        inference=List::create(Named("requested")=true,Named("seed")=static_cast<double>(x.seed),
          Named("screened_in")=x.screened_in,Named("p_value")=optional_value(x.p_value),
          Named("p_value_mc_se")=optional_value(x.p_value_mc_se),
          Named("pvalue_draws")=static_cast<double>(x.pvalue_draws),
          Named("pvalue_stages")=static_cast<double>(x.pvalue_stages),
          Named("pvalue_retained")=NumericVector(x.pvalue_retained.begin(),x.pvalue_retained.end()),
          Named("pvalue_discarded")=NumericVector(x.pvalue_discarded.begin(),x.pvalue_discarded.end()),
          Named("pvalue_precision_met")=x.pvalue_precision_met,
          Named("pvalue_budget_exhausted")=x.pvalue_budget_exhausted,
          Named("correlation_interval")=lava_interval(x.correlation_interval),
          Named("interval_draws")=static_cast<double>(x.interval_draws),
          Named("interval_retained")=static_cast<double>(x.interval_retained),
          Named("interval_discarded")=static_cast<double>(x.interval_discarded),
          Named("interval_precision_met")=x.interval_precision_met,
          Named("interval_budget_exhausted")=x.interval_budget_exhausted,
          Named("unavailable_reason")=x.unavailable_reason,
          Named("pvalue_undefined_reason")=x.pvalue_undefined_reason,
          Named("interval_undefined_reason")=x.interval_undefined_reason);
      } else append("partial_rg",partial,point.targets[0],point.targets[1]);
      append("partial_cov",point.partial_genetic_covariance,point.targets[0],point.targets[1]);
      for(int i=0;i<2;++i){
        append("residual_genetic_variance",point.residual_genetic_variances[i],point.targets[i]);
        append("explained_proportion",point.explained_proportions[i],point.targets[i]);
      }
      conditional=List::create(Named("targets")=point.targets,
        Named("conditioned_on")=point.conditioned_on,
        Named("joint_covariance")=lava_covariance_check(point.joint_covariance),
        Named("conditioning_covariance")=lava_covariance_check(point.conditioning_covariance),
        Named("residual_near_zero_or_negative")=point.residual_near_zero_or_negative,
        Named("correlation_out_of_range")=point.correlation_out_of_range,
        Named("unavailable_reason")=point.unavailable_reason);
    } else if(analysis=="regression"){
      const std::size_t outcome=static_cast<std::size_t>(Rcpp::as<int>(options["outcome"]));
      const auto predictors=Rcpp::as<std::vector<std::size_t>>(options["predictors"]);
      std::optional<gcorr::LavaRegressionInferenceResult> simulated;
      gcorr::LavaRegressionResult point;
      if(simulate){
        gcorr::LavaRegressionInferenceOptions controls; controls.numerical=numerical;
        controls.simulation=lava_simulation_options(Rcpp::as<List>(options["inference"]));
        simulated=gcorr::infer_lava_regression(result,outcome,predictors,controls);
        point=simulated->point;
      } else point=gcorr::estimate_lava_regression(result,outcome,predictors,numerical);
      for(std::size_t j=0;j<predictors.size();++j){
        auto coefficient=point.coefficients[j]; auto standardized=point.standardized_coefficients[j];
        if(simulated){const auto& x=*simulated;
          const auto reason=x.pvalue_undefined_reasons[j].empty()?x.unavailable_reason:x.pvalue_undefined_reasons[j];
          coefficient=lava_simulated_summary(coefficient,x.p_values[j],reason);
          standardized=lava_simulated_summary(standardized,x.p_values[j],reason);
          append("coefficient",coefficient,point.outcome,point.predictors[j],
            optional_value(x.coefficient_intervals[j].lower),optional_value(x.coefficient_intervals[j].upper),
            optional_value(x.p_value_mc_se[j]));
          append("standardized_coefficient",standardized,point.outcome,point.predictors[j],
            optional_value(x.standardized_coefficient_intervals[j].lower),
            optional_value(x.standardized_coefficient_intervals[j].upper),optional_value(x.p_value_mc_se[j]));
        } else {
          append("coefficient",coefficient,point.outcome,point.predictors[j]);
          append("standardized_coefficient",standardized,point.outcome,point.predictors[j]);
        }
      }
      if(simulated){const auto& x=*simulated;
        append("explained_genetic_variance",lava_simulated_summary(point.explained_genetic_variance,{},x.interval_undefined_reason),point.outcome,"",
          optional_value(x.explained_genetic_variance_interval.lower),optional_value(x.explained_genetic_variance_interval.upper));
        append("r_squared",lava_simulated_summary(point.r_squared,{},x.interval_undefined_reason),point.outcome,"",
          optional_value(x.r_squared_interval.lower),optional_value(x.r_squared_interval.upper));
        NumericVector p_values(x.p_values.size()),mc_se(x.p_values.size());
        for(std::size_t j=0;j<x.p_values.size();++j){p_values[j]=optional_value(x.p_values[j]);mc_se[j]=optional_value(x.p_value_mc_se[j]);}
        p_values.attr("names")=point.predictors; mc_se.attr("names")=point.predictors;
        inference=List::create(Named("requested")=true,Named("seed")=static_cast<double>(x.seed),
          Named("screened_in")=x.screened_in,Named("p_values")=p_values,
          Named("p_value_mc_se")=mc_se,Named("pvalue_draws")=static_cast<double>(x.pvalue_draws),
          Named("pvalue_stages")=static_cast<double>(x.pvalue_stages),
          Named("pvalue_retained")=x.pvalue_retained,Named("pvalue_discarded")=x.pvalue_discarded,
          Named("pvalue_precision_met")=x.pvalue_precision_met,
          Named("pvalue_budget_exhausted")=x.pvalue_budget_exhausted,
          Named("r_squared_interval")=lava_interval(x.r_squared_interval),
          Named("explained_genetic_variance_interval")=lava_interval(x.explained_genetic_variance_interval),
          Named("interval_draws")=static_cast<double>(x.interval_draws),
          Named("interval_retained")=static_cast<double>(x.interval_retained),
          Named("interval_discarded")=static_cast<double>(x.interval_discarded),
          Named("interval_precision_met")=x.interval_precision_met,
          Named("interval_budget_exhausted")=x.interval_budget_exhausted,
          Named("unavailable_reason")=x.unavailable_reason,
          Named("interval_undefined_reason")=x.interval_undefined_reason);
      } else {
        append("explained_genetic_variance",point.explained_genetic_variance,point.outcome);
        append("r_squared",point.r_squared,point.outcome);
      }
      append("residual_genetic_variance",point.residual_genetic_variance,point.outcome);
      conditional=List::create(Named("outcome")=point.outcome,Named("predictors")=point.predictors,
        Named("joint_covariance")=lava_covariance_check(point.joint_covariance),
        Named("predictor_covariance")=lava_covariance_check(point.predictor_covariance),
        Named("residual_near_zero_or_negative")=point.residual_near_zero_or_negative,
        Named("r_squared_out_of_range")=point.r_squared_out_of_range,
        Named("unavailable_reason")=point.unavailable_reason);
      if(options.containsElementNamed("omnibus") && !Rf_isNull(options["omnibus"])){
        const List controls=options["omnibus"]; gcorr::LavaOmnibusOptions omnibus;
        omnibus.numerical=numerical; omnibus.seed=static_cast<std::uint64_t>(Rcpp::as<double>(controls["seed"]));
        omnibus.draws=static_cast<std::size_t>(Rcpp::as<double>(controls["draws"]));
        omnibus.relative_pvalue_mc_tolerance=Rcpp::as<double>(controls["relative_pvalue_mc_tolerance"]);
        const auto test=gcorr::test_lava_regression(result,outcome,predictors,omnibus);
        gcorr::EstimateSummary summary; summary.estimate=test.statistic; summary.p_value=test.p_value;
        summary.undefined_reason=test.unavailable_reason;
        summary.uncertainty_undefined_reason="Fixed-metric null simulation; no estimator SE or percentile interval.";
        append("omnibus",summary,point.outcome,"",NA_REAL,NA_REAL,optional_value(test.p_value_mc_se));
        conditional["omnibus"]=List::create(Named("seed")=static_cast<double>(test.seed),
          Named("statistic")=optional_value(test.statistic),Named("p_value")=optional_value(test.p_value),
          Named("p_value_mc_se")=optional_value(test.p_value_mc_se),Named("draws")=static_cast<double>(test.draws),
          Named("exceedances")=static_cast<double>(test.exceedances),Named("screened_in")=test.screened_in,
          Named("precision_met")=test.precision_met,Named("budget_exhausted")=test.budget_exhausted,
          Named("unavailable_reason")=test.unavailable_reason);
      }
    }
    const auto dimnames=List::create(traits,traits);
    covariance.attr("dimnames")=dimnames; correlation.attr("dimnames")=dimnames; sampling.attr("dimnames")=dimnames;
    matrices=List::create(Named("genetic_covariance")=covariance,
      Named("genetic_correlation")=correlation,Named("component_sampling_covariance")=sampling);
    diagnostics=List::create(Named("used_marker_ids")=result.used_marker_ids,
      Named("eigenvalues")=result.eigenvalues,
      Named("numerical_rank")=static_cast<double>(result.numerical_rank),
      Named("retained_components")=static_cast<double>(result.retained_components),
      Named("retained_ld_fraction")=result.retained_ld_fraction,
      Named("sample_cap_applied")=result.sample_cap_applied,
      Named("eigensystem_reused")=result.regional_eigensystem_reused,
      Named("univariate")=univariate,Named("inference")=inference,
      Named("conditional")=conditional);
    if(input.allele_frequencies)
      diagnostics["allele_frequencies"]=input.allele_frequencies->values;
  } else if(method=="hdll"){
    const List second=statistics[1]; const auto second_name=Rcpp::as<std::string>(traits[1]);
    gcorr::HdllInput input{{first_name,named_values(first,"z"),scalar_n(first)},
      {second_name,named_values(second,"z"),scalar_n(second)},number("shared_sample_size",0)};
    gcorr::HdllOptions fit_options;
    fit_options.explained_ld_fraction=number("explained_ld_fraction",.99);
    fit_options.relative_eigenvalue_tolerance=number("relative_eigenvalue_tolerance",1e-10);
    fit_options.variance_floor=number("variance_floor",std::exp(-18.0));
    fit_options.alpha=number("alpha",.05);
    fit_options.parameter_tolerance=number("parameter_tolerance",1e-8);
    fit_options.maximum_iterations=static_cast<std::size_t>(number("maximum_iterations",400));
    const auto result=gcorr::fit_hdll(input,*region,fit_options);
    append("h2",result.trait1.heritability,first_name); append("h2",result.trait2.heritability,second_name);
    append("cov",result.genetic_covariance,first_name,second_name);
    append("rg",result.genetic_correlation,first_name,second_name);
    diagnostics=List::create(Named("used_marker_ids")=result.diagnostics.used_marker_ids,
      Named("eigenvalues")=result.diagnostics.eigenvalues,
      Named("numerical_rank")=static_cast<double>(result.diagnostics.numerical_rank),
      Named("retained_components")=static_cast<double>(result.diagnostics.retained_components),
      Named("retained_ld_fraction")=result.diagnostics.retained_ld_fraction,
      Named("eigensystem_reused")=result.diagnostics.regional_eigensystem_reused,
      Named("floored_variances")=static_cast<double>(result.diagnostics.floored_variances),
      Named("intercepts")=NumericVector::create(result.trait1.intercept,
        result.trait2.intercept,result.covariance_intercept),
      Named("correlation_interval")=NumericVector::create(
        optional_value(result.genetic_correlation_interval.lower),
        optional_value(result.genetic_correlation_interval.upper)));
  } else Rcpp::stop("Unknown regional method.");
  return List::create(Named("estimates")=frame(),Named("matrices")=matrices,
    Named("diagnostics")=diagnostics);
}

// [[Rcpp::export]]
Rcpp::List cpp_gcorr_regional_fit_batch(std::string method,Rcpp::List slices,
                                        Rcpp::List prepared_regions,
                                        Rcpp::List options) {
  if(slices.size()!=prepared_regions.size() || slices.size()!=options.size())
    Rcpp::stop("Regional slices, prepared regions, and options must have equal length.");
  Rcpp::List fits(slices.size());
  for(R_xlen_t region=0;region<slices.size();++region)
    fits[region]=cpp_gcorr_regional_fit(method,Rcpp::as<Rcpp::List>(slices[region]),
      prepared_regions[region],Rcpp::as<Rcpp::List>(options[region]));
  fits.attr("names")=slices.names();
  return fits;
}

// [[Rcpp::export]]
Rcpp::List cpp_gcorr_joint_hess_fit(std::string method,Rcpp::List slices,
                                    Rcpp::List prepared_regions,Rcpp::List options, bool projected = false) {
  auto number=[&](const char* name,double fallback){
    return options.containsElementNamed(name)?Rcpp::as<double>(options[name]):fallback;
  };
  gcorr::HessJointOptions fit_options;
  const std::string uncertainty=options.containsElementNamed("uncertainty")
    ? Rcpp::as<std::string>(options["uncertainty"]) : "strict";
  if(uncertainty!="strict" && uncertainty!="moment" && uncertainty!="hess")
    Rcpp::stop("Unknown joint HESS uncertainty policy");
  const auto policy=uncertainty=="hess" ? gcorr::HessUncertaintyPolicy::hess_software
    : uncertainty=="moment" ? gcorr::HessUncertaintyPolicy::estimated_moments
    : gcorr::HessUncertaintyPolicy::strict_conditional;
  fit_options.regional.maximum_components=static_cast<std::size_t>(number("maximum_components",50));
  fit_options.regional.minimum_eigenvalue=number("minimum_eigenvalue",1);
  fit_options.regional.relative_eigenvalue_tolerance=number("relative_eigenvalue_tolerance",1e-10);
  fit_options.minimum_correction_denominator=number("minimum_correction_denominator",1e-8);
  const CharacterVector region_names=slices.names();
  const List first_region=slices[0]; const CharacterVector trait_names=first_region.names();
  CharacterVector region,component,quantity,trait1,trait2,undefined_reason,uncertainty_reason;
  NumericVector estimate,standard_error,z_score,p_value;
  auto append=[&](const std::string& region_name,const char* q,
                  const gcorr::EstimateSummary& value,const std::string& first,
                  const std::string& second=""){
    add_estimate(quantity,estimate,standard_error,z_score,p_value,
      undefined_reason,uncertainty_reason,q,value);
    if(region_name.empty())region.push_back(NA_STRING); else region.push_back(region_name);
    component.push_back(region_name.empty()?"total":"region");
    trait1.push_back(first); if(second.empty())trait2.push_back(NA_STRING); else trait2.push_back(second);
  };
  auto moment_diagnostics=[&](const List& region) {
    gcorr::HessDiagnostics d;
    // Membership is checked in R; only ranks and moments enter this fit.
    auto whole=[&](const char* key) { const double v=Rcpp::as<double>(region[key]);
      if(!std::isfinite(v)||v<0||v!=std::floor(v)||v>9007199254740992.)Rcpp::stop("Invalid projected rank");
      return static_cast<std::size_t>(v); };
    d.retained_components=whole("retained_components");d.numerical_rank=whole("numerical_rank");
    return d;
  };
  List regional_diagnostics; List diagnostics;
  if(method=="hess"){
    std::vector<gcorr::PreparedHessRegionInput> inputs;
    if(!projected)for(R_xlen_t r=0;r<slices.size();++r){
      Rcpp::XPtr<gcorr::PreparedRegionalLd> pointer(prepared_regions[r]);
      std::shared_ptr<const gcorr::PreparedRegionalLd> ld(pointer.get(),[](const gcorr::PreparedRegionalLd*){});
      const List slice=slices[r]; const List data=slice[0];
      inputs.push_back({Rcpp::as<std::string>(region_names[r]),ld,named_values(data,"z")});
    }
    const List data=first_region[0]; NumericVector n=data["n"];
    std::vector<gcorr::AlignedHessMomentRegionInput> moments;
    if(projected)for(R_xlen_t r=0;r<prepared_regions.size();++r) {
      const List region=prepared_regions[r];const NumericMatrix q=region["quadratic_forms"];
      if(q.nrow()!=1||q.ncol()!=1)Rcpp::stop("Invalid projected HESS moment dimensions");
      gcorr::HessResult m;m.diagnostics=moment_diagnostics(region);m.quadratic_form=q(0,0);
      moments.push_back({Rcpp::as<std::string>(region_names[r]),std::move(m),n[0],static_cast<std::size_t>(Rcpp::as<double>(region["marker_count"]))});
    }
    const auto result=projected?gcorr::fit_aligned_joint_hess(moments,n[0],policy,fit_options):
      gcorr::fit_joint_hess(inputs,n[0],policy,fit_options);
    for(std::size_t r=0;r<result.regions.size();++r){
      append(result.region_names[r],"h2",result.regions[r].heritability,
        Rcpp::as<std::string>(trait_names[0]));
      regional_diagnostics.push_back(List::create(
        Named("marker_count")=projected?Rcpp::as<double>(Rcpp::as<List>(prepared_regions[r])["marker_count"]):static_cast<double>(result.regions[r].diagnostics.used_marker_ids.size()),
        Named("retained_components")=static_cast<double>(result.regions[r].diagnostics.retained_components),
        Named("outside_heritability")=result.regions[r].outside_heritability),result.region_names[r]);
    }
    append("","h2",result.total_heritability,Rcpp::as<std::string>(trait_names[0]));
    diagnostics=List::create(Named("correction_denominator")=result.correction_denominator,
      Named("retained_components")=static_cast<double>(result.retained_components));
  } else {
    std::vector<gcorr::PreparedRhoHessRegionInput> inputs;
    if(!projected)for(R_xlen_t r=0;r<slices.size();++r){
      Rcpp::XPtr<gcorr::PreparedRegionalLd> pointer(prepared_regions[r]);
      std::shared_ptr<const gcorr::PreparedRegionalLd> ld(pointer.get(),[](const gcorr::PreparedRegionalLd*){});
      const List slice=slices[r]; const List first=slice[0],second=slice[1];
      inputs.push_back({Rcpp::as<std::string>(region_names[r]),ld,
        named_values(first,"z"),named_values(second,"z")});
    }
    const List first=first_region[0],second=first_region[1];
    NumericVector n1=first["n"],n2=second["n"];
    std::vector<gcorr::AlignedRhoHessMomentRegionInput> moments;
    if(projected)for(R_xlen_t r=0;r<prepared_regions.size();++r) {
      const List region=prepared_regions[r];const NumericMatrix q=region["quadratic_forms"];
      if(q.nrow()!=2||q.ncol()!=2||!std::isfinite(q(0,1))||q(0,1)!=q(1,0))Rcpp::stop("Invalid projected rho-HESS moment dimensions");
      gcorr::RhoHessResult m;m.diagnostics=moment_diagnostics(region);
      m.quadratic_form1=q(0,0);m.quadratic_form2=q(1,1);m.bilinear_form=q(0,1);
      m.shared_sample_size=number("shared_sample_size",0);m.phenotypic_correlation=number("phenotypic_correlation",0);
      moments.push_back({Rcpp::as<std::string>(region_names[r]),std::move(m),n1[0],n2[0],static_cast<std::size_t>(Rcpp::as<double>(region["marker_count"]))});
    }
    const auto result=projected?gcorr::fit_aligned_joint_rho_hess(moments,n1[0],n2[0],
      number("shared_sample_size",0),number("phenotypic_correlation",0),policy,fit_options):
      gcorr::fit_joint_rho_hess(inputs,n1[0],n2[0],number("shared_sample_size",0),number("phenotypic_correlation",0),policy,fit_options);
    const auto first_name=Rcpp::as<std::string>(trait_names[0]);
    const auto second_name=Rcpp::as<std::string>(trait_names[1]);
    for(std::size_t r=0;r<result.regions.size();++r){const auto& fit=result.regions[r];
      append(result.region_names[r],"h2",fit.heritability1,first_name);
      append(result.region_names[r],"h2",fit.heritability2,second_name);
      append(result.region_names[r],"cov",fit.genetic_covariance,first_name,second_name);
      append(result.region_names[r],"rg",fit.genetic_correlation,first_name,second_name);
      regional_diagnostics.push_back(List::create(
        Named("marker_count")=projected?Rcpp::as<double>(Rcpp::as<List>(prepared_regions[r])["marker_count"]):static_cast<double>(fit.diagnostics.used_marker_ids.size()),
        Named("retained_components")=static_cast<double>(fit.diagnostics.retained_components),
        Named("outside_heritability1")=fit.outside_heritability1,
        Named("outside_heritability2")=fit.outside_heritability2,
        Named("outside_genetic_covariance")=fit.outside_genetic_covariance,
        Named("sampling_covariance_reason")=fit.sampling_covariance_undefined_reason),result.region_names[r]);
    }
    append("","h2",result.total_heritability1,first_name);
    append("","h2",result.total_heritability2,second_name);
    append("","cov",result.total_genetic_covariance,first_name,second_name);
    append("","rg",result.total_genetic_correlation,first_name,second_name);
    diagnostics=List::create(Named("correction_denominators")=NumericVector(
        result.correction_denominators.begin(),result.correction_denominators.end()),
      Named("retained_components")=static_cast<double>(result.retained_components),
      Named("total_genetic_matrix_indefinite")=result.total_genetic_matrix_indefinite);
    if(uncertainty=="hess") {
      std::vector<double> h1,h2,cov;
      for(const auto& region:result.regions) {
        h1.push_back(*region.heritability1.estimate);
        h2.push_back(*region.heritability2.estimate);
        cov.push_back(*region.genetic_covariance.estimate);
      }
      const auto jack=gcorr::hess_correlation_jackknife(h1,h2,cov);
      diagnostics["genome_rg_jackknife"]=List::create(
        Named("method")="delete_one_region_fixed_contributions",
        Named("centering")="full_sample_ratio",
        Named("delete_region_correlations")=jack.delete_region_correlations,
        Named("invalid_replicates")=static_cast<double>(jack.invalid_replicates),
        Named("outside_unit_interval")=jack.outside_unit_interval);
    }
  }
  diagnostics["regions"]=regional_diagnostics;
  diagnostics["uncertainty_policy"]=uncertainty;
  return List::create(Named("estimates")=DataFrame::create(Named("region")=region,
    Named("component")=component,Named("quantity")=quantity,Named("trait1")=trait1,
    Named("trait2")=trait2,Named("estimate")=estimate,
    Named("standard_error")=standard_error,Named("z")=z_score,
    Named("p_value")=p_value,Named("undefined_reason")=undefined_reason,
    Named("uncertainty_reason")=uncertainty_reason),Named("diagnostics")=diagnostics);
}
