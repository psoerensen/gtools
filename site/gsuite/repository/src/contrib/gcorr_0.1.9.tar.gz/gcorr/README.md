# gcorr

`gcorr` provides focused genetic-correlation workflows in the gsuite R-package
decomposition. It imports the task-neutral `gbase` package and does not import
the root `gsuite` package.

For ordinary score methods, use the stored Glist scores and the existing gact
output directly:

```r
fit <- gcorr(Glist, stat, method = "ldsc")
fit <- gcorr(Glist, stat, method = "gnova")
fit <- gcorr(Glist, stat, method = "sumher")
fit$estimates

fit <- ldsc(z = stat$z, n = stat$n, ldscores = ldscores, what = "rg")
```

The Glist workflow supplies delete blocks, estimates LDSC intercepts with a
squared-Z cutoff of 80, estimates GNOVA's overlap intercept using LDSC unless
overridden, and constructs an equal-marker SumHer baseline with multiplicative
inflation. That baseline is illustrative. GNOVA still requires constant N per
trait. Named Z/N matrices are matched once to common reference markers in
LD-score order and must already have harmonized allele orientation. Extracted
sample sizes are unchanged. The direct `ldsc()` interface retains its existing
intercept and filtering defaults.

`ldsc()` is the recommended LD-score regression workflow. It accepts the same
checked `stat` contract as `glma::vegas()`: one ordinary summary-statistics data
frame or a uniquely named list for multiple traits. A sparse-LD Glist supplies
marker identity, ordinary and annotation LD scores, reference metadata and the
reference ordering used for default delete blocks. Optional `sets` are named
marker-ID vectors and may overlap; `set_model = "stratified"` computes standard
annotation-specific LD scores, whereas `set_model = "grouped"` masks and
reuses the stored ordinary scores without scanning sparse LD. `residual = TRUE`
adds the marker complement. The returned fit includes
convenient `h2` and `rg` views as well as the complete estimates, uncertainty,
diagnostics and provenance.

Marker-set names are matched once to one-based integer positions in the
reference order. Disjoint grouped sets retain one group index and one LD score
per marker through native fitting, avoiding a dense marker-by-set matrix.
`gcorr_set_scores(marker_ids, ldscores, sets)` prepares the same compact input
for `gcorr_ldsc_partitioned()`. Native membership is zero-based; these positions
are separate from physical BED offsets. Overlapping sets retain dense
annotation scores. Score-based marginal fits reuse checked arrays
instead of rebuilding named inputs for each trait.

LDSC, partitioned LDSC, GNOVA and SumHer keep marker identity in R after checking
alignment once. Native fits consume numeric Z, sample-size and LD-score vectors plus integer
jackknife block membership. It filters arrays in place and returns retained row
indices only when needed; nested fit results contain estimates, diagnostics and
jackknife summaries without per-marker ID, regression-weight or fitted-mean
copies. Constant sample sizes use one value per trait.

The explicit functions remain `gcorr_ldsc()` for ordinary LDSC,
`gcorr_ldsc_partitioned()` for partitioned LDSC, `gcorr_gnova()` for ordinary
or binary-annotation GNOVA, and `gcorr_sumher()` for architecture-component
SumHer. Annotation and architecture routes accept explicit named score,
annotation, weight, tagging, and block inputs; they never infer annotation or
allele alignment. SumHer optionally
returns native category, enrichment, contrast, and multivariate category-
covariance summaries from full-reference architecture weights.

For a BED Glist already prepared with `gbase::gprep(task="eigen", sets=sets)`,
use the same interface for one or two traits:

```r
fit <- gcorr(Glist, stat, method="hess", nthreads=4)
fit$estimates
```

This uses `Glist$eigen$sets` and its saved reference sample selection. Named
Z/N input must already be oriented to Glist's a1 alleles; allele-labelled
frames are checked and swapped when needed. Only common regional markers are
retained, and empty regions are reported in `fit$projection$reference_selection`.
Both overlap inputs default to zero, assuming no shared samples; set
`shared_sample_size` and `phenotypic_correlation` when appropriate. Stored
eigenvalues do not contain the vectors needed for HESS: vectors are computed
per region, all traits are projected together, and the vectors are discarded.
`fit$projection` retains compact moments for subsequent fits.

For explicit joint HESS preparation without persistent LD files, `gcorr_prepare_hess(statistics,
Glist, regions)` matches region membership to physical BED indices once, retains
physical BED/FAM rows without rebuilding chromosome metadata or name lookup
tables, and projects all supplied traits once per
region. It decomposes the smaller sample- or marker-space Gram matrix and
discards eigenvectors after projection. Saved projections retain integer BED
indices and marker counts; new native moment fits receive no marker names.
Schema-1 projections remain readable alongside the new schema-2 representation.
`gcorr_fit_hess(projections, traits)`
reuses the serializable moments for one trait or a pair with the supplied overlap,
including the existing joint correction. Spectral
controls are fixed at preparation. The default `maximum_components="auto"`
caps each region at `min(50, floor(min(N)/(2*number_of_regions)))`, so the
conservative total rank is at most half the smallest supplied sample size.
Explicit numeric caps remain available and high-rank fits warn. This is a
conditioning policy; stronger truncation can discard genetic signal.
`fit$diagnostics$conditioning` reports rank fractions, denominators and moment
amplification. `fit$diagnostics$inference` names negative and indefinite regions
and reports unavailable uncertainty; raw points remain unchanged.

Compact fits default to `uncertainty="hess"`. This uses the pinned original
HESS software variance systems for heritability and covariance, including
their full regional LD rank rather than the retained projection rank. The
diagonal-plus-rank-one systems are solved in linear storage and arithmetic.
Genome-wide correlation uses the original delete-one-region jackknife,
centered on the full-sample ratio of summed regional contributions. It does
not refit the coupled equations after deletion. Invalid delete-region ratios
remain missing and invalidate the SE; none is replaced with zero. An rg
outside [-1,1] retains a descriptive jackknife SE but has no Wald Z/P.
`diagnostics$genome_rg_jackknife` records the replicates and their validity.

Point estimates retain the documented row-rank moment equations. The original
software instead uses a column-rank convention, so unequal ranks can cause
small point differences. Original variance parity is assessed at identical
point inputs. This convention does not supply a joint sampling covariance or
regional rg SEs. Select `uncertainty="moment"` for the previous signed
conditional fourth-moment covariance and regional delta SEs, or `"strict"`
for its admissibility checks. Prepared-LD fitters retain their strict default.
The h2 test uses the directional upper tail, including for negative estimates.
These SEs remain approximate: changing their calculation does not restore
discarded signal or establish the scale of genomic-control-adjusted statistics.

`gcorr_fit_hess(..., genomic_control=c(CAD=known_factor),
genomic_control_provenance=c(CAD="source of applied factor"))` explicitly
multiplies Z-squared and records the assumption. For pairs, name both selected
traits; cross moments receive the geometric mean of their factors. Scaling
starts from unchanged projections on every fit, needs no new decomposition,
and never changes N. Factors default to one and are never inferred from an
LDSC intercept. A sensitivity assumption must be labelled as such and is not
a validated correction.

The memory limit covers estimated regional
numerical workspace; reference metadata, statistics and R overhead are extra.

Other regional workflows use `gcorr_prepare_regions()` with a sparse-LD Glist and
named marker regions, or with explicit signed LD matrices. The Glist route
opens one native reader for all requested regions, and each full eigensystem is
verified once. The same session-bound preparation is accepted by `gcorr_hess()`,
`gcorr_rho_hess()`, `gcorr_supergnova()`, `gcorr_lava()`, and `gcorr_hdll()`.
HESS and rho-HESS provide both independent regional fits and native joint
multi-region correction. LAVA exposes continuous and binary-trait regional
heritability, covariance, correlation, univariate screening, seeded bivariate
simulation inference, partial correlation, genetic regression, and supported
conditional and omnibus inference through `gcorr_lava_partial()` and
`gcorr_lava_regression()`.

Continuous-trait covariance summaries use `gcorr_covariance()` to validate
trait units, provenance, and the full joint sampling covariance. `gcorr_sem()`
fits an explicit recursive structural model; `gcorr_ggm()` fits an explicitly
allowed fixed graph; and `gcorr_ggm_network()` reports the descriptive
all-trait conditional network without fitting or edge selection. Linear SEM
constraints and selected free GGM edges have separate native Wald-test
functions. No covariance repair, graph search, or reconstruction from marginal
standard errors is performed.

`gcorr_grouped_covariance()` extracts GNOVA categories, SumHer architecture
components, or transformed SumHer categories together with their full
cross-group block-jackknife covariance. `gcorr_grouped_sem()` and
`gcorr_grouped_ggm()` apply one prespecified model across the selected groups;
their explicit contrast functions propagate cross-group uncertainty for SEM
parameters, precision terms, and free-edge partial correlations.

Prepared-instrument MR starts with `gcorr_prepare_mr()`. It requires two
already aligned `gbase` effect/standard-error summaries, an exactly labelled
signed-LD matrix, matching trait/reference ancestry, the reference sample
count, and an explicit non-overlapping-sample assertion. It records instrument
and pairwise LD decisions in a serializable package-owned object. That object is
accepted by `gcorr_gsmr()`, `gcorr_gsmr2()`, `gcorr_mr_ivw()`,
`gcorr_mr_egger()`, and `gcorr_mr_weighted_median()`. Sensitivity estimators
require approximately independent instruments, and weighted median requires
an explicit seed.

`gcorr()` also retains the focused package-owned dispatcher. It delegates
`method = "ldsc"`, `method = "gnova"`, `method = "sumher"`, focused regional
and covariance-fit names, and `method = "gsmr"`, `"gsmr2"`, `"ivw"`,
`"egger"`, or `"weighted_median"` to those functions. It has no `task` selector
and never forwards to the root gsuite package.

The adapters use installed public gcorr and gmat interfaces. No native
implementation is copied or exposed here.

Release source archives are published through the gsuite R package repository
and compile the required native implementation with the package.
