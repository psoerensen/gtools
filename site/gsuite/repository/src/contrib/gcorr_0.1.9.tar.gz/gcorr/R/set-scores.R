#' Store disjoint marker-set LD scores using integer membership
#'
#' Matches marker names once and keeps one group index and one ordinary LD
#' score per marker. This represents ordinary scores masked by disjoint sets;
#' it assumes no LD contribution across set boundaries. Supply a numeric
#' annotation LD-score matrix for overlapping sets or cross-set LD.
#' @param marker_ids Unique marker names in summary-statistics order.
#' @param ldscores Positive finite named ordinary LD scores containing every marker.
#' @param sets Uniquely named list of disjoint marker-name vectors covering all markers.
#' @return Compact scores accepted by `gcorr_ldsc_partitioned()`.
#' @export
gcorr_set_scores <- function(marker_ids, ldscores, sets) {
  if (!is.character(marker_ids) || !length(marker_ids) || anyNA(marker_ids) ||
      any(!nzchar(marker_ids)) || anyDuplicated(marker_ids))
    .gcorr_stop("marker_ids must contain unique nonempty marker names.")
  parsed <- .gcorr_ldsc_annotations(sets, marker_ids, FALSE, compact = TRUE)
  if (is.null(parsed$group) || any(parsed$group == 0L))
    .gcorr_stop("Compact scores require disjoint sets covering every marker.")
  values <- .gcorr_ldsc_scores(ldscores, marker_ids)
  .gcorr_disjoint_scores(marker_ids, names(parsed$sets), parsed$group, unname(values))
}

.gcorr_disjoint_scores <- function(markers, annotations, group, scores) {
  structure(list(marker_ids = markers, annotation_names = annotations,
    group = as.integer(group), scores = as.numeric(scores)),
    class = "gcorr_disjoint_ld_scores")
}

.gcorr_partitioned_scores <- function(x, markers) {
  if (!inherits(x, "gcorr_disjoint_ld_scores"))
    return(.gcorr_marker_matrix(x, markers, "annotation_ld_scores"))
  annotations <- x$annotation_names
  if (!identical(x$marker_ids, markers) || !is.character(annotations) ||
      !length(annotations) || anyNA(annotations) || any(!nzchar(annotations)) ||
      anyDuplicated(annotations) || !is.integer(x$group) ||
      length(x$group) != length(markers) || anyNA(x$group) ||
      any(x$group < 1L | x$group > length(annotations)) ||
      !is.numeric(x$scores) || length(x$scores) != length(markers) ||
      any(!is.finite(x$scores)))
    .gcorr_stop("Compact annotation scores must have matching marker order, valid integer groups and finite scores.")
  x
}
