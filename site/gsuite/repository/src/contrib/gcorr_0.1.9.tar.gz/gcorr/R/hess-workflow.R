.gcorr_hess_workflow <- function(Glist, stat, regions=NULL, nthreads=1L,
    maximum_components="auto", minimum_eigenvalue=1,
    relative_eigenvalue_tolerance=1e-10, maximum_dimension=2048L,
    memory_limit_bytes=512*1024^2, shared_sample_size=0,
    phenotypic_correlation=0, minimum_correction_denominator=1e-8,
    genomic_control=NULL, genomic_control_provenance=NULL,
    uncertainty=c("hess","moment","strict")) {
  trait_count <- if (is.data.frame(stat)) 1L
    else if (is.list(stat) && all(c("z","n") %in% names(stat))) {
      if (is.null(dim(stat$z))) 1L else ncol(stat$z)
    } else if (inherits(stat,"gcorr_prepared_statistics")) length(stat$prepared)
    else length(stat)
  if (!trait_count %in% c(1L,2L))
    .gcorr_stop("The HESS workflow fits one or two traits; use gcorr_prepare_hess() to prepare more traits for separate fits.")
  projection <- gcorr_prepare_hess(stat, Glist, regions=regions,
    nthreads=nthreads, maximum_components=maximum_components,
    minimum_eigenvalue=minimum_eigenvalue,
    relative_eigenvalue_tolerance=relative_eigenvalue_tolerance,
    maximum_dimension=maximum_dimension, memory_limit_bytes=memory_limit_bytes)
  fit <- gcorr_fit_hess(projection, shared_sample_size=shared_sample_size,
    phenotypic_correlation=phenotypic_correlation,
    minimum_correction_denominator=minimum_correction_denominator,
    genomic_control=genomic_control,
    genomic_control_provenance=genomic_control_provenance, uncertainty=uncertainty)
  fit$projection <- projection
  fit
}
