.gcorr_stop <- function(message) stop(message, call. = FALSE)

.gcorr_scalar_number <- function(x, name, lower = -Inf, whole = FALSE) {
  if (!is.numeric(x) || length(x) != 1L || !is.finite(x) || x < lower ||
      (whole && x != floor(x))) {
    .gcorr_stop(paste(name, "must be one", if (whole) "whole" else "finite",
      "number", if (is.finite(lower)) paste0(" >= ", lower) else ""))
  }
  as.numeric(x)
}

.gcorr_summary_input <- function(x, label) {
  required <- c("rsids", "chr", "pos", "ea", "nea", "n")
  if (!identical(class(x), "data.frame") || !nrow(x) ||
      length(setdiff(required, names(x))))
    .gcorr_stop(paste(label, "must be an ordinary data frame with rsids, chr, pos, ea, nea and n."))
  if ("stat" %in% names(x)) z <- x$stat
  else if ("z" %in% names(x)) z <- x$z
  else if (all(c("b", "seb") %in% names(x))) z <- x$b / x$seb
  else if (all(c("score", "information") %in% names(x)))
    z <- x$score / sqrt(x$information)
  else .gcorr_stop(paste(label, "must contain stat, z, b/seb or score/information."))
  n <- x$n
  if (any(!is.finite(z)) || any(!is.finite(n)) || any(n <= 0)) {
    .gcorr_stop(paste(label, "does not yield finite Z scores and sample sizes."))
  }
  list(
    trait = label,
    marker = x$rsids,
    chromosome = x$chr,
    position = x$pos,
    effect_allele = x$ea,
    other_allele = x$nea,
    z = as.numeric(z),
    n = as.numeric(n)
  )
}

.gcorr_prepare_statistics <- function(statistics, scalar_sample_size = FALSE) {
  if (inherits(statistics, "gcorr_prepared_statistics")) {
    if (scalar_sample_size && any(vapply(statistics$prepared,
        function(x) length(unique(x$n)) != 1L, logical(1)))) {
      .gcorr_stop("This method requires one constant sample size per trait.")
    }
    return(statistics)
  }
  if (identical(class(statistics), "data.frame")) {
    statistics <- setNames(list(statistics), "trait")
  }
  if (!is.list(statistics) || !length(statistics) || is.null(names(statistics)) ||
      anyNA(names(statistics)) || any(!nzchar(names(statistics))) ||
      anyDuplicated(names(statistics))) {
    .gcorr_stop("statistics must be one data frame or a uniquely named list of data frames.")
  }
  prepared <- Map(.gcorr_summary_input, statistics, names(statistics))
  first <- prepared[[1L]]
  if (!is.character(first$marker) || anyNA(first$marker) ||
      any(!nzchar(first$marker)) || anyDuplicated(first$marker))
    .gcorr_stop("Statistics must contain unique nonempty marker IDs.")
  identity_fields <- c("marker", "chromosome", "position", "effect_allele",
    "other_allele")
  if (!all(vapply(identity_fields, function(field) {
    all(vapply(prepared[-1L], function(x) identical(first[[field]], x[[field]]),
      logical(1)))
  }, logical(1)))) {
    .gcorr_stop("All traits must have identical marker order and allele orientation.")
  }
  if (scalar_sample_size &&
      any(vapply(prepared, function(x) length(unique(x$n)) != 1L, logical(1)))) {
    .gcorr_stop("This method requires one constant sample size per trait.")
  }
  structure(list(statistics = statistics, prepared = prepared, first = first),
    class = "gcorr_prepared_statistics")
}

.gcorr_named_marker_vector <- function(x, markers, name, numeric = TRUE,
    positive = numeric) {
  valid_type <- if (numeric) is.numeric(x) else is.character(x)
  if (!valid_type || length(x) != length(markers) || is.null(names(x)) ||
      anyNA(names(x)) || any(!nzchar(names(x))) || anyDuplicated(names(x)) ||
      (!identical(names(x), markers) && !setequal(names(x), markers))) {
    .gcorr_stop(paste(name, "must be a uniquely named vector matching all markers."))
  }
  if (!identical(names(x), markers)) x <- x[match(markers, names(x))]
  if (numeric && (any(!is.finite(x)) || (positive && any(x <= 0)))) {
    qualifier <- if (positive) "positive finite" else "finite"
    .gcorr_stop(paste(name, "must contain", qualifier, "values."))
  }
  if (!numeric && (anyNA(x) || any(!nzchar(x)))) {
    .gcorr_stop(paste(name, "must contain nonempty block labels."))
  }
  unname(x)
}

.gcorr_marker_matrix <- function(x, markers, name, binary = FALSE) {
  if (!is.matrix(x) || !is.numeric(x) || nrow(x) != length(markers) ||
      !length(x) || any(!is.finite(x)) || is.null(rownames(x)) ||
      !identical(rownames(x), markers) || is.null(colnames(x)) ||
      anyNA(colnames(x)) || any(!nzchar(colnames(x))) ||
      anyDuplicated(colnames(x))) {
    .gcorr_stop(paste(name, "must be a finite numeric matrix whose row names",
      "exactly match markers and whose column names are unique."))
  }
  if (binary && any(!x %in% c(0, 1))) {
    .gcorr_stop(paste(name, "must contain only binary 0/1 annotations."))
  }
  x
}

.gcorr_blocks <- function(blocks, markers) {
  blocks <- .gcorr_named_marker_vector(blocks, markers, "blocks", FALSE)
  if (length(unique(blocks)) < 2L) {
    .gcorr_stop("blocks must contain at least two delete blocks.")
  }
  blocks
}
