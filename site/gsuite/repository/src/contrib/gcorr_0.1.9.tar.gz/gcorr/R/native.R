#' Report the loaded native compatibility set
#'
#' @return Versions and ABIs compiled into and reported by the loaded gcorr,
#'   gmat, and gsolve libraries.
#' @export
gcorr_native_info <- function() cpp_gcorr_native_info()

.onLoad <- function(libname, pkgname) {
  info <- cpp_gcorr_native_info()
  expected <- list(
    gcorr = c(version = "0.1.4", abi = "0"),
    gmat = c(version = "0.6.0", abi = "0"),
    gsolve = c(version = info$gsolve$header_version, abi = "4")
  )
  for (component in names(expected)) {
    observed <- info[[component]]
    if (!identical(as.character(observed$runtime_version), expected[[component]][["version"]]) ||
        !identical(as.character(observed$runtime_abi), expected[[component]][["abi"]]) ||
        !isTRUE(observed$headers_match_runtime)) {
      stop("Loaded ", component, " native version/ABI is incompatible with gcorr.",
        call. = FALSE)
    }
  }
  if (!isTRUE(info$gcorr$linked_gmat_matches_runtime)) {
    stop("Loaded gcorr was linked against an incompatible gmat ABI.",
      call. = FALSE)
  }
}
