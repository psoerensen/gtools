#' Prepare compact multi-trait HESS projections directly from BED
#'
#' Resolves region membership to physical BED indices once and retains one
#' chromosome's BED file at a time after validating the descriptor. Numerical
#' decoding uses physical row indices without rebuilding BIM/FAM metadata.
#' Computes one region at a time and projects every
#' trait through the same eigensystem. The smaller sample- or marker-space
#' Gram is decomposed. No persistent LD or eigenvector files are created.
#' @param statistics Uniquely named aligned summary-statistics data frames,
#'   or named Z/N matrices. One constant sample size per trait is required.
#'   Frame alleles must match Glist directly or by swapping; strand complements
#'   are not inferred. Matrix Z must already be oriented to Glist's a1 alleles.
#' @param Glist A gbase-prepared BED reference.
#' @param regions Uniquely named, disjoint marker vectors, each on one chromosome.
#'   They jointly define the genetic universe for the subsequent joint solve.
#'   Defaults to `Glist$eigen$sets`, using its saved reference samples. With
#'   stored regions or matrix input, missing statistic markers are omitted and
#'   empty regions are dropped; explicit regions with frames remain strict.
#' @param nthreads Local decoding and matrix-product threads.
#' @param maximum_components Per-region rank cap. The default `"auto"` uses
#'   `min(50, floor(min(N)/(2*number_of_regions)))`, giving a conservative
#'   total-rank bound of at most half the smallest supplied sample size.
#'   A nonnegative whole number overrides this policy; zero retains all
#'   eligible components. A smaller cap can discard genetic signal.
#' @param minimum_eigenvalue,relative_eigenvalue_tolerance HESS spectral
#'   controls, fixed during preparation.
#' @param maximum_dimension Maximum dimension of the smaller Gram matrix.
#' @param memory_limit_bytes Conservative per-region numerical workspace limit.
#'   Reference metadata, statistics, R and allocator overhead are additional.
#' @return A serializable `gcorr_hess_projection` bound to these traits, sample
#'   sizes and spectral controls, retaining integer BED indices and marker counts.
#'   Use `gcorr_fit_hess()` to fit traits or pairs.
#' @export
gcorr_prepare_hess <- function(statistics, Glist, regions=NULL, nthreads=1L,
    maximum_components="auto", minimum_eigenvalue=1,
    relative_eigenvalue_tolerance=1e-10, maximum_dimension=2048L,
    memory_limit_bytes=512*1024^2) {
  started <- proc.time()[[3L]]
  stored_regions <- is.null(regions)
  if (stored_regions) {
    if (is.null(Glist$eigen$sets))
      .gcorr_stop("Prepare independent regions with gbase::gprep(Glist, task='eigen', sets=sets), or supply regions.")
    regions <- Glist$eigen$sets
  }
  gbase::validate_Glist(Glist)
  regions <- .gcorr_named_list(regions, "regions")
  members <- unlist(regions, use.names=FALSE)
  if (!is.character(members) || anyNA(members) || any(!nzchar(members)) ||
      any(lengths(regions)==0L) || anyDuplicated(members))
    .gcorr_stop("HESS regions must contain nonempty, unique, disjoint marker IDs.")
  inputs <- .gcorr_prepare_statistics(
    .gcorr_score_inputs(statistics, reference_ids=members), scalar_sample_size=TRUE)
  first <- inputs$first
  if (!is.character(first$marker) || anyNA(first$marker) ||
      any(!nzchar(first$marker)) || anyDuplicated(first$marker))
    .gcorr_stop("Statistics must contain unique, nonempty marker IDs.")
  matrix_input <- isTRUE(inputs$matrix_input)
  if (!matrix_input) {
    for (field in c("chromosome", "effect_allele", "other_allele"))
      if (anyNA(first[[field]]) || any(!nzchar(as.character(first[[field]]))))
        .gcorr_stop("Regional chromosome and allele labels must be nonmissing and nonempty.")
    if (!is.numeric(first$position) || any(!is.finite(first$position)) ||
        any(first$position<=0))
      .gcorr_stop("Regional positions must be positive finite numbers.")
  }
  stat_index <- match(members, first$marker)
  requested_marker_count <- length(members)
  omitted_regions <- character()
  if (anyNA(stat_index)) {
    if (!stored_regions && !matrix_input)
      .gcorr_stop("Every regional marker must occur in statistics.")
    offsets <- c(0L, cumsum(lengths(regions)))
    regions <- lapply(seq_along(regions), function(i) {
      rows <- seq.int(offsets[i]+1L, offsets[i+1L])
      members[rows[!is.na(stat_index[rows])]]
    }) |> setNames(names(regions))
    empty <- lengths(regions)==0L
    omitted_regions <- names(regions)[empty]
    regions <- regions[!empty]
    if (!length(regions)) .gcorr_stop("No regional markers occur in statistics.")
    members <- members[!is.na(stat_index)]
    stat_index <- stat_index[!is.na(stat_index)]
  }
  sample_sizes <- vapply(inputs$prepared,function(x)x$n[[1L]],numeric(1))
  rank_policy <- .gcorr_hess_rank_policy(maximum_components,sample_sizes,lengths(regions))
  markers <- unlist(Glist$rsids, use.names=FALSE)
  at <- match(members, markers)
  if (anyNA(at)) .gcorr_stop("Every regional marker must occur in Glist.")
  ends <- cumsum(lengths(Glist$rsids))
  starts <- c(0L, head(ends, -1L))
  component <- findInterval(at - 1L, c(0L, ends))
  physical <- as.integer(at - starts[component])
  active <- sort(unique(component))
  offsets <- c(0, cumsum(as.double(lengths(regions))))
  indices <- lapply(seq_along(regions), function(i) {
    selected <- seq.int(offsets[i]+1, offsets[i+1])
    parts <- unique(component[selected])
    if (length(parts)!=1L)
      .gcorr_stop("Each HESS region must belong to one chromosome.")
    part <- parts[[1L]]
    selected <- selected[order(Glist$source_marker_indices_0based[[part]][physical[selected]])]
    rows <- physical[selected]
    stats <- stat_index[selected]
    chr <- Glist$chr[[part]][rows]
    if (length(unique(as.character(chr)))!=1L)
      .gcorr_stop("Each HESS region must belong to one chromosome.")
    sign <- rep.int(1L, length(rows))
    if (!matrix_input) {
      if (any(as.character(first$chromosome[stats])!=as.character(chr)) ||
          any(first$position[stats]!=Glist$pos[[part]][rows]))
        .gcorr_stop("Regional chromosome/position must match Glist.")
      a1 <- Glist$a1[[part]][rows]; a2 <- Glist$a2[[part]][rows]
      direct <- first$effect_allele[stats]==a1 & first$other_allele[stats]==a2
      swapped <- first$effect_allele[stats]==a2 & first$other_allele[stats]==a1
      if (any(!(direct | swapped))) .gcorr_stop("Regional alleles must match or swap Glist alleles.")
      sign <- ifelse(direct,1L,-1L)
    }
    list(component=as.integer(match(part,active)-1L),
      panel=as.integer(Glist$source_marker_indices_0based[[part]][rows]),
      statistics=as.integer(stats-1L),
      sign=sign)
  })
  names(indices) <- names(regions)
  prepared <- lapply(inputs$prepared, function(x) list(z=x$z, n=x$n[[1L]]))
  traits <- names(inputs$statistics)
  options <- list(
    maximum_components=rank_policy$maximum_components,
    minimum_eigenvalue=.gcorr_regional_number(minimum_eigenvalue,"minimum_eigenvalue",0),
    relative_eigenvalue_tolerance=.gcorr_regional_number(relative_eigenvalue_tolerance,"relative_eigenvalue_tolerance",.Machine$double.eps,1-.Machine$double.eps),
    maximum_dimension=.gcorr_regional_number(maximum_dimension,"maximum_dimension",1,whole=TRUE))
  nthreads <- .gcorr_regional_number(nthreads,"nthreads",1,whole=TRUE)
  memory_limit_bytes <- .gcorr_regional_number(memory_limit_bytes,"memory_limit_bytes",1)
  sample_indices <- as.integer(if (stored_regions) Glist$eigen$sample_indices_0based
    else Glist$sample_source_indices_0based)
  reference_selection <- list(source=if (stored_regions) "Glist$eigen" else "Glist",
    sample_count=length(sample_indices), requested_marker_count=requested_marker_count,
    retained_marker_count=length(members), omitted_regions=omitted_regions,
    allele_alignment=if (matrix_input) "caller oriented Z to Glist a1" else "checked against Glist")
  paths <- Map(function(bed,bim,fam,count)list(bed=bed,bim=bim,fam=fam,
      source_sample_count=length(Glist$ids),source_marker_count=count),
    Glist$bedfiles[active],Glist$bimfiles[active],Glist$famfiles[active],
    Glist$physical_marker_counts[active])
  # Only numeric statistics and resolved rows are needed by the native call.
  # Remove preparation-only references before collecting validation garbage.
  rm(inputs,first,members,markers,at,ends,starts,component,physical,active,
    stat_index,offsets,statistics,Glist,regions)
  invisible(gc())
  validation <- unname(proc.time()[[3L]]-started)
  native <- cpp_gcorr_project_bed(paths,sample_indices,indices,prepared,
    options,as.integer(nthreads),memory_limit_bytes)
  for(i in seq_along(native)) {
    dimnames(native[[i]]$quadratic_forms) <- list(traits,traits)
    names(native[[i]]$sample_sizes) <- traits
  }
  structure(list(schema_version=2L, traits=traits,
    reference_files=paths, reference_selection=reference_selection,
    sample_sizes=setNames(vapply(prepared,function(x)x$n[[1L]],numeric(1)),traits),
    regions=native, options=options, rank_policy=rank_policy, nthreads=nthreads,
    timings_seconds=list(validation=validation,panel_setup=attr(native,"panel_setup_seconds"),
      total=unname(proc.time()[[3L]]-started)), software=gcorr_native_info()),
    class="gcorr_hess_projection")
}

#' Fit joint HESS or rho-HESS from compact projections
#' @param projections Object from `gcorr_prepare_hess()`; it can be saved with RDS.
#' @param traits One or two prepared trait names. Defaults to all prepared traits.
#' @param shared_sample_size,phenotypic_correlation Overlap inputs for
#'   a two-trait fit, both defaulting to zero (no shared samples).
#'   The phenotypic correlation is not an LDSC intercept.
#' @param minimum_correction_denominator Guard against the total-rank boundary.
#' @param genomic_control Optional positive numeric vector named exactly for
#'   the selected traits. Each factor multiplies Z-squared; cross moments are
#'   multiplied by the geometric mean of the two factors. Defaults to one.
#'   Supply a known applied genomic-control factor to undo that correction,
#'   or clearly label a sensitivity scenario. No factor is inferred from LDSC.
#' @param genomic_control_provenance Character vector named for the selected
#'   traits, required when any factor differs from one. Records the source or
#'   sensitivity assumption. Scaling always starts from the unchanged compact
#'   moments, so repeated fits do not accumulate adjustments.
#' @param uncertainty `"hess"` (default) uses the original HESS software variance
#'   equations, with full regional LD ranks, for h2 and covariance. Genome-wide
#'   correlation uses its delete-one-region jackknife; regional correlation SEs
#'   are unavailable under this convention. Point estimates retain the documented
#'   row-rank moment equations. `"moment"` evaluates the Gaussian fourth-moment
#'   covariance estimator at unconstrained regional/total estimates and
#'   propagates it through the joint correction. Only finite nonnegative
#'   resulting variances receive SEs. Correlation inference additionally
#'   requires an admissible joint sampling covariance and interior correlation.
#'   `"strict"` retains the previous conditional model requiring admissible
#'   regional genetic and total residual parameters. All are approximate,
#'   conditional on supplied LD, sample sizes, overlap and retained subspaces.
#' @return The same point estimates as joint regional
#'   HESS, without retaining reference LD or eigenvectors. Negative estimates
#'   are preserved; unavailable inference has an explicit reason.
#' @export
gcorr_fit_hess <- function(projections, traits=projections$traits,
    shared_sample_size=0, phenotypic_correlation=0,
    minimum_correction_denominator=1e-8,
    genomic_control=NULL, genomic_control_provenance=NULL,
    uncertainty=c("hess","moment","strict")) {
  if(!inherits(projections,"gcorr_hess_projection") ||
      !projections$schema_version %in% c(1L,2L) || !length(projections$regions))
    .gcorr_stop("projections must come from gcorr_prepare_hess().")
  .gcorr_hess_projection_membership(projections)
  if(!is.character(traits) || !length(traits) || length(traits)>2L ||
      anyNA(traits) || anyDuplicated(traits) || any(!traits %in% projections$traits))
    .gcorr_stop("Select one or two distinct prepared trait names.")
  n <- projections$sample_sizes[traits]
  if(any(!is.finite(n)) || any(n<=0)) .gcorr_stop("Invalid projected sample sizes.")
  scaling <- .gcorr_hess_scaling(genomic_control,genomic_control_provenance,traits)
  uncertainty <- match.arg(uncertainty)
  options <- projections$options
  options$uncertainty <- uncertainty
  options$minimum_correction_denominator <- .gcorr_regional_number(
    minimum_correction_denominator,"minimum_correction_denominator",.Machine$double.eps,1-.Machine$double.eps)
  method <- if(length(traits)==1L) "hess" else "rho_hess"
  if(length(traits)==2L) {
    options$shared_sample_size <- .gcorr_regional_number(shared_sample_size,"shared_sample_size",0,min(n))
    options$phenotypic_correlation <- .gcorr_regional_number(phenotypic_correlation,"phenotypic_correlation",-1,1)
  } else {
    if ((!is.null(shared_sample_size) &&
          .gcorr_regional_number(shared_sample_size,"shared_sample_size",0)>0) ||
        (!is.null(phenotypic_correlation) &&
          .gcorr_regional_number(phenotypic_correlation,"phenotypic_correlation",-1,1)!=0))
      .gcorr_stop("Nonzero overlap inputs apply only to two traits.")
  }
  moments <- lapply(projections$regions,function(x) {
    if(!identical(x$sample_sizes,projections$sample_sizes))
      .gcorr_stop("Projected sample sizes no longer match preparation.")
    if(!identical(rownames(x$quadratic_forms),projections$traits) ||
       !identical(colnames(x$quadratic_forms),projections$traits))
      .gcorr_stop("Invalid projected trait identities.")
    x$quadratic_forms <- x$quadratic_forms[traits,traits,drop=FALSE] *
      outer(sqrt(scaling$z_squared_multiplier),sqrt(scaling$z_squared_multiplier))
    if(any(!is.finite(x$quadratic_forms)))
      .gcorr_stop("Genomic-control scaling produced nonfinite moments.")
    x$sample_sizes <- x$sample_sizes[traits]
    if(is.null(x$marker_count)) x$marker_count <- length(x$marker_ids)
    x
  })
  slice <- setNames(lapply(n,function(value)list(n=value)),traits)
  slices <- setNames(rep(list(slice),length(moments)),names(moments))
  started <- proc.time()[[3L]]
  native <- cpp_gcorr_joint_hess_fit(method,slices,moments,options,TRUE)
  conditioning <- .gcorr_hess_conditioning(native$diagnostics$retained_components,n)
  if(any(conditioning$rank_fraction>0.5))
    warning("Joint HESS retains more than half a trait's sample size in rank; inspect diagnostics$conditioning and prepare again with maximum_components='auto'.",
      call.=FALSE)
  native$diagnostics$conditioning <- conditioning
  native$diagnostics$inference <- .gcorr_hess_inference(native$estimates,traits,
    options$shared_sample_size,options$phenotypic_correlation,uncertainty)
  structure(list(method=method,traits=traits,estimates=native$estimates,
    matrices=NULL,diagnostics=native$diagnostics,
    preparation=list(source="bed_compact_projection",options=projections$options,
      rank_policy=projections$rank_policy,
      timings_seconds=projections$timings_seconds), input_scaling=scaling,
    fit_seconds=unname(proc.time()[[3L]]-started),software=gcorr_native_info()),
    class=c(paste0("gcorr_",method,"_fit"),"gcorr_regional_fit"))
}

.gcorr_hess_projection_membership <- function(projections) {
  regions <- .gcorr_named_list(projections$regions,"projected regions")
  if(identical(projections$schema_version,1L)) {
    ids <- unlist(lapply(regions,`[[`,"marker_ids"),use.names=FALSE)
    if(!is.character(ids) || any(lengths(lapply(regions,`[[`,"marker_ids"))==0L) ||
       anyNA(ids) || any(!nzchar(ids)) || anyDuplicated(ids))
      .gcorr_stop("Projected regions must contain unique, nonempty, disjoint marker IDs.")
    return(invisible(NULL))
  }
  components <- vapply(regions,function(x)
    .gcorr_regional_number(x$bed_component,"projected BED component",0,
      length(projections$reference_files)-1,whole=TRUE),numeric(1))
  for(component in unique(components)) {
    selected <- regions[components==component]
    for(x in selected) {
      indices <- x$bed_marker_indices_0based
      count <- .gcorr_regional_number(x$marker_count,"projected marker count",1,whole=TRUE)
      if(!is.integer(indices) || length(indices)!=count || anyNA(indices) || any(indices<0L))
        .gcorr_stop("Invalid projected physical BED indices.")
    }
    if(anyDuplicated(unlist(lapply(selected,`[[`,"bed_marker_indices_0based"),use.names=FALSE)))
      .gcorr_stop("Projected regions must have disjoint physical BED indices.")
  }
  invisible(NULL)
}

.gcorr_hess_rank_policy <- function(maximum_components,n,region_sizes) {
  automatic <- identical(maximum_components,"auto")
  if(is.character(maximum_components) && !automatic)
    .gcorr_stop("maximum_components must be 'auto' or a nonnegative whole number.")
  cap <- if(automatic) min(50,floor(min(n)/(2*length(region_sizes)))) else
    .gcorr_regional_number(maximum_components,"maximum_components",0,whole=TRUE)
  if(automatic && cap<1)
    .gcorr_stop("Automatic HESS rank cannot retain one component per region within half the smallest sample size; use fewer regions or an explicit rank policy.")
  bound <- sum(pmin(region_sizes,if(cap==0) Inf else cap))
  if(!automatic && bound>min(n)/2)
    warning("Explicit HESS rank cap has a conservative total-rank bound above half the smallest sample size; actual ranks and conditioning are checked at fitting.",call.=FALSE)
  list(mode=if(automatic) "automatic_half_sample" else "explicit",
    maximum_components=cap,region_count=length(region_sizes),
    smallest_sample_size=min(n),conservative_rank_bound=bound,
    target_maximum_rank_fraction=if(automatic) 0.5 else NULL)
}

.gcorr_hess_scaling <- function(factors,provenance,traits) {
  if(is.null(factors)) factors <- setNames(rep(1,length(traits)),traits)
  if(!is.numeric(factors) || length(factors)!=length(traits) ||
      is.null(names(factors)) || anyNA(names(factors)) ||
      anyDuplicated(names(factors)) || !setequal(names(factors),traits) ||
      any(!is.finite(factors)) || any(factors<=0))
    .gcorr_stop("genomic_control must be positive finite factors named exactly for the selected traits.")
  factors <- factors[traits]
  if(is.null(provenance)) {
    if(any(factors!=1))
      .gcorr_stop("Nonunit genomic_control requires genomic_control_provenance for the selected traits.")
    provenance <- setNames(rep("Unchanged supplied Z scale",length(traits)),traits)
  }
  if(!is.character(provenance) || length(provenance)!=length(traits) ||
      is.null(names(provenance)) || anyNA(names(provenance)) ||
      anyDuplicated(names(provenance)) || !setequal(names(provenance),traits) ||
      anyNA(provenance) || any(!nzchar(trimws(provenance))))
    .gcorr_stop("genomic_control_provenance must contain nonempty sources or sensitivity assumptions named exactly for the selected traits.")
  list(z_squared_multiplier=factors,provenance=provenance[traits],
    applied_to="unchanged_compact_moments",sample_size_transformation="none")
}

.gcorr_hess_conditioning <- function(rank,n) {
  data.frame(trait=names(n),sample_size=unname(n),retained_rank=rank,
    rank_fraction=unname(rank/n),correction_denominator=unname(1-rank/n),
    moment_amplification=unname(1/(1-rank/n)),
    status=ifelse(rank/n<=0.5,"within_half_sample_rank","high_rank"),
    row.names=NULL,stringsAsFactors=FALSE)
}

.gcorr_hess_inference <- function(estimates,traits,shared,rp,uncertainty="strict") {
  regional <- estimates[estimates$component=="region",,drop=FALSE]
  totals <- estimates[estimates$component=="total",,drop=FALSE]
  h <- setNames(lapply(traits,function(trait) {
    regional[regional$quantity=="h2" & regional$trait1==trait,,drop=FALSE]
  }),traits)
  total_h <- vapply(traits,function(trait) {
    totals$estimate[totals$quantity=="h2" & totals$trait1==trait]
  },numeric(1))
  negative <- lapply(h,function(x)x$region[x$estimate<0])
  summary <- data.frame(trait=traits,total_h2=unname(total_h),
    total_outside_unit_interval=unname(total_h<0 | total_h>1),
    negative_region_count=lengths(negative),
    unavailable_regional_h2_se=vapply(h,function(x)sum(is.na(x$standard_error)),integer(1)),
    row.names=NULL,stringsAsFactors=FALSE)
  indefinite <- character()
  residual_indefinite <- FALSE
  if(length(traits)==2L) {
    cov <- regional[regional$quantity=="cov",,drop=FALSE]
    a <- h[[1L]]$estimate[match(cov$region,h[[1L]]$region)]
    b <- h[[2L]]$estimate[match(cov$region,h[[2L]]$region)]
    indefinite <- cov$region[a<0 | b<0 | cov$estimate^2>a*b]
    total_cov <- totals$estimate[totals$quantity=="cov"]
    residual_cov <- if(shared==0) 0 else rp-total_cov
    residual_indefinite <- any(total_h>1) ||
      residual_cov^2>(1-total_h[1L])*(1-total_h[2L])
  }
  reasons <- unique(estimates$uncertainty_reason[nzchar(estimates$uncertainty_reason)])
  list(model=switch(uncertainty,strict="strict_conditional_gaussian",
      moment="unconstrained_gaussian_moment_estimate",hess="hess_software_variance"),traits=summary,
    negative_regions=negative,indefinite_genetic_regions=indefinite,
    residual_matrix_indefinite=residual_indefinite,
    negative_sampling_variances=estimates[estimates$uncertainty_reason==
      "Estimated HESS sampling variance is negative",
      c("region","component","quantity","trait1","trait2"),drop=FALSE],
    indefinite_sampling_covariances=estimates[estimates$uncertainty_reason==
      "Estimated HESS sampling covariance is indefinite",
      c("region","component","quantity","trait1","trait2"),drop=FALSE],
    unavailable_standard_errors=sum(is.na(estimates$standard_error)),reasons=reasons)
}
