#' Fit a genetic-correlation method
#'
#' The Glist workflow fits ordinary LDSC, GNOVA or an equal-marker SumHer
#' baseline from stored LD scores and checked frames or gact's `z`/`n` list.
#' Common setup and default delete blocks are supplied automatically. HESS
#' uses the independent regions and reference samples saved by
#' `gbase::gprep(task="eigen")`, and returns compact moments in `fit$projection`.
#' The focused dispatcher remains available. Each
#' method delegates to its focused public function and returns all quantities
#' defined by that fit; there is no `task` selector.
#'
#' @param statistics One ordinary qgg-style data frame, a named aligned list, a
#'   covariance object, or a prepared MR instrument object as required by the
#'   selected method.
#' @param ... Arguments for the selected focused method.
#' @param method Migrated method name.
#' @param Glist Reference containing stored LD scores, or a gbase BED reference
#'   with stored eigen-region definitions for HESS. Also accepts the
#'   positional form `gcorr(Glist, stat, method = ...)`.
#' @param stat Checked frames or gact's named Z/N matrices for the Glist workflow.
#' @return The result from the selected focused gcorr function.
#' @export
gcorr <- function(statistics = NULL, ..., method, Glist = NULL, stat = NULL) {
  method <- match.arg(method, c("ldsc", "gnova", "sumher", "hess",
    "rho_hess", "supergnova", "lava", "lava_partial", "lava_regression",
    "hdll", "sem", "ggm", "gsmr", "gsmr2", "ivw", "egger",
    "weighted_median"))
  dots <- list(...)
  positional_reference <- is.list(statistics) &&
    (!is.null(statistics$bedfiles) || inherits(statistics, "Glist"))
  if (positional_reference) {
    if (!is.null(Glist)) .gcorr_stop("Supply Glist only once.")
    Glist <- statistics; statistics <- NULL
    if (is.null(stat) && length(dots) &&
        (is.null(names(dots)) || is.na(names(dots)[1L]) || names(dots)[1L] == "")) {
      stat <- dots[[1L]]; dots <- dots[-1L]
    }
  }
  if (!is.null(Glist) || !is.null(stat)) {
    if (!method %in% c("ldsc", "gnova", "sumher", "hess"))
      .gcorr_stop("The Glist/stat workflow supports ldsc, gnova, sumher and hess.")
    if (!is.null(stat) && !is.null(statistics)) .gcorr_stop("Supply stat or statistics, not both.")
    if (is.null(stat)) stat <- statistics
    if (method == "hess")
      return(do.call(.gcorr_hess_workflow,
        c(list(Glist = Glist, stat = stat), dots)))
    return(do.call(.gcorr_score_workflow,
      c(list(Glist = Glist, stat = stat, method = method), dots)))
  }
  mr <- list(gsmr = gcorr_gsmr, gsmr2 = gcorr_gsmr2,
    ivw = gcorr_mr_ivw, egger = gcorr_mr_egger,
    weighted_median = gcorr_mr_weighted_median)
  if (method %in% names(mr)) {
    return(do.call(mr[[method]], c(list(instruments = statistics), list(...))))
  }
  if (method == "sem") {
    return(do.call(gcorr_sem, c(list(covariance = statistics), list(...))))
  }
  if (method == "ggm") {
    return(do.call(gcorr_ggm, c(list(covariance = statistics), list(...))))
  }
  arguments <- list(statistics = statistics, ...)
  regional <- list(hess = gcorr_hess, rho_hess = gcorr_rho_hess,
    supergnova = gcorr_supergnova, lava = gcorr_lava,
    lava_partial = gcorr_lava_partial,
    lava_regression = gcorr_lava_regression, hdll = gcorr_hdll)
  if (method %in% names(regional)) return(do.call(regional[[method]], arguments))
  if (method == "sumher") return(do.call(gcorr_sumher, arguments))
  if (method == "gnova") {
    return(do.call(gcorr_gnova, arguments))
  }
  if ("annotation_ld_scores" %in% names(arguments)) {
    return(do.call(gcorr_ldsc_partitioned, arguments))
  }
  do.call(gcorr_ldsc, arguments)
}
