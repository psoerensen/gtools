.gcorr_ldsc_reference <- function(Glist, prepared) {
  if (is.null(Glist$sparseLD) || is.null(prepared$chromosome)) {
    ids <- names(.gcorr_stored_scores(Glist))
    index <- match(prepared$marker, ids)
    if (anyNA(index)) .gcorr_stop("Every statistic marker must occur in Glist LD scores.")
    return(list(metadata = if (is.null(Glist$sparseLD))
      list(marker_id = ids) else Glist$sparseLD$marker_metadata, index = index))
  }
  gbase::validate_Glist(Glist)
  if (!is.list(Glist$sparseLD)) {
    .gcorr_stop("Glist must be augmented with gprep(task = 'sparseld').")
  }
  metadata <- Glist$sparseLD$marker_metadata
  index <- match(prepared$marker, metadata$marker_id)
  if (anyNA(index) || is.unsorted(index, strictly = TRUE)) {
    .gcorr_stop("Statistics must follow the retained sparse-LD marker order.")
  }
  selected <- metadata[index, , drop = FALSE]
  if (!identical(as.character(prepared$chromosome),
        as.character(selected$chromosome)) ||
      !identical(as.numeric(prepared$position),
        as.numeric(selected$base_pair_position)) ||
      !identical(as.character(prepared$effect_allele),
        as.character(selected$allele1)) ||
      !identical(as.character(prepared$other_allele),
        as.character(selected$allele2))) {
    .gcorr_stop("Statistics must match Glist marker coordinates and allele orientation exactly.")
  }
  list(metadata = metadata, index = index)
}

.gcorr_ldsc_scores <- function(ldscores, markers) {
  if (!is.numeric(ldscores) || !length(ldscores) || is.null(names(ldscores)) ||
      anyNA(names(ldscores)) || any(!nzchar(names(ldscores))) ||
      anyDuplicated(names(ldscores)) || any(!is.finite(ldscores)) ||
      any(ldscores <= 0) || any(!markers %in% names(ldscores))) {
    .gcorr_stop("ldscores must be positive finite uniquely named values containing every statistic marker.")
  }
  if (identical(names(ldscores), markers)) return(ldscores)
  stats::setNames(as.numeric(ldscores[match(markers, names(ldscores))]), markers)
}

.gcorr_ldsc_blocks <- function(blocks, prepared, block_count) {
  markers <- prepared$marker
  if (is.null(blocks)) {
    block_count <- .gcorr_scalar_number(block_count, "block_count", 2, TRUE)
    if (length(markers) < 2L) {
      .gcorr_stop("At least two markers are required to form delete blocks.")
    }
    if (is.null(prepared$chromosome)) {
      chunk <- ceiling(seq_along(markers) * min(block_count, length(markers)) / length(markers))
      return(stats::setNames(paste0("delete", chunk), markers))
    }
    width <- ceiling(length(markers) / min(block_count, length(markers)))
    chunk <- (seq_along(markers) - 1L) %/% width + 1L
    blocks <- paste(as.character(prepared$chromosome), chunk, sep = ":")
    return(stats::setNames(blocks, markers))
  }
  if (!is.character(blocks) || anyNA(blocks) || any(!nzchar(blocks))) {
    .gcorr_stop("blocks must contain nonempty delete-block labels.")
  }
  if (is.null(names(blocks))) {
    if (length(blocks) != length(markers)) {
      .gcorr_stop("Unnamed blocks must follow the statistic marker order.")
    }
    return(stats::setNames(blocks, markers))
  }
  if (anyNA(names(blocks)) || any(!nzchar(names(blocks))) ||
      anyDuplicated(names(blocks)) || any(!markers %in% names(blocks))) {
    .gcorr_stop("Named blocks must contain every statistic marker exactly once.")
  }
  stats::setNames(as.character(blocks[markers]), markers)
}

.gcorr_ldsc_annotations <- function(sets, marker_ids, residual, compact = FALSE,
    drop_unknown = FALSE) {
  if (!is.list(sets) || !length(sets) || is.object(sets) ||
      is.null(names(sets)) || anyNA(names(sets)) || any(!nzchar(names(sets))) ||
      anyDuplicated(names(sets))) .gcorr_stop("sets must be a nonempty uniquely named ordinary list.")
  if (!all(vapply(sets, function(ids) is.character(ids) && length(ids) > 0L &&
      !anyNA(ids) && all(nzchar(ids)) && !anyDuplicated(ids), logical(1))))
    .gcorr_stop("Every set must contain unique nonempty marker IDs.")
  if (!is.logical(residual) || length(residual) != 1L || is.na(residual))
    .gcorr_stop("residual must be TRUE or FALSE.")
  # One name lookup for all sets. Reuse these 1-based indices below.
  rows <- match(unlist(sets, use.names = FALSE), marker_ids)
  if (anyNA(rows) && !drop_unknown)
    .gcorr_stop("Every set marker must exist in the Glist sparse-LD reference.")
  indices <- split(rows, rep.int(seq_along(sets), lengths(sets)))
  names(indices) <- names(sets)
  if (drop_unknown) {
    indices <- lapply(indices, function(rows) rows[!is.na(rows)])
    indices <- indices[lengths(indices) > 0L]
    if (!length(indices)) .gcorr_stop("No supplied sets contain reference markers.")
    sets <- lapply(indices, function(rows) marker_ids[rows])
    rows <- unlist(indices, use.names = FALSE)
  }
  if (residual) {
    if ("Residual" %in% names(sets)) .gcorr_stop("sets cannot contain a set named Residual when residual = TRUE.")
    used <- logical(length(marker_ids)); used[rows] <- TRUE
    remaining <- which(!used)
    if (!length(remaining)) .gcorr_stop("The residual marker set is empty; use residual = FALSE.")
    indices$Residual <- remaining; sets$Residual <- marker_ids[remaining]
  }
  rows <- unlist(indices, use.names = FALSE)
  if (compact && !anyDuplicated(rows)) {
    group <- integer(length(marker_ids))
    group[rows] <- rep.int(seq_along(indices), lengths(indices))
    sums <- stats::setNames(as.numeric(lengths(indices)), names(indices))
    overlap <- diag(unname(sums), nrow = length(sums))
    dimnames(overlap) <- list(names(sums), names(sums))
    return(list(sets = sets, indices = indices, group = group,
      sums = sums, overlap = overlap))
  }
  annotation <- matrix(0, nrow = length(marker_ids), ncol = length(indices),
    dimnames = list(marker_ids, names(indices)))
  for (column in seq_along(indices)) annotation[indices[[column]], column] <- 1
  list(sets = sets, indices = indices, annotation = annotation,
    sums = colSums(annotation), overlap = crossprod(annotation))
}

.gcorr_ldsc_views <- function(fit, what) {
  estimates <- fit$estimates
  rows <- estimates$quantity == "h2" & is.na(estimates$trait2)
  h2 <- estimates[rows, , drop = FALSE]
  components <- if ("component" %in% names(h2)) h2$component else rep("all", nrow(h2))
  component_names <- unique(components)
  values <- matrix(NA_real_, nrow = length(component_names),
    ncol = length(fit$traits), dimnames = list(component_names, fit$traits))
  if (nrow(h2)) {
    values[cbind(match(components, component_names),
      match(h2$trait1, fit$traits))] <- h2$estimate
  }
  correlation <- if (!is.null(fit$matrices$total_genetic_correlation)) {
    fit$matrices$total_genetic_correlation
  } else if (!is.null(fit$matrices$genetic_correlation)) {
    fit$matrices$genetic_correlation
  } else {
    matrix(1, 1L, 1L, dimnames = list(fit$traits, fit$traits))
  }
  fit$h2 <- values
  fit$rg <- correlation
  fit$requested <- what
  fit
}

.gcorr_grouped_estimates <- function(fit, marker_counts) {
  source <- fit$estimates$quantity %in% c("tau", "tau_cov")
  grouped <- fit$estimates[source, , drop = FALSE]
  if (!nrow(grouped)) return(fit)
  scale <- unname(marker_counts[match(grouped$component,
    names(marker_counts))])
  grouped$quantity <- ifelse(grouped$quantity == "tau", "h2", "cov")
  grouped$estimate <- grouped$estimate * scale
  grouped$standard_error <- grouped$standard_error * scale
  fit$estimates <- rbind(fit$estimates, grouped)
  fit$group_marker_counts <- marker_counts
  fit
}

#' Fit LD-score regression from checked summary statistics
#'
#' Convenience interface for ordinary, stratified, or grouped LD-score
#' regression. The
#' `stat` contract is shared with `glma::vegas()`: supply one checked ordinary
#' summary-statistics data frame or a uniquely named list for multiple traits.
#'
#' @param stat One checked summary-statistics data frame, or a uniquely named
#'   list of aligned data frames, or gact's list containing named `z` and `n`
#'   matrices. Matrix summaries must already share allele orientation.
#' @param z,n Alternatively, supply marker-named Z scores and sample sizes
#'   directly. Z may be a vector or marker-by-trait matrix; N may be a matching
#'   matrix, a scalar or named trait sizes. Common markers are matched once to
#'   LD-score order. Retained values must be finite and N positive.
#' @param Glist Optional prepared Glist containing sparse LD. Required when
#'   stratified `sets` are supplied; otherwise stored scores suffice.
#' @param ldscores Optional positive named ordinary LD-score vector. When both
#'   `Glist` and `ldscores` are supplied, this vector is used for regression
#'   weighting while Glist supplies annotation LD scores.
#' @param sets Optional uniquely named list of marker-ID vectors. Sets may
#'   overlap. Annotation LD scores are computed from Glist.
#' @param set_model How supplied marker sets enter the regression. `stratified`
#'   computes standard annotation-specific LD scores from sparse LD;
#'   `grouped` masks the stored ordinary LD-score vector by set membership,
#'   matching the qgg grouped-set construction without scanning sparse LD.
#' @param residual Whether to add markers outside every supplied set as a
#'   `Residual` annotation.
#' @param what Requested convenient result view: heritability or genetic
#'   correlation. The complete fit is always retained.
#' @param blocks Optional character delete-block labels, either in statistic
#'   order or uniquely named by marker.
#' @param block_count Target number of deterministic contiguous delete blocks
#'   when `blocks` is omitted.
#' @param marginal_intercept Whether marginal LDSC intercepts are estimated or
#'   fixed to one.
#' @param overlap_intercept Optional finite cross-trait LDSC intercept.
#' @param maximum_chi_square Optional inclusive squared-Z filtering threshold.
#' @param corrected Whether annotation LD scores use finite-reference
#'   correction.
#' @param marker_count Optional reference marker count. Defaults to common
#'   reference markers for matrix input. Frames retain the Glist reference
#'   count, or the supplied score count when no Glist is supplied.
#' @param reference_sample_size Reference sample size for grouped sets without
#'   Glist; otherwise obtained from Glist.
#' @return A `gcorr_ldsc_fit` containing the complete focused fit plus convenient
#'   `h2`, `rg`, and `requested` components.
#' @export
ldsc <- function(stat = NULL, Glist = NULL, ldscores = NULL, sets = NULL,
    residual = FALSE, what = c("h2", "rg"), blocks = NULL,
    block_count = 200L, marginal_intercept = c("free", "fixed_one"),
    overlap_intercept = NULL, maximum_chi_square = NULL,
    corrected = FALSE, set_model = c("stratified", "grouped"),
    z = NULL, n = NULL, marker_count = NULL, reference_sample_size = NULL) {
  what <- match.arg(what)
  marginal_intercept <- match.arg(marginal_intercept)
  set_model <- match.arg(set_model)
  if (!is.logical(residual) || length(residual) != 1L || is.na(residual)) {
    .gcorr_stop("residual must be TRUE or FALSE.")
  }
  if (is.null(sets) && residual) {
    .gcorr_stop("residual = TRUE requires sets.")
  }
  if (is.null(sets) && set_model != "stratified") {
    .gcorr_stop("set_model applies only when sets are supplied.")
  }
  if (is.null(ldscores)) {
    if (is.null(Glist)) .gcorr_stop("Supply either Glist or named ordinary ldscores.")
    ldscores <- .gcorr_stored_scores(Glist)
  }
  inputs <- .gcorr_score_inputs(stat, z, n, names(ldscores))
  prepared <- inputs$first
  reference <- if (is.null(Glist) || (isTRUE(inputs$matrix_input) &&
      (is.null(sets) || set_model == "grouped"))) NULL else
    .gcorr_ldsc_reference(Glist, prepared)

  if (is.null(marker_count)) marker_count <- if (isTRUE(inputs$matrix_input))
    length(prepared$marker) else if (!is.null(reference))
      length(reference$metadata$marker_id) else length(ldscores)
  ldscores <- .gcorr_ldsc_scores(ldscores, prepared$marker)
  blocks <- .gcorr_ldsc_blocks(blocks, prepared, block_count)

  if (is.null(sets)) {
    fit <- gcorr_ldsc(inputs, ldscores, blocks,
      overlap_intercept = overlap_intercept, marker_count = marker_count,
      marginal_intercept = marginal_intercept,
      maximum_chi_square = maximum_chi_square)
    return(.gcorr_score_result(.gcorr_ldsc_views(fit, what), inputs))
  }
  if (set_model == "stratified" && (is.null(Glist) || is.null(Glist$sparseLD))) {
    .gcorr_stop("Glist with sparse LD is required for stratified sets.")
  }
  if (set_model == "grouped" && is.null(Glist) && is.null(reference_sample_size))
    .gcorr_stop("reference_sample_size is required for grouped sets without Glist.")
  annotation_markers <- if (set_model == "grouped") prepared$marker else
    reference$metadata$marker_id
  parsed <- .gcorr_ldsc_annotations(sets, annotation_markers, residual,
    compact = set_model == "grouped", drop_unknown = isTRUE(inputs$matrix_input))
  if (set_model == "stratified") {
    annotation_scores <- gbase::ld_scores(Glist,
      annotation = parsed$annotation, corrected = corrected)
    annotation_scores <- annotation_scores[prepared$marker, , drop = FALSE]
  } else {
    if (corrected) {
      .gcorr_stop("corrected = TRUE is available only for stratified set scores.")
    }
    if (!is.null(parsed$group)) {
      group <- parsed$group
      values <- unname(ldscores)
      values[group == 0L] <- 0
      group[group == 0L] <- 1L
      annotation_scores <- .gcorr_disjoint_scores(annotation_markers,
        names(parsed$sets), group, values)
    } else {
      annotation_scores <- sweep(parsed$annotation, 1L, unname(ldscores), `*`)
    }
  }
  annotation_sums <- parsed$sums
  annotation_overlap <- parsed$overlap
  fit <- gcorr_ldsc_partitioned(inputs, annotation_scores, ldscores,
    annotation_sums, blocks,
    annotation_overlap = if (set_model == "stratified" || isTRUE(inputs$matrix_input))
      annotation_overlap else NULL,
    reference_sample_size = if (!is.null(reference_sample_size)) reference_sample_size
      else if (is.list(Glist$sparseLD)) Glist$sparseLD$n else Glist$n,
    reference_marker_count = length(annotation_markers), corrected = corrected,
    overlap_intercept = overlap_intercept,
    marginal_intercept = marginal_intercept,
    maximum_chi_square = maximum_chi_square)
  if (set_model == "grouped") {
    if (isTRUE(inputs$matrix_input)) fit$group_marker_counts <- annotation_sums
    else fit <- .gcorr_grouped_estimates(fit, annotation_sums)
    fit$set_overlap <- annotation_overlap
  }
  fit$sets <- parsed$sets
  fit$set_model <- set_model
  fit$method <- paste0(set_model, "_ldsc")
  fit$assumptions$set_model <- set_model
  fit$assumptions$set_score_construction <- if (set_model == "stratified")
    "annotation-specific squared-LD sums" else
    "ordinary LD scores masked by focal-marker set membership"
  if (set_model == "grouped") {
    class(fit) <- c("gcorr_ldsc_grouped_fit", class(fit))
  }
  .gcorr_score_result(.gcorr_ldsc_views(fit, what), inputs)
}
