.gcorr_score_names <- function(ids, label) {
  if (!is.character(ids) || !length(ids) || anyNA(ids) ||
      any(!nzchar(ids)) || anyDuplicated(ids))
    .gcorr_stop(paste(label, "must be unique nonempty names."))
  ids
}

.gcorr_stored_scores <- function(Glist) {
  if (!is.list(Glist) || is.null(Glist$ldscores))
    .gcorr_stop("Glist must contain stored ldscores, or supply ldscores explicitly.")
  scores <- unlist(Glist$ldscores, use.names = FALSE)
  ids <- unlist(if (is.null(Glist$rsidsLD)) Glist$rsids else Glist$rsidsLD,
    use.names = FALSE)
  .gcorr_score_names(ids, "Glist LD-score marker IDs")
  if (length(scores) != length(ids))
    .gcorr_stop("Glist LD scores must match its LD-score marker IDs.")
  .gcorr_ldsc_scores(stats::setNames(scores, ids), ids)
}

# Matrix summaries have already been harmonized by their data provider. Match
# names once; native score methods receive only Z, N and integer membership.
.gcorr_score_inputs <- function(stat = NULL, z = NULL, n = NULL,
    reference_ids = NULL) {
  if (!is.null(z) || !is.null(n)) {
    if (!is.null(stat)) .gcorr_stop("Supply stat or z and n, not both.")
  } else if (is.list(stat) && all(c("z", "n") %in% names(stat)) &&
      !is.data.frame(stat)) {
    z <- stat$z; n <- stat$n
  } else {
    return(.gcorr_prepare_statistics(stat))
  }
  if (is.numeric(z) && is.null(dim(z))) {
    ids <- .gcorr_score_names(names(z), "z marker IDs")
    z <- matrix(z, ncol = 1L, dimnames = list(ids, "trait"))
  }
  if (!is.matrix(z) || !is.numeric(z) || !nrow(z) || !ncol(z))
    .gcorr_stop("z must be a named numeric vector or marker-by-trait matrix.")
  ids <- .gcorr_score_names(rownames(z), "z marker IDs")
  traits <- .gcorr_score_names(colnames(z), "z trait names")
  if (!is.numeric(n)) .gcorr_stop("n must be numeric.")
  if (is.matrix(n)) {
    n_ids <- .gcorr_score_names(rownames(n), "n marker IDs")
    n_traits <- .gcorr_score_names(colnames(n), "n trait names")
    if (!setequal(traits, n_traits)) .gcorr_stop("z and n trait names must match.")
    at_n <- match(ids, n_ids)
  } else if (is.null(dim(n)) && length(n) == 1L) {
    at_n <- seq_along(ids)
  } else if (is.null(dim(n)) && ncol(z) == 1L &&
      !is.null(names(n)) && all(ids %in% names(n))) {
    .gcorr_score_names(names(n), "n marker IDs")
    at_n <- match(ids, names(n))
  } else if (is.null(dim(n)) && length(n) == length(traits) &&
      !is.null(names(n)) && setequal(names(n), traits)) {
    .gcorr_score_names(names(n), "n trait names")
    at_n <- seq_along(ids)
  } else .gcorr_stop("n must be a scalar, named trait sizes, or marker-named sizes matching z.")
  rows <- which(!is.na(at_n))
  if (!is.null(reference_ids)) {
    .gcorr_score_names(reference_ids, "LD-score marker IDs")
    # Preserve genomic reference order for contiguous jackknife deletes.
    rows <- rows[match(reference_ids, ids[rows], nomatch = 0L)]
  }
  if (length(rows) < 2L) .gcorr_stop("At least two common statistic and LD-score markers are required.")
  markers <- ids[rows]
  prepared <- stats::setNames(lapply(seq_along(traits), function(j) {
    sizes <- if (is.matrix(n)) n[at_n[rows], match(traits[j], colnames(n))]
      else if (length(n) == 1L) n
      else if (ncol(z) == 1L && all(ids %in% names(n))) n[at_n[rows]]
      else n[match(traits[j], names(n))]
    values <- z[rows, j]
    if (any(!is.finite(values)) || any(!is.finite(sizes)) || any(sizes <= 0))
      .gcorr_stop("Retained z and n must be finite, with positive sample sizes.")
    if (all(sizes == sizes[1L])) sizes <- sizes[1L]
    list(trait = traits[j], marker = markers, z = as.numeric(values), n = as.numeric(sizes))
  }), traits)
  structure(list(statistics = stats::setNames(vector("list", length(traits)), traits),
    prepared = prepared, first = prepared[[1L]], matrix_input = TRUE,
    input_marker_count = length(ids)), class = "gcorr_prepared_statistics")
}

.gcorr_score_result <- function(fit, inputs) {
  if (isTRUE(inputs$matrix_input)) {
    fit$assumptions$allele_alignment <- "caller harmonized; named Z/N markers matched"
    fit$diagnostics$input_markers <- inputs$input_marker_count
    fit$diagnostics$common_reference_markers <- length(inputs$first$marker)
  }
  fit
}

.gcorr_score_workflow <- function(Glist, stat, method, ldscores = NULL,
    blocks = NULL, block_count = 200L, marker_count = NULL,
    marginal_intercept = "free", maximum_chi_square = 80,
    overlap_intercept = NULL, overlap_intercepts = NULL,
    inflation = "multiplicative", reference_sample_size = NULL, ...) {
  if (is.null(ldscores)) ldscores <- .gcorr_stored_scores(Glist)
  inputs <- .gcorr_score_inputs(stat, reference_ids = names(ldscores))
  if (method == "gnova")
    inputs <- .gcorr_prepare_statistics(inputs, scalar_sample_size = TRUE)
  scores <- .gcorr_ldsc_scores(ldscores, inputs$first$marker)
  if (is.null(marker_count)) marker_count <- if (isTRUE(inputs$matrix_input))
    length(inputs$first$marker) else length(ldscores)
  blocks <- .gcorr_ldsc_blocks(blocks, inputs$first, block_count)
  if (method == "ldsc")
    return(ldsc(inputs, Glist = Glist,
      ldscores = ldscores, blocks = blocks, marker_count = marker_count,
      marginal_intercept = marginal_intercept,
      maximum_chi_square = maximum_chi_square,
      overlap_intercept = overlap_intercept,
      reference_sample_size = reference_sample_size, ...))
  if (method == "gnova") {
    if (is.null(overlap_intercepts) && length(inputs$prepared) > 1L) {
      intercept_fit <- gcorr_ldsc(inputs, scores, blocks,
        marker_count = marker_count, marginal_intercept = marginal_intercept,
        maximum_chi_square = maximum_chi_square,
        overlap_intercept = overlap_intercept)
      overlap_intercepts <- intercept_fit$matrices$ldsc_intercept
    }
    return(.gcorr_score_result(gcorr_gnova(inputs, blocks, scores,
      overlap_intercepts = overlap_intercepts, ...), inputs))
  }
  if (is.null(reference_sample_size)) {
    reference_sample_size <- if (is.list(Glist$sparseLD)) Glist$sparseLD$n else Glist$n
  }
  architecture <- matrix(unname(scores), ncol = 1L,
    dimnames = list(names(scores), "baseline"))
  .gcorr_score_result(gcorr_sumher(inputs, architecture, c(baseline = marker_count), scores,
    blocks, reference_sample_size = reference_sample_size,
    inflation = inflation, overlap_intercepts = overlap_intercepts, ...), inputs)
}
