#' Prepare a full PLINK panel as a mapped Glist
#'
#' Build a new immutable gmat panel directory. Components retain their supplied
#' order and every marker and sample retains its physical BIM or FAM order.
#' The per-file `rsids` vectors are kept in memory for BED row lookup.
#' Other per-marker columns are read on demand from the companion.
#' @param bedfiles,bimfiles,famfiles PLINK paths. BIM and FAM paths can be inferred.
#' @param out_dir Optional legacy resource directory. With NULL, write one
#'   same-stem `.ext` companion per BED file.
#' @param study Optional study label.
#' @return A serializable mapped Glist descriptor for [gfilter()] and sparse LD in [gprep()].
#' @md
#' @export
gprep_mapped <- function(bedfiles, out_dir = NULL, bimfiles = NULL, famfiles = NULL, study = NULL) {
  if (!is.null(study) && (!is.character(study) || length(study) != 1L || is.na(study)))
    .gbase_stop("`study` must be NULL or one string.")
  bedfiles <- .gprep_path(bedfiles, "bedfiles")
  if (is.null(bimfiles)) bimfiles <- .gprep_companion(bedfiles, "bim")
  if (is.null(famfiles)) famfiles <- .gprep_companion(bedfiles, "fam")
  bimfiles <- .gprep_path(bimfiles, "bimfiles")
  famfiles <- .gprep_path(famfiles, "famfiles")
  path <- if (is.null(out_dir)) character() else .mapped_glist_path(out_dir)
  .mapped_glist_descriptor(cpp_gbase_mapped_prepare(path, bedfiles, bimfiles, famfiles, study))
}

.gprep_ext <- function(bedfiles, bimfiles, famfiles, study) {
  if (!is.null(study) && (!is.character(study) || length(study) != 1L || is.na(study)))
    .gbase_stop("`study` must be NULL or one string.")
  bedfiles <- .gprep_path(bedfiles, "bedfiles")
  if (is.null(bimfiles)) bimfiles <- .gprep_companion(bedfiles, "bim")
  if (is.null(famfiles)) famfiles <- .gprep_companion(bedfiles, "fam")
  bimfiles <- .gprep_path(bimfiles, "bimfiles")
  famfiles <- .gprep_path(famfiles, "famfiles")
  if (length(bimfiles) != length(bedfiles) || length(famfiles) != length(bedfiles))
    .gbase_stop("PLINK path vectors must have equal lengths.")

  paths <- sub("([^/])\\.[^./]*$", "\\1", bedfiles)
  if (any(paths == bedfiles)) .gbase_stop("BED path needs a file extension for .ext naming.")
  paths <- paste0(paths, ".ext")
  existing <- file.exists(paths)
  if (!any(existing))
    return(gprep_mapped(bedfiles, bimfiles = bimfiles, famfiles = famfiles, study = study))

  panel <- cpp_gbase_mapped_open(paths[existing], all(existing))
  if (!identical(panel$bedfiles, bedfiles[existing]) ||
      !identical(panel$bimfiles, bimfiles[existing]) ||
      !identical(panel$famfiles, famfiles[existing]))
    .gbase_stop("Existing .ext files do not match the supplied BED/BIM/FAM paths.")
  if (!is.null(study) && !identical(panel$study, study))
    .gbase_stop("Existing .ext files do not match the supplied study.")

  created <- character()
  finished <- FALSE
  on.exit(if (!finished) unlink(created), add = TRUE)
  if (!all(existing)) {
    created <- gprep_mapped(bedfiles[!existing], bimfiles = bimfiles[!existing],
      famfiles = famfiles[!existing], study = panel$study)$gstatfiles
    panel <- cpp_gbase_mapped_open(paths, TRUE)
  }
  if (length(paths) > 1L && anyDuplicated(unlist(panel$rsids, use.names = FALSE)))
    .gbase_stop("Marker IDs must be globally unique.")
  prepared <- .mapped_glist_descriptor(panel)
  finished <- TRUE
  prepared
}

.mapped_glist_path <- function(path) {
  if (!is.character(path) || length(path) != 1L || is.na(path) || !nzchar(path))
    .gbase_stop("Mapped Glist path must be one nonempty directory path.")
  path <- path.expand(path)
  if (!dir.exists(dirname(path))) .gbase_stop("Mapped Glist parent directory does not exist.")
  file.path(normalizePath(dirname(path), winslash = "/", mustWork = TRUE), basename(path))
}

.mapped_glist_marker_fields <- c("rsids", "chr", "pos", "map", "a1", "a2", "cpra",
  "nmiss", "af", "af1", "af2", "maf", "hom", "het", "n0", "n1", "n2",
  "source_marker_indices_0based")

.mapped_glist_descriptor <- function(x) {
  if (!dir.exists(x$path[1L])) x$gstatfiles <- x$path
  x["study_ids"] <- list(NULL)
  x$physical_marker_counts <- as.double(x$mchr)
  x$sample_source_indices_0based <- as.double(seq_along(x$ids) - 1L)
  x$genotype_format <- "PLINK BED SNP-major"
  x$marker_selection_order <- "canonical file/BIM order"
  x$provenance <- list(persistent_store = "mapped PLINK panel and existing PLINK BED files",
    summary_samples = "all", dosage_allele = "BIM field 5 (a1)",
    af_policy = "exact empirical; no clipping", versions = gbase_native_info())
  x$m <- sum(x$mchr)
  structure(x, class = c("gs_mapped_genotypes", "gs_genotypes", "Glist"))
}


#' Open a mapped Glist
#'
#' Loads the per-file `rsids` vectors into memory and opens other marker
#' columns on demand.
#' @param path A legacy resource directory, or companion paths in BED order.
#' @return A serializable mapped Glist descriptor for [gfilter()] and sparse LD in [gprep()].
#' @md
#' @export
open_mapped_Glist <- function(path) {
  .mapped_glist_descriptor(cpp_gbase_mapped_open(.gstat_resource_paths(path), TRUE))
}

.gstat_resource_paths <- function(path) {
  if (is.character(path) && length(path) == 1L && dir.exists(path))
    return(.mapped_glist_path(path))
  .gprep_path(path, "gstatfiles")
}

#' Read marker columns from a mapped Glist
#' @param Glist A mapped Glist descriptor.
#' @param fields One or more qgg marker field names.
#' @param component One-based BED component index.
#' @param start One-based first row within the component.
#' @param count Number of rows. By default, read to the end of the component.
#' @return A named list of marker vectors in physical BIM order.
#' @export
read_mapped_Glist <- function(Glist, fields, component = 1L, start = 1L, count = NULL) {
  if (!inherits(Glist, "gs_mapped_genotypes")) .gbase_stop("Expected a mapped Glist.")
  fields <- .gprep_selection(fields, "fields")
  if (is.null(fields)) .gbase_stop("Supply at least one mapped marker field.")
  component <- .gprep_count(component, "component")
  start <- .gprep_count(start, "start")
  if (component > Glist$nchr) .gbase_stop("Invalid mapped component.")
  if (is.null(count)) count <- as.double(Glist$mchr[component]) - start + 1
  count <- .gprep_count(count, "count", minimum = 0L)
  if (start - 1 > Glist$mchr[component] || count > Glist$mchr[component] - start + 1)
    .gbase_stop("Requested mapped rows are out of range.")
  columns <- if (!is.null(Glist$rsids)) setdiff(fields, "rsids") else fields
  result <- if (length(columns)) cpp_gbase_mapped_read(Glist$path, columns,
    component - 1L, start - 1L, count) else list()
  if ("rsids" %in% fields && !is.null(Glist$rsids))
    result$rsids <- Glist$rsids[[component]][start - 1 + seq_len(count)]
  result[fields]
}

.gprep_validate_mapped <- function(Glist, check_ld = TRUE, check_rsids = check_ld) {
  original <- .mapped_glist_descriptor(cpp_gbase_mapped_open(
    .gstat_resource_paths(Glist$path), FALSE))
  descriptor_fields <- c("study", "bedfiles", "bimfiles", "famfiles", "ids", "n",
    "mchr", "nchr", "path", if (!is.null(original$gstatfiles)) "gstatfiles")
  if (!identical(Glist[descriptor_fields], unclass(original)[descriptor_fields]))
    .gbase_stop("Mapped Glist fields no longer match the panel manifest.")
  # Older serialized descriptors only had the scalar manifest fields.
  if (inherits(Glist, "Glist")) {
    scalar_fields <- c("study_ids", "physical_marker_counts", "sample_source_indices_0based",
      "m", "genotype_format", "marker_selection_order")
    if (!identical(Glist[scalar_fields], unclass(original)[scalar_fields]))
      .gbase_stop("Mapped Glist dimensions or sample indices no longer match the panel.")
    # Validate shape cheaply on all paths. Full identity is checked by
    # validate_Glist(), which is also the explicit validation entry point.
    if (!is.list(Glist$rsids) || !identical(lengths(Glist$rsids), Glist$mchr) ||
        !all(vapply(Glist$rsids, is.character, logical(1))))
      .gbase_stop("Mapped Glist rsids must match the physical component sizes.")
    fields <- if (check_rsids) .mapped_glist_marker_fields
      else setdiff(.mapped_glist_marker_fields, "rsids")
    for (field in fields) {
      actual <- Glist[[field]]
      expected <- original[[field]]
      if (!.mapped_columns_equal(actual, expected))
        .gbase_stop("Mapped Glist field `", field, "` no longer matches the panel.")
    }
  }
  if (check_ld) {
    if (!is.null(Glist$sparseLD)) {
      sparse_ld <- .gprep_validate_sparse_ld(Glist)
      if (!is.null(Glist$ldBlocks)) .gprep_validate_ld_blocks(Glist$ldBlocks, sparse_ld)
    } else if (!is.null(Glist$ldBlocks)) {
      .gbase_stop("Glist ldBlocks requires sparse LD.")
    }
  }
  invisible(original)
}

.mapped_columns_equal <- function(actual, expected) {
  is.list(actual) && length(actual) == length(expected) &&
    all(vapply(seq_along(expected), function(i) {
      x <- actual[[i]]
      y <- expected[[i]]
      cpp_gbase_same_mapped_column(x, y) || identical(x, y)
    }, logical(1)))
}

.mapped_ld_marker_indices <- function(Glist, saved) {
  rows <- saved$marker_indices_0based
  meta <- saved$marker_metadata
  if (!is.list(rows) || !identical(lengths(rows), lengths(saved$rsids)) ||
      any(vapply(rows, is.unsorted, logical(1), strictly = TRUE)) ||
      !identical(as.double(meta$component_index_0based),
        rep(seq_along(saved$chr) - 1, lengths(rows))) ||
      !cpp_gbase_mapped_ld_rows_match(Glist$path, rep(saved$chr - 1, lengths(rows)),
        as.double(unlist(rows, use.names = FALSE)), meta$marker_id, meta$chromosome,
        meta$base_pair_position, meta$allele1, meta$allele2))
    .gbase_stop("Glist sparse-LD marker mappings do not match the mapped panel.")
  rows
}

.gprep_mapped_sparseld <- function(Glist, out_prefix, rows, reference_ids, ids, rsids, options) {
  original <- .gprep_validate_mapped(Glist, check_ld = FALSE)
  missing <- setdiff(names(original), names(Glist))
  if (length(missing) || !inherits(Glist, "Glist")) {
    original <- open_mapped_Glist(Glist$path)
    Glist[missing] <- original[missing]
    Glist$rsids <- original$rsids
  }
  class(Glist) <- class(original)
  if (is.null(out_prefix))
    out_prefix <- file.path(dirname(Glist$bedfiles[1L]), "sparseLD")
  result <- cpp_gbase_mapped_sparse_ld(Glist$path, if (is.null(rsids)) character() else rsids,
    as.double(rows - 1L), .gprep_prefix(out_prefix), options)
  resource <- result$resource
  active <- as.integer(result$source_components) + 1L
  meta <- resource$markers
  groups <- split(seq_len(nrow(meta)), meta$component_index_0based)
  selected_ids <- vector("list", Glist$nchr)
  selected_ids[active] <- unname(lapply(groups, function(i) meta$marker_id[i]))
  source <- vector("list", Glist$nchr)
  source[active] <- unname(lapply(groups, function(i) meta$source_marker_index_0based[i]))
  af <- unname(lapply(groups, function(i) result$af[i]))
  af_source <- if (identical(reference_ids, Glist$ids)) "mapped Glist allele frequencies"
    else "recomputed for LD reference samples from BED"
  .gprep_attach_sparseld(Glist, resource, active, source, selected_ids, af, af_source,
    rows, reference_ids, ids, rsids, options)
}

.gfilter_mapped <- function(Glist, maf, missing, hwe, info, ambiguous, indels, mhc, assembly) {
  .gprep_validate_mapped(Glist, check_ld = FALSE, check_rsids = !is.null(info))
  maf <- .gfilter_threshold(maf, "maf")
  missing <- .gfilter_threshold(missing, "missing")
  hwe <- .gfilter_threshold(hwe, "hwe")
  info <- .gfilter_threshold(info, "info")
  ambiguous <- .gfilter_logical(ambiguous, "ambiguous")
  indels <- .gfilter_logical(indels, "indels")
  mhc <- .gfilter_logical(mhc, "mhc")
  interval <- if (mhc) {
    .gfilter_mhc_interval(if (is.null(assembly)) Glist$assembly else assembly)
  } else numeric()
  info_values <- if (!is.null(info)) {
    if (!"info" %in% names(Glist))
      .gbase_stop("`info` filtering requires a marker-aligned `Glist$info` field.")
    marker_rsids <- Glist$rsids
    if (is.null(marker_rsids))
      marker_rsids <- open_mapped_Glist(Glist$path)$rsids
    .gfilter_info(Glist$info, unlist(marker_rsids, use.names = FALSE))
  } else numeric()
  thresholds <- vapply(list(maf, missing, hwe, info), function(x)
    if (is.null(x)) NA_real_ else x, numeric(1))
  cpp_gbase_mapped_filter(Glist$path, thresholds, ambiguous, indels, interval, info_values)
}
