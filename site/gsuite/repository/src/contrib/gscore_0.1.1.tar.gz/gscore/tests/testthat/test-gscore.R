test_that("gscore applies multiple scores in selected sample order", {
  fixture <- prepare_gscore_fixture(c("I8", "I2", "I5"))
  on.exit(remove_gscore_fixture(fixture), add = TRUE)
  result <- gscore(fixture$weights, fixture$Glist,
    coding = "raw_mean_imputed", scale_scores = FALSE)
  expected <- fixture$genotypes[c(8, 2, 5), ] %*%
    as.matrix(fixture$weights[c("score_a", "score_b")])
  dimnames(expected) <- dimnames(result$scores)
  expect_s3_class(result, "gscore_prediction")
  expect_equal(result$scores, expected)
  expect_identical(result$samples$individual_id, c("I8", "I2", "I5"))
  expect_match(capture.output(print(result)), "3 samples x 2 scores")
})

test_that("allele swaps preserve effect-allele scoring", {
  fixture <- prepare_gscore_fixture()
  on.exit(remove_gscore_fixture(fixture), add = TRUE)
  swapped <- fixture$weights
  swapped$effect_allele[2] <- "G"
  swapped$other_allele[2] <- "A"
  swapped$allele_frequency[2] <- 1 - swapped$allele_frequency[2]
  raw <- gscore(swapped, fixture$Glist, coding = "raw_mean_imputed",
    scale_scores = FALSE)
  effect_dosage <- fixture$genotypes
  effect_dosage[, 2] <- 2 - effect_dosage[, 2]
  expected <- effect_dosage %*% as.matrix(swapped[c("score_a", "score_b")])
  dimnames(expected) <- dimnames(raw$scores)
  expect_equal(raw$scores, expected)
  expect_identical(raw$alignment$swapped_markers, "m2")

  standard <- gscore(swapped, fixture$Glist, coding = "standardized",
    scale_scores = FALSE)
  standardized <- sweep(effect_dosage, 2, 2 * swapped$allele_frequency, "-")
  standardized <- sweep(standardized, 2,
    sqrt(2 * swapped$allele_frequency * (1 - swapped$allele_frequency)), "/")
  expected_standard <- standardized %*%
    as.matrix(swapped[c("score_a", "score_b")])
  dimnames(expected_standard) <- dimnames(standard$scores)
  expect_equal(standard$scores, expected_standard, tolerance = 1e-12)
})

test_that("missing markers and mismatches are explicit", {
  fixture <- prepare_gscore_fixture()
  on.exit(remove_gscore_fixture(fixture), add = TRUE)
  extra <- fixture$weights[1, ]
  extra$marker <- "absent"
  extra$position <- 999
  weights <- rbind(fixture$weights, extra)
  dropped <- gscore(weights, fixture$Glist, coding = "raw_mean_imputed",
    scale_scores = FALSE)
  expect_identical(dropped$alignment$dropped_markers, "absent")
  expect_error(gscore(weights, fixture$Glist,
    control = list(missing_markers = "error")), "absent")
  bad <- fixture$weights
  bad$effect_allele[1] <- "C"
  expect_error(gscore(bad, fixture$Glist), "alleles")
  bad <- fixture$weights
  bad$position[1] <- 999
  expect_error(gscore(bad, fixture$Glist), "coordinate")
  expect_error(gscore(fixture$weights, fixture$Glist,
    control = list(memory_limit_bytes = 1)), "memory_limit_bytes")
})

test_that("score scaling and native contract are deterministic", {
  fixture <- prepare_gscore_fixture()
  on.exit(remove_gscore_fixture(fixture), add = TRUE)
  first <- gscore(fixture$weights, fixture$Glist,
    coding = "raw_mean_imputed")
  second <- gscore(fixture$weights, fixture$Glist,
    coding = "raw_mean_imputed")
  expect_identical(first$scores, second$scores)
  expect_equal(colMeans(first$scores), c(score_a = 0, score_b = 0),
    tolerance = 1e-15)
  expect_equal(apply(first$scores, 2, sd), c(score_a = 1, score_b = 1),
    tolerance = 1e-15)
  info <- gscore_native_info()
  expect_identical(names(info), c("gscore", "gbayes", "gmat", "gsolve", "gbits"))
  expect_true(all(vapply(info, `[[`, logical(1), "compatible")))
})

test_that("marker-name sets score overlaps across BED components in one call", {
  fixture <- prepare_gscore_multifile_fixture(c("I8", "I2", "I5"))
  on.exit(remove_gscore_fixture(fixture), add = TRUE)
  sets <- list(cross = c("m1", "m3"), overlap = c("m2", "m3", "m4"))
  result <- gscore(fixture$weights, fixture$Glist, sets = sets,
    include_total = TRUE, coding = "raw_mean_imputed", scale_scores = FALSE)
  genotype <- fixture$genotypes[c(8, 2, 5), , drop = FALSE]
  base <- as.matrix(fixture$weights[c("score_a", "score_b")])
  expected <- cbind(genotype %*% base,
    genotype[, c(1, 3), drop = FALSE] %*% base[c(1, 3), , drop = FALSE],
    genotype[, c(2, 3, 4), drop = FALSE] %*% base[c(2, 3, 4), , drop = FALSE])
  colnames(expected) <- c("score_a", "score_b", "cross:score_a",
    "cross:score_b", "overlap:score_a", "overlap:score_b")
  rownames(expected) <- rownames(result$scores)
  expect_equal(result$scores, expected)
  expect_identical(result$set_membership, sets)
  expect_identical(result$coverage$used_markers, c(2L, 3L))
})

test_that("set coverage and post-standardization weights are explicit", {
  fixture <- prepare_gscore_fixture()
  on.exit(remove_gscore_fixture(fixture), add = TRUE)
  weights <- fixture$weights[-4, c(1:7)]
  sets <- list(first = c("m1", "m4", "absent"), second = c("m2", "m3"))
  result <- gscore(weights, fixture$Glist, sets = sets,
    set_weights = c(first = 2, second = 0.5))
  expect_identical(colnames(result$scores), names(sets))
  expect_equal(apply(result$scores, 2, stats::sd), c(first = 2, second = 0.5),
    tolerance = 1e-14)
  expect_identical(result$coverage$used_markers, c(1L, 2L))
  expect_identical(result$coverage$missing_from_Glist, c(1L, 0L))
  expect_identical(result$coverage$missing_from_weights, c(2L, 0L))
  expect_identical(result$missing_set_markers$first$Glist, "absent")
  expect_error(gscore(weights, fixture$Glist, sets = sets,
    control = list(missing_markers = "error")), "unavailable marker")
  expect_error(gscore(weights, fixture$Glist,
    sets = list(empty = "absent")), "retain at least one")
})

test_that("raw set scores preserve swapped effect-allele coding", {
  fixture <- prepare_gscore_fixture()
  on.exit(remove_gscore_fixture(fixture), add = TRUE)
  swapped <- fixture$weights[1:7]
  swapped$effect_allele[2] <- "G"
  swapped$other_allele[2] <- "A"
  swapped$allele_frequency[2] <- 1 - swapped$allele_frequency[2]
  result <- gscore(swapped, fixture$Glist,
    sets = list(pair = c("m1", "m2")), coding = "raw_mean_imputed",
    scale_scores = FALSE)
  dosage <- fixture$genotypes[, 1:2, drop = FALSE]
  dosage[, 2] <- 2 - dosage[, 2]
  expected <- drop(dosage %*% swapped$score_a[1:2])
  expect_equal(unname(drop(result$scores)), expected)
})
