write_gscore_bed <- function(genotypes, path) {
  encode <- function(x) {
    if (is.na(x)) return(1L)
    switch(as.character(x), "2" = 0L, "1" = 2L, "0" = 3L)
  }
  body <- raw()
  for (marker in seq_len(ncol(genotypes))) {
    codes <- vapply(genotypes[, marker], encode, integer(1))
    bytes <- raw(ceiling(nrow(genotypes) / 4))
    for (byte in seq_along(bytes)) {
      value <- 0L
      for (offset in 0:3) {
        sample <- (byte - 1L) * 4L + offset + 1L
        if (sample <= length(codes))
          value <- bitwOr(value, bitwShiftL(codes[[sample]], 2L * offset))
      }
      bytes[[byte]] <- as.raw(value)
    }
    body <- c(body, bytes)
  }
  writeBin(c(as.raw(c(0x6c, 0x1b, 0x01)), body), path)
}

prepare_gscore_fixture <- function(selected_ids = NULL, sparse_ld = FALSE) {
  genotypes <- matrix(c(
    0, 0, 2, 0,
    0, 1, 2, 1,
    0, 2, 1, 2,
    1, 0, 1, 2,
    1, 1, 0, 1,
    1, 2, 0, 0,
    2, 0, 1, 0,
    2, 2, 2, 2), nrow = 8, byrow = TRUE)
  marker <- paste0("m", seq_len(ncol(genotypes)))
  prefix <- tempfile("gscore-plink-")
  paths <- setNames(paste0(prefix, c(".bed", ".bim", ".fam")),
    c("bed", "bim", "fam"))
  write_gscore_bed(genotypes, paths[["bed"]])
  write.table(data.frame(chromosome = "1", marker_id = marker,
    genetic_distance_cm = 0, base_pair_position = seq_along(marker) * 100,
    allele1 = "A", allele2 = "G"), paths[["bim"]], quote = FALSE,
    row.names = FALSE, col.names = FALSE)
  write.table(data.frame(family_id = paste0("F", seq_len(nrow(genotypes))),
    individual_id = paste0("I", seq_len(nrow(genotypes))), paternal_id = "0",
    maternal_id = "0", sex = "0", phenotype = "-9"), paths[["fam"]],
    quote = FALSE, row.names = FALSE, col.names = FALSE)
  Glist <- gbase::gprep(bedfiles = paths[["bed"]], ids = selected_ids)
  if (sparse_ld) {
    Glist <- gbase::gprep(Glist, task = "sparseld",
      out_prefix = tempfile("gscore-sparseld-"), max_distance_bp = 1000,
      max_distance_variants = 0, r2 = 0.01)
  }
  weights <- data.frame(marker = marker, chromosome = "1",
    position = seq_along(marker) * 100, effect_allele = "A",
    other_allele = "G", allele_frequency = Glist$af[[1]],
    score_a = c(1, -0.5, 0.25, 2), score_b = c(0, 1, 0, -1),
    stringsAsFactors = FALSE)
  list(Glist = Glist, weights = weights, paths = paths,
    genotypes = genotypes)
}

remove_gscore_fixture <- function(fixture) {
  sparse_paths <- if (is.null(fixture$Glist$sparseLD)) character() else
    unlist(fixture$Glist$sparseLD$paths, use.names = FALSE)
  unlink(c(unname(fixture$paths), sparse_paths))
}

prepare_gscore_multifile_fixture <- function(selected_ids = NULL) {
  base <- prepare_gscore_fixture(selected_ids)
  unlink(base$paths[["bed"]])
  prefixes <- paste0(tempfile("gscore-component-"), 1:2)
  paths <- lapply(prefixes, function(prefix) setNames(
    paste0(prefix, c(".bed", ".bim", ".fam")), c("bed", "bim", "fam")))
  for (part in 1:2) {
    columns <- if (part == 1L) 1:2 else 3:4
    write_gscore_bed(base$genotypes[, columns, drop = FALSE],
      paths[[part]][["bed"]])
    write.table(data.frame(chromosome = as.character(part),
      marker_id = paste0("m", columns), genetic_distance_cm = 0,
      base_pair_position = columns * 100, allele1 = "A", allele2 = "G"),
      paths[[part]][["bim"]], quote = FALSE, row.names = FALSE,
      col.names = FALSE)
    file.copy(base$paths[["fam"]], paths[[part]][["fam"]])
  }
  unlink(unname(base$paths))
  Glist <- gbase::gprep(
    bedfiles = vapply(paths, `[[`, character(1), "bed"), ids = selected_ids)
  weights <- data.frame(marker = paste0("m", 1:4),
    chromosome = c("1", "1", "2", "2"), position = (1:4) * 100,
    effect_allele = "A", other_allele = "G",
    allele_frequency = unlist(Glist$af, use.names = FALSE),
    score_a = c(1, -0.5, 0.25, 2), score_b = c(0, 1, 0, -1),
    stringsAsFactors = FALSE)
  list(Glist = Glist, weights = weights,
    paths = unlist(paths, use.names = FALSE), genotypes = base$genotypes)
}
