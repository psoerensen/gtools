test_that("clump_threshold constructs directly applicable standardized weights", {
  fixture <- prepare_gscore_fixture(sparse_ld = TRUE)
  on.exit(remove_gscore_fixture(fixture), add = TRUE)
  stat <- data.frame(rsids = paste0("m", 1:4), chr = "1",
    pos = 100 * (1:4), ea = "A", nea = "G",
    b = c(0.2, 0.4, -0.3, 0.5), seb = rep(0.1, 4), n = rep(100, 4),
    p = c(0.01, 0.001, 0.2, 0.002), stringsAsFactors = FALSE)

  weights <- clump_threshold(stat, fixture$Glist,
    p_threshold = 0.05, r2_threshold = 0.1, window_bp = 500)
  expect_identical(class(weights), "data.frame")
  expect_identical(weights$marker, paste0("m", 1:4))
  expect_equal(weights$weight,
    c(0.2 / sqrt(1.04), 0.4 / sqrt(1.16), 0, 0), tolerance = 1e-12)

  prediction <- gscore(weights, fixture$Glist, scale_scores = FALSE)
  standardized <- sweep(fixture$genotypes, 2,
    2 * weights$allele_frequency, "-")
  standardized <- sweep(standardized, 2,
    sqrt(2 * weights$allele_frequency * (1 - weights$allele_frequency)), "/")
  expected <- standardized %*% weights$weight
  expect_equal(as.numeric(prediction$scores[, "weight"]),
    as.numeric(expected), tolerance = 1e-12)
})

test_that("clump_threshold rejects incomplete or unsupported inputs", {
  fixture <- prepare_gscore_fixture()
  on.exit(remove_gscore_fixture(fixture), add = TRUE)
  stat <- data.frame(rsids = paste0("m", 1:4), chr = "1",
    pos = 100 * (1:4), ea = "A", nea = "G", b = rep(0.1, 4),
    seb = rep(0.1, 4), p = rep(0.01, 4), n = rep(100, 4))
  expect_error(clump_threshold(stat, fixture$Glist), "sparse LD")

  with_ld <- prepare_gscore_fixture(sparse_ld = TRUE)
  on.exit(remove_gscore_fixture(with_ld), add = TRUE)
  no_p <- stat[names(stat) != "p"]
  expect_error(clump_threshold(no_p, with_ld$Glist), "ordinary data frame")
  expect_error(clump_threshold(stat, with_ld$Glist,
    r2_threshold = 0), "r2_threshold")
  changed <- stat
  changed$pos[1] <- 999
  expect_error(clump_threshold(changed, with_ld$Glist), "positions disagree")
})
