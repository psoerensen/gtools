test_that("stat scoring respects raw and standardized effect units", {
  f <- prepare_gscore_fixture(); on.exit(remove_gscore_fixture(f))
  s <- f$weights[c('marker','chromosome','position','effect_allele','other_allele','allele_frequency','score_a')]
  names(s) <- c('rsids','chr','pos','ea','nea','eaf','b')
  raw <- gscore(Glist=f$Glist, stat=s, scale_scores=FALSE)
  w <- f$weights[c('marker','chromosome','position','effect_allele','other_allele','allele_frequency','score_a')]
  ref <- gscore(w, f$Glist, coding='raw_mean_imputed', scale_scores=FALSE)
  expect_equal(unname(raw$scores), unname(ref$scores), tolerance=0)
  names(s)[7] <- 'bm'
  standard <- gscore(Glist=f$Glist, stat=s, scale_scores=FALSE)
  ref <- gscore(w, f$Glist, coding='standardized', scale_scores=FALSE)
  expect_equal(unname(standard$scores), unname(ref$scores), tolerance=0)
  expect_error(gscore(w, f$Glist, stat=s), 'either')
})
