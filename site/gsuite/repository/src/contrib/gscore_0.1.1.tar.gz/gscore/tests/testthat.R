library(testthat);library(gscore);test_check("gscore")
