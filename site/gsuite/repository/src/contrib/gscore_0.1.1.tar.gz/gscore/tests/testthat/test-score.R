test_that("BED score is deterministic",{
 p<-tempfile(fileext=".bed");writeBin(as.raw(c(0x6c,0x1b,0x01,0x78)),p)
 x<-gscore_bed(p,3,1,0,.5,matrix(2,nrow=1),"raw_mean_imputed")
 expect_equal(as.numeric(x),c(4,2,0));expect_identical(x,gscore_bed(p,3,1,0,.5,matrix(2,nrow=1),"raw_mean_imputed"))
})
