#include <Rcpp.h>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>
#include <gbayes/bayesc.hpp>
#include <gbits/c_api.h>
#include <gscore/bed_score.hpp>
#include <gscore/summary_fit.hpp>
#include <gscore/version.hpp>
#include <gmat/version.hpp>
#include <gsolve/version.hpp>

namespace {

Rcpp::List version(const char* expected_version, std::uint32_t expected_abi,
                   const char* runtime_version, std::uint32_t runtime_abi) {
  return Rcpp::List::create(
      Rcpp::_ ["expected_version"] = expected_version,
      Rcpp::_ ["expected_abi"] = expected_abi,
      Rcpp::_ ["runtime_version"] = runtime_version,
      Rcpp::_ ["runtime_abi"] = runtime_abi,
      Rcpp::_ ["compatible"] = std::string(runtime_version) == expected_version &&
          runtime_abi == expected_abi);
}

gscore::BedScoreRequest bed_score_request(
    const std::string& path, double samples, double physical,
    const std::vector<double>& indices,
    const std::vector<double>& frequencies,
    const Rcpp::NumericMatrix& coefficients, const std::string& coding,
    const Rcpp::List& control) {
  gscore::BedScoreRequest request;
  request.bed_path = path;
  request.sample_count = static_cast<std::uint64_t>(samples);
  request.physical_marker_count = static_cast<std::uint64_t>(physical);
  request.allele_frequencies = frequencies;
  request.score_count = coefficients.ncol();
  request.coding = coding == "standardized"
      ? gscore::GenotypeCoding::standardized
      : gscore::GenotypeCoding::raw_mean_imputed;
  request.thread_count =
      static_cast<std::uint32_t>(Rcpp::as<double>(control["threads"]));
  request.marker_tile_size =
      static_cast<std::uint64_t>(Rcpp::as<double>(control["marker_tile_size"]));
  request.sample_tile_size =
      static_cast<std::uint64_t>(Rcpp::as<double>(control["sample_tile_size"]));
  request.score_tile_size =
      static_cast<std::uint64_t>(Rcpp::as<double>(control["score_tile_size"]));
  for (double index : indices)
    request.marker_indices.push_back(static_cast<std::uint64_t>(index));
  for (R_xlen_t marker = 0; marker < coefficients.nrow(); ++marker)
    for (R_xlen_t score = 0; score < coefficients.ncol(); ++score)
      request.coefficients.push_back(coefficients(marker, score));
  return request;
}

Rcpp::NumericMatrix score_matrix(const gscore::ScoreResult& result) {
  Rcpp::NumericMatrix output(result.sample_count(), result.score_count());
  for (std::uint64_t sample = 0; sample < result.sample_count(); ++sample)
    for (std::uint64_t score = 0; score < result.score_count(); ++score)
      output(sample, score) = result.at(sample, score);
  return output;
}

}  // namespace

// [[Rcpp::export]]
Rcpp::List cpp_gscore_native_info() {
  return Rcpp::List::create(
      Rcpp::_ ["gscore"] = version("0.1.0", 0, gscore::version_string(),
                                   gscore::abi_version()),
      Rcpp::_ ["gbayes"] = Rcpp::List::create(
          Rcpp::_ ["expected_version"] = "0.1.0",
          Rcpp::_ ["expected_abi"] = 0,
          Rcpp::_ ["runtime_version"] = gbayes::version_string(),
          Rcpp::_ ["runtime_abi"] = 0,
          Rcpp::_ ["compatible"] = std::string(gbayes::version_string()) == "0.1.0"),
      Rcpp::_ ["gmat"] = version("0.6.0", 0, gmat::version_string(),
                                 gmat::abi_version()),
      Rcpp::_ ["gsolve"] = version((std::to_string(gsolve::version_major) + "." +
          std::to_string(gsolve::version_minor) + "." + std::to_string(gsolve::version_patch)).c_str(),
          gsolve::experimental_abi, gsolve::version_string(),
                                   gsolve::abi_version()),
      Rcpp::_ ["gbits"] = version("0.21.0", 4, gbits_library_version(),
                                  gbits_abi_version()));
}

// [[Rcpp::export]]
Rcpp::List cpp_gscore_clump_threshold(
    std::vector<std::string> marker,
    std::vector<std::string> chromosome,
    std::vector<double> position,
    std::vector<std::string> effect_allele,
    std::vector<std::string> other_allele,
    std::vector<double> effect,
    std::vector<double> standard_error,
    std::vector<double> sample_count,
    std::vector<double> p_value,
    std::string trait,
    std::string ld_prefix,
    std::string reference_sample_set,
    double p_threshold,
    double r2_threshold,
    double window_bp) {
  gscore::ReportedGwasSummary reported;
  reported.marker_ids = std::move(marker);
  reported.chromosomes = std::move(chromosome);
  for (double value : position)
    reported.positions_bp.push_back(static_cast<std::uint64_t>(value));
  reported.effect_alleles = std::move(effect_allele);
  reported.other_alleles = std::move(other_allele);
  reported.effects = std::move(effect);
  reported.standard_errors = std::move(standard_error);
  reported.effective_sample_sizes = std::move(sample_count);
  reported.p_values = std::move(p_value);
  reported.trait = std::move(trait);

  auto reader = std::make_shared<const gmat::SparseLdDiskReader>(ld_prefix);
  auto prepared = gscore::prepare_gwas_summary(
      reported, reader->resource().markers);
  auto resource = std::shared_ptr<const gmat::SparseLdDiskResource>(
      reader, &reader->resource());
  gscore::SummaryLd ld{{}, resource->options, resource,
      reference_sample_set, reader};
  gscore::validate_summary_ld(prepared, ld);
  gscore::ClumpControls controls;
  controls.p_threshold = p_threshold;
  controls.r2_threshold = r2_threshold;
  controls.window_bp = static_cast<std::uint64_t>(window_bp);
  const auto result = gscore::clump_threshold_weights(prepared, ld, controls);
  return Rcpp::List::create(
      Rcpp::_ ["marker"] = result.marker_ids,
      Rcpp::_ ["weight"] = result.effects,
      Rcpp::_ ["nonzero_count"] = static_cast<double>(result.nonzero_count));
}

// [[Rcpp::export]]
Rcpp::NumericMatrix cpp_gscore_bed(
    std::string path, double samples, double physical,
    std::vector<double> indices, std::vector<double> frequencies,
    Rcpp::NumericMatrix coefficients, std::string coding,
    Rcpp::List control) {
  const auto request = bed_score_request(path, samples, physical, indices,
      frequencies, coefficients, coding, control);
  return score_matrix(gscore::score_bed(request));
}

// [[Rcpp::export]]
Rcpp::NumericMatrix cpp_gscore_bed_sets(
    std::string path, double samples, double physical,
    std::vector<double> indices, std::vector<double> frequencies,
    Rcpp::NumericMatrix coefficients, double set_count,
    std::vector<double> marker_set_offsets,
    std::vector<double> marker_sets, bool include_total,
    std::string coding, Rcpp::List control) {
  gscore::BedSetScoreRequest request;
  request.bed = bed_score_request(path, samples, physical, indices,
      frequencies, coefficients, coding, control);
  request.set_count = static_cast<std::uint64_t>(set_count);
  request.include_total = include_total;
  for (double offset : marker_set_offsets)
    request.marker_set_offsets.push_back(static_cast<std::uint64_t>(offset));
  for (double set : marker_sets)
    request.marker_sets.push_back(static_cast<std::uint64_t>(set));
  return score_matrix(gscore::score_bed_sets(request));
}
