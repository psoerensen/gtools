\name{compact_ld_Glist}
\alias{compact_ld_Glist}
\title{Move existing sparse LD marker metadata to disk}
\usage{compact_ld_Glist(Glist)}
\arguments{\item{Glist}{A Glist with sparse LD.}}
\value{A Glist referencing the original CSR and disk-backed metadata. Save the
returned object to persist the conversion.}
\description{Reuse the original LD files and scores. Write an index alongside
the marker table and a frequency sidecar when frequencies are specific to
the LD reference samples or the source panel has no disk-backed fields.}
