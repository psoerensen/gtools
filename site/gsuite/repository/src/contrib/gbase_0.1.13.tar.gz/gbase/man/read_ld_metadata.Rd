\name{read_ld_metadata}
\alias{read_ld_metadata}
\title{Read sparse LD marker metadata}
\usage{read_ld_metadata(Glist, rows = NULL, fields = NULL)}
\arguments{
\item{Glist}{A Glist with sparse LD.}
\item{rows}{One-based CSR rows in the order requested. NULL selects all rows.}
\item{fields}{Column names. NULL selects all fields.}
}
\value{A data frame in the requested row and column order.}
\description{Read selected marker metadata columns for a sparse LD resource.}
