#pragma once
#include "gbayes/export.h"
#include <cstddef>
#include <memory>
#include <string>
#include <vector>
namespace gbayes {
class CrossProducts;
// Reference genotype covariance is C / divisor. Effects are converted to that
// genotype coding by the explicit positive per-marker multiplier. No allele flips.
struct GeneticCovarianceReference {
  std::shared_ptr<const CrossProducts> cross_products;
  std::vector<std::string> marker_ids, counted_alleles;
  std::vector<double> effect_multipliers;
  double divisor{};
  std::string reference_id, genotype_coding, provenance;
};
struct GeneticCovariancePosterior {
  std::string reference_id;
  bool reference_truncated{false};
  std::vector<std::string> trait_ids;
  std::size_t draws{};
  // T*T column-major. Empirical posterior variance uses divisor draws, not draws-1.
  std::vector<double> covariance_mean, covariance_variance;
  // Conditional on both genetic variances being positive. NaN if count is zero.
  std::vector<double> correlation_mean, correlation_variance;
  std::vector<std::size_t> correlation_draws;
  std::vector<std::vector<double>> covariance_trace; // optional, one T*T per draw
};
GBAYES_EXPORT void validate_genetic_reference(const GeneticCovarianceReference&);
// B is marker-major, trait changes fastest. Returns (D B)' C (D B) / divisor.
GBAYES_EXPORT std::vector<double> genetic_covariance(
    const GeneticCovarianceReference&,const std::vector<double>& effects,std::size_t traits);
// Streaming posterior moments: no dense marker covariance or stored effect draws.
class GBAYES_EXPORT GeneticCovarianceAccumulator {
  GeneticCovarianceReference reference_;
  GeneticCovariancePosterior state_;
  bool retain_;
 public:
  GeneticCovarianceAccumulator(GeneticCovarianceReference,std::vector<std::string> trait_ids,
                               bool retain_covariance_draws=false);
  void add(const std::vector<double>& effects);
  GeneticCovariancePosterior summary() const;
};
// Pool empirical draw distributions in caller order. Same reference/trait contract
// is required; the caller must not reuse a reference_id for different resources.
GBAYES_EXPORT GeneticCovariancePosterior combine_genetic_covariance(
    const std::vector<GeneticCovariancePosterior>&);
}
