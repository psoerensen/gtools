# gmap

Standalone R interfaces for regional fine-mapping and colocalisation.
The package imports `gbase`, never root `gsuite`, and uses installed public
native interfaces.

The public workflows are:

- `gmap_stat()` for explicit OLS beta/SE/n conversion;
- `gmap()` for regional multi-effect, BayesC or BayesR fitting. Familiar
  `sets`, `method="bayesC"`, `algorithm="mcmc"`, `nit` and `seed` arguments
  use full BED LD in memory and the native dense sampler. Advanced eigen calls
  retain Glist-owned sparse LD and explicit retained-mass controls;
- `gmap_bed()` for checked regional interpretation of a saved individual-BED
  `gbayes_fit`, without refitting;
- `gmap_sets()` for labelled set and member tables, and `gmap_bfdr()` for
  PIP-threshold Bayesian-FDR summaries;
- `getCredibleSets()` for qgg-compatible CS2/CS3 grouping of saved marginal
  PIPs using full BED LD, without refitting or a qgg runtime dependency;
- `gmap_coloc()` for single-causal two-trait ABF colocalisation;
- `gmap_coloc_components()` for post-fit comparison of saved multi-effect
  components, without refitting.

Prepare genotype resources with `gbase::gprep()` and add sparse LD with
`gbase::gprep(Glist = ..., task = "sparseld")`. There is no public LDlist or
root-gsuite compatibility interface.

Dense MCMC requires positive-definite regional LD and applies no truncation,
jitter or PSD repair. BED decoding uses local `nthreads`; LD products use R's
configured BLAS. The result retains native diagnostics, controls and phase
timings. Familiar fields include `stat$bm`/`stat$dm`, regional `post` rows with
`ve`, `vg`, `vb`, `pi`, `pip`, native R-hat/ESS/MCSE/status columns in `conv`,
and named region groups in `cs`. `vg` averages retained joint-effect genetic
variance using the cached residual; it is not an independent variance draw.
`pip` is expected active-marker count. Marginal-PIP groups do not imply
component credible coverage.

BayesC/BayesR accept `control=list(ld_swap=list(probability=.05,
minimum_r2=.8, maximum_friends=50L, moves=1L))` on dense and eigen routes.
Native Metropolis-Hastings swaps relocate effects among LD neighbours;
`fit$ld_swap` reports per-region/trait attempted and accepted moves, including
burn-in, and `details` retains per-chain counts. Probability defaults to zero;
neighbour preparation adds cost and swaps do not guarantee better convergence.
