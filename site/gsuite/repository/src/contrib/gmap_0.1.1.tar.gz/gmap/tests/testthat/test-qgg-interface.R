test_that("familiar regional controls reuse the dense native sampler", {
  fixture <- gmap_stat_fixture();on.exit(fixture$cleanup())
  G <- fixture$Glist;G$sparseLD <- NULL
  stat <- data.frame(rsids=paste0('m',1:3),ea='A',nea='G',
    b=c(.2,-.1,.05),seb=c(.1,.2,.15),n=5)
  fit <- gmap(Glist=G,stat=stat,sets=list(region=stat$rsids),method='bayesC',
    algorithm='mcmc',nit=20,nburn=2,nthin=2,seed=11,mc=3,
    pi=.2,updateB=FALSE,updateE=FALSE,updatePi=FALSE)
  expect_identical(fit$algorithm,'mcmc')
  expect_identical(fit$control$seeds,11)
  expect_equal(fit$control$sampling_sweeps,20)
  expect_equal(fit$stat$bm,fit$estimates$mean,tolerance=0)
  expect_equal(fit$stat$dm,fit$estimates$pip,tolerance=0)
  expect_identical(fit$details$region$trait$chains[[1]]$working_residual_dimension,3)
  expect_true(is.na(fit$diagnostic_summary$minimum_retained_eigenvalue))
  expect_identical(names(fit$csets),'region')
  expect_identical(fit$cs,fit$csets)
  expect_identical(rownames(fit$post),'region')
  expect_true(all(c('ve','vg','vb','pi','pip') %in% names(fit$post)))
  expect_equal(fit$post$pip,sum(fit$stat$dm))
  expect_equal(fit$post$pi,fit$details$region$trait$parameter_mean$weights[2])
  expect_true(is.finite(fit$post$vg) && fit$post$vg>=0)
  expect_true(all(c('rhat_ve','ess_vg','status_pi','nrun') %in% names(fit$conv)))
  exact <- gmap(fit$stat,G,regions=list(region=stat$rsids),method='bayesc',
    algorithm='mcmc',prior=fit$prior,control=fit$control)
  expect_equal(exact$estimates,fit$estimates,tolerance=0)
  expect_error(gmap(Glist=G,stat=stat,sets=list(region=stat$rsids),method='bayesC',
    nit=20,control=list(sampling_sweeps=20)),'either')
  expect_error(gmap(Glist=G,stat=stat,sets=list(region=stat$rsids),method='bayesC',
    control=list(eigen=list(retained_positive_mass=.9))),'truncation')
})

test_that("regional dense and eigen routes retain familiar multi-chain tables", {
  fixture <- gmap_stat_fixture();on.exit(fixture$cleanup())
  stat <- data.frame(rsids=paste0('m',1:3),ea='A',nea='G',
    b=c(.2,-.1,.05),seb=c(.1,.2,.15),n=5)
  run <- function(algorithm,method) gmap(stat,fixture$Glist,
    sets=list(left=stat$rsids[1:2],right=stat$rsids[2:3]),
    method=method,algorithm=algorithm,nit=40,nburn=4,nrun=2,seed=21,
    pi=if(method=='bayesC') c(.8,.2) else c(.6,.2,.1,.1),mc=3,
    updateE=FALSE,updateB=TRUE,updatePi=TRUE,
    eigen_threshold=if(algorithm=='mcmc-eigen') 1 else NULL)
  for(method in c('bayesC','bayesR')) {
    dense <- run('mcmc',method);eigen <- run('mcmc-eigen',method)
    # Sparse LD stores float32 correlations; dense BED LD is computed in double.
    expect_equal(dense$stat$bm,eigen$stat$bm,tolerance=1e-7)
    expect_equal(dense$post,eigen$post,tolerance=1e-7)
    expect_identical(rownames(eigen$post),c('left','right'))
    expect_equal(eigen$conv$nrun,c(2,2))
    expect_equal(eigen$conv$draws,c(80,80))
    expect_true(all(is.finite(eigen$post$vg)))
    expect_identical(names(eigen$cs),c('left','right'))
    expect_true(all(eigen$conv$status_ve=='not_updated'))
  }
  stat$n <- 50
  external <- gmap(stat,fixture$Glist,sets=list(region=stat$rsids),
    method='bayesC',algorithm='mcmc',nit=8,updateB=FALSE,
    updateE=FALSE,updatePi=FALSE)
  expect_equal(external$details$region$trait$genetic_variance_denominator,50)
})

test_that("standalone posterior grouping matches qgg boundaries and ordering", {
  native <- function(LD,p,threshold=.8,r2=.5,method='CS2') {
    ids <- names(p)
    value <- gmap:::cpp_gmap_qgg_sets(LD,ids,p,threshold,r2,.001,method)
    if(!length(value$sets)) return(list(NULL))
    result <- lapply(value$sets,function(x) ids[x$indices])
    names(result) <- paste0('Set',seq_along(result));result
  }
  LD <- matrix(c(1,.8,0,.8,1,0,0,0,1),3)
  dimnames(LD) <- list(c('a','b','c'),c('a','b','c'))
  p <- c(a=.6,b=.3,c=.9)
  expect_identical(native(LD,p),list(Set1='c',Set2=c('a','b')))
  boundary <- matrix(c(1,.5,.5,1),2,dimnames=list(c('a','b'),c('a','b')))
  expect_identical(native(boundary,c(a=.7,b=.7),r2=.25),list(NULL))
  if(requireNamespace('qgg',quietly=TRUE)) {
    for(method in c('CS2','CS3'))
      expect_identical(native(LD,p,method=method),qgg:::crs(p,LD,threshold=.8,method=method))
  }
  fixture <- gmap_stat_fixture();on.exit(fixture$cleanup())
  fake <- list(stat=data.frame(rsids=paste0('m',1:3),dm=c(.99,.01,.01)))
  result <- getCredibleSets(fixture$Glist,fake,list(region=fake$stat$rsids))
  expect_identical(result$region,list(Set1='m1'))
  expect_match(attr(result,'implementation'),'standalone native')
  expect_error(getCredibleSets(fixture$Glist,list(stat=transform(fake$stat,dm=2)),
    list(region=fake$stat$rsids)),'Invalid')
})
