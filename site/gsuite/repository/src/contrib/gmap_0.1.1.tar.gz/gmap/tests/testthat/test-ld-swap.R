test_that("regional LD swaps run on dense and eigen BayesC/BayesR likelihoods", {
  first <- rep(0:2, each = 4)
  second <- first; second[1] <- 1
  genotype <- cbind(first, second, rep(c(0, 1, 2, 1), 3))
  fixture <- gmap_stat_fixture(genotype); on.exit(fixture$cleanup())
  stat <- data.frame(rsids = paste0("m", 1:3), ea = "A", nea = "G",
    b = c(.25, .24, 0), seb = .2, n = nrow(genotype))
  run <- function(algorithm, method, swap = NULL) {
    gmap(stat, fixture$Glist, sets = list(region = stat$rsids),
      method = method, algorithm = algorithm, nit = 100, nburn = 10,
      nrun = 2, seed = 31, ve = 1, vb = .2,
      pi = if (method == "bayesC") c(.7, .3) else c(.7, .2, .1),
      gamma = if (method == "bayesC") c(0, 1) else c(0, .1, 1),
      updateB = FALSE, updateE = FALSE, updatePi = FALSE,
      control = list(ld_swap = swap, eigen = list(retained_positive_mass = 1,
        select_on_convergence = FALSE)))
  }
  for (algorithm in c("mcmc", "mcmc-eigen")) for (method in c("bayesC", "bayesR")) {
    settings <- list(probability = 1, minimum_r2 = .8, moves = 2L)
    fit <- run(algorithm, method, settings)
    repeat_fit <- run(algorithm, method, settings)
    expect_identical(fit$estimates, repeat_fit$estimates)
    expect_identical(fit$ld_swap, repeat_fit$ld_swap)
    expect_gt(fit$ld_swap$attempted, 0)
    expect_gt(fit$ld_swap$accepted, 0)
    expect_lte(fit$ld_swap$accepted, fit$ld_swap$attempted)
    expect_equal(fit$ld_swap$acceptance_rate,
      fit$ld_swap$accepted / fit$ld_swap$attempted)
    chains <- fit$details$region$trait$chains
    expect_equal(fit$ld_swap$attempted, sum(vapply(chains,
      function(x) x$ld_swap_attempted, numeric(1))))
    expect_equal(fit$ld_swap$accepted, sum(vapply(chains,
      function(x) x$ld_swap_accepted, numeric(1))))
    expect_true(all(vapply(chains, function(x)
      x$maximum_residual_drift < 1e-8 && x$maximum_working_residual_drift < 1e-8,
      logical(1))))
    expect_true(all(is.finite(fit$estimates$mean)))
    none <- run(algorithm, method)
    disabled <- run(algorithm, method, list(probability = 0))
    expect_identical(none$estimates, disabled$estimates)
    expect_equal(none$control$ld_swap$probability, 0)
    expect_equal(none$ld_swap$attempted, 0)
    expect_true(is.na(none$ld_swap$acceptance_rate))
    isolated <- run(algorithm, method, list(probability = 1, minimum_r2 = 1))
    expect_equal(isolated$ld_swap$attempted, 0)
  }
})

test_that("regional swap controls reject invalid settings before sampling", {
  for (settings in list(list(probability = NA_real_), list(probability = 1.1),
      list(minimum_r2 = -.1), list(maximum_friends = 0), list(moves = .5),
      list(unknown = 1)))
    expect_error(gmap:::.gmap_ld_swap(settings), "ld_swap")
  expect_equal(gmap:::.gmap_ld_swap(list(moves = 0))$moves, 0)
  fixture <- gmap_stat_fixture(); on.exit(fixture$cleanup())
  stat <- gmap_stat(data.frame(rsids = paste0("m", 1:3), ea = "A",
    nea = "G", b = c(.2, -.1, .05), seb = .2, n = 6),
    fixture$Glist, phenotype_variance = 1)
  expect_error(gmap(stat, fixture$Glist, regions = list(region = paste0("m", 1:3)),
    method = "multi_effect", prior = list(residual_variance = 1, effect_variance = .2),
    control = list(ld_swap = list(probability = 1))),
    "control")
})
