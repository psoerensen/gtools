test_that("gmap_stat reconstructs exact OLS cross-products", {
  fixture <- gmap_stat_fixture(); on.exit(fixture$cleanup())
  stat <- data.frame(rsids = paste0("m", 1:3), ea = "A", nea = "G",
    b = c(.2, -.1, .05), seb = c(.1, .2, .15), n = 100L)
  result <- gmap_stat(stat, fixture$Glist, phenotype_variance = 2)
  information <- 99 * 2 / (98 * stat$seb^2 + stat$b^2)
  expect_equal(result$information, information, tolerance = 0)
  expect_equal(result$score, stat$b * information, tolerance = 0)
  expect_identical(result$rsids, stat$rsids)
  expect_identical(attr(result, "gmap_preparation")$response_ss, 198)
  traits <- gmap_stat(list(A = stat, B = transform(stat, b = b / 2)),
    fixture$Glist, c(A = 2, B = 3))
  expect_identical(names(traits), c("A", "B"))
  expect_error(gmap_stat(transform(stat, ea = c("G", "A", "A")),
    fixture$Glist, 2), "marker and allele order")
})

test_that("gmap fits deterministic regional methods from Glist sparse LD", {
  fixture <- gmap_stat_fixture(); on.exit(fixture$cleanup())
  stat <- data.frame(rsids = paste0("m", 1:3), ea = "A", nea = "G",
    b = c(.2, -.1, .05), seb = c(.1, .2, .15), n = 100L)
  prepared <- gmap_stat(stat, fixture$Glist, phenotype_variance = 2)
  regions <- list(region1 = prepared$rsids)
  common_prior <- list(residual_variance = 1, effect_variance = .1)

  multi <- gmap(prepared, fixture$Glist, regions, method = "multi_effect",
    prior = common_prior, control = list(effects = 2L, max_sweeps = 20L,
      eigen = list(retained_positive_mass = 1)))
  expect_s3_class(multi, "gmap_fit")
  expect_identical(multi$method, "multi_effect")
  expect_identical(multi$estimates$marker, prepared$rsids)
  expect_length(multi$estimates$mean, 3L)
  expect_identical(multi$diagnostic_summary$retained_rank,
    multi$diagnostic_summary$full_rank)
  expect_identical(multi$eigen_attempts$selected, TRUE)

  sampler <- list(burnin = 2L, sampling_sweeps = 8L,
    seeds = c(11, 23), sets = list(allow_incomplete = TRUE),
    eigen = list(select_on_convergence = FALSE))
  bayesc <- gmap(prepared, fixture$Glist, regions, method = "bayesc",
    prior = c(common_prior, list(inclusion_probability = .5)),
    control = sampler)
  bayesc_again <- gmap(prepared, fixture$Glist, regions, method = "bayesc",
    prior = c(common_prior, list(inclusion_probability = .5)),
    control = sampler)
  expect_equal(bayesc$estimates, bayesc_again$estimates, tolerance = 0)
  expect_identical(bayesc$diagnostic_summary$chains, 2L)

  bayesr <- gmap(prepared, fixture$Glist, regions, method = "bayesr",
    prior = common_prior, control = sampler)
  expect_s3_class(bayesr, "gmap_fit")
  expect_identical(bayesr$method, "bayesr")
  expect_equal(vapply(bayesr$details$region1$trait$component_probability,
    sum, numeric(1)), rep(1, 3), tolerance = 1e-12)

  expect_warning(provisional <- gmap(prepared, fixture$Glist, regions,
    method = "multi_effect", prior = common_prior,
    control = list(effects = 2L, max_sweeps = 1L,
      objective_tolerance = 1e-16,
      eigen = list(retained_positive_mass = c(.995, .9)))),
    "final complete fit is provisional")
  expect_identical(provisional$diagnostic_summary$attempts, 2L)
  expect_true(provisional$diagnostic_summary$fallback_required)
  expect_identical(provisional$eigen_attempts$attempt, c(1L, 2L))
  expect_identical(provisional$eigen_attempts$selected, c(FALSE, TRUE))
})

test_that("adaptive eigen controls are explicit and ordered", {
  fixture <- gmap_stat_fixture(); on.exit(fixture$cleanup())
  stat <- data.frame(rsids = paste0("m", 1:3), ea = "A", nea = "G",
    b = c(.2, -.1, .05), seb = c(.1, .2, .15), n = 100L)
  prepared <- gmap_stat(stat, fixture$Glist, phenotype_variance = 2)
  prior <- list(residual_variance = 1, effect_variance = .1)
  expect_error(gmap(prepared, fixture$Glist,
    list(region1 = prepared$rsids), prior = prior,
    control = list(eigen = list(retained_positive_mass = c(.9, .95)))),
    "strictly decreasing")
  expect_error(gmap(prepared, fixture$Glist,
    list(region1 = prepared$rsids), prior = prior,
    control = list(estimate_residual_variance = TRUE,
      eigen = list(retained_positive_mass = .995)),
    normalization = list(response_ss = 198, likelihood_dimension = 99,
      in_sample_ld = TRUE)), "requires retained_positive_mass = 1")
})
