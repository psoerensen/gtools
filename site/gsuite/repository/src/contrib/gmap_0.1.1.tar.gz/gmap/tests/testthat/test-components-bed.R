test_that("saved component colocalisation consumes Glist LD without refitting", {
  fixture <- gmap_stat_fixture(); on.exit(fixture$cleanup())
  stat <- data.frame(rsids = paste0("m", 1:3), ea = "A", nea = "G",
    b = c(.4, .05, 0), seb = rep(.1, 3), n = 100L)
  prepared <- gmap_stat(list(A = stat, B = transform(stat, b = c(.3, 0, .02))),
    fixture$Glist, c(A = 1, B = 1))
  regions <- list(first = stat$rsids, second = stat$rsids)
  fit <- gmap(prepared, fixture$Glist, regions,
    method = "multi_effect", prior = list(residual_variance = 1,
      effect_variance = .1), control = list(effects = 1L,
      eigen = list(retained_positive_mass = 1)))
  control <- list(complete_region_coverage = TRUE,
    non_overlapping_samples = TRUE)
  result <- gmap_coloc_components(fit, fit, fixture$Glist,
    trait1 = "A", trait2 = "B", control = control)
  expect_s3_class(result, "gmap_coloc")
  expect_identical(names(result$details), names(regions))
  expect_true(all(vapply(result$details, function(x) !x$refitted, logical(1))))
  expect_equal(rowSums(result$estimates[paste0("H", 0:4)]),
    rep(1, nrow(result$estimates)),
    tolerance = 1e-12)
  expect_true(all(result$component_status$status == "eligible"))
  expect_identical(unserialize(serialize(result, NULL)), result)
  expect_error(gmap_coloc_components(fit, fit, fixture$Glist,
    trait1 = "A", trait2 = "B"), "Explicit")
  changed <- fixture$Glist
  changed$sparseLD$checksums[[1L]] <- "changed"
  expect_error(gmap_coloc_components(fit, fit, changed,
    trait1 = "A", trait2 = "B", control = control),
    "changed after preparation|differ from the fitted reference")
  mislabeled <- fit
  mislabeled$details$first$A$trait <- "other"
  expect_error(gmap_coloc_components(mislabeled, fit, fixture$Glist,
    trait1 = "A", trait2 = "B", control = control), "trait labels")
})

test_that("saved gbayes BED posterior is interpreted without refitting", {
  fixture <- gmap_stat_fixture(); on.exit(fixture$cleanup())
  Glist <- fixture$Glist
  marker <- unlist(Glist$rsids, use.names = FALSE)
  paths <- normalizePath(Glist$bedfiles, winslash = "/", mustWork = TRUE)
  weights <- data.frame(marker = marker,
    chromosome = unlist(Glist$chr), position = unlist(Glist$pos),
    effect_allele = unlist(Glist$a1), other_allele = unlist(Glist$a2),
    allele_frequency = unlist(Glist$af), effect = c(.1, .2, .3))
  fit <- structure(list(method = "bayesc", likelihood = "individual_bed",
    trait = "trait", weights = weights,
    estimates = data.frame(marker = marker, mean = c(.1, .2, .3),
      variance = .01, pip = c(.2, .5, .8),
      chain_pip_range = c(.01, .02, .03)), chains = list(list(), list()),
    prior = list(residual_variance = 1),
    provenance = list(selected_ids = Glist$ids),
    continuation = list(signature = list(bedfiles = paths,
      marker = marker, selected_ids = Glist$ids))),
    class = c("gbayes_fit", "list"))
  mapped <- gmap_bed(fit, Glist, list(all = marker, edge = marker[2:3]),
    control = list(sets = list(coverage = .1, pip_cutoff = 0,
      min_r2 = 0, allow_incomplete = TRUE)))
  expect_s3_class(mapped, "gmap_bed_fit")
  expect_identical(mapped$source, "global_individual_bed")
  expect_equal(mapped$details$all$trait$pip, fit$estimates$pip)
  expect_equal(mapped$details$edge$trait$pip, fit$estimates$pip[2:3])
  expect_identical(mapped$sets$all$trait$meaning, "marginal_pip_mass")
  expect_false(mapped$sets$all$trait$incomplete_ld_reference)
  expect_identical(unserialize(serialize(mapped, NULL)), mapped)
  wrong <- Glist
  wrong$sparseLD$sample_ids <- rev(wrong$sparseLD$sample_ids)
  expect_error(gmap_bed(fit, wrong, list(all = marker)),
    "idsLD|sample order|changed after preparation")
})
