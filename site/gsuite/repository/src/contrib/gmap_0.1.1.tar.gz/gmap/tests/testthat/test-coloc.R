test_that("coloc is deterministic and normalized", {
  make <- function(trait, beta) data.frame(
    rsids=c("m1","m2","m3"), chr="1", pos=1:3,
    ea="A", nea="G", b=beta, seb=rep(.1,3))
  x <- gmap_coloc(make("a", c(.4,.05,0)), make("b", c(.3,0,.02)), "r", 1, 1)
  expect_equal(sum(x$hypothesis_probability), 1, tolerance=1e-12)
  expect_equal(sum(x$shared_variant_probability), 1, tolerance=1e-12)
  expect_identical(x, gmap_coloc(make("a", c(.4,.05,0)), make("b", c(.3,0,.02)), "r", 1, 1))
})
