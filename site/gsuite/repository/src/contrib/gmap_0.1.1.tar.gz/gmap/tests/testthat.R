library(testthat)
library(gmap)
test_check("gmap")
