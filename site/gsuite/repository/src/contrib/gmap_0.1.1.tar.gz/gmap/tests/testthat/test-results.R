gmap_result_fixture <- function() {
  native_set <- list(source_index = 1, lead_index = 1L, indices = c(1L, 2L),
    probabilities = c(.95, .8), r2_to_lead = c(1, .7), mass = 1.75,
    complete = TRUE, lead_probability = .95, min_r2_to_lead = .7,
    mean_r2_to_lead = .85, remaining_mass_before = 1.95,
    remaining_mass_after = .2, min_pairwise_r2 = .7,
    mean_pairwise_r2 = .7, passes_ld_threshold = TRUE,
    duplicate_of = NA_real_)
  value <- list(meaning = "marginal_pip_mass", sets = list(native_set),
    inactive_components = integer(), component_variances = numeric(),
    incomplete_ld_reference = FALSE, truncated_likelihood = FALSE)
  structure(list(source = "regional_summary", method = "bayesc",
    estimates = data.frame(region = "region1", trait = "trait1",
      marker = c("m1", "m2", "m3"), pip = c(.95, .8, .2)),
    sets = list(region1 = list(trait1 = value)),
    details = list(), control = list(sets = list(coverage = .95)),
    diagnostic_summary = data.frame(region = "region1", trait = "trait1",
      converged = NA, status = "MCMC; convergence not certified"),
    parameters = NULL, prior = list()), class = c("gmap_fit", "list"))
}

test_that("gmap_sets presents set and member tables without changing meaning", {
  fit <- gmap_result_fixture()
  result <- gmap_sets(fit)

  expect_named(result, c("summary", "members"))
  expect_equal(result$summary$lead_marker, "m1")
  expect_equal(result$summary$mass, 1.75)
  expect_identical(result$summary$meaning, "marginal_pip_mass")
  expect_true(result$summary$complete)
  expect_false(result$summary$incomplete_ld_reference)
  expect_equal(result$members$marker, c("m1", "m2"))
  expect_equal(result$members$probability, c(.95, .8))
  expect_identical(result$members$is_lead, c(TRUE, FALSE))
  expect_identical(summary(fit)$sets, result$summary)
})

test_that("gmap_sets returns typed empty tables", {
  fit <- gmap_result_fixture()
  fit$sets$region1$trait1$sets <- list()
  result <- gmap_sets(fit)

  expect_equal(nrow(result$summary), 0L)
  expect_equal(nrow(result$members), 0L)
  expect_identical(result$summary$set, integer())
  expect_identical(result$members$marker, character())
})

test_that("gmap_bfdr evaluates thresholds independently by fitted group", {
  fit <- gmap_result_fixture()
  result <- gmap_bfdr(fit, threshold = c(.8, .99))

  expect_equal(result$selected_markers, c(2, 0))
  expect_equal(result$expected_false_discoveries, c(.25, 0), tolerance = 0)
  expect_equal(result$bfdr[[1L]], .125, tolerance = 0)
  expect_true(is.na(result$bfdr[[2L]]))
})

test_that("gmap_bfdr finds the largest threshold-defined set below a target", {
  fit <- gmap_result_fixture()

  expect_equal(gmap_bfdr(fit, target = .13)$selected_markers, 2)
  expect_equal(gmap_bfdr(fit, target = .1)$threshold, .95)
  none <- gmap_bfdr(fit, target = .04)
  expect_equal(none$selected_markers, 0)
  expect_true(is.na(none$threshold))
  expect_error(gmap_bfdr(fit, threshold = .8, target = .1), "either")
})

test_that("result helpers reject invalid objects and probabilities", {
  expect_error(gmap_sets(list()), "gmap_fit")
  fit <- gmap_result_fixture(); fit$estimates$pip[[1L]] <- 1.1
  expect_error(gmap_bfdr(fit), "finite probabilities")
})
