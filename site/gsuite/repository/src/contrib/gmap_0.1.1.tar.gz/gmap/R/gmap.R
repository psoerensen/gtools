gmap_native_info <- function() cpp_gmap_native_info()

.onLoad <- function(libname, pkgname) {
  info <- cpp_gmap_native_info()
  if (!length(info) || any(!vapply(info, function(value)
      is.list(value) && isTRUE(value$compatible), logical(1)))) {
    stop("Loaded gmap native version/ABI is incompatible.", call. = FALSE)
  }
}

.gmap_input <- function(x, label, effect_units) {
  required <- c("rsids", "chr", "pos", "ea", "nea", "b", "seb")
  if (!identical(class(x), "data.frame") || !nrow(x) ||
      length(setdiff(required, names(x))))
    stop(label, " must be an ordinary data frame with rsids, chr, pos, ea, nea, b and seb.", call. = FALSE)
  if (any(!is.finite(x$b)) || any(!is.finite(x$seb)) || any(x$seb <= 0))
    stop(label, " must contain finite effects and positive standard errors.", call. = FALSE)
  if (!is.character(effect_units) || length(effect_units) != 1L ||
      is.na(effect_units) || !nzchar(effect_units))
    stop("effect units must be one nonempty character value.", call. = FALSE)
  list(trait = label, units = effect_units, marker = x$rsids,
       chromosome = x$chr, position = x$pos,
       effect_allele = x$ea, other_allele = x$nea,
       effect = x$b, standard_error = x$seb)
}

#' Colocalise two continuous-trait association summaries
#' @param trait1,trait2 Allele-aligned ordinary effect/standard-error data frames.
#' @param region Nonempty region label.
#' @param phenotype_sd1,phenotype_sd2 Positive phenotype standard deviations.
#' @param effect_units1,effect_units2 Nonempty labels for the effect units.
#' @param p1,p2,p12 Per-variant prior probabilities.
#' @return Native hypothesis probabilities and shared-variant probabilities.
#' @export
gmap_coloc <- function(trait1, trait2, region, phenotype_sd1, phenotype_sd2,
                       p1 = 1e-4, p2 = 1e-4, p12 = 1e-5,
                       effect_units1 = "phenotype units",
                       effect_units2 = effect_units1) {
  a <- .gmap_input(trait1, "trait1", effect_units1)
  b <- .gmap_input(trait2, "trait2", effect_units2)
  keys <- c("marker", "chromosome", "position", "effect_allele", "other_allele")
  if (!all(vapply(keys, function(k) identical(a[[k]], b[[k]]), logical(1))))
    stop("Traits must have identical marker order and allele orientation.", call. = FALSE)
  if (!is.character(region) || length(region) != 1L || !nzchar(region)) stop("region must be nonempty.", call. = FALSE)
  numeric_args <- c(phenotype_sd1, phenotype_sd2, p1, p2, p12)
  if (any(!is.finite(numeric_args)) || any(numeric_args <= 0)) stop("SDs and priors must be positive finite values.", call. = FALSE)
  cpp_gmap_coloc(a, b, region, phenotype_sd1, phenotype_sd2, p1, p2, p12)
}
