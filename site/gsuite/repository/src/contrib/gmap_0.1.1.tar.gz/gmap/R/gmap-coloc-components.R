.gmap_select_one <- function(value, available, name) {
  if (is.null(value) && length(available) == 1L) return(available)
  if (!is.character(value) || length(value) != 1L || is.na(value) ||
      !value %in% available)
    .gmap_stop("Select one ", name, " from: ", paste(available, collapse = ", "))
  value
}

#' Colocalise saved regional multi-effect fits
#' @param fit1,fit2 Standalone `gmap_fit` objects fitted with `multi_effect`.
#' @param Glist The same Glist-owned sparse-LD reference used by both fits.
#' @param trait1,trait2 Selected trait names; inferred for single-trait fits.
#' @param regions Optional region names present in both fits.
#' @param prior Per-variant `p1`, `p2`, and `p12` probabilities.
#' @param control Explicit `complete_region_coverage=TRUE` and
#'   `non_overlapping_samples=TRUE` assertions plus optional set controls.
#' @return A serializable component-pair `gmap_coloc` result. No model is refit.
#' @export
gmap_coloc_components <- function(fit1, fit2, Glist, trait1 = NULL,
    trait2 = NULL, regions = NULL, prior = list(), control = list()) {
  for (fit in list(fit1, fit2))
    if (!inherits(fit, "gmap_fit") || !identical(fit$schema_version, 1L) ||
        !identical(fit$method, "multi_effect"))
      .gmap_stop("Component colocalisation requires current standalone multi_effect fits.")
  trait1 <- .gmap_select_one(trait1, fit1$selection$traits, "trait1")
  trait2 <- .gmap_select_one(trait2, fit2$selection$traits, "trait2")
  if (identical(trait1, trait2)) .gmap_stop("Colocalisation requires distinct trait labels.")
  if (is.null(regions)) {
    if (!identical(fit1$selection$regions, fit2$selection$regions))
      .gmap_stop("Region selections differ; specify the region names to compare.")
    regions <- names(fit1$selection$regions)
  }
  if (!is.character(regions) || !length(regions) || anyNA(regions) ||
      any(!nzchar(regions)) || anyDuplicated(regions) ||
      any(!regions %in% names(fit1$selection$regions)) ||
      any(!regions %in% names(fit2$selection$regions)))
    .gmap_stop("`regions` must name unique regions present in both fits.")
  if (!identical(fit1$reference, fit2$reference))
    .gmap_stop("Colocalisation requires the same Glist LD reference and metadata.")
  reference <- .gmap_reference(Glist)
  if (!identical(reference$sparseLD$prefix, fit1$reference$prefix) ||
      !identical(reference$sparseLD$checksums, fit1$reference$checksums))
    .gmap_stop("Glist LD files or metadata differ from the fitted reference.")
  p <- .gmap_settings(prior, list(p1 = 1e-4, p2 = 1e-4, p12 = 1e-5), "coloc prior")
  for (name in names(p)) .gmap_probability(p[[name]], name, TRUE)
  settings <- .gmap_settings(control, list(complete_region_coverage = FALSE,
    non_overlapping_samples = FALSE, sets = list()), "coloc control")
  if (!isTRUE(settings$complete_region_coverage) ||
      !isTRUE(settings$non_overlapping_samples))
    .gmap_stop("Explicit complete_region_coverage=TRUE and non_overlapping_samples=TRUE are required.")
  settings$sets <- .gmap_set_control(settings$sets, "multi_effect")
  rows <- status <- diagnostics <- list()
  details <- stats::setNames(vector("list", length(regions)), regions)
  indices <- lapply(regions, function(region)
    .gmap_region_indices(fit1$selection$regions[[region]], reference$metadata))
  names(indices) <- regions
  reader <- cpp_gmap_open_ld(reference$sparseLD$prefix)
  on.exit(cpp_gmap_release_ld(reader), add = TRUE)
  for (region in regions) {
    markers <- fit1$selection$regions[[region]]
    if (!identical(markers, fit2$selection$regions[[region]]) ||
        !identical(fit1$region_metadata[[region]], fit2$region_metadata[[region]]))
      .gmap_stop("Regional coordinates or marker order differ: ", region)
    first <- fit1$details[[region]][[trait1]]
    second <- fit2$details[[region]][[trait2]]
    for (item in list(first, second))
      if (!is.list(item) || !identical(item$marker_ids, markers))
        .gmap_stop("Saved posterior labels do not match the selected region.")
    if (!identical(first$trait, trait1) || !identical(second$trait, trait2))
      .gmap_stop("Saved posterior trait labels do not match the selected traits.")
    matrix <- cpp_gmap_read_ld_region(reader, as.double(indices[[region]]),
      as.integer(max(2048L, length(markers))))
    value <- tryCatch(cpp_gmap_coloc_components(first, second, matrix,
      region, p, settings), error = function(error)
        .gmap_stop("Region ", region, ": ", conditionMessage(error)))
    n <- nrow(value$pairs)
    rows[[length(rows) + 1L]] <- cbind(data.frame(region = rep(region, n),
      trait1 = rep(trait1, n), trait2 = rep(trait2, n),
      stringsAsFactors = FALSE), value$pairs)
    for (i in 1:2) {
      values <- value[[paste0("status", i)]]
      status[[length(status) + 1L]] <- data.frame(region = region,
        trait = if (i == 1L) trait1 else trait2,
        component = seq_along(values), status = values)
    }
    diagnostics[[length(diagnostics) + 1L]] <- data.frame(region = region,
      eligible_pairs = n, status = if (n) "eligible_pairs" else "no_eligible_pairs",
      refitted = FALSE)
    details[[region]] <- value
  }
  structure(list(estimates = do.call(rbind, rows),
    component_status = do.call(rbind, status),
    diagnostic_summary = do.call(rbind, diagnostics), details = details,
    selection = list(regions = regions, trait1 = trait1, trait2 = trait2),
    reference = fit1$reference, prior = p, control = settings,
    probability_scope = "component_pair", call = match.call()),
    class = c("gmap_coloc", "list"))
}

#' @export
print.gmap_coloc <- function(x, ...) {
  cat("Component-pair colocalisation:", x$selection$trait1, "/",
    x$selection$trait2, "\n")
  print(x$diagnostic_summary, row.names = FALSE)
  invisible(x)
}

#' @export
summary.gmap_coloc <- function(object, ...) {
  list(estimates = object$estimates, component_status = object$component_status,
    diagnostics = object$diagnostic_summary, prior = object$prior,
    probability_scope = object$probability_scope)
}

#' @export
plot.gmap_coloc <- function(x, region = NULL, ...) {
  region <- .gmap_select_one(region, x$selection$regions, "region")
  rows <- x$estimates[x$estimates$region == region, , drop = FALSE]
  if (!nrow(rows)) {
    graphics::plot.new(); graphics::title(main = region)
    graphics::text(.5, .5, "No eligible component pairs\nThis is not evidence for H0")
  } else {
    values <- t(as.matrix(rows[paste0("H", 0:4)]))
    graphics::barplot(values,
      names.arg = paste(rows$component1, rows$component2, sep = " / "),
      ylim = c(0, 1), col = grDevices::hcl.colors(5, "Set 2"),
      legend.text = rownames(values),
      args.legend = list(x = "topright", bty = "n", cex = .7),
      xlab = "Component pair", ylab = "Pair-specific posterior probability",
      main = region, ...)
  }
  invisible(x)
}
