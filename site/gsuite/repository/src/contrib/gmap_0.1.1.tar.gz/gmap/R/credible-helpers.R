#' LD grouping of fitted marginal inclusion probabilities
#' @param Glist Prepared BED reference used for LD.
#' @param fit Regional gmap, summary/individual gbayes, or an ordinary list with
#'   a stat table containing unique rsids and dm.
#' @param sets Named marker sets; regional fit names must identify fitted regions.
#' @param cs_threshold Target cumulative marginal PIP mass; defaults to .8 as in
#'   qgg getCredibleSets(). This is not a component coverage probability.
#' @param cs_r2 Strict minimum squared correlation, matching qgg's helper.
#' @param cutoff PIPs below this value are zeroed before grouping.
#' @param cs_method CS2 ranks by PIP; CS3 uses the initial LD-weighted PIP order.
#' @param trait Select one trait from a labelled multi-trait fit.
#' @param nthreads,maximum_dimension Local BED decoding threads and matrix limit.
#' @return Named region list of named marker-ID vectors. An empty region returns
#'   list(NULL), matching qgg. Attributes record marginal-PIP semantics, grouping
#'   settings and LD timing. No sampler or fitter is called.
#' @export
getCredibleSets <- function(Glist, fit, sets, cs_threshold=.8, cs_r2=.5,
    cutoff=.001, cs_method=c("CS2","CS3"), trait=NULL, nthreads=1L,
    maximum_dimension=2048L) {
  cs_method <- match.arg(cs_method)
  .gmap_probability(cs_threshold,"cs_threshold",TRUE)
  .gmap_probability(cs_r2,"cs_r2")
  .gmap_probability(cutoff,"cutoff")
  gbase::validate_Glist(Glist)
  .gmap_named(sets,"sets")
  table <- fit$stat
  if(is.null(table)) {
    table <- fit$estimates
    if(!is.data.frame(table)||!all(c("marker","pip") %in% names(table)))
      .gmap_stop("fit must contain labelled fitted PIPs.")
    table$rsids <- table$marker;table$dm <- table$pip
  }
  if(!is.data.frame(table)||!all(c("rsids","dm") %in% names(table))||
      !is.numeric(table$dm)||any(!is.finite(table$dm))||any(table$dm<0|table$dm>1)||
      anyNA(table$rsids)||any(!nzchar(table$rsids))) .gmap_stop("Invalid fitted marker IDs or PIPs.")
  if("trait" %in% names(table)) {
    traits <- unique(table$trait)
    if(is.null(trait)&&length(traits)>1L) .gmap_stop("Select one fitted trait.")
    if(is.null(trait)) trait <- traits[1L]
    if(!is.character(trait)||length(trait)!=1L||!trait %in% traits) .gmap_stop("Unknown fitted trait.")
    table <- table[table$trait==trait,,drop=FALSE]
  }
  regional <- inherits(fit,"gmap_fit") && "region" %in% names(table)
  if(!regional && anyDuplicated(table$rsids)) .gmap_stop("Fitted marker IDs must be unique.")
  timings <- list()
  result <- lapply(names(sets),function(region) {
    current <- if(regional) table[table$region==region,,drop=FALSE] else table
    if(!nrow(current)||anyDuplicated(current$rsids)) .gmap_stop("No unique fitted marker table for region ",region,".")
    members <- gbase::mapSets(setNames(list(sets[[region]]),region),
      rsids=current$rsids,index=FALSE)[[1L]]
    members <- members[members %in% unlist(Glist$rsids,use.names=FALSE)]
    if(!length(members)) .gmap_stop("No fitted/reference markers in region ",region,".")
    LD <- gbase::getLD(Glist,members,nthreads=nthreads,maximum_dimension=maximum_dimension)
    timings[[region]] <<- attr(LD,"timings_seconds")
    value <- cpp_gmap_qgg_sets(LD,members,current$dm[match(members,current$rsids)],
      cs_threshold,cs_r2,cutoff,cs_method)
    if(!length(value$sets)) return(list(NULL))
    groups <- lapply(value$sets,function(x) members[x$indices])
    names(groups) <- paste0("Set",seq_along(groups));groups
  })
  names(result) <- names(sets)
  attr(result,"meaning") <- "marginal-PIP/LD groups; mass is expected active-marker count, not component credible coverage"
  attr(result,"implementation") <- "standalone native gmap qgg-compatible CS2/CS3 grouping"
  attr(result,"settings") <- list(cs_threshold=cs_threshold,cs_r2=cs_r2,
    cutoff=cutoff,cs_method=cs_method,trait=trait)
  attr(result,"ld_timings_seconds") <- timings
  result
}
