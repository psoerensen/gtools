.gmap_familiar_tables <- function(fit) {
  post <- conv <- list()
  for(region in names(fit$details)) for(trait in names(fit$details[[region]])) {
    x <- fit$details[[region]][[trait]]
    p <- fit$estimates[fit$estimates$region==region & fit$estimates$trait==trait,]
    md <- fit$region_metadata[[region]]$markers
    weights <- x$parameter_mean$weights
    row <- data.frame(region=region,trait=trait,
      ve=x$parameter_mean$residual_variance,vg=x$genetic_variance_mean,
      vb=x$parameter_mean$effect_variance,
      pi=if(length(weights)) 1-weights[1L] else NA_real_,pip=sum(p$pip),
      minb=min(p$mean),maxb=max(p$mean),m=nrow(p),
      mb=diff(range(md$base_pair_position))/1e6,
      chr=as.character(md$chromosome[1L]),
      minmb=min(md$base_pair_position),maxmb=max(md$base_pair_position))
    for(k in seq_along(weights)) row[[paste0("pi",k-1L)]] <- weights[k]
    diagnostic <- fit$diagnostic_summary[
      fit$diagnostic_summary$region==region & fit$diagnostic_summary$trait==trait,]
    cr <- data.frame(region=region,trait=trait,nrun=length(x$chains),
      draws=sum(vapply(x$chains,`[[`,numeric(1),"retained_draws")),
      max_pip_range=diagnostic$max_pip_range,
      ntrials=diagnostic$attempts,cutoff=diagnostic$requested_retained_positive_mass)
    for(name in c("ve","vg","vb","pi","pip")) {
      label <- if(name=="pi") "pi0" else name
      at <- match(label,x$posterior_summary$parameter)
      cr[[paste0("rhat_",name)]] <- x$posterior_summary$rhat[at]
      cr[[paste0("ess_",name)]] <- x$posterior_summary$ess_bulk[at]
      cr[[paste0("mcse_",name)]] <- x$posterior_summary$mcse_mean[at]
      cr[[paste0("status_",name)]] <- if(is.na(at)) "not_available" else
        x$posterior_summary$diagnostic_status[at]
    }
    key <- if(length(fit$selection$traits)==1L) region else paste(region,trait,sep=":")
    rownames(row) <- rownames(cr) <- key
    post[[key]] <- row;conv[[key]] <- cr
  }
  result <- list(post=do.call(rbind,post),conv=do.call(rbind,conv))
  attr(result$post,"definitions") <- c(vg="Posterior mean b' C b / likelihood sample count; derived joint-effect quantity, not a separate variance hyperparameter draw",
    pi="Posterior mean total non-null mixture probability",
    pip="Sum of marginal marker PIPs; expected active count",
    minmb="Minimum base-pair position (qgg column name)",
    maxmb="Maximum base-pair position (qgg column name)")
  attr(result$conv,"diagnostics") <- "Native rank/split R-hat, bulk ESS and mean MCSE; statuses preserve single-chain, fixed and unavailable cases. These are not qgg Geweke z scores."
  result
}
