#' Interpret a saved individual-BED posterior in Glist regions
#' @param fit A standalone individual-BED `gbayes_fit` using BayesC or BayesR.
#' @param Glist The fitted Glist augmented with in-sample sparse LD.
#' @param regions A uniquely named list of regional marker IDs in LD order.
#' @param control Marginal-set controls plus `maximum_dimension` and
#'   `allow_incomplete_ld`.
#' @return A serializable `gmap_bed_fit`; no model is refit.
#' @export
gmap_bed <- function(fit, Glist, regions, control = list()) {
  if (!inherits(fit, "gbayes_fit") || !identical(fit$likelihood, "individual_bed") ||
      !fit$method %in% c("bayesc", "bayesr"))
    .gmap_stop("`fit` must be a standalone individual-BED BayesC/BayesR gbayes_fit.")
  reference <- .gmap_reference(Glist)
  saved <- reference$sparseLD
  signature <- fit$continuation$signature
  if (!identical(saved$sample_ids, fit$provenance$selected_ids) ||
      !identical(saved$sample_indices_0based,
        as.double(Glist$sample_source_indices_0based)))
    .gmap_stop("Sparse LD must use the same fitted BED samples and order.")
  active <- which(lengths(Glist$rsids) > 0L)
  paths <- normalizePath(Glist$bedfiles[active], winslash = "/", mustWork = TRUE)
  markers <- unlist(Glist$rsids[active], use.names = FALSE)
  if (!identical(unname(signature$bedfiles), unname(paths)) ||
      !identical(signature$marker, markers) ||
      !identical(signature$selected_ids, fit$provenance$selected_ids))
    .gmap_stop("Glist markers, samples, or BED files differ from the saved gbayes fit.")
  fitted <- data.frame(marker = markers,
    path = rep(paths, lengths(Glist$rsids[active])),
    index = unlist(Glist$source_marker_indices_0based[active], use.names = FALSE),
    af = unlist(Glist$af[active], use.names = FALSE), stringsAsFactors = FALSE)
  coding <- fit$weights
  if (is.null(coding) || !all(c("marker", "effect_allele", "other_allele") %in% names(coding)))
    .gmap_stop("The saved gbayes fit lacks portable marker coding.")
  metadata <- saved$marker_metadata
  at <- match(metadata$marker_id, fitted$marker)
  if (anyNA(at) || anyDuplicated(metadata$marker_id) ||
      !identical(metadata$marker_id, coding$marker[at]) ||
      !identical(metadata$allele1, coding$effect_allele[at]) ||
      !identical(metadata$allele2, coding$other_allele[at]) ||
      !isTRUE(all.equal(as.double(metadata$source_marker_index_0based),
        as.double(fitted$index[at]), tolerance = 0)) ||
      !isTRUE(all.equal(as.double(metadata$allele_frequency),
        as.double(fitted$af[at]), tolerance = 1e-12)))
    .gmap_stop("Sparse-LD markers, BED offsets, frequencies, or alleles differ from the saved fit.")
  settings <- .gmap_settings(control, list(sets = list(),
    maximum_dimension = 2048L, allow_incomplete_ld = FALSE), "control")
  settings$sets <- .gmap_set_control(settings$sets, fit$method)
  .gmap_integer(settings$maximum_dimension, "maximum_dimension")
  settings$allow_incomplete_ld <- .gmap_flag(settings$allow_incomplete_ld,
    "allow_incomplete_ld")
  .gmap_named(regions, "regions")
  indices <- lapply(regions, .gmap_region_indices, reference = metadata)
  traits <- if (inherits(fit, "gbayes_multivariate_fit")) fit$traits else fit$trait
  sets <- details <- region_info <- stats::setNames(vector("list", length(regions)), names(regions))
  rows <- diagnostics <- list()
  reference_id <- if (is.character(saved$reference) && length(saved$reference) == 1L &&
      nzchar(saved$reference)) saved$reference else "gbase-sparse-ld"
  reader <- cpp_gmap_open_ld(saved$prefix)
  on.exit(cpp_gmap_release_ld(reader), add = TRUE)
  for (name in names(regions)) {
    index <- indices[[name]]; position <- metadata$base_pair_position[index]
    chromosome <- unique(metadata$chromosome[index])
    if (length(chromosome) != 1L || anyNA(chromosome) || !nzchar(chromosome))
      .gmap_stop("Region ", name, " requires one chromosome.")
    complete <- identical(as.double(saved$r2_threshold), 0) &&
      (saved$max_distance_bp == 0 || diff(range(position)) <= saved$max_distance_bp) &&
      (saved$max_distance_variants == 0 || diff(range(index)) <= saved$max_distance_variants)
    if (!complete && !settings$allow_incomplete_ld)
      .gmap_stop("Region ", name, " has incomplete sparse LD.")
    region_info[[name]] <- list(id = name, chromosome = chromosome,
      assembly = Glist$assembly, start = min(position), end = max(position),
      markers = metadata[index, , drop = FALSE])
    details[[name]] <- sets[[name]] <- stats::setNames(vector("list", length(traits)), traits)
    for (trait in traits) {
      fit_index <- match(regions[[name]], fitted$marker)
      values <- if (inherits(fit, "gbayes_multivariate_fit"))
        list(mean = fit$estimates$mean[fit_index, trait],
          variance = fit$estimates$variance[fit_index, trait],
          pip = fit$estimates$pip[fit_index, trait]) else
        list(mean = fit$estimates$mean[fit_index],
          variance = fit$estimates$variance[fit_index], pip = fit$estimates$pip[fit_index])
      posterior_sets <- cpp_gmap_bed_sets(reader, as.double(index),
        regions[[name]], as.double(values$pip), settings$sets,
        as.integer(settings$maximum_dimension), !complete)
      details[[name]][[trait]] <- c(values, list(marker_ids = regions[[name]],
        trait = trait, sets = posterior_sets,
        effect_units = "standardized counted-allele dosage",
        provenance = "standalone gbayes individual-BED posterior; no regional refit",
        chain_agreement = NULL, chains = list(), truncated_likelihood = FALSE))
      sets[[name]][[trait]] <- posterior_sets
      pip_range <- if (inherits(fit, "gbayes_multivariate_fit"))
        fit$estimates$chain_pip_range[fit_index, trait] else
        fit$estimates$chain_pip_range[fit_index]
      rows[[length(rows) + 1L]] <- data.frame(reference = reference_id,
        region = name, trait = trait, marker = regions[[name]], position = position,
        mean = values$mean, variance = values$variance, pip = values$pip)
      diagnostics[[length(diagnostics) + 1L]] <- data.frame(region = name,
        trait = trait, status = "global BED posterior; no regional refit",
        incomplete_ld_reference = !complete, chains = length(fit$chains),
        max_pip_range = if (any(is.finite(pip_range)))
          max(pip_range[is.finite(pip_range)]) else NA_real_)
    }
  }
  structure(list(schema_version = 1L, source = "global_individual_bed",
    estimates = do.call(rbind, rows), sets = sets, details = details,
    diagnostic_summary = do.call(rbind, diagnostics), parameters = NULL,
    region_metadata = region_info,
    reference = list(reference = reference_id, assembly = Glist$assembly,
      checksums = saved$checksums, prefix = saved$prefix),
    selection = list(regions = regions, traits = traits), prior = fit$prior,
    control = settings, input_provenance = list(fit_method = fit$method,
      selected_ids = fit$provenance$selected_ids,
      interpretation = "marginal PIP groups; not component credible sets"),
    method = fit$method, call = match.call()),
    class = c("gmap_bed_fit", "gmap_fit", "list"))
}
