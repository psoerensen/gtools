.gmap_result_fit <- function(x) {
  if (!inherits(x, "gmap_fit") || !is.data.frame(x$estimates) ||
      !is.list(x$sets))
    .gmap_stop("`x` must be a gmap_fit returned by gmap() or gmap_bed().")
  required <- c("region", "trait", "marker", "pip")
  if (length(setdiff(required, names(x$estimates))))
    .gmap_stop("The gmap_fit does not contain labelled marker PIPs.")
  invisible(x)
}

.gmap_empty_set_summary <- function() {
  data.frame(region = character(), trait = character(), set = integer(),
    meaning = character(), source_index = integer(), lead_marker = character(),
    lead_probability = numeric(), mass = numeric(), requested_coverage = numeric(),
    complete = logical(), marker_count = integer(), min_r2_to_lead = numeric(),
    mean_r2_to_lead = numeric(), min_pairwise_r2 = numeric(),
    mean_pairwise_r2 = numeric(), passes_ld_threshold = logical(),
    duplicate_of = integer(), remaining_mass_before = numeric(),
    remaining_mass_after = numeric(), incomplete_ld_reference = logical(),
    truncated_likelihood = logical(), converged = logical(), status = character(),
    stringsAsFactors = FALSE)
}

.gmap_empty_set_members <- function() {
  data.frame(region = character(), trait = character(), set = integer(),
    meaning = character(), marker = character(), rank = integer(),
    probability = numeric(), r2_to_lead = numeric(), is_lead = logical(),
    stringsAsFactors = FALSE)
}

#' Tidy posterior sets from a regional mapping result
#'
#' Converts the nested native posterior-set result into two ordinary data
#' frames. Marginal-PIP set mass is an expected active-marker count, whereas
#' component-assignment set mass is posterior assignment probability. The
#' `meaning` column keeps these interpretations explicit.
#'
#' @param x A `gmap_fit` returned by [gmap()] or [gmap_bed()].
#' @return A list containing set-level `summary` and marker-level `members`
#'   data frames. Empty fitted components remain available in the original
#'   result's native set metadata but do not create set rows.
#' @export
gmap_sets <- function(x) {
  .gmap_result_fit(x)
  summaries <- members <- list()
  requested <- x$control$sets$coverage
  if (is.null(requested) || length(requested) != 1L) requested <- NA_real_

  for (region in names(x$sets)) {
    for (trait in names(x$sets[[region]])) {
      value <- x$sets[[region]][[trait]]
      marker_rows <- x$estimates$region == region & x$estimates$trait == trait
      marker_ids <- as.character(x$estimates$marker[marker_rows])
      diagnostic <- x$diagnostic_summary[
        x$diagnostic_summary$region == region &
          x$diagnostic_summary$trait == trait, , drop = FALSE]
      converged <- if (nrow(diagnostic) && "converged" %in% names(diagnostic))
        as.logical(diagnostic$converged[[1L]]) else NA
      status <- if (nrow(diagnostic) && "status" %in% names(diagnostic))
        as.character(diagnostic$status[[1L]]) else NA_character_
      native_sets <- value$sets
      if (!length(native_sets)) next

      for (set_index in seq_along(native_sets)) {
        item <- native_sets[[set_index]]
        indices <- as.integer(item$indices)
        lead_index <- as.integer(item$lead_index)
        if (anyNA(indices) || any(indices < 1L | indices > length(marker_ids)) ||
            length(lead_index) != 1L || is.na(lead_index) ||
            lead_index < 1L || lead_index > length(marker_ids))
          .gmap_stop("Stored posterior-set indices do not match the fitted markers.")
        if (length(item$probabilities) != length(indices) ||
            length(item$r2_to_lead) != length(indices))
          .gmap_stop("Stored posterior-set member fields have inconsistent lengths.")

        duplicate_of <- as.integer(item$duplicate_of)
        if (!length(duplicate_of)) duplicate_of <- NA_integer_
        summaries[[length(summaries) + 1L]] <- data.frame(
          region = region, trait = trait, set = set_index,
          meaning = as.character(value$meaning),
          source_index = as.integer(item$source_index),
          lead_marker = marker_ids[[lead_index]],
          lead_probability = as.double(item$lead_probability),
          mass = as.double(item$mass), requested_coverage = requested,
          complete = as.logical(item$complete), marker_count = length(indices),
          min_r2_to_lead = as.double(item$min_r2_to_lead),
          mean_r2_to_lead = as.double(item$mean_r2_to_lead),
          min_pairwise_r2 = as.double(item$min_pairwise_r2),
          mean_pairwise_r2 = as.double(item$mean_pairwise_r2),
          passes_ld_threshold = as.logical(item$passes_ld_threshold),
          duplicate_of = duplicate_of,
          remaining_mass_before = as.double(item$remaining_mass_before),
          remaining_mass_after = as.double(item$remaining_mass_after),
          incomplete_ld_reference = as.logical(value$incomplete_ld_reference),
          truncated_likelihood = as.logical(value$truncated_likelihood),
          converged = converged, status = status, stringsAsFactors = FALSE)
        members[[length(members) + 1L]] <- data.frame(
          region = region, trait = trait, set = set_index,
          meaning = as.character(value$meaning), marker = marker_ids[indices],
          rank = seq_along(indices), probability = as.double(item$probabilities),
          r2_to_lead = as.double(item$r2_to_lead),
          is_lead = indices == lead_index, stringsAsFactors = FALSE)
      }
    }
  }

  list(
    summary = if (length(summaries)) do.call(rbind, summaries) else
      .gmap_empty_set_summary(),
    members = if (length(members)) do.call(rbind, members) else
      .gmap_empty_set_members())
}

.gmap_bfdr_row <- function(region, trait, threshold, pip, target) {
  selected <- if (is.na(threshold)) rep(FALSE, length(pip)) else pip >= threshold
  count <- sum(selected)
  expected <- sum(1 - pip[selected])
  data.frame(region = region, trait = trait, threshold = threshold,
    selected_markers = count, expected_false_discoveries = expected,
    bfdr = if (count) expected / count else NA_real_, target = target,
    stringsAsFactors = FALSE)
}

#' Summarize Bayesian false discovery rates from marker PIPs
#'
#' For a PIP threshold `t`, the selected markers have `PIP >= t`. Their
#' expected number of false discoveries is `sum(1 - PIP)`, and Bayesian FDR is
#' that expectation divided by the number selected. Alternatively, `target`
#' returns the largest threshold-defined marker set whose Bayesian FDR does not
#' exceed the requested bound. Calculations are separate by region and trait.
#'
#' @param x A `gmap_fit` returned by [gmap()] or [gmap_bed()].
#' @param threshold One or more PIP thresholds in `[0, 1]`.
#' @param target Optional scalar Bayesian-FDR bound in `[0, 1]`. When supplied,
#'   omit `threshold`.
#' @return A data frame with the threshold, selected-marker count, expected
#'   false discoveries and Bayesian FDR for every region and trait.
#' @export
gmap_bfdr <- function(x, threshold = 0.8, target = NULL) {
  .gmap_result_fit(x)
  threshold_supplied <- !missing(threshold)
  if (!is.null(target)) {
    if (threshold_supplied)
      .gmap_stop("Supply either `threshold` or `target`, not both.")
    .gmap_probability(target, "target")
  } else {
    if (!is.numeric(threshold) || !length(threshold) || anyNA(threshold) ||
        any(!is.finite(threshold)) || any(threshold < 0 | threshold > 1))
      .gmap_stop("`threshold` must contain finite probabilities in [0, 1].")
  }
  pip <- as.double(x$estimates$pip)
  if (anyNA(pip) || any(!is.finite(pip)) || any(pip < 0 | pip > 1))
    .gmap_stop("The fitted marker PIPs must be finite probabilities in [0, 1].")

  groups <- unique(x$estimates[c("region", "trait")])
  rows <- list()
  for (group_index in seq_len(nrow(groups))) {
    region <- as.character(groups$region[[group_index]])
    trait <- as.character(groups$trait[[group_index]])
    selected_group <- x$estimates$region == region & x$estimates$trait == trait
    group_pip <- pip[selected_group]
    if (is.null(target)) {
      for (cutoff in threshold)
        rows[[length(rows) + 1L]] <- .gmap_bfdr_row(
          region, trait, cutoff, group_pip, NA_real_)
    } else {
      cutoffs <- sort(unique(group_pip), decreasing = TRUE)
      candidate <- lapply(cutoffs, function(cutoff)
        .gmap_bfdr_row(region, trait, cutoff, group_pip, target))
      candidate <- do.call(rbind, candidate)
      eligible <- which(candidate$bfdr <= target)
      rows[[length(rows) + 1L]] <- if (length(eligible))
        candidate[eligible[[length(eligible)]], , drop = FALSE] else
        .gmap_bfdr_row(region, trait, NA_real_, group_pip, target)
    }
  }
  output <- do.call(rbind, rows)
  rownames(output) <- NULL
  output
}
