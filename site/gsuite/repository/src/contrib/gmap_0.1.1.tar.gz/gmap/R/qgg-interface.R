.gmap_alias <- function(settings, name, value, argument, explicit = TRUE) {
  if (is.null(value)) return(settings)
  if (!is.null(settings[[name]])) {
    if (explicit) .gmap_stop("Specify either `", argument,
      "` or its nested setting `", name, "`, not both.")
    return(settings)
  }
  settings[[name]] <- value
  settings
}

#' Regional mapping with ordinary summaries and familiar MCMC controls
#' @param stat Ordinary labelled summaries, or prepared score/information data.
#' @param Glist Prepared BED reference; the eigen route requires sparse LD.
#' @param regions Named regional marker vectors for the advanced route.
#' @param method Mapping model, including bayesC/bayesR aliases.
#' @param prior,control Existing nested prior/control settings.
#' @param normalization Explicit response normalization for advanced learning.
#' @param sets Alias for regions. Requests the qgg-style summary-statistic route.
#' @param algorithm `mcmc` uses full BED LD and the dense gbayes sampler;
#'   `mcmc-eigen` uses the existing sparse-LD eigen route.
#' @param nit,nburn,nthin,nrun,seed Post-burn sweeps, burn-in, thinning, chains and
#'   starting uint32 seed. Chains use seed, seed+1, ... .
#' @param h2,mc,pi,gamma,vb,ve,vy,nub,nue Familiar starting-prior settings.
#' @param updateB,updateE,updatePi Slab, residual and mixture-weight learning flags.
#' @param cs_threshold,cs_r2 Marginal-PIP grouping controls.
#' @param output `summary` or `full`; both retain diagnostics and native details.
#' @param verbose Print the final diagnostic summary.
#' @param nthreads Local BED decoding threads; BLAS threading is unchanged.
#' @param eigen_threshold Familiar scalar alias for the retained positive LD
#'   eigenvalue mass in control$eigen. Compare several thresholds with separate fits.
#' @return A gmap_fit with native estimates/details and a labelled `stat` table
#'   containing `bm` (effect mean) and `dm` (PIP). This interface does not recreate
#'   qgg's independent genetic-variance draw or certify single-chain convergence.
#' @export
gmap <- function(stat, Glist, regions = NULL, method = c("multi_effect", "bayesc", "bayesr"),
    prior = list(), control = list(), normalization = NULL, sets = NULL,
    algorithm = NULL, nit = NULL, nburn = NULL, nthin = NULL, nrun = NULL,
    seed = NULL, h2 = NULL, mc = NULL, pi = NULL, gamma = NULL, vb = NULL,
    ve = NULL, vy = NULL, nub = NULL, nue = NULL, updateB = NULL,
    updateE = NULL, updatePi = NULL, cs_threshold = NULL, cs_r2 = NULL,
    output = "summary", verbose = FALSE, nthreads = 1L,
    eigen_threshold = NULL) {
  call <- match.call()
  if (!is.null(eigen_threshold)) {
    .gmap_probability(eigen_threshold, "eigen_threshold")
    if (eigen_threshold == 0) .gmap_stop("eigen_threshold must be positive.")
    if (is.null(control$eigen)) control$eigen <- list()
    if (!is.null(control$eigen$retained_positive_mass))
      .gmap_stop("Specify either `eigen_threshold` or `control$eigen$retained_positive_mass`, not both.")
    control$eigen$retained_positive_mass <- eigen_threshold
    if (!is.null(algorithm) && algorithm != "mcmc-eigen")
      .gmap_stop("eigen_threshold requires algorithm = 'mcmc-eigen'.")
    algorithm <- "mcmc-eigen"
  }
  alias <- function(settings,name,value,argument) .gmap_alias(settings,name,value,argument,
    any(strsplit(argument,"/",fixed=TRUE)[[1L]] %in% names(call)))
  familiar <- !is.null(sets) || !is.null(algorithm) && !all(c("score","information") %in% names(stat)) || length(method)==1L &&
    method %in% c("bayesC", "bayesR") || any(!vapply(list(nit,nburn,nthin,nrun,
      seed,h2,mc,pi,gamma,vb,ve,vy,nub,nue,updateB,updateE,updatePi,cs_threshold,cs_r2),is.null,logical(1)))
  if (!is.null(sets) && !is.null(regions)) .gmap_stop("Specify either `sets` or `regions`.")
  if (!is.null(sets)) regions <- sets
  if (familiar) {
    if (length(method)>1L) method <- "bayesr"
    method <- match.arg(tolower(method),c("bayesc","bayesr"))
    if (is.null(algorithm)) algorithm <- "mcmc"
    algorithm <- match.arg(algorithm,c("mcmc","mcmc-eigen"))
    if (!is.data.frame(stat)) .gmap_stop("The qgg-style route requires one summary-statistic data frame.")
    needed <- c("rsids","ea","nea","b","seb","n")
    if (length(setdiff(needed,names(stat))) || anyDuplicated(stat$rsids) ||
        !all(vapply(stat[c("b","seb","n")],is.numeric,logical(1))) ||
        any(!is.finite(as.matrix(stat[c("b","seb","n")]))) || any(stat$seb<=0) || any(stat$n<=2))
      .gmap_stop("Supply unique labelled summaries with finite b, positive seb and n > 2.")
    reference <- .gmap_reference(Glist,bed=algorithm=="mcmc")$metadata
    at <- match(reference$marker_id,stat$rsids)
    if (anyNA(at)) .gmap_stop("Statistics must cover the prepared reference; prepare/check the same markers first.")
    stat <- stat[at,,drop=FALSE]
    mapped <- gbase::mapSets(regions,rsids=stat$rsids,index=FALSE)
    if (!length(mapped) || any(lengths(mapped)==0L)) .gmap_stop("Every region must retain at least one supplied marker.")
    regions <- lapply(mapped,function(x) stat$rsids[stat$rsids %in% x])
    yy <- median((stat$b^2+(stat$n-2)*stat$seb^2)*stat$n)
    n <- median(stat$n)
    if (is.null(vy)) vy <- yy/(n-1)
    if (is.null(h2)) h2 <- .5
    .gmap_probability(h2,"h2",TRUE)
    if (is.null(mc)) mc <- 5000
    .gmap_integer(mc,"mc")
    if (is.null(pi)) pi <- if(method=="bayesc") c(.99,.01) else c(.99,.006,.003,.001)
    if (method == "bayesc" && length(pi) == 1L) {
      .gmap_probability(pi, "pi", TRUE)
      pi <- c(1 - pi, pi)
    }
    if (is.null(gamma)) gamma <- if(method=="bayesc") c(0,1) else c(0,.01,.1,1)
    if (!is.numeric(pi)||!is.numeric(gamma)||length(pi)!=length(gamma)||
        any(!is.finite(c(pi,gamma)))||any(pi<0)||abs(sum(pi)-1)>1e-10||
        gamma[1]!=0||any(diff(gamma)<=0)||sum(pi*gamma)<=0||
        method=="bayesc" && !identical(as.double(gamma),c(0,1)))
      .gmap_stop("pi/gamma must define normalized mixture weights and increasing multipliers starting at zero.")
    if (is.null(ve)) ve <- vy*(1-h2)
    if (is.null(vb)) vb <- vy*h2/(mc*sum(pi*gamma))
    prior <- alias(prior,"residual_variance",ve,"ve/h2")
    prior <- alias(prior,"effect_variance",vb,"vb/h2/mc/pi/gamma")
    if(method=="bayesc") prior <- alias(prior,"inclusion_probability",pi[2],"pi")
    else {
      prior <- alias(prior,"weights",pi,"pi")
      prior <- alias(prior,"variance_multipliers",gamma,"gamma")
    }
    vb <- prior$effect_variance;ve <- prior$residual_variance
    if(is.null(nub)) nub <- 4
    if(is.null(nue)) nue <- 4
    if(!is.numeric(nub)||length(nub)!=1||!is.finite(nub)||nub<=2||
        !is.numeric(nue)||length(nue)!=1||!is.finite(nue)||nue<=2) .gmap_stop("nub/nue must exceed 2.")
    flags <- list(estimate_effect_variance=if(is.null(updateB)) TRUE else updateB,
      estimate_residual_variance=if(is.null(updateE)) TRUE else updateE,
      estimate_weights=if(is.null(updatePi)) TRUE else updatePi)
    arguments <- c(estimate_effect_variance="updateB",estimate_residual_variance="updateE",estimate_weights="updatePi")
    for(name in names(flags)) control <- alias(control,name,flags[[name]],arguments[[name]])
    for(name in names(flags)) control[[name]] <- .gmap_flag(control[[name]],arguments[[name]])
    if(control$estimate_effect_variance) prior <- alias(prior,"effect_variance_prior",list(df=nub,scale=(nub-2)/nub*vb),"nub")
    if(control$estimate_residual_variance) prior <- alias(prior,"residual_variance_prior",list(df=nue,scale=(nue-2)/nue*ve),"nue")
    if(control$estimate_weights) prior <- alias(prior,"weight_prior",rep(1,length(pi)),"updatePi")
    control <- alias(control,"sampling_sweeps",if(is.null(nit)) 1000L else nit,"nit")
    control <- alias(control,"burnin",if(is.null(nburn)) 100L else nburn,"nburn")
    control <- alias(control,"thinning",if(is.null(nthin)) 1L else nthin,"nthin")
    if(is.null(nrun)) nrun <- 1L
    .gmap_integer(nrun,"nrun")
    if(is.null(seed)) seed <- 10L
    control <- alias(control,"seeds",seed+seq_len(nrun)-1,"seed/nrun")
    if(is.null(control$sets)) control$sets <- list()
    control$sets <- alias(control$sets,"coverage",if(is.null(cs_threshold)) .9 else cs_threshold,"cs_threshold")
    control$sets <- alias(control$sets,"min_r2",if(is.null(cs_r2)) .5 else cs_r2,"cs_r2")
    if(is.null(control$eigen)) control$eigen <- list()
    if(is.null(control$qgg_sets)) control$qgg_sets <- TRUE
    if(is.null(control$retain_diagnostics)) control$retain_diagnostics <- TRUE
    if(is.null(control$fitted_variance)) control$fitted_variance <- TRUE
    if(control$estimate_residual_variance) {
      if(is.null(control$eigen$retained_positive_mass)) control$eigen$retained_positive_mass <- 1
      if(is.null(normalization)) normalization <- list(trait=list(response_ss=yy,
        likelihood_dimension=n,in_sample_ld=TRUE))
    }
    if(is.null(stat$ww)) stat$ww <- (yy/n)/(stat$seb^2+stat$b^2/stat$n)
    if(is.null(stat$wy)) stat$wy <- stat$b*stat$ww
    stat$score <- stat$wy;stat$information <- stat$ww
  }
  if(is.null(algorithm)) algorithm <- "mcmc-eigen"
  algorithm <- match.arg(algorithm,c("mcmc","mcmc-eigen"))
  mode <- if(algorithm=="mcmc") "mcmc" else "eigen"
  output <- match.arg(output,c("summary","full"))
  verbose <- .gmap_flag(verbose,"verbose")
  fit <- .gmap_fit(stat,Glist,regions,method,prior,control,normalization,mode,nthreads)
  fit$call <- call;fit$output <- output
  fit$interface <- if(familiar) "qgg-style" else "native"
  add_stat <- function(x) {
    at <- match(x$marker,stat$rsids)
    result <- stat[at,,drop=FALSE]
    md <- do.call(rbind,lapply(fit$region_metadata,`[[`,"markers"))
    md <- md[match(x$marker,md$marker_id),,drop=FALSE]
    swapped <- result$ea != md$allele1
    for(name in intersect(c("b","wy","score"),names(result)))
      if(is.numeric(result[[name]])) result[[name]][swapped] <- -result[[name]][swapped]
    result$ea <- md$allele1;result$nea <- md$allele2
    result$chr <- md$chromosome;result$pos <- md$base_pair_position
    result$eaf <- md$allele_frequency
    result$region <- x$region;result$trait <- x$trait
    result$bm <- x$mean;result$dm <- x$pip
    result$vm <- 2*result$eaf*(1-result$eaf)*result$bm^2
    result
  }
  if(is.data.frame(stat)) fit$stat <- add_stat(fit$estimates)
  if(familiar) fit$csets <- lapply(names(fit$sets), function(region) {
    values <- fit$sets[[region]][[1L]]$sets
    if (!length(values)) return(list(NULL))
    result <- lapply(values,function(x) regions[[region]][x$indices])
    names(result) <- paste0("Set",seq_along(result));result
  })
  if(familiar) names(fit$csets) <- names(fit$sets)
  if(familiar) {
    tables <- .gmap_familiar_tables(fit)
    fit$post <- tables$post
    fit$conv <- tables$conv
    fit$cs <- fit$csets
  }
  if(verbose) print(fit)
  fit
}
