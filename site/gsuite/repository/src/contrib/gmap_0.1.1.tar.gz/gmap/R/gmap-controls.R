.gmap_settings <- function(value, defaults, name) {
  if (!is.list(value) || (length(value) && (is.null(names(value)) ||
      anyNA(names(value)) || anyDuplicated(names(value)) ||
      any(!names(value) %in% names(defaults)))))
    .gmap_stop("Unknown or unnamed ", name, " setting.")
  defaults[names(value)] <- value
  defaults
}

.gmap_integer <- function(value, name, minimum = 1L) {
  if (!is.numeric(value) || length(value) != 1L || !is.finite(value) ||
      value != floor(value) || value < minimum || value > .Machine$integer.max)
    .gmap_stop("Invalid integer control: ", name, ".")
  invisible(value)
}

.gmap_probability <- function(value, name, open = FALSE) {
  if (!is.numeric(value) || length(value) != 1L || !is.finite(value) ||
      value < 0 || value > 1 || (open && value %in% c(0, 1)))
    .gmap_stop("Invalid probability: ", name, ".")
  invisible(value)
}

.gmap_flag <- function(value, name) {
  if (!is.logical(value) || length(value) != 1L || is.na(value))
    .gmap_stop("`", name, "` must be TRUE or FALSE.")
  value
}

.gmap_ld_swap <- function(value) {
  output <- .gmap_settings(if (is.null(value)) list() else value,
    list(probability = 0, minimum_r2 = .8, maximum_friends = 50L,
      moves = 1L), "ld_swap")
  for (name in c("probability", "minimum_r2"))
    .gmap_probability(output[[name]], paste0("ld_swap$", name))
  .gmap_integer(output$maximum_friends, "ld_swap$maximum_friends")
  .gmap_integer(output$moves, "ld_swap$moves", 0L)
  output
}

.gmap_set_control <- function(value, method) {
  if (method == "multi_effect") {
    output <- .gmap_settings(value,
      list(coverage = .95, min_pairwise_r2 = .5), "sets")
    .gmap_probability(output$min_pairwise_r2, "min_pairwise_r2")
  } else {
    output <- .gmap_settings(value, list(coverage = .95, min_r2 = .5,
      pip_cutoff = .001, lead = "pip", remove = "ld_neighborhood",
      mode = "neighborhood", max_sets = .Machine$integer.max,
      allow_incomplete = FALSE, signal_coverage = .95,
      min_signal_pip = .05), "sets")
    for (name in c("min_r2", "pip_cutoff", "min_signal_pip"))
      .gmap_probability(output[[name]], name)
    if (!is.numeric(output$signal_coverage) ||
        length(output$signal_coverage) != 1L ||
        !is.finite(output$signal_coverage) || output$signal_coverage < 0)
      .gmap_stop("signal_coverage must be finite and nonnegative.")
    .gmap_integer(output$max_sets, "max_sets", 0L)
    output$allow_incomplete <- .gmap_flag(output$allow_incomplete,
      "allow_incomplete")
    choices <- list(lead = c("pip", "ld_pip"),
      remove = c("ld_neighborhood", "selected_set"),
      mode = c("neighborhood", "approximate_multi_signal"))
    for (name in names(choices))
      if (!is.character(output[[name]]) || length(output[[name]]) != 1L ||
          is.na(output[[name]]) || !output[[name]] %in% choices[[name]])
        .gmap_stop("Invalid set control: ", name, ".")
  }
  .gmap_probability(output$coverage, "coverage", TRUE)
  output
}

.gmap_learning <- function(prior, control, method) {
  positive <- function(x) is.numeric(x) && length(x) == 1L &&
    is.finite(x) && x > 0
  if (method == "multi_effect") {
    if (!positive(control$residual_relative_tolerance) ||
        control$residual_relative_tolerance >= 1)
      .gmap_stop("residual_relative_tolerance must be between zero and one.")
    return(invisible(NULL))
  }
  for (pair in list(c("effect_variance_prior", "estimate_effect_variance"),
                    c("residual_variance_prior", "estimate_residual_variance"))) {
    value <- prior[[pair[[1L]]]]
    if (control[[pair[[2L]]]]) {
      if (!is.list(value) || length(value) != 2L ||
          !setequal(names(value), c("df", "scale")) ||
          !positive(value$df) || !positive(value$scale))
        .gmap_stop("Learning requires `", pair[[1L]],
          " = list(df=..., scale=...)` with positive values.")
    } else if (!is.null(value))
      .gmap_stop("`", pair[[1L]], "` requires its learning flag.")
  }
  if (control$estimate_weights) {
    count <- if (method == "bayesc") 2L else length(prior$weights)
    if (!is.numeric(prior$weight_prior) ||
        length(prior$weight_prior) != count ||
        any(!is.finite(prior$weight_prior)) || any(prior$weight_prior <= 0))
      .gmap_stop("weight_prior must contain one positive concentration per component.")
  } else if (!is.null(prior$weight_prior))
    .gmap_stop("weight_prior requires estimate_weights=TRUE.")
  invisible(NULL)
}

.gmap_normalization <- function(value, traits, learn, reference_n) {
  if (!learn) {
    if (!is.null(value))
      .gmap_stop("normalization requires estimate_residual_variance=TRUE.")
    return(stats::setNames(rep(list(NULL), length(traits)), traits))
  }
  .gmap_named(value, "normalization")
  if (!setequal(names(value), traits))
    .gmap_stop("normalization must have exactly one named entry per trait.")
  for (trait in traits) {
    item <- value[[trait]]
    if (!is.list(item) || !setequal(names(item),
        c("response_ss", "likelihood_dimension", "in_sample_ld")))
      .gmap_stop("Each normalization requires response_ss, likelihood_dimension and in_sample_ld.")
    if (!identical(item$in_sample_ld, TRUE))
      .gmap_stop("Residual learning requires explicit in_sample_ld=TRUE.")
    if (!is.numeric(item$response_ss) || length(item$response_ss) != 1L ||
        !is.finite(item$response_ss) || item$response_ss <= 0)
      .gmap_stop("response_ss must be positive and finite.")
    .gmap_integer(item$likelihood_dimension, "likelihood_dimension")
    if (item$likelihood_dimension > reference_n)
      .gmap_stop("likelihood_dimension cannot exceed the LD reference sample count.")
  }
  value[traits]
}
