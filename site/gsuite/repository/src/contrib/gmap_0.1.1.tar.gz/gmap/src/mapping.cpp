#include <Rcpp.h>
#include <gmap/prepared_region.hpp>
#include <gbayes/diagnostics.hpp>
#include <gbayes/posterior_summary.hpp>
#include <gmat/sparse_ld_disk.hpp>
#include <chrono>
#include <unordered_map>

namespace {
using namespace Rcpp;

List parameters(const gbayes::GaussianParameters& p) {
  return List::create(_["residual_variance"] = p.residual_variance,
    _["effect_variance"] = p.slab_variance, _["weights"] = p.weights);
}

template<class Sampler> auto capture_prepared(const gmap::BoundMappingRegion& d,
    const gbayes::ScalarPosteriorControls& capture,
    const gmap::MarginalSetControls& controls, Sampler sample) {
  const auto start=std::chrono::steady_clock::now();
  auto posterior=sample(capture);
  const auto sampled=std::chrono::steady_clock::now();
  auto sets=gmap::make_marginal_sets(posterior,*d.ld,controls);
  const auto finished=std::chrono::steady_clock::now();
  return gmap::PreparedMappingFit<decltype(posterior)>{d,std::move(posterior),
    std::move(sets),std::chrono::duration<double>(sampled-start).count(),
    std::chrono::duration<double>(finished-sampled).count()};
}

template<class Fit> void posterior_table(List& out,const Fit& fit) {
  using Q=gbayes::PosteriorQuantity;
  std::vector<gbayes::PosteriorSelection> selections{
    {"ve",Q::residual_variance,0},{"vb",Q::slab_variance,0},
    {"pip",Q::active_markers,0}};
  for(size_t k=0;k<fit.parameter_mean.weights.size();++k)
    selections.push_back({"pi"+std::to_string(k),Q::mixture_weight,k});
  if(fit.genetic_covariance.draws)
    selections.push_back({"vg",Q::genetic_covariance,0});
  const auto rows=gbayes::summarize_posterior(fit,selections);
  CharacterVector name,status(rows.size());
  NumericVector mean,rhat,ess,mcse;
  for(size_t i=0;i<rows.size();++i) {
    const auto& x=rows[i];name.push_back(x.selection.label);
    status[i]=x.summary.diagnostics.status;mean.push_back(x.summary.mean);
    rhat.push_back(x.summary.diagnostics.rhat);
    ess.push_back(x.summary.diagnostics.ess_bulk);
    mcse.push_back(x.summary.diagnostics.mcse_mean);
  }
  out["posterior_summary"]=DataFrame::create(_["parameter"]=name,
    _["mean"]=mean,_["rhat"]=rhat,_["ess_bulk"]=ess,
    _["mcse_mean"]=mcse,_["diagnostic_status"]=status);
  out["genetic_variance_mean"]=fit.genetic_covariance.draws ?
    fit.genetic_covariance.covariance_mean[0] : NA_REAL;
  out["genetic_variance_denominator"]=fit.posterior_controls.genetic_reference ?
    fit.posterior_controls.genetic_reference->divisor : NA_REAL;
}

List chain(const gbayes::BayesCChain& c) {
  List trace(c.trace.parameters.size());
  for (size_t i = 0; i < c.trace.parameters.size(); ++i)
    trace[i] = parameters(c.trace.parameters[i]);
  return List::create(_["seed"] = double(c.seed),
    _["retained_draws"] = double(c.retained_draws), _["mean"] = c.mean,
    _["second_moment"] = c.second_moment, _["pip"] = c.pip,
    _["final_effect"] = c.final_effect,
    _["final_score_residual"] = c.final_score_residual,
    _["final_inclusion"] = c.final_inclusion,
    _["maximum_residual_drift"] = c.maximum_residual_drift,
    _["maximum_working_residual_drift"] = c.maximum_working_residual_drift,
    _["working_residual_dimension"] = double(c.working_residual_dimension),
    _["ld_swap_attempted"] = double(c.ld_swap_attempted),
    _["ld_swap_accepted"] = double(c.ld_swap_accepted),
    _["parameter_mean"] = parameters(c.parameter_mean),
    _["final_parameters"] = parameters(c.final_parameters),
    _["parameter_trace"] = trace,
    _["active_markers_trace"] = c.trace.active_markers);
}

const gbayes::BayesCChain& swap_posterior(const gbayes::BayesCChain& x) {return x;}
const gbayes::BayesCChain& swap_posterior(const gbayes::BayesRChain& x) {return x.posterior;}

template<class Fit> List swap_summary(const Fit& fit) {
  double attempted = 0, accepted = 0;
  for (const auto& chain : fit.chains) {
    const auto& x = swap_posterior(chain);
    attempted += double(x.ld_swap_attempted);
    accepted += double(x.ld_swap_accepted);
  }
  return List::create(_["attempted"] = attempted, _["accepted"] = accepted,
    _["acceptance_rate"] = attempted ? accepted / attempted : NA_REAL);
}

List sets(const gmap::PosteriorSets& value) {
  List rows(value.sets.size());
  for (size_t i = 0; i < value.sets.size(); ++i) {
    const auto& x = value.sets[i];
    IntegerVector indices(x.indices.size());
    for (size_t j = 0; j < x.indices.size(); ++j) indices[j] = x.indices[j] + 1;
    rows[i] = List::create(_["source_index"] = double(x.source_index + 1),
      _["lead_index"] = double(x.lead_index + 1), _["indices"] = indices,
      _["probabilities"] = x.probabilities, _["r2_to_lead"] = x.r2_to_lead,
      _["mass"] = x.mass, _["complete"] = x.complete,
      _["lead_probability"] = x.lead_probability,
      _["min_r2_to_lead"] = x.min_r2_to_lead,
      _["mean_r2_to_lead"] = x.mean_r2_to_lead,
      _["remaining_mass_before"] = x.remaining_mass_before,
      _["remaining_mass_after"] = x.remaining_mass_after,
      _["min_pairwise_r2"] = x.min_pairwise_r2,
      _["mean_pairwise_r2"] = x.mean_pairwise_r2,
      _["passes_ld_threshold"] = x.passes_ld_threshold,
      _["duplicate_of"] = x.duplicate_of ? double(*x.duplicate_of + 1) : NA_REAL);
  }
  IntegerVector inactive(value.inactive_components.size());
  for (size_t i = 0; i < value.inactive_components.size(); ++i)
    inactive[i] = value.inactive_components[i] + 1;
  return List::create(_["meaning"] =
      value.meaning == gmap::SetMeaning::component_assignment ?
        "component_assignment" : "marginal_pip_mass",
    _["sets"] = rows, _["inactive_components"] = inactive,
    _["component_variances"] = value.component_variances,
    _["incomplete_ld_reference"] = value.incomplete_ld_reference,
    _["truncated_likelihood"] = value.truncated_likelihood);
}

gmap::ComponentSetControls component_controls(const List& x) {
  gmap::ComponentSetControls c;
  c.coverage = as<double>(x["coverage"]);
  c.min_pairwise_r2 = as<double>(x["min_pairwise_r2"]);
  return c;
}

gmap::MarginalSetControls marginal_controls(const List& x) {
  gmap::MarginalSetControls c;
  c.coverage = as<double>(x["coverage"]);
  c.min_r2 = as<double>(x["min_r2"]);
  c.pip_cutoff = as<double>(x["pip_cutoff"]);
  c.max_sets = as<int>(x["max_sets"]);
  c.allow_incomplete = as<bool>(x["allow_incomplete"]);
  c.signal_coverage = as<double>(x["signal_coverage"]);
  c.min_signal_pip = as<double>(x["min_signal_pip"]);
  c.lead = as<std::string>(x["lead"]) == "pip" ?
    gmap::LeadSelection::pip : gmap::LeadSelection::ld_pip;
  c.remove = as<std::string>(x["remove"]) == "ld_neighborhood" ?
    gmap::SetRemoval::ld_neighborhood : gmap::SetRemoval::selected_set;
  c.mode = as<std::string>(x["mode"]) == "neighborhood" ?
    gmap::MarginalSetMode::neighborhood :
    gmap::MarginalSetMode::approximate_multi_signal;
  return c;
}

DataFrame spreads(const std::vector<gbayes::ChainSpread>& x) {
  NumericVector mean, sd, low, high;
  for (const auto& a : x) {
    mean.push_back(a.mean); sd.push_back(a.sd);
    low.push_back(a.minimum); high.push_back(a.maximum);
  }
  return DataFrame::create(_["mean"] = mean, _["sd"] = sd,
    _["minimum"] = low, _["maximum"] = high);
}

List agreement(const gbayes::ChainAgreement& a) {
  IntegerVector flagged(a.flagged_markers.size());
  for (size_t j = 0; j < a.flagged_markers.size(); ++j)
    flagged[j] = a.flagged_markers[j] + 1;
  return List::create(_["marker_ids"] = a.marker_ids, _["seeds"] = a.seeds,
    _["retained_draws"] = a.retained_draws, _["effect"] = spreads(a.effect),
    _["pip"] = spreads(a.pip),
    _["parameters"] = spreads({a.residual_variance, a.slab_variance,
      a.expected_active}),
    _["parameter_names"] = CharacterVector::create("residual_variance",
      "effect_variance", "expected_active"), _["weights"] = spreads(a.weights),
    _["region_inclusion"] = spreads(a.region_inclusion),
    _["flagged_markers"] = flagged, _["multiple_chains"] = a.multiple_chains,
    _["pip_range_threshold"] = a.pip_range_threshold);
}

template<class T> List mapping_result(const T& fit,
    const gmap::EigenRetention& retention) {
  const auto& p = fit.posterior;
  return List::create(_["mean"] = p.mean, _["variance"] = p.variance,
    _["pip"] = p.pip, _["sets"] = sets(fit.sets),
    _["truncated_likelihood"] = p.truncated_likelihood,
    _["imported_eigensystem"] = fit.input.imported_eigensystem,
    _["requested_retained_positive_mass"] = retention.requested_positive_mass,
    _["achieved_retained_positive_mass"] = retention.achieved_positive_mass,
    _["retained_rank"] = double(retention.retained_rank),
    _["full_rank"] = double(retention.full_rank),
    _["minimum_retained_eigenvalue"] = retention.minimum_retained_eigenvalue,
    _["maximum_score_projection_change"] = fit.input.maximum_score_projection_change,
    _["marker_ids"] = p.marker_ids, _["trait"] = p.trait,
    _["effect_units"] = p.effect_units, _["provenance"] = p.provenance);
}
}

// Conversion layer only; all numerical work remains in installed public libraries.
// [[Rcpp::export]]
SEXP cpp_gmap_open_ld(std::string prefix) {
  return Rcpp::XPtr<gmat::SparseLdDiskReader>(
    new gmat::SparseLdDiskReader(prefix), true);
}

// [[Rcpp::export]]
void cpp_gmap_release_ld(SEXP reader_pointer) {
  Rcpp::XPtr<gmat::SparseLdDiskReader> reader(reader_pointer);
  reader.release();
}

// [[Rcpp::export]]
Rcpp::NumericMatrix cpp_gmap_read_ld_region(SEXP reader_pointer,
    Rcpp::NumericVector indices, int maximum_dimension) {
  using namespace Rcpp;
  if (maximum_dimension < 1) stop("maximum_dimension must be positive");
  std::vector<uint64_t> selected;
  selected.reserve(indices.size());
  for (double value : indices) {
    if (!std::isfinite(value) || value < 1 || value != std::floor(value))
      stop("Invalid regional index");
    selected.push_back(uint64_t(value - 1));
  }
  XPtr<gmat::SparseLdDiskReader> reader(reader_pointer);
  if (!reader) stop("Expired sparse-LD reader");
  auto region = reader->read_region(selected,
    static_cast<std::uint64_t>(maximum_dimension));
  const int n = static_cast<int>(region.markers.size());
  CharacterVector marker_ids(n);
  for (int i = 0; i < n; ++i)
    marker_ids[i] = region.markers[static_cast<std::size_t>(i)].marker_id;
  NumericMatrix matrix(n, n, region.matrix.begin());
  matrix.attr("dimnames") = List::create(marker_ids, marker_ids);
  return matrix;
}

// [[Rcpp::export]]
SEXP cpp_gmap_prepare_region(SEXP reader_pointer, Rcpp::NumericVector indices,
    Rcpp::List region, std::string reference, Rcpp::List eigen_control) {
  using namespace Rcpp;
  gmap::Region r;
  r.id = as<std::string>(region["id"]);
  r.chromosome = as<std::string>(region["chromosome"]);
  r.assembly = as<std::string>(region["assembly"]);
  r.start = as<double>(region["start"]);
  r.end = as<double>(region["end"]);
  std::vector<uint64_t> selected;
  for (double value : indices) {
    if (!std::isfinite(value) || value < 1 || value != std::floor(value))
      stop("Invalid regional index");
    selected.push_back(uint64_t(value - 1));
  }
  gsolve::SymmetricEigensystemOptions options;
  options.maximum_dimension = as<double>(eigen_control["maximum_dimension"]);
  options.symmetry_tolerance = as<double>(eigen_control["symmetry_tolerance"]);
  options.verification_tolerance = as<double>(eigen_control["verification_tolerance"]);
  XPtr<gmat::SparseLdDiskReader> reader(reader_pointer);
  if (!reader) stop("Expired sparse-LD reader");
  const bool dense = eigen_control.containsElementNamed("dense") && as<bool>(eigen_control["dense"]);
  auto prepared = dense ? gmap::PreparedMappingRegion::from_dense_reference(*reader, r,
    reference, selected, options) : gmap::PreparedMappingRegion::from_reference(*reader, r,
    reference, selected, 0, nullptr, options);
  XPtr<gmap::PreparedMappingRegion> pointer(
    new gmap::PreparedMappingRegion(std::move(prepared)), true);
  return pointer;
}

// [[Rcpp::export]]
SEXP cpp_gmap_prepare_matrix(Rcpp::NumericMatrix matrix, Rcpp::DataFrame metadata,
    Rcpp::NumericVector indices, Rcpp::List region, std::string reference,
    double sample_count, Rcpp::List eigen_control, bool dense) {
  using namespace Rcpp;
  CharacterVector ids=metadata["marker_id"], chr=metadata["chromosome"],
    a1=metadata["allele1"], a2=metadata["allele2"];
  NumericVector positions=metadata["base_pair_position"];
  const auto n=static_cast<size_t>(ids.size());
  if(matrix.nrow()!=int(n)||matrix.ncol()!=int(n)||indices.size()!=int(n) ||
      !std::isfinite(sample_count)||sample_count<2||sample_count!=std::floor(sample_count))
    stop("Invalid dense region dimensions or reference sample count");
  gmat::SparseLdRegion data;
  data.reference_sample_count=static_cast<uint64_t>(sample_count);
  data.matrix=as<std::vector<double>>(matrix);
  std::vector<uint64_t> selected;
  for(size_t j=0;j<n;++j) {
    const double index=indices[j];
    if(!std::isfinite(index)||index<1||index!=std::floor(index))stop("Invalid dense region index");
    selected.push_back(static_cast<uint64_t>(index-1));
    data.markers.push_back({as<std::string>(ids[j]),as<std::string>(chr[j]),
      static_cast<uint64_t>(positions[j]),as<std::string>(a1[j]),as<std::string>(a2[j]),0,selected.back()});
  }
  gmap::Region r;
  r.id=as<std::string>(region["id"]);r.chromosome=as<std::string>(region["chromosome"]);
  r.assembly=as<std::string>(region["assembly"]);
  r.start=as<double>(region["start"]);r.end=as<double>(region["end"]);
  gsolve::SymmetricEigensystemOptions options;
  options.maximum_dimension=as<double>(eigen_control["maximum_dimension"]);
  options.symmetry_tolerance=as<double>(eigen_control["symmetry_tolerance"]);
  options.verification_tolerance=as<double>(eigen_control["verification_tolerance"]);
  auto prepared=dense ? gmap::PreparedMappingRegion::from_dense_ld(std::move(data),r,
    reference,selected,false,options) : gmap::PreparedMappingRegion::from_ld(std::move(data),r,
    reference,selected,false,0,nullptr,options);
  return XPtr<gmap::PreparedMappingRegion>(new gmap::PreparedMappingRegion(std::move(prepared)),true);
}

// [[Rcpp::export]]
void cpp_gmap_release_region(SEXP prepared_pointer) {
  Rcpp::XPtr<gmap::PreparedMappingRegion> prepared(prepared_pointer);
  prepared.release();
}

// [[Rcpp::export]]
Rcpp::List cpp_gmap_fit_region(SEXP prepared_pointer, Rcpp::DataFrame stat,
    std::string trait, std::string method, Rcpp::List prior,
    Rcpp::List control, double retained_positive_mass) {
  using namespace Rcpp;
  XPtr<gmap::PreparedMappingRegion> prepared(prepared_pointer);
  if (!prepared) stop("Expired prepared region");
  gmap::RegionalScoreTable table;
  table.marker_ids = as<std::vector<std::string>>(stat["marker"]);
  table.allele1 = as<std::vector<std::string>>(stat["allele1"]);
  table.allele2 = as<std::vector<std::string>>(stat["allele2"]);
  table.score = as<std::vector<double>>(stat["score"]);
  table.marker_ss = as<std::vector<double>>(stat["marker_ss"]);
  table.trait = trait;
  table.effect_units = "caller-supplied design scale";
  table.provenance = "standalone gmap exact sufficient statistics";
  const auto binding_start=std::chrono::steady_clock::now();
  auto retention = prepared->retention(retained_positive_mass);
  auto bound = prepared->bind(table, retention,
    retention.retained_rank < retention.full_rank);
  const double binding_seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-binding_start).count();
  const double residual = as<double>(prior["residual_variance"]);
  const double effect = as<double>(prior["effect_variance"]);
  const bool learn_residual = as<bool>(control["estimate_residual_variance"]);
  gbayes::GaussianNormalization normalization;
  if (learn_residual) {
    List value = control["normalization"];
    if (!as<bool>(value["in_sample_ld"]) || bound.ld->incomplete_reference)
      stop("Residual learning requires complete in-sample regional LD");
    normalization.phenotype_sum_squares = as<double>(value["response_ss"]);
    normalization.likelihood_dimension = as<double>(value["likelihood_dimension"]);
    normalization.space = gbayes::GaussianSpace::full;
    if (normalization.likelihood_dimension > double(bound.reference_sample_count))
      stop("In-sample likelihood dimension exceeds reference sample count");
    bound.statistics.cross_products->validate_normalization(normalization,
      bound.statistics.response_coordinates);
  }
  if (method == "multi_effect") {
    gbayes::SingleEffectPrior p;
    p.residual_variance = residual; p.effect_variance = effect;
    gbayes::MultiEffectControls c;
    c.effects = as<int>(control["effects"]);
    c.max_sweeps = as<int>(control["max_sweeps"]);
    c.objective_tolerance = as<double>(control["objective_tolerance"]);
    c.estimate_effect_variance = as<bool>(control["estimate_effect_variance"]);
    c.estimate_residual_variance = learn_residual;
    c.normalization = normalization;
    c.residual_relative_tolerance = as<double>(control["residual_relative_tolerance"]);
    List learning = control["variance_learning"];
    c.variance_learning.max_updates = as<int>(learning["max_updates"]);
    c.variance_learning.relative_tolerance = as<double>(learning["relative_tolerance"]);
    auto fit = gmap::fit_prepared_multi_effect(bound, p, c,
      component_controls(as<List>(control["sets"])));
    auto output = mapping_result(fit, retention);
    output["timings_seconds"]=List::create(_["binding"]=binding_seconds,
      _["sampling"]=fit.sampling_seconds,_["sets"]=fit.sets_seconds);
    const auto& q = fit.posterior;
    List components(q.components.size());
    for (size_t i = 0; i < q.components.size(); ++i) {
      const auto& x = q.components[i];
      components[i] = List::create(_["active"] = x.active,
        _["effect_variance"] = x.prior.effect_variance,
        _["prior_probability"] = x.prior_probability,
        _["assignment_probability"] = x.assignment_probability,
        _["log_bayes_factor"] = x.log_bayes_factor,
        _["conditional_mean"] = x.conditional_mean,
        _["conditional_variance"] = x.conditional_variance,
        _["mean"] = x.mean, _["variance"] = x.variance,
        _["second_moment"] = x.second_moment,
        _["model_log_bayes_factor"] = x.model_log_bayes_factor,
        _["variance_learning_converged"] = x.variance_learning_converged ?
          LogicalVector::create(*x.variance_learning_converged) :
          LogicalVector::create(NA_LOGICAL),
        _["variance_updates"] = double(x.variance_updates));
    }
    output["components"] = components;
    output["converged"] = q.converged;
    output["sweeps"] = double(q.sweeps);
    output["objective"] = q.objective;
    output["residual_variance"] = q.residual_variance;
    output["residual_variance_trace"] = q.residual_variance_trace;
    output["residual_variance_converged"] = q.residual_variance_converged ?
      LogicalVector::create(*q.residual_variance_converged) :
      LogicalVector::create(NA_LOGICAL);
    output["final_score_residual"] = q.final_score_residual;
    return output;
  }
  gbayes::BayesCControls c;
  c.burnin = as<int>(control["burnin"]);
  c.sampling_sweeps = as<int>(control["sampling_sweeps"]);
  c.thinning = as<int>(control["thinning"]);
  c.chain_seeds.clear();
  for (double seed : as<NumericVector>(control["seeds"]))
    c.chain_seeds.push_back(uint32_t(seed));
  c.retain_diagnostics = as<bool>(control["retain_diagnostics"]);
  List swap = control["ld_swap"];
  c.ld_swap.probability = as<double>(swap["probability"]);
  c.ld_swap.minimum_r2 = as<double>(swap["minimum_r2"]);
  c.ld_swap.maximum_friends = as<int>(swap["maximum_friends"]);
  c.ld_swap.moves = as<int>(swap["moves"]);
  gbayes::GaussianLearning learning;
  learning.slab_variance = as<bool>(control["estimate_effect_variance"]);
  learning.residual_variance = learn_residual;
  learning.mixture_weights = as<bool>(control["estimate_weights"]);
  learning.normalization = normalization;
  if (learning.slab_variance) {
    List value = prior["effect_variance_prior"];
    learning.slab_prior = {as<double>(value["df"]), as<double>(value["scale"])};
  }
  if (learning.residual_variance) {
    List value = prior["residual_variance_prior"];
    learning.residual_prior = {as<double>(value["df"]), as<double>(value["scale"])};
  }
  if (learning.mixture_weights)
    learning.weight_prior = as<std::vector<double>>(prior["weight_prior"]);
  const bool fitted_variance=as<bool>(control["fitted_variance"]);
  gbayes::ScalarPosteriorControls capture;
  if(fitted_variance) {
    auto ref=std::make_shared<gbayes::GeneticCovarianceReference>();
    ref->cross_products=bound.statistics.cross_products;
    ref->marker_ids=bound.statistics.marker_ids;
    std::unordered_map<std::string,std::string> alleles;
    for(size_t j=0;j<table.marker_ids.size();++j)
      alleles.emplace(table.marker_ids[j],table.allele1[j]);
    for(const auto& id:ref->marker_ids) ref->counted_alleles.push_back(alleles.at(id));
    ref->effect_multipliers.assign(ref->marker_ids.size(),1.0);
    ref->divisor=as<double>(control["genetic_variance_denominator"]);
    ref->reference_id=bound.reference;ref->genotype_coding=table.effect_units;
    ref->provenance=bound.statistics.provenance;
    capture.genetic_reference=ref;
  }
  if (method == "bayesc") {
    gbayes::BayesCPrior p;
    p.residual_variance = residual; p.slab_variance = effect;
    p.inclusion_probability = as<double>(prior["inclusion_probability"]);
    auto set_control=marginal_controls(as<List>(control["sets"]));
    auto fit = fitted_variance ? capture_prepared(bound,capture,set_control,
      [&](const auto& q){return gbayes::fit_bayesc(bound.statistics,p,c,learning,q);}) :
      gmap::fit_prepared_bayesc(bound,p,c,learning,set_control);
    if(control.containsElementNamed("qgg_sets") && as<bool>(control["qgg_sets"])) {
      const auto grouping_start=std::chrono::steady_clock::now();
      fit.sets=gmap::make_qgg_marginal_sets(fit.posterior.pip,*bound.ld,
        marginal_controls(as<List>(control["sets"])));
      fit.sets.trait=fit.posterior.trait;fit.sets.provenance=fit.posterior.provenance;
      fit.sets.truncated_likelihood=fit.posterior.truncated_likelihood;
      fit.sets_seconds+=std::chrono::duration<double>(std::chrono::steady_clock::now()-grouping_start).count();
    }
    auto output = mapping_result(fit, retention);
    output["timings_seconds"]=List::create(_["binding"]=binding_seconds,
      _["sampling"]=fit.sampling_seconds,_["sets"]=fit.sets_seconds);
    List chains(fit.posterior.chains.size());
    for (size_t i = 0; i < fit.posterior.chains.size(); ++i)
      chains[i] = chain(fit.posterior.chains[i]);
    output["chain_agreement"] = agreement(gbayes::summarize_chains(
      fit.posterior, as<double>(control["pip_range_threshold"])));
    output["chains"] = chains;
    output["ld_swap"] = swap_summary(fit.posterior);
    output["parameter_mean"] = parameters(fit.posterior.parameter_mean);
    posterior_table(output,fit.posterior);
    return output;
  }
  if (method != "bayesr") stop("Unknown mapping method");
  gbayes::BayesRPrior p;
  p.residual_variance = residual; p.slab_variance = effect;
  p.weights = as<std::vector<double>>(prior["weights"]);
  p.variance_multipliers = as<std::vector<double>>(prior["variance_multipliers"]);
  auto set_control=marginal_controls(as<List>(control["sets"]));
  auto fit = fitted_variance ? capture_prepared(bound,capture,set_control,
    [&](const auto& q){return gbayes::fit_bayesr(bound.statistics,p,c,learning,q);}) :
    gmap::fit_prepared_bayesr(bound,p,c,learning,set_control);
  if(control.containsElementNamed("qgg_sets") && as<bool>(control["qgg_sets"])) {
    const auto grouping_start=std::chrono::steady_clock::now();
    fit.sets=gmap::make_qgg_marginal_sets(fit.posterior.pip,*bound.ld,
      marginal_controls(as<List>(control["sets"])));
    fit.sets.trait=fit.posterior.trait;fit.sets.provenance=fit.posterior.provenance;
    fit.sets.truncated_likelihood=fit.posterior.truncated_likelihood;
    fit.sets_seconds+=std::chrono::duration<double>(std::chrono::steady_clock::now()-grouping_start).count();
  }
  auto output = mapping_result(fit, retention);
  output["timings_seconds"]=List::create(_["binding"]=binding_seconds,
    _["sampling"]=fit.sampling_seconds,_["sets"]=fit.sets_seconds);
  List chains(fit.posterior.chains.size());
  for (size_t i = 0; i < fit.posterior.chains.size(); ++i) {
    const auto& x = fit.posterior.chains[i];
    auto value = chain(x.posterior);
    value["component_probability"] = x.component_probability;
    value["final_component_zero_based"] = x.final_component;
    value["marker_order_zero_based"] = x.marker_order;
    chains[i] = value;
  }
  output["chain_agreement"] = agreement(gbayes::summarize_chains(
    fit.posterior, as<double>(control["pip_range_threshold"])));
  output["chains"] = chains;
  output["ld_swap"] = swap_summary(fit.posterior);
  output["component_probability"] = fit.posterior.component_probability;
  output["parameter_mean"] = parameters(fit.posterior.parameter_mean);
  posterior_table(output,fit.posterior);
  return output;
}

// [[Rcpp::export]]
Rcpp::List cpp_gmap_qgg_sets(Rcpp::NumericMatrix matrix,
    Rcpp::CharacterVector marker_ids, Rcpp::NumericVector pip,
    double threshold, double minimum_r2, double cutoff, std::string method) {
  using namespace Rcpp;
  if(method!="CS2"&&method!="CS3")stop("cs_method must be CS2 or CS3");
  gmap::RegionalLd ld{as<std::vector<std::string>>(marker_ids),
    as<std::vector<double>>(matrix),false};
  if(matrix.nrow()!=marker_ids.size()||matrix.ncol()!=marker_ids.size())
    stop("LD dimensions differ from marker IDs");
  gmap::MarginalSetControls c;
  c.coverage=threshold;c.min_r2=minimum_r2;c.pip_cutoff=cutoff;
  c.lead=method=="CS3" ? gmap::LeadSelection::ld_pip : gmap::LeadSelection::pip;
  return sets(gmap::make_qgg_marginal_sets(as<std::vector<double>>(pip),ld,c));
}

// [[Rcpp::export]]
Rcpp::List cpp_gmap_bed_sets(SEXP reader_pointer, Rcpp::NumericVector indices,
    Rcpp::CharacterVector marker_ids, Rcpp::NumericVector pip,
    Rcpp::List control, int maximum_dimension, bool incomplete_reference) {
  using namespace Rcpp;
  if (indices.size() != marker_ids.size() || pip.size() != marker_ids.size())
    stop("Regional BED marker and PIP lengths differ");
  std::vector<std::uint64_t> selected;
  for (double value : indices) {
    if (!std::isfinite(value) || value < 1 || value != std::floor(value))
      stop("Invalid regional LD index");
    selected.push_back(std::uint64_t(value - 1));
  }
  XPtr<gmat::SparseLdDiskReader> reader(reader_pointer);
  if (!reader) stop("Expired sparse-LD reader");
  auto region = reader->read_region(selected, std::uint64_t(maximum_dimension));
  auto ids = as<std::vector<std::string>>(marker_ids);
  for (std::size_t j = 0; j < ids.size(); ++j)
    if (region.markers[j].marker_id != ids[j])
      stop("Regional LD marker order differs from fitted BED markers");
  gmap::RegionalLd ld{ids, std::move(region.matrix), incomplete_reference};
  return sets(gmap::make_marginal_sets(as<std::vector<double>>(pip), ld,
    marginal_controls(control)));
}

namespace {
bool stored_flag(const Rcpp::List& x, const char* name) {
  Rcpp::LogicalVector value = x[name];
  if (value.size() != 1 || value[0] == NA_LOGICAL)
    Rcpp::stop("Invalid saved logical field: %s", name);
  return value[0];
}

gbayes::MultiEffectResult restore_multi_effect(const Rcpp::List& x) {
  using namespace Rcpp;
  gbayes::MultiEffectResult fit;
  fit.marker_ids = as<std::vector<std::string>>(x["marker_ids"]);
  fit.trait = as<std::string>(x["trait"]);
  fit.effect_units = as<std::string>(x["effect_units"]);
  fit.provenance = as<std::string>(x["provenance"]);
  fit.converged = stored_flag(x, "converged");
  fit.truncated_likelihood = stored_flag(x, "truncated_likelihood");
  fit.residual_variance = as<double>(x["residual_variance"]);
  fit.mean = as<std::vector<double>>(x["mean"]);
  fit.variance = as<std::vector<double>>(x["variance"]);
  fit.pip = as<std::vector<double>>(x["pip"]);
  List components = x["components"];
  for (SEXP item : components) {
    List value(item); gbayes::SingleEffectResult component;
    component.marker_ids = fit.marker_ids;
    component.trait = fit.trait;
    component.effect_units = fit.effect_units;
    component.provenance = fit.provenance;
    component.truncated_likelihood = fit.truncated_likelihood;
    component.active = stored_flag(value, "active");
    component.prior.effect_variance = as<double>(value["effect_variance"]);
    component.prior.residual_variance = fit.residual_variance;
    component.prior_probability = as<std::vector<double>>(value["prior_probability"]);
    component.assignment_probability = as<std::vector<double>>(value["assignment_probability"]);
    component.log_bayes_factor = as<std::vector<double>>(value["log_bayes_factor"]);
    LogicalVector flag = value["variance_learning_converged"];
    if (flag.size() != 1) stop("Invalid saved variance-learning status");
    if (flag[0] != NA_LOGICAL) component.variance_learning_converged = bool(flag[0]);
    fit.components.push_back(std::move(component));
  }
  return fit;
}

const char* coloc_status(gmap::ComponentColocStatus status) {
  switch (status) {
    case gmap::ComponentColocStatus::eligible: return "eligible";
    case gmap::ComponentColocStatus::inactive: return "inactive";
    case gmap::ComponentColocStatus::incomplete_set: return "incomplete_set";
    case gmap::ComponentColocStatus::low_purity: return "low_purity";
    case gmap::ComponentColocStatus::duplicate_set: return "duplicate_set";
  }
  Rcpp::stop("Unknown component status"); return "";
}
}

// Reconstructs typed posterior evidence only. No fitter, sampler or eigensolver.
// [[Rcpp::export]]
Rcpp::List cpp_gmap_coloc_components(Rcpp::List first, Rcpp::List second,
    Rcpp::NumericMatrix matrix, std::string region, Rcpp::List prior,
    Rcpp::List control) {
  using namespace Rcpp;
  auto a = restore_multi_effect(first), b = restore_multi_effect(second);
  if (matrix.nrow() != matrix.ncol() || size_t(matrix.nrow()) != a.marker_ids.size())
    stop("Regional LD dimensions do not match saved posterior");
  gmap::RegionalLd ld1{a.marker_ids, as<std::vector<double>>(matrix),
    stored_flag(as<List>(first["sets"]), "incomplete_ld_reference")};
  gmap::RegionalLd ld2{b.marker_ids, ld1.correlation,
    stored_flag(as<List>(second["sets"]), "incomplete_ld_reference")};
  gmap::ComponentColocControls settings;
  settings.region = region;
  settings.provenance = "standalone gmap saved component evidence; no refit";
  settings.complete_region_coverage = stored_flag(control, "complete_region_coverage");
  settings.non_overlapping_samples = stored_flag(control, "non_overlapping_samples");
  settings.priors = {as<double>(prior["p1"]), as<double>(prior["p2"]),
    as<double>(prior["p12"])};
  settings.sets = component_controls(as<List>(control["sets"]));
  auto result = gmap::coloc_components(a, ld1, b, ld2, settings);
  IntegerVector component1, component2; NumericVector h0, h1, h2, h3, h4;
  List shared(result.pairs.size());
  for (size_t i = 0; i < result.pairs.size(); ++i) {
    const auto& pair = result.pairs[i]; const auto& p = pair.posterior;
    component1.push_back(pair.component1 + 1); component2.push_back(pair.component2 + 1);
    h0.push_back(p.probabilities[0]); h1.push_back(p.probabilities[1]);
    h2.push_back(p.probabilities[2]); h3.push_back(p.probabilities[3]);
    h4.push_back(p.probabilities[4]);
    NumericVector probabilities = wrap(p.shared_variant_probabilities);
    probabilities.attr("names") = wrap(a.marker_ids); shared[i] = probabilities;
  }
  CharacterVector status1, status2;
  for (auto status : result.status1) status1.push_back(coloc_status(status));
  for (auto status : result.status2) status2.push_back(coloc_status(status));
  return List::create(_["pairs"] = DataFrame::create(
      _["component1"] = component1, _["component2"] = component2,
      _["H0"] = h0, _["H1"] = h1, _["H2"] = h2, _["H3"] = h3, _["H4"] = h4),
    _["shared_variant_given_H4"] = shared, _["status1"] = status1,
    _["status2"] = status2, _["sets1"] = sets(result.sets1),
    _["sets2"] = sets(result.sets2), _["refitted"] = false);
}
