#include <Rcpp.h>
#include <gbayes/bayesc.hpp>
#include <gbits/c_api.h>
#include <gmap/coloc.hpp>
#include <gmap/version.hpp>
#include <gmat/version.hpp>
#include <gsolve/version.hpp>

namespace {
Rcpp::List version(const char* expected_version, std::uint32_t expected_abi,
                   const char* runtime_version, std::uint32_t runtime_abi) {
  return Rcpp::List::create(
    Rcpp::Named("expected_version") = expected_version,
    Rcpp::Named("expected_abi") = expected_abi,
    Rcpp::Named("runtime_version") = runtime_version,
    Rcpp::Named("runtime_abi") = runtime_abi,
    Rcpp::Named("compatible") = std::string(runtime_version) == expected_version &&
      runtime_abi == expected_abi);
}
}

// [[Rcpp::export]]
Rcpp::List cpp_gmap_native_info() {
  return Rcpp::List::create(
    Rcpp::Named("gmap") = version("0.3.0", 2,
      gmap::version_string(), gmap::abi_version()),
    Rcpp::Named("gbayes") = version("0.1.0", 0,
      gbayes::version_string(), 0),
    Rcpp::Named("gmat") = version("0.6.0", 0,
      gmat::version_string(), gmat::abi_version()),
    Rcpp::Named("gsolve") = version((std::to_string(gsolve::version_major) + "." +
      std::to_string(gsolve::version_minor) + "." + std::to_string(gsolve::version_patch)).c_str(),
      gsolve::experimental_abi,
      gsolve::version_string(), gsolve::abi_version()),
    Rcpp::Named("gbits") = version("0.21.0", 4,
      gbits_library_version(), gbits_abi_version()));
}

gmap::ColocTraitInput trait(const Rcpp::List& x, double sd) {
  return {Rcpp::as<std::string>(x["trait"]), Rcpp::as<std::string>(x["units"]),
    {Rcpp::as<std::vector<std::string>>(x["marker"]), Rcpp::as<std::vector<double>>(x["effect"])},
    {Rcpp::as<std::vector<std::string>>(x["marker"]), Rcpp::as<std::vector<double>>(x["standard_error"])}, sd};
}

// [[Rcpp::export]]
Rcpp::List cpp_gmap_coloc(Rcpp::List first, Rcpp::List second, std::string region,
                          double sd1, double sd2, double p1, double p2, double p12) {
  gmap::ColocInput input{region, "gmap R task package", trait(first, sd1), trait(second, sd2), true, true};
  const auto result = gmap::fit_coloc(input, {p1, p2, p12});
  return Rcpp::List::create(
    Rcpp::Named("region") = result.region,
    Rcpp::Named("hypothesis_probability") = Rcpp::NumericVector(result.posterior.probabilities.begin(), result.posterior.probabilities.end()),
    Rcpp::Named("shared_variant_probability") = Rcpp::NumericVector(result.posterior.shared_variant_probabilities.begin(), result.posterior.shared_variant_probabilities.end()),
    Rcpp::Named("markers") = first["marker"], Rcpp::Named("software") = cpp_gmap_native_info());
}
