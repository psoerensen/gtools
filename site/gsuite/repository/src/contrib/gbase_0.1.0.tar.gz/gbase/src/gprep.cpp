#include <Rcpp.h>
#include <gbits/bed_summary.hpp>
#include <gbits/c_api.h>
#include <gmat/bed_matrix.hpp>
#include <gmat/bed_panel.hpp>
#include <gmat/ld_score.hpp>
#include <gmat/sparse_ld_disk.hpp>
#include <gmat/version.hpp>
#include <gsolve/symmetric_eigensystem.hpp>
#include <gsolve/version.hpp>

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <limits>
#include <memory>
#include <string>
#include <vector>

namespace {
double number(std::uint64_t value, const char* name) {
  if (value > (std::uint64_t{1} << 53)) Rcpp::stop(std::string(name) + " exceeds R's exact range");
  return static_cast<double>(value);
}
std::uint64_t integer(double value, const char* name) {
  if (!std::isfinite(value) || value < 0 || value != std::floor(value) ||
      value > 9007199254740992.0) Rcpp::stop(std::string(name) + " must be a nonnegative exact integer");
  return static_cast<std::uint64_t>(value);
}
std::vector<std::uint64_t> indices(Rcpp::NumericVector x, const char* name) {
  std::vector<std::uint64_t> out; out.reserve(x.size());
  for (double value : x) out.push_back(integer(value, name));
  return out;
}
std::vector<std::string> strings(Rcpp::CharacterVector x, const char* name) {
  std::vector<std::string> out; out.reserve(x.size());
  for (auto value : x) {
    if (Rcpp::CharacterVector::is_na(value)) Rcpp::stop(std::string(name) + " contains NA");
    auto text = Rcpp::as<std::string>(value);
    if (text.empty()) Rcpp::stop(std::string(name) + " contains an empty value");
    out.push_back(std::move(text));
  }
  return out;
}
std::string field(Rcpp::List x, const char* name) {
  if (!x.containsElementNamed(name)) Rcpp::stop(std::string("missing path field ") + name);
  return Rcpp::as<std::string>(x[name]);
}
std::vector<std::shared_ptr<const gmat::BedMatrix>> components(Rcpp::List paths) {
  if (!paths.size()) Rcpp::stop("BED component list is empty");
  std::vector<std::shared_ptr<const gmat::BedMatrix>> out; out.reserve(paths.size());
  for (R_xlen_t i = 0; i < paths.size(); ++i) {
    Rcpp::List p(paths[i]);
    out.push_back(std::make_shared<const gmat::BedMatrix>(field(p,"bed"),field(p,"bim"),field(p,"fam")));
  }
  return out;
}
gmat::BedPanelSelection selection(Rcpp::CharacterVector families,
    Rcpp::CharacterVector individuals, Rcpp::List marker_ids, std::size_t count) {
  if (families.size() != individuals.size() || static_cast<std::size_t>(marker_ids.size()) != count)
    Rcpp::stop("panel selection dimensions are inconsistent");
  gmat::BedPanelSelection out;
  auto f = strings(families,"family IDs"), id = strings(individuals,"individual IDs");
  for (std::size_t i=0;i<f.size();++i) out.samples.push_back({f[i],id[i]});
  for (R_xlen_t i=0;i<marker_ids.size();++i)
    out.markers_by_component.push_back(strings(Rcpp::CharacterVector(marker_ids[i]),"marker IDs"));
  return out;
}
Rcpp::DataFrame markers(const std::vector<gmat::MarkerMetadata>& x) {
  R_xlen_t n=static_cast<R_xlen_t>(x.size());
  Rcpp::CharacterVector chr(n),id(n),a1(n),a2(n); Rcpp::NumericVector cm(n),pos(n);
  for(R_xlen_t i=0;i<n;++i){const auto& m=x[static_cast<std::size_t>(i)];chr[i]=m.chromosome;id[i]=m.marker_id;cm[i]=m.genetic_distance_cm;pos[i]=number(m.base_pair_position,"position");a1[i]=m.allele1;a2[i]=m.allele2;}
  return Rcpp::DataFrame::create(Rcpp::_["chromosome"]=chr,Rcpp::_["marker_id"]=id,
    Rcpp::_["genetic_distance_cm"]=cm,Rcpp::_["base_pair_position"]=pos,
    Rcpp::_["allele1"]=a1,Rcpp::_["allele2"]=a2);
}
Rcpp::DataFrame samples(const std::vector<gmat::SampleMetadata>& x) {
  R_xlen_t n=static_cast<R_xlen_t>(x.size()); Rcpp::CharacterVector fid(n),iid(n),pid(n),mid(n),sex(n),pheno(n);
  for(R_xlen_t i=0;i<n;++i){const auto& s=x[static_cast<std::size_t>(i)];fid[i]=s.family_id;iid[i]=s.individual_id;pid[i]=s.paternal_id;mid[i]=s.maternal_id;sex[i]=s.sex;pheno[i]=s.phenotype;}
  return Rcpp::DataFrame::create(Rcpp::_["family_id"]=fid,Rcpp::_["individual_id"]=iid,
    Rcpp::_["paternal_id"]=pid,Rcpp::_["maternal_id"]=mid,Rcpp::_["sex"]=sex,Rcpp::_["phenotype"]=pheno);
}
Rcpp::DataFrame disk_markers(const std::vector<gmat::SparseLdDiskMarker>& x) {
  R_xlen_t n=static_cast<R_xlen_t>(x.size()); Rcpp::CharacterVector id(n),chr(n),a1(n),a2(n); Rcpp::NumericVector pos(n),component(n),source(n);
  for(R_xlen_t i=0;i<n;++i){const auto& m=x[static_cast<std::size_t>(i)];id[i]=m.marker_id;chr[i]=m.chromosome;pos[i]=number(m.base_pair_position,"position");a1[i]=m.allele1;a2[i]=m.allele2;component[i]=number(m.component_index,"component");source[i]=number(m.source_marker_index,"source marker");}
  return Rcpp::DataFrame::create(Rcpp::_["marker_id"]=id,Rcpp::_["chromosome"]=chr,
    Rcpp::_["base_pair_position"]=pos,Rcpp::_["allele1"]=a1,Rcpp::_["allele2"]=a2,
    Rcpp::_["component_index_0based"]=component,Rcpp::_["source_marker_index_0based"]=source);
}
Rcpp::List disk(const gmat::SparseLdDiskResource& x) {
  return Rcpp::List::create(Rcpp::_["prefix"]=x.prefix,
    Rcpp::_["paths"]=Rcpp::List::create(Rcpp::_["row_ptr"]=x.row_ptr_path,Rcpp::_["col_idx"]=x.col_idx_path,Rcpp::_["values"]=x.values_path,Rcpp::_["metadata"]=x.metadata_path,Rcpp::_["markers"]=x.markers_path),
    Rcpp::_["marker_count"]=number(x.marker_count,"marker count"),Rcpp::_["stored_entry_count"]=number(x.stored_entry_count,"entry count"),
    Rcpp::_["reference_sample_count"]=number(x.reference_sample_count,"reference samples"),Rcpp::_["source_sample_count"]=number(x.source_sample_count,"source samples"),
    Rcpp::_["component_count"]=number(x.component_count,"components"),Rcpp::_["format"]="sparse_ld_csr",Rcpp::_["format_version"]=x.format_version,
    Rcpp::_["settings"]=Rcpp::List::create(Rcpp::_["block_size"]=number(x.options.block_size,"block size"),Rcpp::_["max_distance_bp"]=number(x.options.max_distance_bp,"distance"),Rcpp::_["max_distance_markers"]=number(x.options.max_distance_markers,"marker distance"),Rcpp::_["r2_threshold"]=x.options.r2_threshold,Rcpp::_["threads"]=x.options.requested_threads,Rcpp::_["allow_full_ld"]=x.options.allow_full_ld),
    Rcpp::_["markers"]=disk_markers(x.markers));
}
}

// [[Rcpp::export]]
Rcpp::List cpp_gbase_native_info(){return Rcpp::List::create(
  Rcpp::_["gmat"]=Rcpp::List::create(Rcpp::_["header_version"]="0.6.0",Rcpp::_["header_abi"]=gmat::experimental_abi,Rcpp::_["runtime_version"]=gmat::version_string(),Rcpp::_["runtime_abi"]=gmat::abi_version()),
  Rcpp::_["gbits"]=Rcpp::List::create(Rcpp::_["header_version"]="0.21.0",Rcpp::_["header_abi"]=4,Rcpp::_["runtime_version"]=gbits_library_version(),Rcpp::_["runtime_abi"]=gbits_abi_version()),
  Rcpp::_["gsolve"]=Rcpp::List::create(Rcpp::_["header_version"]="0.22.0",Rcpp::_["header_abi"]=gsolve::experimental_abi,Rcpp::_["runtime_version"]=gsolve::version_string(),Rcpp::_["runtime_abi"]=gsolve::abi_version()));}

// [[Rcpp::export]]
Rcpp::List cpp_gbase_bed_resource(std::string bed,std::string bim,std::string fam){gmat::BedMatrix x(bed,bim,fam);return Rcpp::List::create(Rcpp::_["paths"]=Rcpp::List::create(Rcpp::_["bed"]=x.bed_path(),Rcpp::_["bim"]=x.bim_path(),Rcpp::_["fam"]=x.fam_path()),Rcpp::_["sample_count"]=number(x.sample_count(),"samples"),Rcpp::_["marker_count"]=number(x.marker_count(),"markers"),Rcpp::_["markers"]=markers(x.markers()),Rcpp::_["samples"]=samples(x.samples()));}

// [[Rcpp::export]]
Rcpp::List cpp_gbase_bed_panel(Rcpp::List paths,Rcpp::CharacterVector families,Rcpp::CharacterVector individuals,Rcpp::List marker_ids){auto c=components(paths);gmat::BedPanel panel(std::move(c),selection(families,individuals,marker_ids,paths.size()));Rcpp::NumericVector rows(panel.sample_count());for(std::uint64_t i=0;i<panel.sample_count();++i)rows[i]=number(panel.sample_source_index(i),"sample index");Rcpp::List source(panel.component_count());for(std::uint64_t k=0;k<panel.component_count();++k){const auto& x=panel.component_marker_indices(k);source[k]=Rcpp::NumericVector(x.begin(),x.end());}return Rcpp::List::create(Rcpp::_["samples"]=samples(panel.samples()),Rcpp::_["sample_source_indices_0based"]=rows,Rcpp::_["component_marker_indices_0based"]=source);}

// [[Rcpp::export]]
Rcpp::List cpp_gbase_bed_counts(Rcpp::CharacterVector bed,double sample_count,Rcpp::NumericVector marker_counts,Rcpp::NumericVector sample_indices,Rcpp::List marker_indices,int threads){if(bed.size()!=marker_counts.size()||bed.size()!=marker_indices.size()||threads<1)Rcpp::stop("invalid BED count inputs");Rcpp::List out(bed.size());auto selected_samples=indices(sample_indices,"sample indices");for(R_xlen_t k=0;k<bed.size();++k){auto selected=indices(Rcpp::NumericVector(marker_indices[k]),"marker indices");if(selected.empty()){Rcpp::NumericVector empty;out[k]=Rcpp::DataFrame::create(Rcpp::_["n0"]=empty,Rcpp::_["n1"]=empty,Rcpp::_["n2"]=empty,Rcpp::_["nmiss"]=empty);continue;}auto count=gbits::bed_genotype_counts(Rcpp::as<std::string>(bed[k]),integer(sample_count,"sample count"),integer(marker_counts[k],"marker count"),selected_samples,selected,static_cast<std::uint32_t>(threads));Rcpp::NumericVector n0(count.size()),n1(count.size()),n2(count.size()),miss(count.size());for(std::size_t j=0;j<count.size();++j){n0[j]=number(count[j].n0,"n0");n1[j]=number(count[j].n1,"n1");n2[j]=number(count[j].n2,"n2");miss[j]=number(count[j].nmiss,"missing");}out[k]=Rcpp::DataFrame::create(Rcpp::_["n0"]=n0,Rcpp::_["n1"]=n1,Rcpp::_["n2"]=n2,Rcpp::_["nmiss"]=miss);}return out;}

// [[Rcpp::export]]
Rcpp::List cpp_gbase_sparse_ld(Rcpp::List paths,Rcpp::CharacterVector families,Rcpp::CharacterVector individuals,Rcpp::List marker_ids,std::string prefix,Rcpp::List options){auto c=components(paths);gmat::BedPanel panel(std::move(c),selection(families,individuals,marker_ids,paths.size()));gmat::SparseLdOptions o;o.block_size=Rcpp::as<std::uint64_t>(options["block_size"]);o.max_distance_bp=Rcpp::as<std::uint64_t>(options["max_distance_bp"]);o.max_distance_markers=Rcpp::as<std::uint64_t>(options["max_distance_markers"]);o.r2_threshold=Rcpp::as<double>(options["r2_threshold"]);o.requested_threads=Rcpp::as<std::uint32_t>(options["threads"]);o.allow_full_ld=Rcpp::as<bool>(options["allow_full_ld"]);return disk(gmat::compute_sparse_ld_csr_to_disk(panel,prefix,o,Rcpp::as<bool>(options["overwrite"])));}

// [[Rcpp::export]]
Rcpp::List cpp_gbase_sparse_ld_open(std::string prefix){return disk(gmat::inspect_sparse_ld_csr_disk(prefix));}

// [[Rcpp::export]]
Rcpp::List cpp_gbase_sparse_ld_identity(std::string prefix){return disk(gmat::open_sparse_ld_csr_disk(prefix));}

// [[Rcpp::export]]
SEXP cpp_gbase_ld_scores(std::string prefix,bool corrected,Rcpp::Nullable<Rcpp::NumericMatrix> annotation_values,Rcpp::CharacterVector annotation_marker_ids,Rcpp::CharacterVector annotation_names){auto d=gmat::open_sparse_ld_csr_disk(prefix);Rcpp::CharacterVector marker_names;for(const auto& m:d.markers)marker_names.push_back(m.marker_id);if(annotation_values.isNull()){auto x=corrected?gmat::corrected_sparse_ld_scores_from_disk(prefix):gmat::sparse_ld_scores_from_disk(prefix);Rcpp::NumericVector out(x.begin(),x.end());out.attr("names")=marker_names;return out;}Rcpp::NumericMatrix matrix(annotation_values);if(matrix.nrow()!=annotation_marker_ids.size()||matrix.ncol()!=annotation_names.size())Rcpp::stop("native annotation dimensions are inconsistent");std::vector<double> values;values.reserve(static_cast<std::size_t>(matrix.nrow())*static_cast<std::size_t>(matrix.ncol()));for(int i=0;i<matrix.nrow();++i)for(int j=0;j<matrix.ncol();++j){double value=matrix(i,j);if(!std::isfinite(value))Rcpp::stop("native annotation values contain a non-finite value");values.push_back(value);}gmat::AnnotationMatrix annotations(strings(annotation_marker_ids,"annotation marker IDs"),strings(annotation_names,"annotation names"),std::move(values));auto scores=corrected?gmat::corrected_partitioned_ld_scores_from_disk(prefix,annotations):gmat::partitioned_ld_scores_from_disk(prefix,annotations);Rcpp::NumericMatrix out(static_cast<int>(scores.marker_count()),static_cast<int>(scores.annotation_count()));for(std::uint64_t i=0;i<scores.marker_count();++i)for(std::uint64_t j=0;j<scores.annotation_count();++j)out(static_cast<int>(i),static_cast<int>(j))=scores.value(i,j);out.attr("dimnames")=Rcpp::List::create(marker_names,annotation_names);return out;}

// [[Rcpp::export]]
Rcpp::List cpp_gbase_ld_region(std::string prefix,Rcpp::NumericVector selected,double maximum_dimension,bool decompose,double symmetry_tolerance,double verification_tolerance){auto indices0=indices(selected,"marker indices");auto region=gmat::sparse_ld_region_from_disk(prefix,indices0,integer(maximum_dimension,"maximum dimension"));int n=static_cast<int>(indices0.size());Rcpp::CharacterVector ids(n);for(int i=0;i<n;++i)ids[i]=region.markers[static_cast<std::size_t>(i)].marker_id;if(!decompose){Rcpp::NumericMatrix matrix(n,n,region.matrix.begin());matrix.attr("dimnames")=Rcpp::List::create(ids,ids);return Rcpp::List::create(Rcpp::_["matrix"]=matrix);}gsolve::SymmetricEigensystemOptions options;options.maximum_dimension=integer(maximum_dimension,"maximum dimension");options.symmetry_tolerance=symmetry_tolerance;options.verification_tolerance=verification_tolerance;auto result=gsolve::compute_symmetric_eigensystem(gsolve::ConstMatrixView(region.matrix.data(),n,n,n),options);if(!result.status.is_ok())Rcpp::stop(result.status.message());Rcpp::NumericMatrix vectors(n,n,result.eigenvectors.begin());vectors.attr("dimnames")=Rcpp::List::create(ids,R_NilValue);const auto& d=result.diagnostics;return Rcpp::List::create(Rcpp::_["values"]=result.eigenvalues,Rcpp::_["vectors"]=vectors,Rcpp::_["diagnostics"]=Rcpp::List::create(Rcpp::_["backend"]=d.backend,Rcpp::_["relative_symmetry_error"]=d.relative_symmetry_error,Rcpp::_["relative_residual"]=d.relative_residual,Rcpp::_["relative_reconstruction_error"]=d.relative_reconstruction_error,Rcpp::_["orthogonality_error"]=d.orthogonality_error));}

// [[Rcpp::export]]
void cpp_gbase_verify_ld_blocks(std::string prefix,Rcpp::NumericVector offsets){
  auto values=indices(offsets,"LD block offsets");
  gmat::visit_sparse_ld_blocks_from_disk(prefix,values,
    [](std::uint64_t,std::uint64_t,const gmat::SparseLdCsr&){});
}
