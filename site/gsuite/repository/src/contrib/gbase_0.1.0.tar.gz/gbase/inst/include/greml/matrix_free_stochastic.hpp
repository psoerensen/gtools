#ifndef GREML_MATRIX_FREE_STOCHASTIC_HPP
#define GREML_MATRIX_FREE_STOCHASTIC_HPP

#include <cstdint>
#include <limits>
#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include "greml/exact_dense_optimizer.hpp"
#include "greml/matrix_free.hpp"
#include "gsolve/affine_spectral_plan.hpp"
#include "gsolve/probes.hpp"
#include "gsolve/slq.hpp"

namespace greml {

struct MatrixFreeStochasticResult;

enum class StochasticEvaluationPurpose {
  accepted_state_full = 0,
  trial_likelihood_only,
  final_result,
  accepted_state_score_ai,
  trial_score_ai,
  convergence_verification_score_ai,
  independent_verification_score_ai,
  final_likelihood_only,
  trial_score_only,
  accepted_state_ai_only
};

enum class AffineSpectralPlanPolicy { disabled = 0, automatic, required };

struct AffineSpectralPlanConfiguration {
  AffineSpectralPlanPolicy policy{AffineSpectralPlanPolicy::disabled};
  double psd_ritz_tolerance{64.0};
};

// Opt-in empirical stabilization of PCG-dependent statistical quantities.
// Tolerances are only tightened; maximum_iterations is never changed.
struct CoordinatedPcgPrecisionOptions {
  bool enabled{false};
  double tightening_factor{10.0};
  double minimum_relative_tolerance{1.0e-12};
  std::optional<double> minimum_absolute_tolerance{};
  std::uint64_t maximum_refinements{4};
  double stochastic_error_fraction{0.25};
  double likelihood_absolute_tolerance{1.0e-8};
  double component_absolute_tolerance{1.0e-8};
};

struct StochasticPrecisionState {
  std::uint64_t probe_count{0};
  std::uint64_t lanczos_steps{0};
  double pcg_relative_tolerance{0.0};
  double pcg_absolute_tolerance{0.0};
  double fixed_effect_pcg_relative_tolerance{0.0};
  double fixed_effect_pcg_absolute_tolerance{0.0};
  std::uint64_t fixed_effect_determinant_probe_count{0};
  std::uint64_t fixed_effect_determinant_lanczos_steps{0};
};

struct LinearPrecisionRefinementRecord {
  StochasticPrecisionState previous_state{};
  StochasticPrecisionState tighter_state{};
  bool stabilized{false};
  double log_likelihood_change{std::numeric_limits<double>::infinity()};
  double log_likelihood_threshold{
      std::numeric_limits<double>::quiet_NaN()};
  std::vector<double> component_score_changes{};
  std::vector<double> component_score_thresholds{};
  std::vector<double> component_trace_changes{};
  std::vector<double> component_trace_thresholds{};
};

// Controls deterministic bounded refinement of an otherwise fixed stochastic
// evaluation. Probe values are prefixes of the seed carried by `probes` in
// MatrixFreeStochasticOptions. Growth factors must be at least two.
struct AdaptiveStochasticPrecisionOptions {
  bool enabled{false};
  std::uint64_t initial_probe_count{16};
  std::uint64_t maximum_probe_count{128};
  std::uint64_t probe_growth_factor{2};
  std::uint64_t probe_batch_size{8};
  std::uint64_t initial_lanczos_steps{20};
  std::uint64_t maximum_lanczos_steps{80};
  std::uint64_t lanczos_growth_factor{2};
  double maximum_trace_standard_error{1.0e-2};
  double maximum_score_standard_error{5.0e-3};
  double maximum_log_determinant_standard_error{1.0e-2};
  double maximum_log_determinant_depth_change{1.0e-3};
  CoordinatedPcgPrecisionOptions coordinated_pcg{};
};

enum class AdaptiveEscalationReason {
  trace_or_score_precision = 0,
  log_determinant_monte_carlo_precision,
  lanczos_depth_stability,
  linear_solve_stability
};

struct AdaptiveEscalationRecord {
  AdaptiveEscalationReason reason{
      AdaptiveEscalationReason::trace_or_score_precision};
  std::uint64_t previous_probe_count{0};
  std::uint64_t next_probe_count{0};
  std::uint64_t previous_lanczos_steps{0};
  std::uint64_t next_lanczos_steps{0};
  double previous_pcg_relative_tolerance{0.0};
  double next_pcg_relative_tolerance{0.0};
  double previous_pcg_absolute_tolerance{0.0};
  double next_pcg_absolute_tolerance{0.0};
};

struct AdaptiveStochasticDiagnostics {
  bool enabled{false};
  bool precision_achieved{false};
  bool coordinated_pcg_enabled{false};
  bool linear_precision_achieved{false};
  bool linear_stability_compared{false};
  bool linear_stability_satisfied{false};
  std::uint64_t initial_probe_count{0};
  std::uint64_t final_probe_count{0};
  std::uint64_t initial_lanczos_steps{0};
  std::uint64_t final_lanczos_steps{0};
  std::uint64_t probe_escalations{0};
  std::uint64_t lanczos_refinements{0};
  std::uint64_t evaluation_count{0};
  std::uint64_t linear_precision_refinements{0};
  bool depth_stability_compared{false};
  bool depth_stability_satisfied{false};
  double previous_depth_log_determinant{
      std::numeric_limits<double>::quiet_NaN()};
  double final_depth_log_determinant{
      std::numeric_limits<double>::quiet_NaN()};
  double absolute_depth_change{std::numeric_limits<double>::infinity()};
  double maximum_trace_standard_error{
      std::numeric_limits<double>::quiet_NaN()};
  double maximum_score_standard_error{
      std::numeric_limits<double>::quiet_NaN()};
  double log_determinant_standard_error{
      std::numeric_limits<double>::quiet_NaN()};
  double starting_pcg_relative_tolerance{0.0};
  double final_pcg_relative_tolerance{0.0};
  double starting_pcg_absolute_tolerance{0.0};
  double final_pcg_absolute_tolerance{0.0};
  double maximum_pcg_relative_true_residual{0.0};
  double successive_log_likelihood_change{
      std::numeric_limits<double>::infinity()};
  double maximum_component_score_change{
      std::numeric_limits<double>::infinity()};
  double maximum_component_trace_change{
      std::numeric_limits<double>::infinity()};
  double likelihood_stabilization_threshold{
      std::numeric_limits<double>::quiet_NaN()};
  std::vector<double> score_stabilization_thresholds{};
  std::vector<double> trace_stabilization_thresholds{};
  StochasticPrecisionState initial_state{};
  StochasticPrecisionState final_state{};
  std::uint64_t total_pcg_operator_applications{0};
  std::uint64_t total_pcg_preconditioner_applications{0};
  std::uint64_t total_component_applications{0};
  std::uint64_t total_slq_operator_applications{0};
  std::uint64_t total_two_level_preconditioner_rebuilds{0};
  std::uint64_t total_two_level_setup_operator_applications{0};
  std::uint64_t total_two_level_setup_operator_processed_columns{0};
  std::vector<AdaptiveEscalationRecord> escalations{};
  std::vector<LinearPrecisionRefinementRecord> linear_refinement_records{};
};

GREML_EXPORT Status validate_adaptive_stochastic_precision(
    const AdaptiveStochasticPrecisionOptions& options);

// Model-independent hook for constructing an SPD preconditioner that is
// paired with one exact immutable covariance state. Implementations may retain
// immutable preparation data across calls, but the returned preconditioner
// must report compatibility with the supplied covariance operator. Named
// counters keep implementation-specific work visible without introducing a
// dependency on the implementation's owning library.
struct ParameterDependentPreconditionerCounter {
  std::string name{};
  std::uint64_t value{0};
};

struct ParameterDependentPreconditionerDiagnostics {
  std::string factory_name{};
  std::uint64_t preparation_count{0};
  std::uint64_t construction_count{0};
  std::uint64_t reuse_count{0};
  std::vector<ParameterDependentPreconditionerCounter> counters{};
};

struct ParameterDependentPreconditionerResult {
  Status status{};
  std::shared_ptr<const gsolve::Preconditioner> preconditioner{};
};

class ParameterDependentPreconditionerFactory;

struct ParameterDependentPreconditionerState {
  std::vector<double> parameters{};
  std::shared_ptr<const ParameterDependentPreconditionerFactory> factory{};
  std::shared_ptr<const gsolve::LinearOperator> covariance{};
  std::shared_ptr<const gsolve::Preconditioner> preconditioner{};
};

class GREML_EXPORT ParameterDependentPreconditionerFactory {
 public:
  virtual ~ParameterDependentPreconditionerFactory() = default;

  [[nodiscard]] virtual ParameterDependentPreconditionerResult prepare(
      const std::vector<double>& validated_parameters,
      std::shared_ptr<const gsolve::LinearOperator> covariance) const
      noexcept = 0;

  [[nodiscard]] virtual ParameterDependentPreconditionerDiagnostics
  diagnostics(const gsolve::Preconditioner& prepared) const noexcept = 0;
};

// Optional coefficient-space backend for evaluating one covariance parameter
// state.  The interface is deliberately storage/model independent: greml owns
// projection semantics and the implementation owns only the numerical batch
// solve and its opaque warm state.  Complete RHS columns are submitted in one
// call so response and common-probe systems can share backend preparation.
enum class BatchedProjectionPurpose : std::uint32_t {
  response_and_common_probes = 0,
  component_information = 1,
  identity_information = 2,
  likelihood_inverse = 3,
  coefficient_probe_cache = 4,
  coefficient_component_reconstruction = 5
};

enum class BatchedScoreAiPolicy : std::uint32_t {
  automatic_identity_optimized = 0,
  direct_component_applications = 1
};

// Execution policy for optional sufficient statistics returned by a compatible
// batched projection backend.  This does not select a different trace or AI
// estimator: supplied probe realizations and component vectors must be the
// same quantities used by direct covariance-component applications.
enum class BatchedCoefficientReusePolicy : std::uint32_t {
  automatic = 0,
  off = 1,
  required = 2
};

enum class BatchedCoefficientReuseResolution : std::uint32_t {
  off = 0,
  partial = 1,
  complete = 2
};

struct BatchedProjectionControls {
  std::uint64_t maximum_symmetric_sweeps{100};
  double relative_tolerance{1.0e-8};
  double absolute_tolerance{0.0};
  std::uint32_t requested_threads{1};
  BatchedCoefficientReusePolicy coefficient_reuse{
      BatchedCoefficientReusePolicy::automatic};
  // Total persistent W'Z cache budget owned by one projection factory.
  std::uint64_t coefficient_cache_memory_limit{512u * 1024u * 1024u};
  // Identifies a generated common-probe stream.  Explicit probes are also
  // checked column-by-column by the backend, so this token never substitutes
  // for validating their actual values.
  std::uint64_t common_probe_identity{0};
  BatchedProjectionPurpose purpose{
      BatchedProjectionPurpose::response_and_common_probes};
};

class GREML_EXPORT BatchedProjectionWarmState {
 public:
  virtual ~BatchedProjectionWarmState() = default;
};

struct BatchedProjectionCounter {
  std::string name{};
  std::uint64_t value{0};
};

struct BatchedProjectionCallDiagnostics {
  BatchedProjectionPurpose purpose{
      BatchedProjectionPurpose::response_and_common_probes};
  std::uint64_t right_hand_side_count{0};
  std::uint32_t requested_threads{1};
  std::uint32_t resolved_threads{1};
  std::uint64_t marker_visits{0};
  std::uint64_t packed_decode_passes{0};
  double decode_seconds{0.0};
  double compute_seconds{0.0};
  double solve_seconds{0.0};
};

struct BatchedComponentSufficientStatistics {
  std::uint64_t component_index{0};
  bool trace_contributions_available{false};
  bool response_quadratic_available{false};
  bool component_py_available{false};
  // One realization per common probe, in submitted probe-column order.
  std::vector<double> trace_contributions{};
  double response_quadratic{std::numeric_limits<double>::quiet_NaN()};
  std::vector<double> component_py{};
  std::string fallback_reason{};
};

struct BatchedProjectionDiagnostics {
  std::string backend_name{};
  BatchedProjectionPurpose purpose{
      BatchedProjectionPurpose::response_and_common_probes};
  std::uint32_t requested_threads{1};
  std::uint32_t resolved_threads{1};
  std::uint64_t system_count{0};
  std::uint64_t warm_start_systems{0};
  std::uint64_t sweeps{0};
  std::uint64_t total_sweeps{0};
  double maximum_normal_residual{0.0};
  double maximum_observation_consistency_residual{0.0};
  double preparation_seconds{0.0};
  double decode_seconds{0.0};
  double compute_seconds{0.0};
  double solve_seconds{0.0};
  BatchedCoefficientReusePolicy requested_coefficient_reuse{
      BatchedCoefficientReusePolicy::automatic};
  BatchedCoefficientReuseResolution resolved_coefficient_reuse{
      BatchedCoefficientReuseResolution::off};
  std::vector<std::uint64_t> coefficient_reuse_eligible_components{};
  std::vector<std::uint64_t> coefficient_reuse_resolved_components{};
  std::vector<std::string> coefficient_reuse_fallback_reasons{};
  std::uint64_t coefficient_cache_hits{0};
  std::uint64_t coefficient_cache_misses{0};
  std::uint64_t coefficient_cache_columns{0};
  std::uint64_t coefficient_cache_bytes{0};
  std::uint64_t coefficient_cache_reused_columns{0};
  std::uint64_t coefficient_cache_appended_columns{0};
  double coefficient_cache_build_seconds{0.0};
  double coefficient_reduction_seconds{0.0};
  double component_reconstruction_seconds{0.0};
  std::uint64_t coefficient_cache_marker_visits{0};
  std::uint64_t coefficient_cache_decode_passes{0};
  std::uint64_t component_reconstruction_marker_visits{0};
  std::uint64_t component_reconstruction_decode_passes{0};
  std::vector<BatchedProjectionCounter> counters{};
  std::vector<BatchedProjectionCallDiagnostics> calls{};
};

struct BatchedProjectionResult {
  Status status{};
  std::uint64_t observation_count{0};
  std::uint64_t fixed_effect_count{0};
  std::uint64_t system_count{0};
  // fixed_effect_count by system_count and observation_count by system_count.
  std::vector<double> fixed_effects{};
  std::vector<double> projected{};
  // Optional exact materialized-projection ingredients.  When present they
  // describe the first submitted system and the retained fixed design.
  std::vector<double> inverse_response{};
  std::vector<double> inverse_fixed_effects{};
  std::vector<double> fixed_effect_covariance{};
  double fixed_effect_log_determinant{0.0};
  std::vector<BatchedComponentSufficientStatistics>
      component_sufficient_statistics{};
  std::shared_ptr<const BatchedProjectionWarmState> warm_state{};
  BatchedProjectionDiagnostics diagnostics{};
};

class GREML_EXPORT ParameterDependentBatchedProjectionFactory {
 public:
  virtual ~ParameterDependentBatchedProjectionFactory() = default;
  [[nodiscard]] virtual BatchedProjectionResult project(
      const std::vector<double>& validated_parameters,
      gsolve::ConstMatrixView systems,
      const BatchedProjectionControls& controls,
      bool require_inverse_and_fixed_determinant,
      std::shared_ptr<const BatchedProjectionWarmState> warm_state) const
      noexcept = 0;
};

// Optional evaluation-side provider for quantities that are mathematically
// identical to explicit covariance-component applications.  It is independent
// of projection and optimization: the evaluator still owns probes, PZ, PY,
// score/AI assembly, and every direct fallback.
struct MatrixFreeTraceStatisticsBatch {
  Status status{};
  std::uint64_t component_count{0};
  std::uint64_t probe_count{0};
  std::vector<std::uint8_t> available{};
  // Component-major component_count by probe_count.
  std::vector<double> contributions{};
  std::vector<std::string> fallback_reasons{};
};

struct MatrixFreeResponseStatistics {
  Status status{};
  std::uint64_t observation_count{0};
  std::uint64_t component_count{0};
  std::vector<std::uint8_t> available{};
  std::vector<double> quadratics{};
  // Component-major observation_count by component_count.
  std::vector<double> component_py{};
  std::vector<std::string> fallback_reasons{};
};

class GREML_EXPORT MatrixFreeComponentStatisticsProvider {
 public:
  virtual ~MatrixFreeComponentStatisticsProvider() = default;
  [[nodiscard]] virtual MatrixFreeTraceStatisticsBatch trace_batch(
      const std::vector<double>& validated_parameters,
      gsolve::ConstMatrixView probes,
      gsolve::ConstMatrixView projected_probes,
      std::uint64_t probe_offset) const noexcept = 0;
  [[nodiscard]] virtual MatrixFreeResponseStatistics response(
      const std::vector<double>& validated_parameters,
      gsolve::ConstMatrixView py) const noexcept = 0;
};

struct MatrixFreeStochasticOptions {
  LikelihoodMode mode{LikelihoodMode::restricted_maximum_likelihood};
  gsolve::PcgOptions pcg{};
  PreconditionerPolicy preconditioner{PreconditionerPolicy::automatic};
  // When non-null, this exact caller-owned preconditioner replaces policy
  // resolution for every PCG solve. Its dimension and concurrency metadata are
  // validated by the projection and batch-PCG paths. SLQ remains
  // unpreconditioned. The current optimizer rejects this fixed-parameter-only
  // route because it cannot refactor the supplied object after parameter updates.
  std::shared_ptr<const gsolve::Preconditioner> supplied_preconditioner{};
  // Optional parameter-state factory. It is mutually exclusive with a fixed
  // supplied preconditioner, an explicitly selected identity/Jacobi policy,
  // and a supplied two-level base. When two-level preconditioning is enabled,
  // the factory result becomes its state-compatible base preconditioner.
  std::shared_ptr<const ParameterDependentPreconditionerFactory>
      parameter_dependent_preconditioner_factory{};
  // Optional exact state retained from an identical parameter evaluation.
  // It is accepted only after factory, parameter, component, and operator
  // identity checks; otherwise evaluation fails rather than pairing stale
  // state silently.
  std::shared_ptr<const ParameterDependentPreconditionerState>
      reusable_parameter_dependent_preconditioner_state{};
  std::shared_ptr<const ParameterDependentBatchedProjectionFactory>
      batched_projection_factory{};
  std::shared_ptr<const MatrixFreeComponentStatisticsProvider>
      component_statistics_provider{};
  std::shared_ptr<const BatchedProjectionWarmState>
      reusable_batched_projection_state{};
  // The component-Py information batch has different column semantics from
  // the response/common-probe batch and therefore retains an independent
  // warm state.
  std::shared_ptr<const BatchedProjectionWarmState>
      reusable_batched_information_projection_state{};
  BatchedProjectionControls batched_projection{};
  BatchedScoreAiPolicy batched_score_ai_policy{
      BatchedScoreAiPolicy::direct_component_applications};
  std::shared_ptr<const gsolve::RademacherProbePlan> probes{};
  std::uint64_t probe_batch_size{8};
  std::uint64_t lanczos_steps{20};
  double lanczos_breakdown_tolerance{1.0e-14};
  gsolve::ExecutionConfig execution{};
  bool compute_component_predictions{true};
  bool retain_slq_probe_estimates{false};
  // Fixed-parameter score/AI evaluation may explicitly omit likelihood and
  // determinant work. The default optimizer remains likelihood-based; the
  // determinant-deferred policy sets this false only for score/AI purposes
  // and performs one final likelihood-only verification after convergence.
  bool compute_log_likelihood{true};
  // When present for REML, supplies the exact combined determinant
  // log|V| + log|F'V^-1F|. This is used by sparse coefficient-space routes
  // that already have the determinant identity and must not invoke SLQ.
  std::optional<double> exact_reml_determinant_sum{};
  // Marks an explicit caller-owned probe set as a complete deterministic
  // trace basis. The trace and score standard errors are then exactly zero.
  bool explicit_probes_are_complete{false};
  // Optional packed n-by-s Rademacher matrix for deterministic small-oracle
  // validation. Normal scalable use leaves this null and generates batches.
  std::shared_ptr<const std::vector<double>> explicit_probes{};
  FixedEffectProjectionStrategy fixed_effect_projection{
      FixedEffectProjectionStrategy::materialized};
  IterativeFixedEffectOptions iterative_fixed_effects{};
  gsolve::MultipleRhsKrylovStrategy covariance_solve_strategy{
      gsolve::MultipleRhsKrylovStrategy::independent};
  gsolve::BlockPcgOptions covariance_block_pcg{};
  TwoLevelPreconditionerConfiguration two_level_preconditioner{};
  StochasticEvaluationPurpose purpose{
      StochasticEvaluationPurpose::accepted_state_full};
  // Operation-local, non-owning input used by final_likelihood_only and
  // accepted_state_ai_only.
  // The retained object must outlive the evaluation call.  Its response
  // projection and quadratic are reused so finalization performs determinant
  // work without repeating response, trace, score, or AI solves.
  const MatrixFreeStochasticResult* retained_score_ai_result{nullptr};
  AffineSpectralPlanConfiguration affine_spectral_plan{};
};

struct MatrixFreeStochasticWarmStart {
  std::vector<double> inverse_fixed_effects{};
  std::vector<double> inverse_response{};
};

struct MatrixFreeStochasticDiagnostics {
  StochasticEvaluationPurpose purpose{
      StochasticEvaluationPurpose::accepted_state_full};
  std::uint32_t requested_threads{1};
  std::uint32_t resolved_threads{1};
  gsolve::MultipleRhsKrylovStrategy requested_multiple_rhs_strategy{
      gsolve::MultipleRhsKrylovStrategy::independent};
  gsolve::MultipleRhsKrylovStrategy resolved_multiple_rhs_strategy{
      gsolve::MultipleRhsKrylovStrategy::independent};
  std::uint64_t probe_batches{0};
  std::uint64_t pcg_operator_applications{0};
  std::uint64_t pcg_preconditioner_applications{0};
  std::uint64_t pcg_operator_processed_columns{0};
  std::uint64_t pcg_preconditioner_processed_columns{0};
  std::uint64_t block_solve_count{0};
  std::uint64_t block_iterations{0};
  std::uint64_t block_rank_loss_events{0};
  std::uint64_t maximum_block_width{0};
  std::uint64_t maximum_block_rank{0};
  PreconditionerPolicy requested_base_preconditioner{
      PreconditionerPolicy::automatic};
  ResolvedPreconditioner resolved_base_preconditioner{
      ResolvedPreconditioner::identity};
  bool parameter_dependent_preconditioner_requested{false};
  bool parameter_dependent_preconditioner_resolved{false};
  ParameterDependentPreconditionerDiagnostics
      parameter_dependent_preconditioner{};
  bool batched_projection_requested{false};
  bool batched_projection_resolved{false};
  BatchedProjectionDiagnostics batched_projection{};
  BatchedProjectionDiagnostics batched_information_projection{};
  bool batched_identity_score_ai_eligible{false};
  bool batched_identity_score_ai_resolved{false};
  double batched_identity_genetic_guard{0.0};
  std::uint64_t batched_information_rhs_width{0};
  bool two_level_preconditioner_requested{false};
  bool two_level_preconditioner_resolved{false};
  bool two_level_preconditioner_fallback_used{false};
  std::uint64_t two_level_preconditioner_rebuild_count{0};
  std::uint64_t two_level_setup_operator_applications{0};
  std::uint64_t two_level_setup_operator_processed_columns{0};
  gsolve::TwoLevelPreconditionerDiagnostics two_level_preconditioner{};
  std::uint64_t fixed_effect_pcg_operator_applications{0};
  std::uint64_t fixed_effect_pcg_preconditioner_applications{0};
  double maximum_fixed_effect_pcg_relative_residual{0.0};
  double covariance_pcg_relative_tolerance{0.0};
  double covariance_pcg_absolute_tolerance{0.0};
  double fixed_effect_pcg_relative_tolerance{0.0};
  double fixed_effect_pcg_absolute_tolerance{0.0};
  std::uint64_t component_applications{0};
  std::uint64_t avoided_trace_component_applications{0};
  std::uint64_t avoided_score_component_applications{0};
  std::uint64_t direct_fallback_component_applications{0};
  std::uint64_t retained_information_projections{0};
  double maximum_pcg_relative_residual{0.0};
  gsolve::PcgBatchResult preparation_solve{};
  gsolve::PcgBatchResult response_solve{};
  gsolve::PcgBatchResult information_solve{};
  gsolve::SlqResult slq{};
  gsolve::SlqResult fixed_effect_determinant_slq{};
  FixedEffectNormalOperatorDiagnostics fixed_effect_normal_operator{};
  AdaptiveStochasticDiagnostics adaptive{};
  AffineSpectralPlanPolicy requested_affine_spectral_plan{
      AffineSpectralPlanPolicy::disabled};
  bool affine_spectral_plan_eligible{false};
  bool affine_spectral_plan_resolved{false};
  std::string affine_spectral_plan_fallback_reason{};
  std::uint64_t affine_plan_build_count{0};
  std::uint64_t affine_plan_extension_count{0};
  std::uint64_t affine_plan_depth_rebuild_count{0};
  std::uint64_t affine_plan_reused_probe_count{0};
  std::uint64_t affine_plan_constructed_probe_count{0};
  std::uint64_t affine_plan_build_operator_applications{0};
  gsolve::AffineSpectralPlanDiagnostics affine_plan{};
  gsolve::AffineSpectralEvaluationResult affine_evaluation{};
};

struct MatrixFreeStochasticResult {
  Status status{};
  LikelihoodMode mode{LikelihoodMode::restricted_maximum_likelihood};
  bool stochastic_approximation{true};
  std::uint64_t observation_count{0};
  std::uint64_t fixed_effect_count{0};
  std::uint64_t component_count{0};
  double log_likelihood{std::numeric_limits<double>::quiet_NaN()};
  bool log_likelihood_available{true};
  double log_likelihood_standard_error{
      std::numeric_limits<double>::quiet_NaN()};
  double log_determinant{std::numeric_limits<double>::quiet_NaN()};
  double log_determinant_standard_error{
      std::numeric_limits<double>::quiet_NaN()};
  double fixed_effect_log_determinant{0.0};
  double fixed_effect_log_determinant_standard_error{0.0};
  FixedEffectProjectionStrategy fixed_effect_projection{
      FixedEffectProjectionStrategy::materialized};
  FixedEffectCovarianceAvailability fixed_effect_covariance_availability{
      FixedEffectCovarianceAvailability::full};
  bool inverse_fixed_effects_available{true};
  double quadratic{std::numeric_limits<double>::quiet_NaN()};
  std::vector<double> parameters{};
  std::vector<double> inverse_response{};
  std::vector<double> inverse_fixed_effects{};
  std::vector<double> beta{};
  std::vector<double> fixed_effect_covariance{};
  std::vector<double> py{};
  // Retained only for the explicit-probe validation route.
  std::vector<double> projected_trace_probes{};
  std::vector<double> score{};
  std::vector<double> trace_estimates{};
  // component-major q-by-probe_count direct trace realizations.
  std::vector<double> trace_probe_contributions{};
  std::vector<double> trace_standard_errors{};
  std::vector<double> score_standard_errors{};
  std::vector<double> average_information{};
  std::vector<double> component_quadratics{};
  // Component-major q-by-observation_count derivative vectors dV_j(PY).
  // Retained score-only states use these to form AI without repeating score
  // or trace work after a trial has passed score-merit acceptance.
  std::vector<double> component_py{};
  std::vector<std::vector<double>> component_predictions{};
  // Retains the exact immutable covariance/preconditioner pairing for the
  // accepted evaluation. Candidate results own independent states.
  std::shared_ptr<const ParameterDependentPreconditionerState>
      parameter_dependent_preconditioner_state{};
  std::shared_ptr<const BatchedProjectionWarmState>
      batched_projection_warm_state{};
  std::shared_ptr<const BatchedProjectionWarmState>
      batched_information_projection_warm_state{};
  MatrixFreeStochasticDiagnostics diagnostics{};
};

class GREML_EXPORT MatrixFreeStochasticWorkspace {
 public:
  Status prepare(std::uint64_t observation_count,
                 std::uint64_t fixed_effect_count,
                 std::uint64_t component_count,
                 std::uint64_t probe_batch_size,
                 std::uint64_t lanczos_steps,
                 std::uint32_t worker_count);

 private:
  friend MatrixFreeStochasticResult evaluate_matrix_free_stochastic(
      gsolve::ConstMatrixView, gsolve::ConstMatrixView,
      const std::vector<MatrixFreeCovarianceComponent>&,
      const std::vector<double>&, const MatrixFreeStochasticOptions&,
      MatrixFreeStochasticWorkspace&, const MatrixFreeStochasticWarmStart*);
  friend MatrixFreeStochasticResult evaluate_matrix_free_stochastic(
      gsolve::ConstMatrixView, std::shared_ptr<const FixedEffectDesign>,
      const std::vector<MatrixFreeCovarianceComponent>&,
      const std::vector<double>&, const MatrixFreeStochasticOptions&,
      MatrixFreeStochasticWorkspace&, const MatrixFreeStochasticWarmStart*);
  std::uint64_t observation_count_{0};
  std::uint64_t fixed_effect_count_{0};
  std::uint64_t component_count_{0};
  std::uint64_t probe_batch_size_{0};
  std::vector<double> probes_{};
  std::vector<double> probe_solutions_{};
  std::vector<double> component_output_{};
  std::vector<double> component_py_{};
  std::vector<double> projected_component_py_{};
  MatrixFreeProjectionWorkspace response_workspace_{};
  MatrixFreeProjectionWorkspace probe_workspace_{};
  MatrixFreeProjectionWorkspace information_workspace_{};
  gsolve::Workspace component_workspace_{};
  gsolve::SlqWorkspace slq_workspace_{};
  gsolve::SlqWorkspace fixed_effect_slq_workspace_{};
  std::shared_ptr<const gsolve::AffineSpectralPlan> affine_spectral_plan_{};
  gsolve::AffineSpectralPlanWorkspace affine_spectral_workspace_{};
};

struct StochasticEvaluationWorkDiagnostics {
  std::uint64_t initial_evaluations{0};
  std::uint64_t initial_covariance_applications{0};
  std::uint64_t initial_probe_solves{0};
  std::uint64_t initial_slq_applications{0};
  std::uint64_t accepted_full_evaluations{0};
  std::uint64_t trial_likelihood_only_evaluations{0};
  std::uint64_t final_result_evaluations{0};
  std::uint64_t avoided_score_ai_evaluations{0};
  std::uint64_t accepted_score_ai_evaluations{0};
  std::uint64_t rejected_score_ai_evaluations{0};
  std::uint64_t convergence_verification_evaluations{0};
  std::uint64_t independent_verification_evaluations{0};
  std::uint64_t final_likelihood_only_evaluations{0};
  std::uint64_t trial_score_only_evaluations{0};
  std::uint64_t accepted_ai_only_evaluations{0};
  std::uint64_t retained_accepted_state_reuses{0};
  std::uint64_t accepted_full_covariance_applications{0};
  std::uint64_t trial_covariance_applications{0};
  std::uint64_t final_covariance_applications{0};
  std::uint64_t accepted_full_probe_solves{0};
  std::uint64_t trial_probe_solves{0};
  std::uint64_t final_probe_solves{0};
  std::uint64_t accepted_full_slq_applications{0};
  std::uint64_t trial_slq_applications{0};
  std::uint64_t final_slq_applications{0};
  std::uint64_t accepted_score_ai_slq_applications{0};
  std::uint64_t rejected_score_ai_slq_applications{0};
  std::uint64_t convergence_verification_slq_applications{0};
  std::uint64_t independent_verification_slq_applications{0};
  std::uint64_t final_likelihood_only_slq_applications{0};
  std::uint64_t trial_score_only_slq_applications{0};
  std::uint64_t accepted_ai_only_slq_applications{0};
  double accepted_full_seconds{0.0};
  double initial_seconds{0.0};
  double trial_likelihood_only_seconds{0.0};
  double final_result_seconds{0.0};
  double accepted_score_ai_seconds{0.0};
  double rejected_score_ai_seconds{0.0};
  double convergence_verification_seconds{0.0};
  double independent_verification_seconds{0.0};
  double final_likelihood_only_seconds{0.0};
  double trial_score_only_seconds{0.0};
  double accepted_ai_only_seconds{0.0};
  std::uint32_t batched_requested_threads{0};
  std::uint32_t batched_resolved_threads{0};
  std::uint64_t batched_projection_calls{0};
  std::uint64_t batched_processed_systems{0};
  std::uint64_t batched_warm_systems{0};
  std::uint64_t batched_symmetric_sweeps{0};
  // Compatibility counter: primary/information marker-MME batches only.
  std::uint64_t batched_packed_decode_passes{0};
  std::uint64_t batched_total_packed_decode_passes{0};
  std::uint64_t batched_total_marker_visits{0};
  double batched_total_decode_seconds{0.0};
  double batched_total_compute_seconds{0.0};
  std::uint64_t batched_coefficient_cache_hits{0};
  std::uint64_t batched_coefficient_cache_misses{0};
  std::uint64_t batched_coefficient_cache_reused_columns{0};
  std::uint64_t batched_coefficient_cache_appended_columns{0};
  std::uint64_t batched_coefficient_cache_peak_bytes{0};
  std::uint64_t covariance_packed_decode_passes{0};
  std::uint64_t covariance_marker_visits{0};
  double covariance_decode_seconds{0.0};
  double covariance_compute_seconds{0.0};
  std::uint64_t total_packed_decode_passes{0};
  std::uint64_t total_marker_visits{0};
};

enum class StagedPrecisionEscalationReason {
  accepted_iteration = 0,
  approaching_convergence,
  ambiguous_likelihood,
  boundary_decision,
  final_verification
};

struct StagedPrecisionLevel {
  std::uint64_t probe_count{16};
  std::uint64_t probe_batch_size{8};
  std::uint64_t lanczos_steps{20};
  double covariance_pcg_relative_tolerance{1.0e-6};
  double covariance_pcg_absolute_tolerance{0.0};
  double fixed_effect_pcg_relative_tolerance{1.0e-6};
  double fixed_effect_pcg_absolute_tolerance{0.0};
  std::uint64_t fixed_effect_determinant_probe_count{16};
  std::uint64_t fixed_effect_determinant_lanczos_steps{20};
  double maximum_trace_standard_error{1.0e-2};
  double maximum_score_standard_error{5.0e-3};
};

struct StagedOptimizationPrecisionOptions {
  bool enabled{false};
  StagedPrecisionLevel initial{};
  StagedPrecisionLevel working{};
  StagedPrecisionLevel final{};
  std::uint64_t working_after_accepted_iterations{2};
  double near_convergence_factor{5.0};
};

GREML_EXPORT Status validate_staged_optimization_precision(
    const StagedOptimizationPrecisionOptions& options);

struct StagedPrecisionEscalationRecord {
  std::uint64_t previous_stage{0};
  std::uint64_t next_stage{0};
  std::uint64_t accepted_iteration{0};
  StagedPrecisionEscalationReason reason{
      StagedPrecisionEscalationReason::accepted_iteration};
};

struct StagedOptimizationPrecisionDiagnostics {
  bool enabled{false};
  std::uint64_t initial_stage{0};
  std::uint64_t final_stage{0};
  StagedPrecisionLevel initial_precision{};
  StagedPrecisionLevel final_precision{};
  StagedPrecisionLevel achieved_precision{};
  bool final_precision_requested{false};
  bool final_precision_achieved{false};
  bool convergence_withheld{false};
  std::uint64_t common_precision_reevaluations{0};
  std::vector<StagedPrecisionEscalationRecord> escalations{};
  std::vector<std::uint64_t> evaluations_by_stage{};
  std::vector<std::uint64_t> covariance_applications_by_stage{};
  std::vector<std::uint64_t> probe_solves_by_stage{};
  std::vector<std::uint64_t> slq_applications_by_stage{};
};

// Component descriptors provide operators, diagonals, and names; coefficients
// are replaced by parameters. Generated probes are processed in bounded
// batches and are identical at every call for the same reusable probe plan.
GREML_EXPORT MatrixFreeStochasticResult evaluate_matrix_free_stochastic(
    gsolve::ConstMatrixView response, gsolve::ConstMatrixView fixed_effects,
    const std::vector<MatrixFreeCovarianceComponent>& component_templates,
    const std::vector<double>& parameters,
    const MatrixFreeStochasticOptions& options,
    MatrixFreeStochasticWorkspace& workspace,
    const MatrixFreeStochasticWarmStart* warm_start = nullptr);

// Adaptive variants retain the fixed-precision entry points above unchanged.
// Every refinement reconstructs a prefix plan from the same seed; storage is
// bounded by precision.probe_batch_size (except the optional explicit-probe
// validation route, whose storage is caller-owned).
GREML_EXPORT MatrixFreeStochasticResult
evaluate_matrix_free_stochastic_adaptive(
    gsolve::ConstMatrixView response, gsolve::ConstMatrixView fixed_effects,
    const std::vector<MatrixFreeCovarianceComponent>& component_templates,
    const std::vector<double>& parameters,
    const MatrixFreeStochasticOptions& options,
    const AdaptiveStochasticPrecisionOptions& precision,
    MatrixFreeStochasticWorkspace& workspace,
    const MatrixFreeStochasticWarmStart* warm_start = nullptr);

GREML_EXPORT MatrixFreeStochasticResult
evaluate_matrix_free_stochastic_adaptive(
    gsolve::ConstMatrixView response,
    std::shared_ptr<const FixedEffectDesign> fixed_effects,
    const std::vector<MatrixFreeCovarianceComponent>& component_templates,
    const std::vector<double>& parameters,
    const MatrixFreeStochasticOptions& options,
    const AdaptiveStochasticPrecisionOptions& precision,
    MatrixFreeStochasticWorkspace& workspace,
    const MatrixFreeStochasticWarmStart* warm_start = nullptr);

// FixedEffectDesign overload. It preserves compact factor/sparse/packed design
// representations during projection preparation and avoids an additional
// complete dense copy of the design.
GREML_EXPORT MatrixFreeStochasticResult evaluate_matrix_free_stochastic(
    gsolve::ConstMatrixView response,
    std::shared_ptr<const FixedEffectDesign> fixed_effects,
    const std::vector<MatrixFreeCovarianceComponent>& component_templates,
    const std::vector<double>& parameters,
    const MatrixFreeStochasticOptions& options,
    MatrixFreeStochasticWorkspace& workspace,
    const MatrixFreeStochasticWarmStart* warm_start = nullptr);

enum class MatrixFreeOptimizationStatusCode {
  converged = 0,
  maximum_iterations,
  invalid_initial_values,
  pcg_failure,
  slq_failure,
  singular_ai_system,
  failed_line_search,
  no_valid_ascent_direction,
  restart_exhaustion,
  active_set_cycling,
  structurally_nonidentifiable,
  insufficient_stochastic_precision,
  numerical_failure,
  invalid_precision_configuration,
  insufficient_linear_solve_precision,
  invalid_parameter_constraints,
  sparse_symbolic_analysis_failure,
  sparse_numerical_factorization_failure,
  covariance_construction_failure,
  preconditioner_construction_failure,
  active_set_incompatibility,
  fixed_effect_pcg_failure,
  fixed_effect_slq_failure,
  fixed_effect_rank_failure,
  block_rank_failure
};

class MatrixFreeOptimizationStatus {
 public:
  MatrixFreeOptimizationStatus() = default;
  MatrixFreeOptimizationStatus(MatrixFreeOptimizationStatusCode code,
                               std::string message)
      : code_(code), message_(std::move(message)) {}
  [[nodiscard]] bool is_converged() const noexcept {
    return code_ == MatrixFreeOptimizationStatusCode::converged;
  }
  [[nodiscard]] MatrixFreeOptimizationStatusCode code() const noexcept {
    return code_;
  }
  [[nodiscard]] const std::string& message() const noexcept { return message_; }

 private:
  MatrixFreeOptimizationStatusCode code_{
      MatrixFreeOptimizationStatusCode::numerical_failure};
  std::string message_{"optimizer did not run"};
};

struct MatrixFreeOptimizerOptions {
  MatrixFreeStochasticOptions evaluation{};
  AdaptiveStochasticPrecisionOptions adaptive_precision{};
  StagedOptimizationPrecisionOptions staged_precision{};
  MatrixFreeAcceptancePolicy acceptance_policy{
      MatrixFreeAcceptancePolicy::likelihood_monotone};
  struct DeterminantDeferredOptions {
    double maximum_curvature_scaled_score{1.0e-3};
    double maximum_newton_decrement{1.0e-3};
    std::uint64_t stable_active_set_iterations{2};
    std::uint64_t verification_probe_count{64};
    std::uint64_t verification_probe_seed{0x9e3779b97f4a7c15ULL};
    double verification_standard_error_multiplier{3.0};
    double verification_absolute_tolerance{1.0e-4};
    bool require_larger_final_probe_prefix{true};
  } determinant_deferred{};
  std::uint64_t maximum_iterations{30};
  double score_tolerance{1.0e-4};
  double relative_parameter_tolerance{1.0e-6};
  double minimum_positive_value{1.0e-8};
  std::uint64_t maximum_line_search_reductions{16};
  double maximum_score_standard_error{1.0e-2};
  double maximum_pcg_relative_residual{1.0e-6};
  SafeguardedOptimizerOptions safeguard{};
  bool retain_history{false};
};

struct MatrixFreeIterationRecord {
  std::uint64_t iteration{0};
  std::uint64_t evaluation_count{0};
  double log_likelihood{std::numeric_limits<double>::quiet_NaN()};
  double projected_score_norm{std::numeric_limits<double>::quiet_NaN()};
  double curvature_scaled_score_norm{
      std::numeric_limits<double>::quiet_NaN()};
  double newton_decrement{std::numeric_limits<double>::quiet_NaN()};
  double score_merit{std::numeric_limits<double>::quiet_NaN()};
  double maximum_score_standard_error{
      std::numeric_limits<double>::quiet_NaN()};
  double relative_parameter_change{std::numeric_limits<double>::quiet_NaN()};
  double accepted_step_scale{0.0};
  double ai_diagonal_damping{0.0};
  StochasticPrecisionState precision_state{};
  std::vector<double> parameters{};
  SafeguardedIterationDiagnostics safeguard{};
};

struct MatrixFreeOptimizationResult {
  MatrixFreeOptimizationStatus status{};
  bool stochastic_approximation{true};
  std::vector<double> parameters{};
  std::vector<double> projected_score{};
  MatrixFreeStochasticResult evaluation{};
  std::uint64_t iterations{0};
  std::uint64_t evaluation_count{0};
  std::uint64_t stable_active_set_iterations{0};
  std::uint64_t total_two_level_preconditioner_rebuilds{0};
  std::uint64_t total_two_level_setup_operator_applications{0};
  std::uint64_t total_two_level_setup_operator_processed_columns{0};
  UnifiedOptimizerDiagnostics optimizer_diagnostics{};
  StochasticEvaluationWorkDiagnostics work_diagnostics{};
  StagedOptimizationPrecisionDiagnostics staged_precision{};
  std::vector<MatrixFreeIterationRecord> history{};
};

GREML_EXPORT MatrixFreeOptimizationResult optimize_matrix_free_stochastic(
    gsolve::ConstMatrixView response, gsolve::ConstMatrixView fixed_effects,
    const std::vector<MatrixFreeCovarianceComponent>& component_templates,
    const std::vector<double>& initial_parameters,
    const std::vector<ComponentConstraint>& constraints,
    const MatrixFreeOptimizerOptions& options,
    MatrixFreeStochasticWorkspace& workspace);

GREML_EXPORT MatrixFreeOptimizationResult optimize_matrix_free_stochastic(
    gsolve::ConstMatrixView response,
    std::shared_ptr<const FixedEffectDesign> fixed_effects,
    const std::vector<MatrixFreeCovarianceComponent>& component_templates,
    const std::vector<double>& initial_parameters,
    const std::vector<ComponentConstraint>& constraints,
    const MatrixFreeOptimizerOptions& options,
    MatrixFreeStochasticWorkspace& workspace);

}  // namespace greml

#endif
