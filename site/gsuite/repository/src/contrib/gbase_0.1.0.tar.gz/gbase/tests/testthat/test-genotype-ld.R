test_that("gfilter selects canonical Glist markers without changing the resource", {
  fixture <- write_tiny_plink(cbind(
    keep = c(0, 1, 2, 0, 1, 2),
    rare = c(0, 0, 0, 0, 0, 0)),
    c("keep", "rare"))
  on.exit(unlink_tiny_plink(fixture), add = TRUE)
  Glist <- gprep(bedfiles = fixture$paths[["bed"]])
  before <- serialize(Glist, NULL)
  expect_identical(gfilter(Glist, hwe = NULL, verbose = FALSE), "keep")
  expect_identical(serialize(Glist, NULL), before)
})

test_that("Glist LD utilities agree with dense deterministic calculations", {
  genotype <- cbind(
    a = c(0, 0, 1, 1, 2, 2),
    b = c(0, 0, 1, 1, 2, 2),
    c = c(2, 2, 1, 1, 0, 0))
  fixture <- write_tiny_plink(genotype, colnames(genotype))
  prefix <- tempfile("gbase-ld-utils-")
  on.exit({ unlink_tiny_plink(fixture); unlink_sparse_ld(prefix) }, add = TRUE)
  Glist <- gprep(bedfiles = fixture$paths[["bed"]])
  Glist <- gprep(Glist, task = "sparseld", out_prefix = prefix,
    max_distance_bp = 0, max_distance_variants = 10, r2 = 0,
    block_size = 2, nthreads = 1)
  expected <- cor(genotype)
  expected[] <- readBin(writeBin(as.double(expected), raw(), size = 4),
    "double", n = length(expected), size = 4)
  dimnames(expected) <- list(colnames(genotype), colnames(genotype))
  expect_equal(ld_region(Glist, colnames(genotype)), expected, tolerance = 1e-12)
  expect_equal(ld_region(Glist, c("a", "c")), expected[c("a", "c"), c("a", "c")])
  expect_error(ld_region(Glist, c("c", "a")), "reference order")
  expect_error(ld_region(Glist, colnames(genotype), maximum_dimension = 2),
    "maximum_dimension")

  expect_equal(unname(ld_scores(Glist)), unname(rowSums(expected^2)), tolerance = 3e-6)
  correction <- expected^2
  correction[row(correction) != col(correction)] <-
    correction[row(correction) != col(correction)] -
    (1 - correction[row(correction) != col(correction)]) / (nrow(genotype) - 2)
  expect_equal(unname(ld_scores(Glist, corrected = TRUE)), unname(rowSums(correction)),
    tolerance = 3e-6)
  annotation <- cbind(first = c(1, 0, 0), rest = c(0, 1, 1))
  rownames(annotation) <- c("a", "b", "c")
  expect_equal(unname(ld_scores(Glist, annotation)),
    unname(expected^2 %*% annotation), tolerance = 3e-6)

  eigen_result <- ld_eigen(Glist, colnames(genotype))
  expect_equal(eigen_result$values, eigen(expected, symmetric = TRUE)$values,
    tolerance = 1e-10)
  expect_equal(unname(eigen_result$vectors %*% diag(eigen_result$values) %*%
      t(eigen_result$vectors)), unname(expected), tolerance = 1e-10)
  expect_identical(rownames(eigen_result$vectors), colnames(genotype))
  expect_lt(eigen_result$diagnostics$relative_reconstruction_error, 1e-10)
})

test_that("LD utilities require one validated Glist owner", {
  fixture <- write_tiny_plink(cbind(a = c(0, 1, 2), b = c(2, 1, 0)), c("a", "b"))
  on.exit(unlink_tiny_plink(fixture), add = TRUE)
  Glist <- gprep(bedfiles = fixture$paths[["bed"]])
  expect_error(ld_scores(Glist), "task = 'sparseld'")
  expect_error(ld_region(Glist, "a"), "task = 'sparseld'")
  expect_error(ld_eigen(Glist, "a"), "task = 'sparseld'")
})

test_that("independent LD blocks are verified once and remain serializable", {
  genotype <- cbind(
    a = c(0, 0, 1, 1, 2, 2),
    b = c(0, 0, 1, 1, 2, 2),
    c = c(2, 2, 1, 1, 0, 0))
  fixture <- write_tiny_plink(genotype, colnames(genotype))
  prefix <- tempfile("gbase-ld-blocks-")
  on.exit({ unlink_tiny_plink(fixture); unlink_sparse_ld(prefix) }, add = TRUE)
  Glist <- gprep(bedfiles = fixture$paths[["bed"]])
  Glist <- gprep(Glist, task = "sparseld", out_prefix = prefix,
    max_distance_bp = 0, max_distance_variants = 10, r2 = 0,
    block_size = 2, nthreads = 1)
  manifest <- data.frame(block_id = "genome", first_marker = "a",
    last_marker = "c")
  blocked <- define_ld_blocks(Glist, manifest)
  expect_identical(blocked$ldBlocks$offsets_0based, c(0, 3))
  expect_identical(blocked$ldBlocks$blocks$marker_count, 3L)
  expect_invisible(validate_Glist(unserialize(serialize(blocked, NULL))))

  expect_error(define_ld_blocks(Glist, data.frame(block_id = c("x", "y"),
    first_marker = c("a", "b"), last_marker = c("a", "c"))),
    "cross-block correlation")
  expect_error(define_ld_blocks(Glist, data.frame(block_id = "x",
    first_marker = "b", last_marker = "c")), "exhaustive partition")
  tampered <- blocked
  tampered$ldBlocks$sparse_ld_checksums[[1L]] <- "changed"
  expect_error(validate_Glist(tampered), "not tied")
})
