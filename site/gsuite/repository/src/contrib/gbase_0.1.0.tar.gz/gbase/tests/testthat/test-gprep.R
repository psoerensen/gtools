test_that("gbase checks its exact native contracts", {
  info <- gbase_native_info()
  expect_identical(info$gmat$header_version, "0.6.0")
  expect_equal(info$gmat$header_abi, 0)
  expect_identical(info$gmat$runtime_version, "0.6.0")
  expect_equal(info$gmat$runtime_abi, 0)
  expect_identical(info$gbits$header_version, "0.21.0")
  expect_equal(info$gbits$header_abi, 4)
  expect_identical(info$gbits$runtime_version, "0.21.0")
  expect_equal(info$gbits$runtime_abi, 4)
  expect_identical(info$gsolve$header_version, "0.22.0")
  expect_equal(info$gsolve$header_abi, 4)
  expect_identical(info$gsolve$runtime_version, "0.22.0")
  expect_equal(info$gsolve$runtime_abi, 4)
})

test_that("gprep prepares deterministic canonical summaries", {
  fixture <- write_tiny_plink(matrix(c(
    0, 1, 2,
    1, 2, NA,
    2, 0, 1,
    0, 1, 2
  ), nrow = 4L, byrow = TRUE), c("rs-a", "rs-b", "rs-c"))
  on.exit(unlink_tiny_plink(fixture), add = TRUE)
  value <- gprep(study = "tiny", bedfiles = fixture$paths[["bed"]],
    ids = c("I3", "I1", "I0"), rsids = c("rs-c", "rs-a"))
  expect_s3_class(value, "gs_genotypes")
  expect_identical(class(value), c("gs_genotypes", "Glist"))
  expect_identical(value$study_ids, c("I3", "I1", "I0"))
  expect_identical(value$rsids, list(c("rs-a", "rs-c")))
  expect_equal(value$source_marker_indices_0based, list(c(0, 2)))
  expect_equal(value$physical_marker_counts, 3)
  expect_equal(value$n0, list(c(2, 0)))
  expect_equal(value$n1, list(c(1, 0)))
  expect_equal(value$n2, list(c(0, 2)))
  expect_equal(value$nmiss, list(c(0, 1)))
  expect_equal(value$af, list(c(1 / 6, 1)))
  expect_invisible(validate_Glist(value))

  saved <- tempfile(fileext = ".rds")
  on.exit(unlink(saved), add = TRUE)
  saveRDS(value, saved)
  expect_identical(readRDS(saved), value)
})

test_that("gprep retains empty components after marker selection", {
  first <- write_tiny_plink(matrix(c(0, 1, 2, 1, 2, 0), ncol = 2L),
    c("first-a", "first-b"))
  second <- write_tiny_plink(matrix(c(2, 1, 0), ncol = 1L), "second-a")
  on.exit({ unlink_tiny_plink(first); unlink_tiny_plink(second) }, add = TRUE)

  value <- gprep(
    bedfiles = c(first$paths[["bed"]], second$paths[["bed"]]),
    rsids = "second-a")

  expect_identical(value$rsids, list(character(), "second-a"))
  expect_identical(value$mchr, c(0L, 1L))
  expect_identical(value$n0[[1L]], numeric())
  expect_identical(value$n1[[1L]], numeric())
  expect_identical(value$n2[[1L]], numeric())
  expect_identical(value$nmiss[[1L]], numeric())
  expect_invisible(validate_Glist(value))
})

test_that("sparseld augments Glist and publishes deterministic LD", {
  fixture <- write_tiny_plink(matrix(c(
    0, 0, 2,
    0, 0, 2,
    1, 1, 1,
    1, 1, 1,
    2, 2, 0,
    2, 2, 0
  ), nrow = 6L, byrow = TRUE), c("a", "a-copy", "negative"))
  prefix <- tempfile("gbase-sparseld-")
  on.exit({ unlink_tiny_plink(fixture); unlink_sparse_ld(prefix) }, add = TRUE)
  prepared <- gprep(bedfiles = fixture$paths[["bed"]],
    ids = c("I5", "I1", "I3", "I0"))
  value <- gprep(Glist = prepared, task = "sparseld", out_prefix = prefix,
    rsids = c("negative", "a"),
    max_distance_bp = 0, max_distance_variants = 3, r2 = 0,
    block_size = 2, nthreads = 1)
  expect_identical(value$idsLD, prepared$study_ids)
  expect_identical(value$rsidsLD, list(c("a", "negative")))
  expect_equal(value$sparseLD$sample_indices_0based, c(5, 1, 3, 0))
  expect_equal(value$sparseLD$marker_indices_0based, list(c(0, 2)))
  expect_equal(value$sparseLD$m, 2)
  expect_equal(value$sparseLD$nnz, 1)
  expect_equal(unname(value$ldscores[[1]]), rep(2, 2), tolerance = 3e-6)
  expect_true(all(file.exists(unlist(value$sparseLD$paths))))
  expect_identical(value$ldfiles, value$sparseLD$paths)
  expect_identical(names(value$sparseLD$checksums), names(value$sparseLD$paths))
  expect_invisible(validate_Glist(value))
  expect_invisible(verify_ld(value))
  changed <- value
  changed$sparseLD$checksums[[1L]] <- paste0("changed-", changed$sparseLD$checksums[[1L]])
  expect_invisible(validate_Glist(changed))
  expect_error(verify_ld(changed), "changed after preparation")

  wrong_samples <- value
  wrong_samples$idsLD <- rev(wrong_samples$idsLD)
  expect_error(validate_Glist(wrong_samples), "idsLD")
  wrong_markers <- value
  wrong_markers$rsidsLD[[1L]] <- rev(wrong_markers$rsidsLD[[1L]])
  expect_error(validate_Glist(wrong_markers), "rsidsLD")
  wrong_files <- value
  wrong_files$ldfiles$values <- wrong_files$ldfiles$row_ptr
  expect_error(validate_Glist(wrong_files), "ldfiles")

  writeBin(as.raw(0), value$sparseLD$paths$values)
  expect_invisible(validate_Glist(value))
  expect_error(verify_ld(value))
})
