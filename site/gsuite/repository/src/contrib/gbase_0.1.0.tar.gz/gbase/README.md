# gbase

`gbase` contains small, task-neutral R data contracts shared by the gsuite
ecosystem. It performs no statistical fitting. Its genotype preparation contract
uses the installed public `gmat`, `gbits`, and `gsolve` interfaces, with a
qualified native prefix checked during compilation and native versions and ABIs
checked again when the package loads. `gsolve` is used only for verified dense
regional eigensystems; the portable binary disables CHOLMOD, MKL and PARDISO
while retaining OpenMP support.

Summary statistics use the established qgg workflow: `checkStat()` maps and
aligns an ordinary data frame to Glist, applies explicit QC, and returns an
ordinary data frame with familiar short column names:

```r
library(gbase)

stat <- checkStat(Glist = Glist, stat = raw_stat)
```

The result has no special summary-statistics class, constructor or accessor.
Each task function validates the columns it uses, and statistical work belongs
to the task package.

PLINK genotype resources are prepared once and remain serializable:

```r
Glist <- gprep(bedfiles = c("chr1.bed", "chr2.bed"))
Glist <- gprep(
  Glist = Glist,
  task = "sparseld",
  out_prefix = "reference",
  max_distance_bp = 1000000,
  max_distance_variants = 1000,
  r2 = 0.01
)
```

The second call returns the same `Glist` contract augmented with its sparse-LD
descriptor; it does not introduce a separate genotype or LD owner.

The same Glist is the input to task-neutral marker and LD utilities:

```r
markers <- gfilter(Glist)
scores <- ld_scores(Glist)
region <- ld_region(Glist, markers = markers[1:100])
spectrum <- ld_eigen(Glist, markers = markers[1:100])

blocks <- data.frame(block_id = "chr1", first_marker = markers[1],
  last_marker = markers[length(markers)])
Glist <- define_ld_blocks(Glist, blocks)
```

Sparse-LD construction and metadata stay on the Glist returned by
`gprep(task = "sparseld")`.
