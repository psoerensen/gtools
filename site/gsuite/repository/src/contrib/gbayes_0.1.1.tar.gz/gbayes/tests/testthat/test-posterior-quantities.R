test_that("posterior quantities use explicit references and Glist marker subsets", {
  fixture <- gbayes_summary_fixture()
  on.exit(remove_gbayes_summary_fixture(fixture), add = TRUE)
  target <- gbase::gprep(bedfiles = fixture$paths[["bed"]],
    rsids = c("m1", "m3"))
  groups <- setNames(c("left", "left", "right", "right"), paste0("m", 1:4))
  selected_ids <- rev(target$ids)[1:4]
  fit <- gbayes(fixture$stat, fixture$Glist, method = "bayesc",
    prior = list(residual_variance = 1, effect_variance = 0.1,
      inclusion_probability = 0.25),
    control = list(burnin = 10, sampling_sweeps = 30, thinning = 2,
      seeds = c(17, 29), storage = "memory"), trait = "height",
    posterior = list(reference = fixture$Glist, partition = groups,
      phenotype_variance = c(height = 1), prediction = list(
        Glist = target, ids = selected_ids, target_set = "subset",
        retain_draws = TRUE, batch_size = 2)))

  expect_true(all(c("genetic", "heritability", "partition", "prediction") %in%
    names(fit$quantities)))
  expect_identical(rownames(fit$quantities$prediction$mean), selected_ids)
  expect_identical(fit$quantities$prediction$coverage$used_markers, 2L)
  expect_identical(fit$quantities$prediction$coverage$omitted_fitted_markers, 2L)
  rows <- match(selected_ids, target$ids)
  columns <- match(c("m1", "m3"), paste0("m", 1:4))
  dosage <- fixture$genotype[rows, columns, drop = FALSE]
  p <- unlist(target$af, use.names = FALSE)
  standardized <- sweep(sweep(dosage, 2L, 2 * p), 2L,
    sqrt(2 * p * (1 - p)), "/")
  expected <- drop(standardized %*%
    fit$estimates$mean[match(c("m1", "m3"), fit$estimates$marker)])
  expect_equal(unname(drop(fit$quantities$prediction$mean)), unname(expected),
    tolerance = 1e-12)
  expect_equal(unname(fit$quantities$heritability$mean),
    unname(diag(fit$quantities$genetic$covariance_mean)), tolerance = 1e-12)
  expect_identical(fit$quantities$partition$groups, c("left", "right"))
  expect_true(any(grepl("^score\\[", fit$posterior$parameter)))
})

test_that("posterior prediction rejects markers outside the fitted model", {
  fixture <- gbayes_summary_fixture()
  on.exit(remove_gbayes_summary_fixture(fixture), add = TRUE)
  bad <- fixture$Glist
  bad$rsids[[1L]][[1L]] <- "not-fitted"
  expect_error(gbayes(fixture$stat, fixture$Glist, method = "bayesc",
    control = list(burnin = 1, sampling_sweeps = 2, seeds = 3),
    posterior = list(prediction = list(Glist = bad))),
    "Glist markers|fitted posterior effect")
})

test_that("multivariate posterior prediction preserves trait and Glist order", {
  fixture <- gbayes_summary_fixture()
  on.exit(remove_gbayes_summary_fixture(fixture), add = TRUE)
  target <- gbase::gprep(bedfiles = fixture$paths[["bed"]], rsids = c("m2", "m4"))
  traits <- c("height", "weight")
  stat <- list(height = fixture$stat,
    weight = transform(fixture$stat, b = b * c(0.5, -1, 1.5, 2)))
  effect <- matrix(c(0.04, 0.01, 0.01, 0.03), 2L,
    dimnames = list(traits, traits))
  ids <- target$ids[c(2, 5)]
  fit <- gbayes(stat, fixture$Glist, method = "bayesc",
    prior = list(effect_covariance = effect),
    sampling = list(dependence = "independent",
      residual_variance = c(height = 1, weight = 0.8)),
    control = list(burnin = 2, sampling_sweeps = 6, seeds = c(13, 29)),
    posterior = list(prediction = list(Glist = target, ids = ids)))
  expect_identical(dimnames(fit$quantities$prediction$mean), list(ids, traits))
  columns <- match(c("m2", "m4"), paste0("m", 1:4))
  dosage <- fixture$genotype[match(ids, target$ids), columns, drop = FALSE]
  p <- unlist(target$af, use.names = FALSE)
  standardized <- sweep(sweep(dosage, 2L, 2 * p), 2L,
    sqrt(2 * p * (1 - p)), "/")
  expected <- standardized %*% fit$estimates$mean[c("m2", "m4"), , drop = FALSE]
  expect_equal(unname(fit$quantities$prediction$mean), unname(expected),
    tolerance = 1e-12)
})

test_that("posterior prediction combines multiple active Glist BED components", {
  fixture <- gbayes_summary_fixture()
  on.exit(remove_gbayes_summary_fixture(fixture), add = TRUE)
  prefixes <- c(tempfile("gbayes-target-a-"), tempfile("gbayes-target-b-"))
  paths <- lapply(prefixes, function(prefix) setNames(
    paste0(prefix, c(".bed", ".bim", ".fam")), c("bed", "bim", "fam")))
  on.exit(unlink(unlist(paths, use.names = FALSE)), add = TRUE)
  samples <- data.frame(paste0("F", 1:6), paste0("I", 1:6), 0, 0, 0, -9)
  for (k in 1:2) {
    columns <- if (k == 1L) 1:2 else 3:4
    write_gbayes_bed(fixture$genotype[, columns, drop = FALSE],
      paths[[k]][["bed"]])
    markers <- data.frame("1", paste0("m", columns), 0, 100 * columns,
      "A", "G")
    write.table(markers, paths[[k]][["bim"]], quote = FALSE,
      row.names = FALSE, col.names = FALSE)
    write.table(samples, paths[[k]][["fam"]], quote = FALSE,
      row.names = FALSE, col.names = FALSE)
  }
  target <- gbase::gprep(
    bedfiles = vapply(paths, `[[`, character(1), "bed"),
    rsids = c("m1", "m4"))
  ids <- target$ids[c(6, 2, 4)]
  fit <- gbayes(fixture$stat, fixture$Glist, method = "bayesc",
    prior = list(residual_variance = 1, effect_variance = 0.1,
      inclusion_probability = 0.25),
    control = list(burnin = 3, sampling_sweeps = 8, seeds = c(11, 23)),
    posterior = list(prediction = list(Glist = target, ids = ids)))

  expect_identical(fit$quantities$prediction$coverage$active_bed_components, 2L)
  expect_identical(rownames(fit$quantities$prediction$mean), ids)
  dosage <- fixture$genotype[match(ids, target$ids), c(1, 4), drop = FALSE]
  frequency <- unlist(target$af, use.names = FALSE)
  standardized <- sweep(sweep(dosage, 2L, 2 * frequency), 2L,
    sqrt(2 * frequency * (1 - frequency)), "/")
  expected <- drop(standardized %*%
    fit$estimates$mean[match(c("m1", "m4"), fit$estimates$marker)])
  expect_equal(unname(drop(fit$quantities$prediction$mean)), unname(expected),
    tolerance = 1e-12)
})
