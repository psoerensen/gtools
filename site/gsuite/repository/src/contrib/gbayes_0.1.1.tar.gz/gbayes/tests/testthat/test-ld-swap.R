test_that("familiar genome LD swaps run on sparse and block-eigen BayesC/BayesR", {
  first <- rep(0:2, each = 4)
  second <- first; second[1] <- 1
  genotype <- cbind(first, second, rep(c(0, 1, 2, 1), 3),
    rep(c(0, 2, 1, 0), 3))
  fixture <- gbayes_summary_fixture(full_ld = TRUE, genotype = genotype)
  on.exit(remove_gbayes_summary_fixture(fixture))
  G <- gbase::define_ld_blocks(fixture$Glist, data.frame(block_id = "all",
    first_marker = "m1", last_marker = "m4"))
  stat <- fixture$stat
  stat$b <- c(.25, .24, 0, 0); stat$seb <- .2; stat$n <- nrow(genotype)
  run <- function(algorithm, method, swap = NULL) {
    gbayes(stat, G, method = method, algorithm = algorithm,
      nit = 100, nburn = 10, nrun = 2, seed = 31, ve = 1, vb = .2,
      pi = if (method == "bayesC") c(.7, .3) else c(.7, .2, .1),
      gamma = if (method == "bayesC") c(0, 1) else c(0, .1, 1),
      updateB = FALSE, updateE = FALSE, updatePi = FALSE,
      control = c(list(ld_swap = swap), if (algorithm == "mcmc-eigen")
        list(eigen_control = list(retained_positive_mass = 1))))
  }
  for (algorithm in c("mcmc", "mcmc-eigen")) for (method in c("bayesC", "bayesR")) {
    settings <- list(probability = 1, minimum_r2 = .8, moves = 2L)
    fit <- run(algorithm, method, settings)
    repeat_fit <- run(algorithm, method, settings)
    expect_identical(fit$estimates, repeat_fit$estimates)
    expect_identical(fit$ld_swap, repeat_fit$ld_swap)
    expect_gt(fit$ld_swap$attempted, 0)
    expect_gt(fit$ld_swap$accepted, 0)
    expect_lte(fit$ld_swap$accepted, fit$ld_swap$attempted)
    expect_equal(fit$ld_swap$acceptance_rate,
      fit$ld_swap$accepted / fit$ld_swap$attempted)
    expect_equal(fit$ld_swap$attempted, sum(vapply(fit$chains,
      function(x) x$ld_swap_attempted, numeric(1))))
    expect_equal(fit$ld_swap$accepted, sum(vapply(fit$chains,
      function(x) x$ld_swap_accepted, numeric(1))))
    expect_true(all(is.finite(fit$estimates$mean)))
    none <- run(algorithm, method)
    disabled <- run(algorithm, method, list(probability = 0))
    expect_identical(none$estimates, disabled$estimates)
    expect_equal(none$control$ld_swap$probability, 0)
    expect_equal(none$ld_swap$attempted, 0)
    expect_true(is.na(none$ld_swap$acceptance_rate))
    isolated <- run(algorithm, method, list(probability = 1, minimum_r2 = 1))
    expect_equal(isolated$ld_swap$attempted, 0)
  }
})

test_that("genome swap controls reject invalid settings", {
  for (settings in list(list(probability = NA_real_), list(probability = 1.1),
      list(minimum_r2 = -.1), list(maximum_friends = 0), list(moves = .5),
      list(unknown = 1)))
    expect_error(gbayes:::.gbayes_ld_swap(settings), "ld_swap")
})
