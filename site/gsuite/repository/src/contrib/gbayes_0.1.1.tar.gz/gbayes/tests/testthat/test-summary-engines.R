test_that("point-normal summary fitting is deterministic", {
  fixture <- gbayes_summary_fixture()
  on.exit(remove_gbayes_summary_fixture(fixture), add = TRUE)
  prior <- list(p = 0.2, h2 = 0.4)
  control <- list(burnin = 10, sampling_sweeps = 30, seed = 19,
    sparse = FALSE, auto_update = FALSE, storage = "memory")
  fit <- gbayes(fixture$stat, fixture$Glist, method = "point_normal",
    prior = prior, control = control, trait = "height")
  again <- gbayes(fixture$stat, fixture$Glist, method = "point_normal",
    prior = prior, control = control, trait = "height")
  expect_identical(fit$estimates, again$estimates)
  expect_true(all(is.na(fit$estimates$variance)))
  expect_true(all(fit$estimates$pip >= 0 & fit$estimates$pip <= 1))
  expect_length(fit$diagnostics$p_path, 40L)
  expect_equal(fit$weights$height, fit$estimates$mean)
})

test_that("continuous shrinkage exposes its distinct posterior summaries", {
  fixture <- gbayes_summary_fixture()
  on.exit(remove_gbayes_summary_fixture(fixture), add = TRUE)
  fit <- gbayes(fixture$stat, fixture$Glist,
    method = "continuous_shrinkage", prior = list(global_scale = 0.5),
    control = list(burnin = 10, sampling_sweeps = 30, thinning = 2,
      seed = 23, block_offsets = c(0, 4), maximum_block_dimension = 4,
      dense_workspace_budget_bytes = 1e6))
  expect_true(all(is.finite(fit$estimates$mean)))
  expect_true(all(is.na(fit$estimates$variance)))
  expect_true(all(is.na(fit$estimates$pip)))
  expect_equal(fit$diagnostics$retained_draws, 15)
  expect_equal(length(fit$diagnostics$local_scale_mean), 4)
  expect_lte(fit$diagnostics$dense_workspace$required_bytes, 1e6)
})

test_that("point-normal and mixture variational engines retain method semantics", {
  fixture <- gbayes_summary_fixture()
  on.exit(remove_gbayes_summary_fixture(fixture), add = TRUE)
  vb <- gbayes(fixture$stat, fixture$Glist, method = "variational",
    prior = list(p = 0.2, h2 = 0.4),
    control = list(maximum_iterations = 500, tolerance = 1e-8,
      storage = "disk"))
  mixture <- gbayes(fixture$stat, fixture$Glist,
    method = "mixture_variational",
    prior = list(variances = c(0, 0.01), weights = c(0.9, 0.1)),
    control = list(maximum_iterations = 5000, tolerance = 1e-6,
      windows = matrix(c(1, 4), ncol = 2)))
  for (fit in list(vb, mixture)) {
    expect_true(all(is.finite(fit$estimates$mean)))
    expect_true(all(is.finite(fit$estimates$variance)))
    expect_true(all(fit$estimates$pip >= 0 & fit$estimates$pip <= 1))
    expect_true(is.finite(fit$diagnostics$final_elbo))
    expect_equal(fit$weights[[fit$trait]], fit$estimates$mean)
  }
  expect_true(isTRUE(vb$diagnostics$globally_converged))
})

test_that("summary-only engine contracts reject unsupported inputs", {
  fixture <- gbayes_summary_fixture()
  on.exit(remove_gbayes_summary_fixture(fixture), add = TRUE)
  variable <- fixture$stat; variable$n <- c(1000, 900, 1000, 900)
  expect_error(gbayes(variable, fixture$Glist, method = "variational"),
    "common sample size")
  expect_error(gbayes(fixture$stat, fixture$Glist,
    method = "continuous_shrinkage",
    control = list(block_offsets = c(0, 2, 4), storage = "disk")),
    "requires.*memory")
  data <- data.frame(id = fixture$Glist$ids, y = seq_along(fixture$Glist$ids))
  expect_error(gbayes(Glist = fixture$Glist, data = data,
    method = "point_normal"), "only BayesC and BayesR")
})
