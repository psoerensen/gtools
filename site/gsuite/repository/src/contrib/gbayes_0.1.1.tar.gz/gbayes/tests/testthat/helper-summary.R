write_gbayes_bed <- function(genotypes, path) {
  encode <- function(x) {
    if (is.na(x)) return(1L)
    switch(as.character(x), "2" = 0L, "1" = 2L, "0" = 3L)
  }
  body <- raw()
  for (marker in seq_len(ncol(genotypes))) {
    codes <- vapply(genotypes[, marker], encode, integer(1))
    bytes <- raw(ceiling(nrow(genotypes) / 4))
    for (byte in seq_along(bytes)) {
      value <- 0L
      for (offset in 0:3) {
        sample <- (byte - 1L) * 4L + offset + 1L
        if (sample <= length(codes))
          value <- bitwOr(value, bitwShiftL(codes[[sample]], 2L * offset))
      }
      bytes[[byte]] <- as.raw(value)
    }
    body <- c(body, bytes)
  }
  writeBin(c(as.raw(c(0x6c, 0x1b, 0x01)), body), path)
}

gbayes_summary_fixture <- function(full_ld = FALSE, genotype = NULL, r2 = 0) {
  if (is.null(genotype)) genotype <- matrix(c(
      0, 0, 2, 1,
      0, 1, 2, 1,
      1, 1, 1, 0,
      1, 2, 1, 0,
      2, 2, 0, 1,
      2, 1, 0, 2
    ), nrow = 6L, byrow = TRUE)
  prefix <- tempfile("gbayes-plink-")
  paths <- setNames(paste0(prefix, c(".bed", ".bim", ".fam")),
    c("bed", "bim", "fam"))
  write_gbayes_bed(genotype, paths[["bed"]])
  markers <- data.frame("1", paste0("m", 1:4), 0, 100 * 1:4, "A", "G")
  samples <- data.frame(paste0("F", seq_len(nrow(genotype))),
    paste0("I", seq_len(nrow(genotype))), 0, 0, 0, -9)
  write.table(markers, paths[["bim"]], quote = FALSE, row.names = FALSE,
    col.names = FALSE)
  write.table(samples, paths[["fam"]], quote = FALSE, row.names = FALSE,
    col.names = FALSE)
  ld_prefix <- tempfile("gbayes-ld-")
  Glist <- gbase::gprep(bedfiles = paths[["bed"]])
  Glist <- gbase::gprep(Glist = Glist, task = "sparseld",
    out_prefix = ld_prefix, max_distance_bp = 0,
    max_distance_variants = if (full_ld) 0 else 4, r2 = r2,
    block_size = 2, nthreads = 1, allow_full_ld = full_ld)
  stat <- data.frame(rsids = paste0("m", 1:4), chr = "1", pos = 100 * 1:4,
    ea = "A", nea = "G", b = c(0.12, -0.04, 0.08, 0.01),
    seb = c(0.05, 0.06, 0.055, 0.07), n = 1000,
    stringsAsFactors = FALSE)
  list(Glist = Glist, stat = stat, paths = paths, ld_prefix = ld_prefix,
    genotype = genotype)
}

remove_gbayes_summary_fixture <- function(x) {
  unlink(unname(x$paths))
  unlink(paste0(x$ld_prefix, c(".row_ptr.u64.bin",
    ".col_idx.u32.0based.bin", ".values.f32.bin", ".meta.txt",
    ".markers.tsv")))
}
