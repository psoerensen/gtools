test_that("individual BED BayesC preserves selected sample and marker order", {
  fixture <- gbayes_summary_fixture()
  on.exit(remove_gbayes_summary_fixture(fixture), add = TRUE)
  Glist <- gbase::gprep(bedfiles = fixture$paths[["bed"]],
    ids = c("I6", "I2", "I4", "I1"), rsids = c("m4", "m2", "m1"))
  data <- data.frame(id = c("I4", "I1", "I6", "I2"),
    height = c(0.5, -1, 1.25, -0.25))
  control <- list(burnin = 10, sampling_sweeps = 30, thinning = 2,
    seeds = c(17, 29), packed_memory_limit_bytes = 1e6)
  prior <- list(residual_variance = 1, effect_variance = 0.1,
    inclusion_probability = 0.25)
  fit <- gbayes(data = data, Glist = Glist, method = "bayesc",
    prior = prior, control = control)
  ordered <- data[match(Glist$study_ids, data$id), , drop = FALSE]
  again <- gbayes(data = ordered, Glist = Glist, method = "bayesc",
    prior = prior, control = control, trait = "height")
  expect_s3_class(fit, "gbayes_fit")
  expect_identical(fit$estimates, again$estimates)
  expect_identical(fit$estimates$marker, c("m1", "m2", "m4"))
  expect_identical(fit$provenance$selected_ids, Glist$study_ids)
  expect_equal(fit$individual_bed$sample_count, 4)
  expect_true(isTRUE(fit$individual_bed$coding$standardized))
  expect_equal(fit$individual_bed$coding$centers,
    2 * fit$individual_bed$coding$allele_frequency)
  expect_equal(fit$individual_bed$coding$scales,
    sqrt(2 * fit$individual_bed$coding$allele_frequency *
      (1 - fit$individual_bed$coding$allele_frequency)))
  expect_identical(names(fit$weights), c("marker", "chromosome", "position",
    "effect_allele", "other_allele", "allele_frequency", "height"))
  expect_equal(fit$weights$height, fit$estimates$mean)
})

test_that("individual BED BayesR returns component probabilities and native coding", {
  fixture <- gbayes_summary_fixture()
  on.exit(remove_gbayes_summary_fixture(fixture), add = TRUE)
  Glist <- gbase::gprep(bedfiles = fixture$paths[["bed"]],
    ids = c("I5", "I1", "I3", "I6"), rsids = c("m1", "m3", "m4"))
  data <- data.frame(id = Glist$study_ids, trait = c(1, -1, 0.5, -0.5))
  fit <- gbayes(data = data, Glist = Glist, method = "bayesr",
    prior = list(residual_variance = 1, effect_variance = 0.1,
      weights = c(0.8, 0.15, 0.05),
      variance_multipliers = c(0, 0.1, 1)),
    control = list(burnin = 10, sampling_sweeps = 30, thinning = 2,
      seeds = 41, likelihood_dimension = 3,
      packed_memory_limit_bytes = 1e6))
  expect_equal(dim(fit$component_probability), c(3, 3))
  expect_equal(rowSums(fit$component_probability), rep(1, 3), tolerance = 1e-12)
  expect_equal(fit$weights$allele_frequency,
    fit$individual_bed$coding$allele_frequency)
  expect_identical(fit$control$likelihood_dimension, 3)
})

test_that("individual BED input contract rejects ambiguous or incomplete data", {
  fixture <- gbayes_summary_fixture()
  on.exit(remove_gbayes_summary_fixture(fixture), add = TRUE)
  Glist <- gbase::gprep(bedfiles = fixture$paths[["bed"]],
    ids = c("I1", "I2", "I3"))
  ambiguous <- data.frame(id = Glist$study_ids, y1 = 1:3, y2 = 3:1)
  expect_error(gbayes(data = ambiguous, Glist = Glist, method = "bayesc",
    control = list(burnin = 1, sampling_sweeps = 2)), "Supply `trait`")
  expect_error(gbayes(data = ambiguous[-1, ], Glist = Glist,
    method = "bayesc", trait = "y1",
    control = list(burnin = 1, sampling_sweeps = 2)), "every selected")
  expect_error(gbayes(stat = data.frame(), data = ambiguous, Glist = Glist,
    method = "bayesc", trait = "y1",
    control = list(burnin = 1, sampling_sweeps = 2)), "either `stat` or `data`")
})
