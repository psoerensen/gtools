learning_control <- function(...) {
  utils::modifyList(list(burnin = 10, sampling_sweeps = 30, thinning = 2,
    seeds = c(17, 29), threads = 1, retain_diagnostics = TRUE), list(...))
}

test_that("summary parameter learning captures scalar posterior diagnostics", {
  fixture <- gbayes_summary_fixture()
  on.exit(remove_gbayes_summary_fixture(fixture), add = TRUE)
  fit <- gbayes(fixture$stat, fixture$Glist, method = "bayesc",
    prior = list(residual_variance = 0.6, effect_variance = 0.1,
      inclusion_probability = 0.25,
      effect_variance_prior = list(df = 4, scale = 0.1),
      residual_variance_prior = list(df = 4, scale = 1000),
      weight_prior = c(1, 1)),
    control = learning_control(estimate_effect_variance = TRUE,
      estimate_weights = TRUE, residual_policy = "reference_ld"))
  expect_true(all(is.finite(unlist(fit$parameter_mean))))
  expect_true(all(c("residual_variance", "effect_variance", "active_markers",
    "weight_0", "weight_1") %in% fit$posterior$parameter))
  expect_true(all(fit$posterior$status == "available"))
  expect_length(fit$continuation$states, 2L)
  expect_gt(nrow(fit$chains[[1L]]$trace), 0L)
})

test_that("annotations retain inclusion, component, and BayesS semantics", {
  fixture <- gbayes_summary_fixture()
  on.exit(remove_gbayes_summary_fixture(fixture), add = TRUE)
  markers <- fixture$Glist$sparseLD$marker_metadata$marker_id
  design <- matrix(seq(-1, 1, length.out = length(markers)), ncol = 1L,
    dimnames = list(markers, "functional"))
  inclusion <- gbayes(fixture$stat, fixture$Glist, method = "bayesc",
    prior = list(residual_variance = 1, effect_variance = 0.1,
      inclusion_probability = 0.25), control = learning_control(),
    annotation = list(inclusion = list(design = design)))
  expect_named(inclusion$annotations, "inclusion")
  expect_equal(inclusion$annotations$inclusion$coefficient_names, "functional")
  expect_true("inclusion[functional]" %in% inclusion$posterior$parameter)

  component <- gbayes(fixture$stat, fixture$Glist, method = "bayesr",
    prior = list(residual_variance = 1, effect_variance = 0.1,
      weights = c(0.8, 0.15, 0.05),
      variance_multipliers = c(0, 0.1, 1)),
    control = learning_control(),
    annotation = list(component = list(design = design)))
  expect_named(component$annotations, "component")
  expect_length(component$annotations$component$coefficient_mean, 4L)

  af <- setNames(fixture$Glist$sparseLD$marker_metadata$allele_frequency,
    markers)
  bayess <- gbayes(fixture$stat, fixture$Glist, method = "bayesc",
    prior = list(residual_variance = 1, effect_variance = 0.1,
      inclusion_probability = 0.25), control = learning_control(),
    annotation = list(bayess = list(allele_frequency = af)))
  expect_named(bayess$annotations, "variance")
  expect_equal(bayess$annotations$variance$coefficient_names,
    "maf_exponent_s")
})

test_that("continuation restores exact scalar chain state", {
  fixture <- gbayes_summary_fixture()
  on.exit(remove_gbayes_summary_fixture(fixture), add = TRUE)
  prior <- list(residual_variance = 1, effect_variance = 0.1,
    inclusion_probability = 0.25)
  first <- gbayes(fixture$stat, fixture$Glist, method = "bayesc",
    prior = prior, control = learning_control(sampling_sweeps = 20))
  continued <- gbayes(fixture$stat, fixture$Glist, method = "bayesc",
    prior = prior, control = list(sampling_sweeps = 20, thinning = 2,
      retain_diagnostics = TRUE), continuation = first)
  direct <- gbayes(fixture$stat, fixture$Glist, method = "bayesc",
    prior = prior, control = learning_control(sampling_sweeps = 40))
  for (chain in seq_along(direct$continuation$states)) {
    expect_identical(continued$continuation$states[[chain]]$effects,
      direct$continuation$states[[chain]]$effects)
    expect_identical(continued$continuation$states[[chain]]$rng_state,
      direct$continuation$states[[chain]]$rng_state)
  }
  expect_error(gbayes(fixture$stat, fixture$Glist, method = "bayesc",
    prior = utils::modifyList(prior, list(effect_variance = 0.2)),
    continuation = first), "differ")
})

test_that("block residual and individual learning use public native updates", {
  fixture <- gbayes_summary_fixture()
  on.exit(remove_gbayes_summary_fixture(fixture), add = TRUE)
  markers <- fixture$Glist$sparseLD$marker_metadata$marker_id
  block <- setNames(rep("all", length(markers)), markers)
  summary_fit <- gbayes(fixture$stat, fixture$Glist, method = "bayesc",
    prior = list(residual_variance = 1, effect_variance = 0.1,
      inclusion_probability = 0.25),
    control = learning_control(block_residual = list(block = block,
      response_ss = 1000, likelihood_dimension = 1000,
      initial_variance = 1, genetic_variance_denominator = 1000)))
  expect_named(summary_fit$block_residual_variance_mean, "all")
  expect_true("block_residual_variance[1]" %in% summary_fit$posterior$parameter)

  Glist <- gbase::gprep(bedfiles = fixture$paths[["bed"]],
    ids = c("I6", "I2", "I4", "I1"), rsids = c("m4", "m2", "m1"))
  data <- data.frame(id = c("I4", "I1", "I6", "I2"),
    height = c(0.5, -1, 1.25, -0.25))
  individual <- gbayes(data = data, Glist = Glist, method = "bayesr",
    prior = list(residual_variance = 1, effect_variance = 0.1,
      weights = c(0.8, 0.15, 0.05),
      variance_multipliers = c(0, 0.1, 1),
      effect_variance_prior = list(df = 4, scale = 0.1),
      residual_variance_prior = list(df = 4, scale = 1),
      weight_prior = c(1, 1, 1)),
    control = learning_control(estimate_effect_variance = TRUE,
      estimate_residual_variance = TRUE, estimate_weights = TRUE,
      likelihood_dimension = 4, packed_memory_limit_bytes = 1e6))
  expect_true(all(is.finite(unlist(individual$parameter_mean))))
  expect_length(individual$continuation$states, 2L)
})

test_that("learning options reject scientifically inconsistent combinations", {
  fixture <- gbayes_summary_fixture()
  on.exit(remove_gbayes_summary_fixture(fixture), add = TRUE)
  expect_error(gbayes(fixture$stat, fixture$Glist, method = "bayesc",
    control = list(estimate_effect_variance = TRUE)),
    "effect_variance_prior")
  expect_error(gbayes(fixture$stat, fixture$Glist, method = "bayesc",
    prior = list(residual_variance_prior = list(df = 4, scale = 1)),
    control = list(residual_policy = "reference_ld",
      block_residual = list())), "block_residual")
  markers <- fixture$Glist$sparseLD$marker_metadata$marker_id
  design <- matrix(0, nrow = length(markers), ncol = 1,
    dimnames = list(markers, "a"))
  expect_error(gbayes(fixture$stat, fixture$Glist, method = "bayesr",
    prior = list(weight_prior = c(1, 1, 1, 1)),
    control = list(estimate_weights = TRUE),
    annotation = list(component = list(design = design))),
    "replace global weight learning")
})
