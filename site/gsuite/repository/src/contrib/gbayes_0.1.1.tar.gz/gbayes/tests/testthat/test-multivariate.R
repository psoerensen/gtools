test_that("multivariate summaries retain trait labels, weights, and continuation", {
  fixture <- gbayes_summary_fixture()
  on.exit(remove_gbayes_summary_fixture(fixture))
  traits <- c("height", "weight")
  stat <- list(height = fixture$stat,
    weight = transform(fixture$stat, b = b * c(0.5, -1, 1.5, 2)))
  effect <- matrix(c(0.04, 0.01, 0.01, 0.03), 2L,
    dimnames = list(traits, traits))
  sampling <- list(dependence = "independent",
    residual_variance = c(height = 1, weight = 0.8))
  control <- list(burnin = 2, sampling_sweeps = 6, seeds = c(13, 29))
  fit <- gbayes(stat, fixture$Glist, method = "bayesc",
    prior = list(effect_covariance = effect), sampling = sampling,
    control = control)
  expect_s3_class(fit, "gbayes_multivariate_fit")
  expect_identical(colnames(fit$estimates$mean), traits)
  expect_identical(names(fit$weights), c("marker", "chromosome", "position",
    "effect_allele", "other_allele", "allele_frequency", traits))
  expect_identical(rownames(fit$parameter_mean$effect_covariance), traits)
  expect_identical(unserialize(serialize(fit, NULL)), fit)
  expect_output(print(fit), "height, weight")

  first <- gbayes(stat, fixture$Glist, method = "bayesc",
    prior = list(effect_covariance = effect), sampling = sampling,
    control = modifyList(control, list(sampling_sweeps = 3)))
  continued <- gbayes(stat, fixture$Glist, method = "bayesc",
    prior = list(effect_covariance = effect), sampling = sampling,
    continuation = first,
    control = list(sampling_sweeps = 3, seeds = c(13, 29)))
  expect_identical(continued$continuation$states, fit$continuation$states)
})

test_that("multivariate BED uses labelled phenotypes and portable weights", {
  fixture <- gbayes_summary_fixture()
  on.exit(remove_gbayes_summary_fixture(fixture))
  traits <- c("height", "weight")
  data <- data.frame(id = rev(fixture$Glist$ids),
    height = c(0.3, -0.1, 0.2, 0, 0.1, -0.2),
    weight = c(-0.2, 0.1, 0.3, -0.1, 0, 0.2))
  effect <- matrix(c(0.04, 0.01, 0.01, 0.03), 2L,
    dimnames = list(traits, traits))
  residual <- matrix(c(0.8, 0.1, 0.1, 0.7), 2L,
    dimnames = list(traits, traits))
  fit <- gbayes(data = data, Glist = fixture$Glist, trait = traits,
    method = "bayesr", prior = list(effect_covariance = effect,
      residual_covariance = residual),
    control = list(burnin = 2, sampling_sweeps = 5, seeds = c(7, 11)))
  expect_s3_class(fit, "gbayes_multivariate_fit")
  expect_identical(fit$likelihood, "individual_bed")
  expect_identical(colnames(fit$estimates$mean), traits)
  expect_identical(names(fit$weights)[-(1:6)], traits)
  expect_true(isTRUE(fit$coding$standardized))
  expect_identical(fit$coding$sample_count, 6)
  expect_true(isTRUE(fit$individual_bed$available))
})

test_that("study-specific references form an explicit marker union", {
  fixture <- gbayes_summary_fixture()
  on.exit(remove_gbayes_summary_fixture(fixture))
  first_prefix <- tempfile("gbayes-study-first-")
  second_prefix <- tempfile("gbayes-study-second-")
  on.exit(unlink(paste0(first_prefix, c(".row_ptr.u64.bin",
    ".col_idx.u32.0based.bin", ".values.f32.bin", ".meta.txt",
    ".markers.tsv"))), add = TRUE)
  on.exit(unlink(paste0(second_prefix, c(".row_ptr.u64.bin",
    ".col_idx.u32.0based.bin", ".values.f32.bin", ".meta.txt",
    ".markers.tsv"))), add = TRUE)
  first <- gbase::gprep(bedfiles = fixture$paths[["bed"]],
    rsids = c("m2", "m3", "m4"))
  first <- gbase::gprep(Glist = first, task = "sparseld",
    out_prefix = first_prefix, max_distance_bp = 0,
    max_distance_variants = 3, r2 = 0, block_size = 2, nthreads = 1)
  second <- gbase::gprep(bedfiles = fixture$paths[["bed"]],
    rsids = c("m1", "m3"))
  second <- gbase::gprep(Glist = second, task = "sparseld",
    out_prefix = second_prefix, max_distance_bp = 0,
    max_distance_variants = 2, r2 = 0, block_size = 2, nthreads = 1)
  stats <- list(study_a = fixture$stat[match(c("m2", "m3", "m4"),
      fixture$stat$rsids), ],
    study_b = fixture$stat[match(c("m1", "m3"), fixture$stat$rsids), ])
  references <- list(study_a = first, study_b = second)
  trait <- c(study_a = "height", study_b = "weight")
  traits <- unique(unname(trait))
  effect <- diag(c(0.04, 0.03));dimnames(effect) <- list(traits, traits)
  fit <- gbayes(stats, references, trait = trait, method = "bayesc",
    prior = list(effect_covariance = effect),
    sampling = list(dependence = "independent",
      residual_variance = c(study_a = 1, study_b = 1)),
    control = list(burnin = 1, sampling_sweeps = 4, seeds = 17))
  expect_identical(rownames(fit$estimates$mean), c("m2", "m3", "m4", "m1"))
  expect_identical(fit$studies$study_b$local_to_global, c(4L, 2L))
  expect_null(fit$weights)
  expect_true(fit$provenance$study_specific_references)
  expect_error(gbayes(stats, references, trait = trait,
    prior = list(effect_covariance = effect),
    sampling = list(dependence = "shared_ld")), "independent")
})

test_that("multivariate covariance and mixture learning are explicit", {
  fixture <- gbayes_summary_fixture()
  on.exit(remove_gbayes_summary_fixture(fixture))
  traits <- c("height", "weight")
  stat <- list(height = fixture$stat,
    weight = transform(fixture$stat, b = b * c(0.7, -1, 1.2, 1.5)))
  effect <- matrix(c(0.04, 0.01, 0.01, 0.03), 2L,
    dimnames = list(traits, traits))
  sampling_covariance <- matrix(c(1, 0.1, 0.1, 0.9), 2L,
    dimnames = list(traits, traits))
  fit <- gbayes(stat, fixture$Glist, method = "bayesr",
    prior = list(effect_covariance = effect,
      covariance_prior = list(df = 4, scale = effect * 2),
      pattern_prior = rep(1, 4), component_prior = rep(1, 3),
      sampling_covariance_prior = list(df = 4,
        scale = sampling_covariance * 2)),
    sampling = list(dependence = "shared_ld",
      covariance = sampling_covariance,
      response_crossproduct = 1000 * sampling_covariance,
      likelihood_dimension = 1000),
    control = list(burnin = 2, sampling_sweeps = 6, seeds = c(19, 31),
      estimate_covariance = TRUE, estimate_sampling_covariance = TRUE,
      estimate_pattern_weights = TRUE,
      estimate_component_weights = TRUE))
  expect_true(all(is.finite(fit$parameter_mean$effect_covariance)))
  expect_true(all(is.finite(fit$parameter_mean$sampling_covariance)))
  expect_true(all(fit$posterior$estimated))
  expect_identical(names(fit$parameter_mean$pattern_weights),
    c("00", "10", "01", "11"))
})

test_that("multivariate annotations remain model-owned", {
  fixture <- gbayes_summary_fixture()
  on.exit(remove_gbayes_summary_fixture(fixture))
  traits <- c("height", "weight")
  stat <- list(height = fixture$stat,
    weight = transform(fixture$stat, b = b * 0.8))
  effect <- diag(c(0.04, 0.03));dimnames(effect) <- list(traits, traits)
  markers <- fixture$Glist$sparseLD$marker_metadata$marker_id
  design <- matrix(seq_along(markers), ncol = 1L,
    dimnames = list(markers, "position"))
  fit <- gbayes(stat, fixture$Glist, method = "bayesr",
    prior = list(effect_covariance = effect),
    sampling = list(dependence = "independent",
      residual_variance = c(height = 1, weight = 1)),
    annotation = list(pattern = list(design = design),
      variance = list(design = design)),
    control = list(burnin = 2, sampling_sweeps = 5, seeds = c(23, 41)))
  expect_named(fit$annotations, c("pattern", "variance"))
  expect_true(any(grepl("^pattern\\[", fit$posterior$parameter)))
  expect_true(any(grepl("^variance\\[", fit$posterior$parameter)))
})
