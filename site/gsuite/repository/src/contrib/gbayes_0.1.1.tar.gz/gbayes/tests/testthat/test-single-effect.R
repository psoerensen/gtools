test_that("single effect probabilities are deterministic", {
  s <- data.frame(rsids=c("a","b","c"), score=c(8,1,0),
    information=c(20,20,20))
  x <- gbayes_single_effect(s, trait="y", response_units="SD")
  expect_equal(sum(x$posterior_probability),1,tolerance=1e-12)
  expect_gt(x$posterior_probability[1],x$posterior_probability[2])
  expect_identical(x,gbayes_single_effect(s, trait="y", response_units="SD"))
})
