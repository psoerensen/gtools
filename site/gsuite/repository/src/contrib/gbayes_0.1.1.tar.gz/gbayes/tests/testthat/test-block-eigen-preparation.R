test_that("block eigensystems are prepared once and rebound across traits", {
  genotype <- cbind(
    m1 = c(0, 0, 0, 0, 2, 2, 2, 2),
    m2 = c(0, 0, 0, 0, 2, 2, 2, 2),
    m3 = c(0, 0, 2, 2, 0, 0, 2, 2),
    m4 = c(0, 0, 2, 2, 0, 0, 2, 2))
  fixture <- gbayes_summary_fixture(genotype = genotype, r2 = 0.5)
  on.exit(remove_gbayes_summary_fixture(fixture), add = TRUE)
  blocks <- data.frame(block_id = c("left", "right"),
    first_marker = c("m1", "m3"), last_marker = c("m2", "m4"))
  fixture$Glist <- gbase::define_ld_blocks(fixture$Glist, blocks)
  second <- fixture$stat
  second$b <- second$b * 1.5
  second$n <- second$n + 0:3
  prepared <- .gbayes_prepare_block_eigen(
    list(first = fixture$stat, second = second), fixture$Glist,
    list(retained_positive_mass = 1))

  expect_identical(prepared$block_rank, c(1L, 1L))
  expect_equal(dim(prepared$response_coordinates), c(2, 2))
  expect_equal(prepared$diagnostics$blocks, 2)
  expect_equal(prepared$diagnostics$block_loads, 2)
  expect_equal(prepared$diagnostics$eigensystem_decompositions, 2)
  expect_equal(prepared$diagnostics$retained_rank, 2)
  expect_equal(prepared$diagnostics$peak_block_markers, 2)
  expect_equal(prepared$diagnostics$maximum_discarded_positive_mass, 0,
    tolerance = 1e-12)

  aligned <- .gbayes_summary_stat(fixture$stat, fixture$Glist)
  original_score <- aligned$n * aligned$beta_std
  expected <- stats::setNames(numeric(4), aligned$rsids)
  for (block_index in seq_along(prepared$block_rank)) {
    markers <- list(c("m1", "m2"), c("m3", "m4"))[[block_index]]
    eigen <- gbase::ld_eigen(fixture$Glist, markers)
    retained <- seq_len(prepared$block_rank[[block_index]])
    expected[match(markers, aligned$rsids)] <-
      eigen$vectors[, retained, drop = FALSE] %*%
      crossprod(eigen$vectors[, retained, drop = FALSE],
        original_score[match(markers, aligned$rsids)])
  }
  expect_equal(prepared$projected_score[, "first"], expected,
    tolerance = 1e-10)
})

test_that("block eigensystem preparation requires a verified Glist manifest", {
  fixture <- gbayes_summary_fixture()
  on.exit(remove_gbayes_summary_fixture(fixture), add = TRUE)
  expect_error(.gbayes_prepare_block_eigen(fixture$stat, fixture$Glist),
    "define_ld_blocks")
})

test_that("eigen retention preserves working variance for every marker", {
  genotype <- cbind(
    m1 = c(0, 0, 0, 0, 2, 2, 2, 2),
    m2 = c(0, 0, 0, 0, 2, 2, 2, 2),
    m3 = c(0, 0, 2, 2, 0, 0, 2, 2),
    m4 = c(0, 0, 2, 2, 0, 0, 2, 2))
  fixture <- gbayes_summary_fixture(genotype = genotype, r2 = 0.5)
  on.exit(remove_gbayes_summary_fixture(fixture), add = TRUE)
  fixture$Glist <- gbase::define_ld_blocks(fixture$Glist, data.frame(
    block_id = "all", first_marker = "m1", last_marker = "m4"))
  expect_error(.gbayes_prepare_block_eigen(fixture$stat, fixture$Glist,
    list(retained_positive_mass = 0.5)), "zero working variance")
})

test_that("SBayesRC fits verified blocks with one preparation pass", {
  genotype <- cbind(
    m1 = c(0, 0, 0, 0, 2, 2, 2, 2),
    m2 = c(0, 0, 0, 0, 2, 2, 2, 2),
    m3 = c(0, 0, 2, 2, 0, 0, 2, 2),
    m4 = c(0, 0, 2, 2, 0, 0, 2, 2))
  fixture <- gbayes_summary_fixture(genotype = genotype, r2 = 0.5)
  on.exit(remove_gbayes_summary_fixture(fixture), add = TRUE)
  fixture$Glist <- gbase::define_ld_blocks(fixture$Glist, data.frame(
    block_id = c("left", "right"), first_marker = c("m1", "m3"),
    last_marker = c("m2", "m4")))
  markers <- fixture$Glist$sparseLD$marker_metadata$marker_id
  design <- matrix(seq(-1, 1, length.out = length(markers)), ncol = 1L,
    dimnames = list(markers, "functional"))
  prior <- list(residual_variance = 1, effect_variance = 0.1)
  annotation <- list(component = list(design = design, learn = FALSE))
  control <- list(burnin = 2, sampling_sweeps = 4, thinning = 1,
    seeds = 17, threads = 1,
    eigen_control = list(retained_positive_mass = 1))
  fit <- gbayes(fixture$stat, fixture$Glist, method = "sbayesrc",
    prior = prior, annotation = annotation, control = control)

  expect_identical(fit$method, "sbayesrc")
  expect_identical(fit$likelihood, "retained_block_eigen")
  expect_identical(names(fit$block_residual_variance_mean),
    c("left", "right"))
  expect_named(fit$annotations, "component")
  expect_equal(fit$diagnostics$block_eigen$blocks, 2)
  expect_equal(fit$diagnostics$block_eigen$block_loads, 2)
  expect_equal(fit$diagnostics$block_eigen$eigensystem_decompositions, 2)
  expect_equal(fit$diagnostics$block_eigen$retained_rank, 2)
  expect_true(all(is.finite(fit$block_residual_variance_mean)))

  continued <- gbayes(fixture$stat, fixture$Glist, method = "sbayesrc",
    prior = prior, annotation = annotation,
    control = list(sampling_sweeps = 4, thinning = 1,
      eigen_control = list(retained_positive_mass = 1)),
    continuation = fit)
  direct <- gbayes(fixture$stat, fixture$Glist, method = "sbayesrc",
    prior = prior, annotation = annotation,
    control = utils::modifyList(control, list(sampling_sweeps = 8)))
  expect_identical(continued$continuation$states[[1L]],
    direct$continuation$states[[1L]])
})

test_that("full-rank SBayesRC matches BayesR sufficient statistics", {
  signs <- cbind(
    c(1, 1, 1, 1, 1, 1, 1, 1, -1, -1, -1, -1, -1, -1, -1, -1),
    rep(c(1, 1, 1, 1, -1, -1, -1, -1), 2),
    rep(c(1, 1, -1, -1), 4),
    rep(c(1, -1), 8))
  fixture <- gbayes_summary_fixture(genotype = signs + 1, r2 = 1e-12)
  on.exit(remove_gbayes_summary_fixture(fixture), add = TRUE)
  fixture$Glist <- gbase::define_ld_blocks(fixture$Glist, data.frame(
    block_id = c("left", "right"), first_marker = c("m1", "m3"),
    last_marker = c("m2", "m4")))
  markers <- fixture$Glist$sparseLD$marker_metadata$marker_id
  design <- matrix(c(-1, -0.25, 0.25, 1), ncol = 1L,
    dimnames = list(markers, "functional"))
  annotation <- list(component = list(design = design, learn = FALSE))
  prior <- list(residual_variance = 1, effect_variance = 0.1)
  common <- list(burnin = 5, sampling_sweeps = 15, thinning = 1,
    seeds = 29, threads = 1)
  ordinary <- gbayes(fixture$stat, fixture$Glist, method = "bayesr",
    prior = prior, annotation = annotation, control = common)
  factorized <- gbayes(fixture$stat, fixture$Glist, method = "sbayesrc",
    prior = prior, annotation = annotation, control = utils::modifyList(common,
      list(eigen_control = list(retained_positive_mass = 1),
        block_eigen_residual = list(mode = "fixed"))))

  expect_equal(factorized$diagnostics$block_eigen$retained_rank, 4)
  expect_equal(factorized$estimates$mean, ordinary$estimates$mean,
    tolerance = 1e-10)
  expect_equal(factorized$estimates$pip, ordinary$estimates$pip,
    tolerance = 1e-10)
  expect_equal(factorized$component_probability,
    ordinary$component_probability, tolerance = 1e-10)
})

test_that("SBayesRC rejects incomplete block and annotation contracts", {
  fixture <- gbayes_summary_fixture()
  on.exit(remove_gbayes_summary_fixture(fixture), add = TRUE)
  markers <- fixture$Glist$sparseLD$marker_metadata$marker_id
  design <- matrix(0, nrow = length(markers), ncol = 1L,
    dimnames = list(markers, "functional"))
  expect_error(gbayes(fixture$stat, fixture$Glist, method = "sbayesrc",
    annotation = list(component = list(design = design))), "define_ld_blocks")

  fixture$Glist <- gbase::define_ld_blocks(fixture$Glist, data.frame(
    block_id = "all", first_marker = "m1", last_marker = "m4"))
  expect_error(gbayes(fixture$stat, fixture$Glist, method = "sbayesrc"),
    "annotation\\$component")
  varying <- fixture$stat
  varying$n[[2L]] <- varying$n[[2L]] - 1
  expect_error(gbayes(varying, fixture$Glist, method = "sbayesrc",
    annotation = list(component = list(design = design))),
    "common sample size")
})
