test_that("familiar genome controls preserve the native summary fit", {
  fixture <- gbayes_summary_fixture();on.exit(remove_gbayes_summary_fixture(fixture))
  fit <- gbayes(Glist=fixture$Glist,stat=fixture$stat,method='bayesC',
    algorithm='mcmc',nit=12,nburn=2,nthin=2,seed=17,
    updateB=FALSE,updateE=FALSE,updatePi=FALSE)
  expect_identical(fit$method,'bayesc')
  expect_equal(fit$control$sampling_sweeps,12)
  expect_equal(fit$control$seeds,17)
  expect_identical(fit$control$residual_policy,'fixed')
  expect_equal(fit$stat$bm,fit$estimates$mean,tolerance=0)
  expect_equal(fit$stat$dm,fit$estimates$pip,tolerance=0)
  expect_true(all(c('ve','vg','vb','pi','pip') %in% names(fit$post)))
  expect_equal(fit$post$pip,sum(fit$stat$dm))
  expect_equal(fit$post$pi,fit$parameter_mean$weights[2])
  expect_true(is.finite(fit$post$vg) && fit$post$vg>=0)
  expect_true(all(c('rhat_ve','ess_vg','status_pi','nrun') %in% names(fit$conv)))
  original_control <- fit$control
  # The returned effective control records a zero adjustment for the native
  # fixed-residual operator; the input contract does not accept that field.
  original_control$residual_adjustment <- NULL
  exact <- gbayes(fixture$stat,fixture$Glist,method='bayesc',
    prior=fit$prior,control=original_control)
  expect_equal(exact$estimates,fit$estimates,tolerance=0)
  learned <- gbayes(fixture$stat,fixture$Glist,method='bayesC',nit=4,seed=17)
  expect_identical(learned$control$residual_policy,'reference_ld')
  expect_true(all(is.finite(learned$estimates$mean)))
  expect_error(gbayes(fixture$stat,fixture$Glist,method='bayesC',nit=12,
    control=list(sampling_sweeps=12)),'either')
  expect_error(gbayes(fixture$stat,fixture$Glist,method='bayesC',algorithm='em-mcmc'),'mcmc')
})

test_that("BayesC and BayesR accept verified block-eigen fits and multiple chains", {
  # Four independent columns: full-rank eigen/CSR equivalence must not project
  # inconsistent marginal scores out of the default fixture's singular LD.
  genotype <- matrix(c(0,0,1,1, 0,1,2,1, 1,1,1,0,
    1,2,1,0, 2,2,0,1, 2,1,0,2),nrow=6,byrow=TRUE)
  fixture <- gbayes_summary_fixture(full_ld=TRUE,genotype=genotype)
  on.exit(remove_gbayes_summary_fixture(fixture))
  G <- gbase::define_ld_blocks(fixture$Glist,data.frame(block_id='all',
    first_marker='m1',last_marker='m4'))
  for(method in c('bayesC','bayesR')) {
    full <- gbayes(fixture$stat,G,method=method,algorithm='mcmc-eigen',
      nit=30,nburn=2,nrun=2,seed=13,updateB=FALSE,updateE=FALSE,updatePi=FALSE,
      control=list(eigen_control=list(retained_positive_mass=1)))
    sparse <- gbayes(fixture$stat,G,method=method,algorithm='mcmc',
      nit=30,nburn=2,nrun=2,seed=13,updateB=FALSE,updateE=FALSE,updatePi=FALSE)
    expect_equal(full$estimates,sparse$estimates,tolerance=1e-8)
    expect_equal(full$post,sparse$post,tolerance=1e-8)
    fit <- gbayes(fixture$stat,G,method=method,algorithm='mcmc-eigen',
      nit=40,nburn=4,nrun=2,seed=31,updateB=TRUE,updateE=TRUE,updatePi=TRUE,
      control=list(eigen_control=list(retained_positive_mass=.8)))
    expect_identical(fit$algorithm,'mcmc-eigen')
    expect_identical(fit$likelihood,'retained_block_eigen')
    expect_identical(fit$control$residual_policy,'retained')
    expect_equal(fit$control$seeds,c(31,32))
    expect_equal(fit$conv$nrun,2)
    expect_true(all(is.finite(unlist(fit$post[c('ve','vg','vb','pi','pip')]))))
    expect_equal(fit$post$pip,sum(fit$stat$dm))
    expect_equal(fit$control$normalization$likelihood_dimension,
      fit$diagnostics$block_eigen$retained_rank)
    expect_equal(fit$post$vg,fit$quantities$genetic$covariance_mean[1,1])
    expect_equal(fit$diagnostics$block_eigen$eigensystem_decompositions,1)
  }
  expect_error(gbayes(fixture$stat,fixture$Glist,method='bayesC',
    algorithm='mcmc-eigen',nit=4),'verified blocks')
  expect_error(gbayes(fixture$stat,G,method='bayesC',algorithm='mcmc-eigen',
    control=list(residual_policy='reference_ld')),'retained')
})
