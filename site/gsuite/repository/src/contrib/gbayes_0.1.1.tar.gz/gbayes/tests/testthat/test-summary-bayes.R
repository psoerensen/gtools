test_that("summary BayesC is deterministic with common sample size", {
  fixture <- gbayes_summary_fixture()
  on.exit(remove_gbayes_summary_fixture(fixture), add = TRUE)
  control <- list(burnin = 10, sampling_sweeps = 30, thinning = 2,
    seeds = c(17, 29), storage = "memory")
  fit <- gbayes(fixture$stat, fixture$Glist, method = "bayesc",
    prior = list(residual_variance = 1, effect_variance = 0.1,
      inclusion_probability = 0.25), control = control, trait = "height")
  again <- gbayes(fixture$stat, fixture$Glist, method = "bayesc",
    prior = list(residual_variance = 1, effect_variance = 0.1,
      inclusion_probability = 0.25), control = control, trait = "height")
  expect_s3_class(fit, "gbayes_fit")
  expect_identical(fit$estimates, again$estimates)
  expect_identical(fit$weights, again$weights)
  expect_identical(fit$weights$marker, fixture$Glist$sparseLD$marker_metadata$marker_id)
  expect_identical(names(fit$weights)[[7L]], "height")
  expect_equal(fit$weights$height, fit$estimates$mean)
  expect_true(all(fit$estimates$pip >= 0 & fit$estimates$pip <= 1))
  expect_length(fit$chains, 2L)
})

test_that("summary BayesR supports explicit variable N and disk LD", {
  fixture <- gbayes_summary_fixture()
  on.exit(remove_gbayes_summary_fixture(fixture), add = TRUE)
  fixture$stat$n <- c(900, 1000, 1100, 950)
  expect_error(gbayes(fixture$stat, fixture$Glist, method = "bayesr",
    control = list(burnin = 2, sampling_sweeps = 4)), "sample sizes")
  fit <- gbayes(fixture$stat[c(4, 2, 1, 3), ], fixture$Glist,
    method = "bayesr", prior = list(residual_variance = 1,
      effect_variance = 0.1, weights = c(0.8, 0.15, 0.05),
      variance_multipliers = c(0, 0.1, 1)),
    control = list(burnin = 10, sampling_sweeps = 30, thinning = 2,
      seeds = 41, sample_size = "variable", storage = "disk"))
  expect_identical(fit$estimates$marker, paste0("m", 1:4))
  expect_equal(dim(fit$component_probability), c(4, 3))
  expect_equal(rowSums(fit$component_probability), rep(1, 4), tolerance = 1e-12)
  expect_identical(fit$provenance$sample_size_range, c(900, 1100))
})

test_that("summary adapter aligns swapped alleles and rejects incomplete input", {
  fixture <- gbayes_summary_fixture()
  on.exit(remove_gbayes_summary_fixture(fixture), add = TRUE)
  swapped <- fixture$stat
  swapped$ea[[1L]] <- "G"; swapped$nea[[1L]] <- "A"
  swapped$b[[1L]] <- -swapped$b[[1L]]
  control <- list(burnin = 5, sampling_sweeps = 10, seeds = 7)
  a <- gbayes(fixture$stat, fixture$Glist, "bayesc", control = control)
  b <- gbayes(swapped, fixture$Glist, "bayesc", control = control)
  expect_identical(a$estimates, b$estimates)
  expect_error(gbayes(fixture$stat[-1, ], fixture$Glist, "bayesc",
    control = control), "every sparse-LD marker")
})

test_that("explicit full LD supports in-sample residual learning", {
  fixture <- gbayes_summary_fixture(full_ld = TRUE)
  on.exit(remove_gbayes_summary_fixture(fixture), add = TRUE)
  fixture$stat$n <- fixture$Glist$sparseLD$n
  fit <- gbayes(fixture$stat, fixture$Glist, method = "bayesc",
    prior = list(residual_variance = 1, effect_variance = 0.1,
      inclusion_probability = 0.25,
      residual_variance_prior = list(df = 4, scale = 1)),
    control = list(burnin = 2, sampling_sweeps = 4, seeds = 9,
      estimate_residual_variance = TRUE, residual_policy = "in_sample",
      normalization = list(response_ss = fixture$Glist$sparseLD$n,
        likelihood_dimension = 4L, in_sample_ld = TRUE)))
  expect_s3_class(fit, "gbayes_fit")
})
