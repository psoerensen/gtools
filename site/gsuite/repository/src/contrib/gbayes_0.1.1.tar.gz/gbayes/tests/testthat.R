library(testthat); library(gbayes); test_check("gbayes")
