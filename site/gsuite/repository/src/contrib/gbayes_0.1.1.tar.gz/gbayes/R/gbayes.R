gbayes_native_info <- function() cpp_gbayes_native_info()
.onLoad <- function(libname, pkgname) {
  x <- cpp_gbayes_native_info()
  ok <- identical(x$runtime_version, "0.1.0") &&
    identical(as.character(x$abi_contract), "0") &&
    identical(x$gmat_version, "0.6.0") &&
    identical(as.character(x$gmat_abi), "0") &&
    utils::compareVersion(x$gsolve_version, "0.26.0") >= 0 &&
    identical(as.character(x$gsolve_abi), "4") &&
    identical(x$gbits_version, "0.21.0") &&
    identical(as.character(x$gbits_abi), "4") &&
    identical(x$gscore_version, "0.1.0") &&
    identical(as.character(x$gscore_abi), "0") &&
    isTRUE(x$headers_match_runtime)
  if (!ok) stop("Loaded gbayes native dependency versions/ABIs are incompatible.", call.=FALSE)
}

.gbayes_stop <- function(...) stop(..., call. = FALSE)

.gbayes_named_list <- function(x, defaults, name) {
  if (!is.list(x) || is.object(x) ||
      (length(x) && (is.null(names(x)) || anyNA(names(x)) ||
        any(!nzchar(names(x))) || anyDuplicated(names(x)))))
    .gbayes_stop("`", name, "` must be an ordinary uniquely named list.")
  extra <- setdiff(names(x), names(defaults))
  if (length(extra)) .gbayes_stop("Unsupported `", name, "` entry: ", extra[[1L]], ".")
  utils::modifyList(defaults, x)
}

.gbayes_positive <- function(x, name) {
  if (!is.numeric(x) || length(x) != 1L || !is.finite(x) || x <= 0)
    .gbayes_stop("`", name, "` must be one positive finite number.")
  as.double(x)
}

.gbayes_count <- function(x, name, minimum = 1) {
  if (!is.numeric(x) || length(x) != 1L || !is.finite(x) || x < minimum ||
      x != floor(x) || x > .Machine$integer.max)
    .gbayes_stop("`", name, "` must be a whole number at least ", minimum, ".")
  as.double(x)
}

.gbayes_summary_stat <- function(stat, Glist) {
  required <- c("rsids", "chr", "pos", "ea", "nea", "b", "seb", "n")
  if (!identical(class(stat), "data.frame") || !nrow(stat) ||
      length(missing <- setdiff(required, names(stat))) || anyDuplicated(names(stat)))
    .gbayes_stop("`stat` must be an ordinary data frame containing: ",
      paste(required, collapse = ", "), ".")
  metadata <- Glist$sparseLD$marker_metadata
  if (nrow(stat) != nrow(metadata) || anyDuplicated(stat$rsids) ||
      anyNA(index <- match(metadata$marker_id, stat$rsids)))
    .gbayes_stop("`stat` must cover every sparse-LD marker exactly once.")
  stat <- stat[index, , drop = FALSE]
  coordinate_ok <- as.character(stat$chr) == as.character(metadata$chromosome) &
    as.double(stat$pos) == as.double(metadata$base_pair_position)
  if (anyNA(coordinate_ok) || any(!coordinate_ok))
    .gbayes_stop("Summary coordinates do not match the sparse-LD reference.")
  effect <- toupper(as.character(stat$ea)); other <- toupper(as.character(stat$nea))
  allele1 <- toupper(as.character(metadata$allele1))
  allele2 <- toupper(as.character(metadata$allele2))
  exact <- effect == allele1 & other == allele2
  swapped <- effect == allele2 & other == allele1
  if (anyNA(exact) || any(!exact & !swapped))
    .gbayes_stop("Summary alleles do not match the sparse-LD reference.")
  for (name in c("b", "seb", "n"))
    if (!is.numeric(stat[[name]]) || anyNA(stat[[name]]) || any(!is.finite(stat[[name]])))
      .gbayes_stop("`stat$", name, "` must contain finite numeric values.")
  if (any(stat$seb <= 0) || any(stat$n <= 0))
    .gbayes_stop("Standard errors and sample sizes must be positive.")
  stat$b[swapped] <- -stat$b[swapped]
  stat$ea <- metadata$allele1; stat$nea <- metadata$allele2
  stat$beta_std <- stat$b / sqrt(stat$n * stat$seb^2 + stat$b^2)
  stat
}

.gbayes_bed_data <- function(data, Glist, trait) {
  if (!identical(class(data), "data.frame") || !nrow(data) ||
      anyDuplicated(names(data)) || !"id" %in% names(data) ||
      !is.character(data$id) || anyNA(data$id) || any(!nzchar(data$id)) ||
      anyDuplicated(data$id))
    .gbayes_stop("`data` must be an ordinary data frame with unique character `id` values.")
  selected_ids <- if (is.null(Glist$study_ids)) Glist$ids else Glist$study_ids
  if (nrow(data) != length(selected_ids) || !setequal(data$id, selected_ids))
    .gbayes_stop("`data` must contain one row for every selected Glist individual.")
  candidates <- setdiff(names(data), "id")
  if (is.null(trait)) {
    if (length(candidates) != 1L)
      .gbayes_stop("Supply `trait` when `data` does not contain exactly one phenotype column.")
    trait <- candidates
  }
  if (!is.character(trait) || length(trait) != 1L || is.na(trait) ||
      !nzchar(trait) || !trait %in% candidates)
    .gbayes_stop("`trait` must name one phenotype column in `data`.")
  phenotype <- data[[trait]][match(selected_ids, data$id)]
  if (!is.numeric(phenotype) || anyNA(phenotype) || any(!is.finite(phenotype)))
    .gbayes_stop("The selected phenotype must contain finite numeric values.")
  active <- which(lengths(Glist$rsids) > 0L)
  if (!length(active)) .gbayes_stop("`Glist` contains no selected markers.")
  list(trait = trait, phenotype = as.double(phenotype), ids = selected_ids,
    active = active, paths = unname(Glist$bedfiles[active]),
    physical_marker_count = as.double(Glist$physical_marker_counts[active]),
    marker_indices = unname(Glist$source_marker_indices_0based[active]),
    marker = unlist(Glist$rsids[active], use.names = FALSE),
    chromosome = unlist(Glist$chr[active], use.names = FALSE),
    position = as.double(unlist(Glist$pos[active], use.names = FALSE)),
    allele1 = unlist(Glist$a1[active], use.names = FALSE),
    allele2 = unlist(Glist$a2[active], use.names = FALSE),
    allele_frequency = as.double(unlist(Glist$af[active], use.names = FALSE)))
}

.gbayes_prior <- function(prior, method) {
  defaults <- list(residual_variance = 1, effect_variance = 1,
    effect_variance_prior = NULL, residual_variance_prior = NULL,
    weight_prior = NULL)
  if (method == "bayesc") defaults$inclusion_probability <- 0.5 else {
    defaults$weights <- c(0.7, 0.1, 0.1, 0.1)
    defaults$variance_multipliers <- c(0, 0.01, 0.1, 1)
  }
  prior <- .gbayes_named_list(prior, defaults, "prior")
  prior$residual_variance <- .gbayes_positive(prior$residual_variance,
    "prior$residual_variance")
  prior$effect_variance <- .gbayes_positive(prior$effect_variance,
    "prior$effect_variance")
  if (method == "bayesc") {
    p <- prior$inclusion_probability
    if (!is.numeric(p) || length(p) != 1L || !is.finite(p) || p <= 0 || p >= 1)
      .gbayes_stop("`prior$inclusion_probability` must lie strictly between zero and one.")
  } else if (!is.numeric(prior$weights) || !is.numeric(prior$variance_multipliers) ||
      length(prior$weights) < 2L || length(prior$weights) != length(prior$variance_multipliers) ||
      any(!is.finite(c(prior$weights, prior$variance_multipliers))) ||
      any(prior$weights < 0) || abs(sum(prior$weights) - 1) > 1e-10 ||
      prior$variance_multipliers[[1L]] != 0 || any(diff(prior$variance_multipliers) <= 0))
    .gbayes_stop("BayesR requires normalized nonnegative weights and increasing variance multipliers starting at zero.")
  prior
}

.gbayes_continuation <- function(x) {
  if (is.null(x)) return(NULL)
  if (inherits(x, "gbayes_fit")) x <- x$continuation
  if (!is.list(x) || !identical(x$version, 1L) || !is.list(x$signature) ||
      !is.list(x$states) || !length(x$states) || !is.numeric(x$seeds) ||
      length(x$seeds) != length(x$states))
    .gbayes_stop("`continuation` must be a gbayes fit or version-1 continuation object.")
  x
}

.gbayes_learning_prior <- function(prior, control, method) {
  for (pair in list(c("effect_variance_prior", "estimate_effect_variance"),
                    c("residual_variance_prior", "estimate_residual_variance"))) {
    value <- prior[[pair[[1L]]]]
    if (control[[pair[[2L]]]]) {
      if (!is.list(value) || !setequal(names(value), c("df", "scale")) ||
          anyDuplicated(names(value)) || length(value) != 2L)
        .gbayes_stop("`prior$", pair[[1L]], "` must be `list(df=, scale=)` when learning is enabled.")
      value$df <- .gbayes_positive(value$df, paste0("prior$", pair[[1L]], "$df"))
      value$scale <- .gbayes_positive(value$scale, paste0("prior$", pair[[1L]], "$scale"))
      prior[[pair[[1L]]]] <- value
    } else if (!is.null(value))
      .gbayes_stop("`prior$", pair[[1L]], "` is only used when its learning flag is TRUE.")
  }
  if (control$estimate_weights) {
    expected <- if (method == "bayesc") 2L else length(prior$weights)
    if (!is.numeric(prior$weight_prior) || length(prior$weight_prior) != expected ||
        anyNA(prior$weight_prior) || any(!is.finite(prior$weight_prior)) ||
        any(prior$weight_prior <= 0))
      .gbayes_stop("`prior$weight_prior` must contain one positive Dirichlet concentration per component, null first.")
  } else if (!is.null(prior$weight_prior))
    .gbayes_stop("`prior$weight_prior` is only used with `control$estimate_weights = TRUE`.")
  prior
}

.gbayes_ld_swap <- function(x) {
  x <- .gbayes_named_list(if (is.null(x)) list() else x,
    list(probability = 0, minimum_r2 = 0.8, maximum_friends = 50L,
      moves = 1L), "control$ld_swap")
  for (name in c("probability", "minimum_r2"))
    if (!is.numeric(x[[name]]) || length(x[[name]]) != 1L ||
        !is.finite(x[[name]]) || x[[name]] < 0 || x[[name]] > 1)
      .gbayes_stop("`control$ld_swap$", name, "` must lie between zero and one.")
  x$maximum_friends <- .gbayes_count(x$maximum_friends,
    "control$ld_swap$maximum_friends")
  x$moves <- .gbayes_count(x$moves, "control$ld_swap$moves", 0)
  x
}

.gbayes_block_residual <- function(x, markers) {
  if (is.null(x)) return(NULL)
  x <- .gbayes_named_list(x, list(block = NULL, response_ss = NULL,
    likelihood_dimension = NULL, initial_variance = NULL,
    genetic_variance_denominator = NULL, prior_df = 4, prior_scale = NULL,
    mode = "sample", resample_threshold = 1.1,
    minimum_variance_ratio = 0.7, space = "full"),
    "control$block_residual")
  block <- x$block
  if (length(block) != length(markers) || anyNA(block) ||
      !identical(names(block), markers) || any(!nzchar(trimws(as.character(block)))))
    .gbayes_stop("`control$block_residual$block` must name one complete block label per marker in LD order.")
  labels <- unique(as.character(block))
  vector <- function(value, name) {
    if (length(value) == 1L) value <- rep(value, length(labels))
    if (!is.numeric(value) || length(value) != length(labels) || anyNA(value) ||
        any(!is.finite(value)) || any(value <= 0) ||
        (!is.null(names(value)) && !identical(names(value), labels)))
      .gbayes_stop("`", name, "` must be positive and follow first block order.")
    unname(value)
  }
  for (name in c("response_ss", "likelihood_dimension", "initial_variance",
      "genetic_variance_denominator", "prior_df"))
    x[[name]] <- vector(x[[name]], paste0("control$block_residual$", name))
  x$prior_scale <- if (is.null(x$prior_scale)) x$initial_variance else
    vector(x$prior_scale, "control$block_residual$prior_scale")
  x$mode <- match.arg(tolower(x$mode), c("sample", "mix", "all_mix", "fixed"))
  x$space <- match.arg(tolower(x$space), c("full", "retained"))
  x$resample_threshold <- .gbayes_positive(x$resample_threshold,
    "control$block_residual$resample_threshold")
  x$minimum_variance_ratio <- .gbayes_positive(x$minimum_variance_ratio,
    "control$block_residual$minimum_variance_ratio")
  x$block <- match(as.character(block), labels) - 1L
  x$block_names <- labels
  x
}

.gbayes_annotations <- function(annotation, markers, method, prior, control) {
  if (is.null(annotation)) return(list())
  if (!is.list(annotation) || !length(annotation) || is.null(names(annotation)) ||
      anyNA(names(annotation)) || any(!nzchar(names(annotation))) ||
      anyDuplicated(names(annotation)))
    .gbayes_stop("`annotation` must be a nonempty uniquely named list.")
  if ("bayess" %in% names(annotation)) {
    if ("variance" %in% names(annotation))
      .gbayes_stop("Choose `annotation$bayess` or `annotation$variance`, not both.")
    s <- .gbayes_named_list(annotation$bayess,
      list(allele_frequency = NULL, learn = TRUE, initial_s = 0,
        coefficient_prior_sd = 1, update_every = 1L,
        maximum_evaluations = 10000L), "annotation$bayess")
    af <- s$allele_frequency
    if (!is.numeric(af) || length(af) != length(markers) || anyNA(af) ||
        any(!is.finite(af)) || any(af <= 0 | af >= 1) ||
        !identical(names(af), markers))
      .gbayes_stop("BayesS allele frequencies must be inside (0,1) and named in marker order.")
    annotation$variance <- list(
      design = matrix(log(2 * unname(af) * (1 - unname(af))), ncol = 1L,
        dimnames = list(markers, "maf_exponent_s")), learn = s$learn,
      initial = stats::setNames(s$initial_s, "maf_exponent_s"),
      coefficient_prior_sd = s$coefficient_prior_sd,
      update_every = s$update_every,
      maximum_evaluations = s$maximum_evaluations)
    annotation$bayess <- NULL
  }
  allowed <- c("variance", if (method == "bayesc") "inclusion" else "component")
  if (!length(annotation) || any(!names(annotation) %in% allowed))
    .gbayes_stop("Available annotation roles are: ", paste(allowed, collapse = ", "), ".")
  out <- list()
  for (role in names(annotation)) {
    probit <- role == "component"
    defaults <- list(design = NULL, learn = TRUE, initial = NULL,
      coefficient_prior_sd = 1, update_every = 1L)
    if (probit) defaults <- c(defaults,
      list(intercept_prior_sd = 1, intercept_means = NULL))
    if (role == "inclusion") defaults$proposal_sd <- 0.1
    if (role == "variance") defaults$maximum_evaluations <- 10000L
    a <- .gbayes_named_list(annotation[[role]], defaults,
      paste0("annotation$", role))
    design <- a$design
    if (!is.matrix(design) || !is.numeric(design) || ncol(design) < 1L ||
        anyNA(design) || any(!is.finite(design)) ||
        !identical(rownames(design), markers) || is.null(colnames(design)) ||
        anyNA(colnames(design)) || any(!nzchar(colnames(design))) ||
        anyDuplicated(colnames(design)) || "(Intercept)" %in% colnames(design))
      .gbayes_stop("Annotation design must be finite with marker row names and unique non-intercept columns.")
    a$learn <- .gbayes_flag(a$learn, paste0("annotation$", role, "$learn"))
    a$update_every <- .gbayes_count(a$update_every,
      paste0("annotation$", role, "$update_every"))
    a$coefficient_prior_sd <- .gbayes_positive(a$coefficient_prior_sd,
      paste0("annotation$", role, "$coefficient_prior_sd"))
    if (role == "inclusion") a$proposal_sd <- .gbayes_positive(a$proposal_sd,
      "annotation$inclusion$proposal_sd")
    if (role == "variance") a$maximum_evaluations <- .gbayes_count(
      a$maximum_evaluations, "annotation$variance$maximum_evaluations")
    if (probit) {
      if (control$estimate_weights)
        .gbayes_stop("Component annotations replace global weight learning.")
      categories <- paste0("component_", seq_along(prior$weights) - 1L)
      sticks <- utils::head(categories, -1L)
      coefficients <- c("(Intercept)", colnames(design))
      a$intercept_prior_sd <- .gbayes_positive(a$intercept_prior_sd,
        "annotation$component$intercept_prior_sd")
      if (!is.null(a$intercept_means) && (!is.numeric(a$intercept_means) ||
          !identical(names(a$intercept_means), sticks) ||
          anyNA(a$intercept_means) || any(!is.finite(a$intercept_means))))
        .gbayes_stop("Component intercept means must be finite and named in stick order.")
      if (!is.null(a$initial) && (!is.matrix(a$initial) || !is.numeric(a$initial) ||
          !identical(rownames(a$initial), coefficients) ||
          !identical(colnames(a$initial), sticks) || anyNA(a$initial) ||
          any(!is.finite(a$initial))))
        .gbayes_stop("Component annotation initial values must be a labelled coefficient-by-stick matrix.")
      a$coefficient_names <- unlist(lapply(sticks,
        function(x) paste0(x, ":", coefficients)), use.names = FALSE)
      a$categories <- categories
    } else {
      if (!is.null(a$initial) && (!is.numeric(a$initial) || !is.null(dim(a$initial)) ||
          !identical(names(a$initial), colnames(design)) || anyNA(a$initial) ||
          any(!is.finite(a$initial))))
        .gbayes_stop("Annotation initial values must be named in design-column order.")
      a$coefficient_names <- colnames(design)
      a$categories <- if (role == "inclusion") "active" else character()
    }
    out[[role]] <- a
  }
  out
}

.gbayes_partition <- function(x, marker) {
  if (!is.character(x) || !is.null(dim(x)) ||
      !identical(names(x), marker) || anyNA(x) ||
      any(!nzchar(trimws(x))))
    .gbayes_stop("`posterior$partition` must be named in fitted marker order with one nonempty group per marker.")
  groups <- unique(unname(x))
  list(marker_ids = marker, group_ids = groups,
    marker_group = match(x, groups) - 1L)
}

.gbayes_prediction <- function(x, metadata) {
  x <- .gbayes_named_list(x, list(Glist = NULL, ids = NULL,
    target_set = "prediction", batch_size = 64L, retain_draws = FALSE,
    preparation_memory_limit_bytes = 256 * 1024^2), "posterior$prediction")
  if (!inherits(x$Glist, "Glist"))
    .gbayes_stop("`posterior$prediction$Glist` must be a gbase Glist.")
  gbase::validate_Glist(x$Glist)
  active <- which(lengths(x$Glist$rsids) > 0L)
  if (!length(active))
    .gbayes_stop("The prediction Glist must contain at least one active BED component.")
  marker <- unlist(x$Glist$rsids[active], use.names = FALSE)
  if (!length(marker) || anyDuplicated(marker))
    .gbayes_stop("Active prediction Glist markers must be nonempty and globally unique.")
  fit_index <- match(marker, metadata$marker_id)
  if (anyNA(fit_index))
    .gbayes_stop("Every active prediction Glist marker must have a fitted posterior effect: ",
      marker[which(is.na(fit_index))[[1L]]], ".")
  coordinate_ok <- as.character(unlist(x$Glist$chr[active], use.names = FALSE)) ==
    as.character(metadata$chromosome[fit_index]) &
    as.double(unlist(x$Glist$pos[active], use.names = FALSE)) ==
    as.double(metadata$base_pair_position[fit_index])
  allele_ok <- toupper(as.character(unlist(x$Glist$a1[active], use.names = FALSE))) ==
    toupper(as.character(metadata$allele1[fit_index])) &
    toupper(as.character(unlist(x$Glist$a2[active], use.names = FALSE))) ==
    toupper(as.character(metadata$allele2[fit_index]))
  if (anyNA(coordinate_ok) || any(!coordinate_ok))
    .gbayes_stop("Prediction Glist marker coordinates do not match the fitted effects.")
  if (anyNA(allele_ok) || any(!allele_ok))
    .gbayes_stop("Prediction Glist alleles must match the fitted counted-allele orientation.")
  ids <- x$ids
  selected_ids <- if (is.null(x$Glist$study_ids)) x$Glist$ids else x$Glist$study_ids
  if (is.null(ids)) ids <- selected_ids
  if (!is.character(ids) || !length(ids) || anyNA(ids) ||
      any(!nzchar(ids)) || anyDuplicated(ids) || any(!ids %in% selected_ids))
    .gbayes_stop("Prediction `ids` must be unique selected Glist sample IDs.")
  x$batch_size <- .gbayes_count(x$batch_size, "posterior$prediction$batch_size")
  x$preparation_memory_limit_bytes <- .gbayes_count(
    x$preparation_memory_limit_bytes,
    "posterior$prediction$preparation_memory_limit_bytes")
  x$retain_draws <- .gbayes_flag(x$retain_draws,
    "posterior$prediction$retain_draws")
  if (!is.character(x$target_set) || length(x$target_set) != 1L ||
      is.na(x$target_set) || !nzchar(x$target_set))
    .gbayes_stop("`posterior$prediction$target_set` must be one nonempty string.")
  components <- lapply(active, function(k) {
    local_marker <- as.character(x$Glist$rsids[[k]])
    list(bed_path = unname(x$Glist$bedfiles[[k]]),
      sample_count = as.double(x$Glist$n),
      physical_marker_count = as.double(x$Glist$physical_marker_counts[[k]]),
      marker_indices = as.double(x$Glist$source_marker_indices_0based[[k]]),
      marker = local_marker,
      fit_index = as.integer(match(local_marker, metadata$marker_id) - 1L),
      counted_allele = as.character(x$Glist$a1[[k]]),
      allele_frequencies = as.double(x$Glist$af[[k]]),
      effect_multipliers = rep(1, length(local_marker)))
  })
  list(components = components,
    sample_ids = as.character(x$Glist$ids),
    sample_indices = as.integer(match(ids, x$Glist$ids) - 1L),
    target_ids = ids, target_set = x$target_set,
    batch_size = as.integer(x$batch_size), retain_draws = x$retain_draws,
    preparation_memory_limit_bytes = x$preparation_memory_limit_bytes,
    coverage = list(fitted_markers = nrow(metadata), used_markers = length(marker),
      omitted_fitted_markers = nrow(metadata) - length(marker),
      fraction = length(marker) / nrow(metadata),
      active_bed_components = length(active)))
}

.gbayes_posterior <- function(x, metadata, traits) {
  x <- .gbayes_named_list(x, list(reference = NULL, partition = NULL,
    prediction = NULL, phenotype_variance = NULL,
    memory_limit_bytes = 256 * 1024^2), "posterior")
  x$memory_limit_bytes <- .gbayes_count(x$memory_limit_bytes,
    "posterior$memory_limit_bytes")
  marker <- metadata$marker_id
  if (!is.null(x$reference)) {
    if (!inherits(x$reference, "Glist"))
      .gbayes_stop("`posterior$reference` must be a Glist containing sparse LD.")
    gbase::validate_Glist(x$reference)
    if (!is.list(x$reference$sparseLD))
      .gbayes_stop("`posterior$reference` must contain sparse LD from gprep(task = \"sparseld\").")
    md <- x$reference$sparseLD$marker_metadata
    if (!identical(as.character(md$marker_id), as.character(marker)) ||
        !identical(toupper(as.character(md$allele1)),
          toupper(as.character(metadata$allele1))) ||
        !identical(toupper(as.character(md$allele2)),
          toupper(as.character(metadata$allele2))))
      .gbayes_stop("Posterior reference markers and alleles must match fitted order exactly.")
    reference_id <- x$reference$sparseLD$reference
    if (is.null(reference_id) || !length(reference_id) ||
        is.na(reference_id[[1L]]) || !nzchar(reference_id[[1L]]))
      reference_id <- "posterior-reference"
    x$reference <- list(prefix = x$reference$sparseLD$prefix,
      id = as.character(reference_id[[1L]]))
  }
  if (!is.null(x$partition))
    x$partition <- .gbayes_partition(x$partition, marker)
  if (!is.null(x$prediction))
    x$prediction <- .gbayes_prediction(x$prediction, metadata)
  if (!is.null(x$phenotype_variance)) {
    if (is.null(x$reference))
      .gbayes_stop("`phenotype_variance` requires `posterior$reference`.")
    x$phenotype_variance <- .gbayes_multi_vector(x$phenotype_variance,
      traits, "posterior$phenotype_variance", positive = TRUE)
  }
  x$fit_marker <- as.character(marker)
  x$fit_allele <- as.character(metadata$allele1)
  x$fit_frequency <- as.double(metadata$allele_frequency)
  x
}

.gbayes_chain_controls <- function(control, prior, method, continuation,
    bed = FALSE, block_eigen = FALSE, summary_eigen = FALSE) {
  defaults <- list(burnin = if (is.null(continuation)) 100L else 0L,
    sampling_sweeps = 1000L, thinning = 1L,
    seeds = if (is.null(continuation)) c(1, 2) else continuation$seeds,
    threads = 1L, retain_diagnostics = TRUE, probability = 0.95,
    estimate_effect_variance = FALSE, estimate_residual_variance = FALSE,
    estimate_weights = FALSE, ld_swap = NULL)
  if (bed) defaults <- c(defaults,
    list(likelihood_dimension = NULL,
      packed_memory_limit_bytes = 256 * 1024^2))
  else if (block_eigen) defaults <- c(defaults,
    list(eigen_control = list(), block_eigen_residual = list()))
  else defaults <- c(defaults, list(residual_policy = NULL,
    residual_adjustment = NULL, normalization = NULL, block_residual = NULL,
    sample_size = "common", storage = "memory", max_ld_entries = 1e7))
  if(summary_eigen) defaults$eigen_control <- list()
  control <- .gbayes_named_list(control, defaults, "control")
  for (name in c("burnin", "sampling_sweeps", "thinning", "threads"))
    control[[name]] <- .gbayes_count(control[[name]], paste0("control$", name),
      if (name == "burnin") 0 else 1)
  if (!is.numeric(control$seeds) || !length(control$seeds) ||
      anyNA(control$seeds) || any(!is.finite(control$seeds)) ||
      any(control$seeds < 0 | control$seeds > 2^32 - 1 |
        control$seeds != floor(control$seeds)) || anyDuplicated(control$seeds))
    .gbayes_stop("`control$seeds` must contain distinct integers between 0 and 2^32-1.")
  control$seeds <- as.double(control$seeds)
  control$retain_diagnostics <- .gbayes_flag(control$retain_diagnostics,
    "control$retain_diagnostics")
  if (!is.numeric(control$probability) || length(control$probability) != 1L ||
      !is.finite(control$probability) || control$probability <= 0 ||
      control$probability >= 1)
    .gbayes_stop("`control$probability` must lie strictly between zero and one.")
  for (name in c("estimate_effect_variance", "estimate_residual_variance",
      "estimate_weights"))
    control[[name]] <- .gbayes_flag(control[[name]], paste0("control$", name))
  control$ld_swap <- .gbayes_ld_swap(control$ld_swap)
  list(control = control, prior = prior)
}

.gbayes_bed_fit <- function(data, Glist, method, prior, control, trait, call,
    annotation, posterior, continuation) {
  parsed <- .gbayes_bed_data(data, Glist, trait)
  continuation <- .gbayes_continuation(continuation)
  prior <- .gbayes_prior(prior, method)
  parsed_controls <- .gbayes_chain_controls(control, prior, method,
    continuation, bed = TRUE)
  control <- parsed_controls$control; prior <- parsed_controls$prior
  prior <- .gbayes_learning_prior(prior, control, method)
  if (is.null(control$likelihood_dimension))
    control$likelihood_dimension <- length(parsed$ids)
  control$likelihood_dimension <- .gbayes_positive(control$likelihood_dimension,
    "control$likelihood_dimension")
  if (control$likelihood_dimension > length(parsed$ids))
    .gbayes_stop("`control$likelihood_dimension` cannot exceed the selected sample count.")
  control$packed_memory_limit_bytes <- .gbayes_count(
    control$packed_memory_limit_bytes, "control$packed_memory_limit_bytes")
  annotation <- .gbayes_annotations(annotation, parsed$marker, method, prior,
    control)
  metadata <- data.frame(marker_id = parsed$marker,
    chromosome = parsed$chromosome, base_pair_position = parsed$position,
    allele1 = parsed$allele1, allele2 = parsed$allele2,
    allele_frequency = parsed$allele_frequency, stringsAsFactors = FALSE)
  posterior <- .gbayes_posterior(posterior, metadata, parsed$trait)
  signature <- list(method = method, marker = parsed$marker,
    selected_ids = parsed$ids, trait = parsed$trait, prior = prior,
    annotation = annotation,
    transition_control = control[c("estimate_effect_variance",
      "estimate_residual_variance", "estimate_weights", "ld_swap")],
    bedfiles = normalizePath(parsed$paths, winslash = "/", mustWork = TRUE))
  states <- NULL
  if (!is.null(continuation)) {
    if (!identical(continuation$signature, signature))
      .gbayes_stop("The continuation model, data, prior, annotations, or transition controls differ from the saved state.")
    if (!identical(as.double(continuation$seeds), control$seeds))
      .gbayes_stop("Continuation seeds must retain saved chain order and values.")
    states <- continuation$states
  }
  native_control <- control
  native_control$scalar_initial_states <- states
  native <- cpp_gbayes_bed_fit(as.double(Glist$n),
    as.double(Glist$sample_source_indices_0based), parsed$paths,
    parsed$physical_marker_count, parsed$marker_indices, parsed$phenotype,
    parsed$marker, parsed$allele_frequency, parsed$trait, method, prior, native_control,
    annotation, posterior)
  if (!is.null(posterior$prediction))
    native$quantities$prediction$coverage <- posterior$prediction$coverage
  estimates <- data.frame(marker = parsed$marker, chromosome = parsed$chromosome,
    position = parsed$position, effect_allele = parsed$allele1,
    other_allele = parsed$allele2,
    allele_frequency = native$coding$allele_frequency,
    mean = native$mean, variance = native$variance, pip = native$pip,
    stringsAsFactors = FALSE)
  weights <- estimates[c("marker", "chromosome", "position", "effect_allele",
    "other_allele", "allele_frequency")]
  weights[[parsed$trait]] <- estimates$mean
  structure(list(call = call, method = method, trait = parsed$trait,
    likelihood = "individual_bed", estimates = estimates, weights = weights,
    component_probability = native$component_probability,
    parameter_mean = native$parameter_mean,
    posterior = if (nrow(native$quantity_posterior))
      rbind(native$posterior, native$quantity_posterior) else native$posterior,
    quantities = native$quantities,
    chains = native$chains, annotations = native$annotations,
    annotation = annotation, continuation = list(version = 1L,
      signature = signature, seeds = control$seeds,
      states = native$continuation_states),
    ld_swap = native$ld_swap,
    control = control, prior = prior,
    diagnostics = list(between_chain = native$between_chain,
      truncated_likelihood = native$truncated_likelihood),
    individual_bed = list(sample_count = native$sample_count,
      packed_memory_bytes = native$packed_memory_bytes,
      coding = native$coding),
    provenance = list(preparation = native$provenance,
      native_version = native$native_version, bedfiles = parsed$paths,
      selected_ids = parsed$ids, marker_order = parsed$marker,
      native = gbayes_native_info())), class = c("gbayes_fit", "list"))
}

.gbayes_flag <- function(x, name) {
  if (!is.logical(x) || length(x) != 1L || is.na(x))
    .gbayes_stop("`", name, "` must be TRUE or FALSE.")
  x
}

.gbayes_seed <- function(x, name = "control$seed") {
  if (!is.numeric(x) || length(x) != 1L || !is.finite(x) ||
      x < 0 || x > 2^32 - 1 || x != floor(x))
    .gbayes_stop("`", name, "` must be an integer between 0 and 2^32-1.")
  as.double(x)
}

.gbayes_engine_fit <- function(stat, Glist, method, prior, control, trait, call) {
  stat <- .gbayes_summary_stat(stat, Glist)
  if (length(unique(stat$n)) != 1L)
    .gbayes_stop("This method requires one common sample size.")
  marker_count <- nrow(stat)
  base_control <- list(storage = "memory", max_ld_entries = 1e7, threads = 1L)
  if (method == "point_normal") {
    prior <- .gbayes_named_list(prior, list(p = 0.01, h2 = 0.5), "prior")
    control <- .gbayes_named_list(control, c(base_control,
      list(burnin = 500L, sampling_sweeps = 200L, seed = 1,
        sparse = FALSE, auto_update = FALSE)), "control")
  } else if (method == "continuous_shrinkage") {
    prior <- .gbayes_named_list(prior, list(global_scale = 1), "prior")
    control <- .gbayes_named_list(control, c(base_control,
      list(burnin = 500L, sampling_sweeps = 500L, thinning = 5L,
        seed = 1, learn_global_scale = FALSE,
        maximum_block_dimension = 2048L, block_offsets = NULL,
        dense_workspace_budget_bytes = 256 * 1024^2)), "control")
  } else {
    prior_defaults <- if (method == "variational") list(p = 0.01, h2 = 0.5) else
      list(variances = NULL, weights = NULL)
    prior <- .gbayes_named_list(prior, prior_defaults, "prior")
    control <- .gbayes_named_list(control, c(base_control,
      list(maximum_iterations = 200L, tolerance = 1e-8,
        windows = matrix(integer(), 0L, 2L))), "control")
  }
  control$storage <- match.arg(control$storage, c("memory", "disk"))
  control$max_ld_entries <- .gbayes_count(control$max_ld_entries,
    "control$max_ld_entries")
  control$threads <- .gbayes_count(control$threads, "control$threads")
  if (control$threads != 1)
    .gbayes_stop("These scalar engines currently require `control$threads = 1`.")
  if (method == "point_normal") {
    prior$p <- .gbayes_positive(prior$p, "prior$p")
    prior$h2 <- .gbayes_positive(prior$h2, "prior$h2")
    if (prior$p > 1) .gbayes_stop("`prior$p` must not exceed one.")
    control$burnin <- .gbayes_count(control$burnin, "control$burnin", 0)
    control$sampling_sweeps <- .gbayes_count(control$sampling_sweeps,
      "control$sampling_sweeps")
    control$seed <- .gbayes_seed(control$seed)
    control$sparse <- .gbayes_flag(control$sparse, "control$sparse")
    control$auto_update <- .gbayes_flag(control$auto_update,
      "control$auto_update")
  } else if (method == "continuous_shrinkage") {
    if (control$storage != "memory")
      .gbayes_stop("Continuous shrinkage requires `control$storage = \"memory\"`.")
    prior$global_scale <- .gbayes_positive(prior$global_scale,
      "prior$global_scale")
    for (name in c("burnin", "sampling_sweeps", "thinning"))
      control[[name]] <- .gbayes_count(control[[name]], paste0("control$", name),
        if (name == "burnin") 0 else 1)
    control$seed <- .gbayes_seed(control$seed)
    control$learn_global_scale <- .gbayes_flag(control$learn_global_scale,
      "control$learn_global_scale")
    control$maximum_block_dimension <- .gbayes_count(
      control$maximum_block_dimension, "control$maximum_block_dimension")
    control$dense_workspace_budget_bytes <- .gbayes_count(
      control$dense_workspace_budget_bytes,
      "control$dense_workspace_budget_bytes")
    offsets <- control$block_offsets
    if (!is.numeric(offsets) || length(offsets) < 2L || anyNA(offsets) ||
        any(!is.finite(offsets)) || any(offsets != floor(offsets)) ||
        offsets[[1L]] != 0 || offsets[[length(offsets)]] != marker_count ||
        any(diff(offsets) <= 0))
      .gbayes_stop("`control$block_offsets` must be increasing zero-based boundaries from 0 to the marker count.")
    if (any(diff(offsets) > control$maximum_block_dimension))
      .gbayes_stop("A declared block exceeds `control$maximum_block_dimension`.")
    control$block_offsets <- as.double(offsets)
  } else {
    if (method == "variational") {
      prior$p <- .gbayes_positive(prior$p, "prior$p")
      prior$h2 <- .gbayes_positive(prior$h2, "prior$h2")
      if (prior$p > 1) .gbayes_stop("`prior$p` must not exceed one.")
    } else {
      if (!is.numeric(prior$variances) || !is.numeric(prior$weights) ||
          !length(prior$weights) || length(prior$variances) != length(prior$weights) ||
          anyNA(prior$variances) || anyNA(prior$weights) ||
          any(!is.finite(c(prior$variances, prior$weights))) ||
          any(prior$variances < 0) || any(prior$weights <= 0) ||
          abs(sum(prior$weights) - 1) > 1e-10)
        .gbayes_stop("Mixture variational fitting requires nonnegative variances and positive normalized weights.")
    }
    control$maximum_iterations <- .gbayes_count(control$maximum_iterations,
      "control$maximum_iterations")
    control$tolerance <- .gbayes_positive(control$tolerance,
      "control$tolerance")
    windows <- control$windows
    if (!is.matrix(windows) || !is.numeric(windows) || ncol(windows) != 2L ||
        anyNA(windows) || any(!is.finite(windows)) || any(windows != floor(windows)) ||
        any(windows < 1 | windows > marker_count) ||
        (nrow(windows) && any(windows[, 1L] > windows[, 2L])))
      .gbayes_stop("`control$windows` must be a two-column matrix of one-based inclusive marker ranges.")
    storage.mode(windows) <- "integer"; control$windows <- windows
  }
  native <- cpp_gbayes_engine(Glist$sparseLD$prefix, as.character(stat$rsids),
    as.double(stat$beta_std), as.double(stat$n), trait, method, prior, control)
  metadata <- Glist$sparseLD$marker_metadata
  estimates <- data.frame(marker = metadata$marker_id,
    chromosome = metadata$chromosome, position = metadata$base_pair_position,
    effect_allele = metadata$allele1, other_allele = metadata$allele2,
    allele_frequency = metadata$allele_frequency, mean = native$mean,
    variance = native$variance, pip = native$pip, stringsAsFactors = FALSE)
  weights <- estimates[c("marker", "chromosome", "position", "effect_allele",
    "other_allele", "allele_frequency")]
  weights[[trait]] <- estimates$mean
  structure(list(call = call, method = method, trait = trait,
    likelihood = "summary_statistics", estimates = estimates, weights = weights,
    parameter_mean = NULL, chains = list(), prior = prior, control = control,
    diagnostics = native$diagnostics,
    provenance = list(preparation = native$provenance,
      native_version = native$native_version,
      reference_sample_count = Glist$sparseLD$n,
      sample_size_range = range(stat$n), checksums = Glist$sparseLD$checksums,
      native = gbayes_native_info())), class = c("gbayes_fit", "list"))
}

#' Fit Bayesian regression from summaries or individual genotypes
#'
#' Fits scalar or multivariate Bayesian models against sparse signed LD or
#' selected individual-level PLINK genotypes. Summary effects are converted to the
#' standardized native Gaussian likelihood scale; individual genotypes are
#' standardized by native packed-BED preparation.
#' @param stat Ordinary checked summary-statistics data frame from
#'   [gbase::checkStat()] with `rsids`, `chr`, `pos`, `ea`, `nea`, `b`, `seb`,
#'   and `n`; a named list selects multivariate fitting. Omit for
#'   individual-level fitting.
#' @param Glist A validated Glist, or for independent study-specific summary
#'   references a named list of Glists matching `stat`. Summary fitting requires
#'   sparse LD; individual fitting uses selected BED samples and markers.
#' @param data For individual-level fitting, an ordinary data frame containing
#'   unique character `id` values and one finite pre-adjusted phenotype column.
#' @param method One of `"bayesr"`, `"bayesc"`, `"sbayesrc"`,
#'   `"point_normal"`, `"continuous_shrinkage"`, `"variational"`, or
#'   `"mixture_variational"`. SBayesRC is a single-trait summary route using
#'   verified Glist LD blocks, retained block eigensystems and a BayesR
#'   component-annotation prior. The remaining four focused engines are also
#'   summary-only.
#' @param prior Named method-specific fixed priors. BayesC/BayesR use
#'   `residual_variance`, `effect_variance`, and their mixture settings;
#'   point-normal and variational fitting use `p` and `h2`; continuous
#'   shrinkage uses `global_scale`; mixture variational fitting uses
#'   `variances` and normalized `weights`.
#' @param control Named method-specific controls. Common summary settings are
#'   `storage`, `max_ld_entries`, and single-thread execution. Gibbs engines
#'   accept sweep and seed controls, continuous shrinkage additionally accepts
#'   explicit zero-based `block_offsets`, and variational engines accept
#'   `maximum_iterations`, `tolerance`, and optional one-based `windows`.
#'   BayesC/BayesR additionally accept learning flags, `probability`,
#'   summary `residual_policy`, `block_residual`, and `ld_swap` settings.
#'   Scalar summary `ld_swap` uses `probability` (default zero), `minimum_r2`
#'   (default .8), `maximum_friends` (default 50), and `moves` (default one).
#'   SBayesRC accepts `eigen_control` and `block_eigen_residual`; its block
#'   residual likelihood is normalized in the retained eigenspace.
#' @param trait Scalar summary output label or phenotype column. For
#'   multivariate individual fitting it is a character vector of phenotype
#'   columns. For study-specific summaries it maps named studies to traits.
#' @param sampling Required multivariate summary sampling model. Declare
#'   `dependence="independent"` with named residual variances, or
#'   `dependence="shared_ld"` with a labelled covariance matrix.
#' @param annotation Optional BayesC `inclusion`, BayesR `component`, general
#'   `variance`, or BayesS `bayess` annotation specification. Design rows must
#'   be named in fitted marker order. SBayesRC requires `component`.
#' @param posterior Optional posterior quantities: an aligned sparse-LD
#'   `reference` Glist, a fitted-marker `partition`, `phenotype_variance`, and
#'   selected-individual `prediction` using a target Glist and optional IDs.
#'   Active prediction markers may span multiple BED components, may be a strict
#'   subset of fitted markers, and are resolved in Glist component and marker
#'   order. `memory_limit_bytes` bounds incremental capture.
#' @param continuation A previous `gbayes_fit` or its version-1 continuation
#'   object. Model-defining inputs must be repeated unchanged; burn-in becomes
#'   zero and saved chain seeds/states are restored exactly.
#' @return A serializable `gbayes_fit` containing estimates, standardized
#'   genomic-score weights, requested posterior quantities, chain summaries,
#'   controls, and provenance.
#' @noRd
.gbayes_fit <- function(stat = NULL, Glist, method = c("bayesr", "bayesc", "sbayesrc",
                   "point_normal", "continuous_shrinkage", "variational",
                   "mixture_variational"),
                   prior = list(), control = list(), trait = NULL,
                   data = NULL, annotation = NULL, posterior = list(),
                   continuation = NULL, sampling = NULL, algorithm = "mcmc",
                   fitted_variance = FALSE) {
  call <- match.call(); method <- match.arg(method)
  eigen <- identical(algorithm,"mcmc-eigen")
  if(eigen && (!is.data.frame(stat) || !is.null(data) ||
      !method %in% c("bayesc","bayesr")))
    .gbayes_stop("mcmc-eigen supports one summary-statistic BayesC/BayesR fit.")
  if (!is.null(data)) {
    if (!is.null(stat))
      .gbayes_stop("Supply either `stat` or `data`, not both.")
    if (!method %in% c("bayesr", "bayesc"))
      .gbayes_stop("Individual-level fitting currently supports only BayesC and BayesR.")
    if (is.character(trait) && length(trait) > 1L)
      return(.gbayes_multivariate_fit(NULL, Glist, data, method, prior,
        control, sampling, trait, call, annotation, posterior, continuation))
    gbase::validate_Glist(Glist)
    return(.gbayes_bed_fit(data, Glist, method, prior, control, trait, call,
      annotation, posterior, continuation))
  }
  if (is.null(stat)) .gbayes_stop("Supply either `stat` or `data`.")
  if (is.list(stat) && !is.data.frame(stat)) {
    if (method == "sbayesrc")
      .gbayes_stop("SBayesRC block-eigen fitting currently supports one trait per call.")
    return(.gbayes_multivariate_fit(stat, Glist, NULL, method, prior,
      control, sampling, trait, call, annotation, posterior, continuation))
  }
  gbase::validate_Glist(Glist)
  if (is.null(trait)) trait <- "trait"
  if (!is.character(trait) || length(trait) != 1L || is.na(trait) || !nzchar(trait))
    .gbayes_stop("`trait` must be one nonempty string.")
  if (!is.list(Glist$sparseLD))
    .gbayes_stop("`Glist` must contain sparse LD from gprep(task = \"sparseld\").")
  if (method == "sbayesrc")
    return(.gbayes_sbayesrc_fit(stat, Glist, prior, control, trait, call,
      annotation, posterior, continuation))
  if (!method %in% c("bayesr", "bayesc")) {
    if (!is.null(annotation) || length(posterior) || !is.null(continuation))
      .gbayes_stop("Annotations, posterior capture, and continuation currently apply only to BayesC and BayesR.")
    return(.gbayes_engine_fit(stat, Glist, method, prior, control, trait, call))
  }
  stat <- .gbayes_summary_stat(stat, Glist)
  continuation <- .gbayes_continuation(continuation)
  prior <- .gbayes_prior(prior, method)
  parsed_controls <- .gbayes_chain_controls(control, prior, method,
    continuation, bed = FALSE, summary_eigen = eigen)
  control <- parsed_controls$control; prior <- parsed_controls$prior
  control$sample_size <- match.arg(control$sample_size, c("common", "variable"))
  control$storage <- match.arg(control$storage, c("memory", "disk"))
  control$max_ld_entries <- .gbayes_count(control$max_ld_entries,
    "control$max_ld_entries")
  if (control$sample_size == "common" && length(unique(stat$n)) != 1L)
    .gbayes_stop("Different sample sizes require `control$sample_size = \"variable\"`.")
  if (control$storage == "disk" && control$threads != 1)
    .gbayes_stop("Disk sparse-LD storage requires `control$threads = 1`.")
  if(eigen) {
    if(is.null(Glist$ldBlocks))
      .gbayes_stop("mcmc-eigen requires verified blocks from gbase::define_ld_blocks().")
    if(control$sample_size!="common" || length(unique(stat$n))!=1L)
      .gbayes_stop("mcmc-eigen requires one common sample size.")
    if(!is.null(control$block_residual))
      .gbayes_stop("Use SBayesRC for block-specific eigen residual scales.")
    control$eigen_control <- .gbayes_block_eigen_control(control$eigen_control)
  }
  policy <- control$residual_policy
  if (is.null(policy)) policy <- if (control$estimate_residual_variance)
    if(eigen) "retained" else "in_sample" else "fixed"
  if (!is.character(policy) || length(policy) != 1L || is.na(policy))
    .gbayes_stop("`control$residual_policy` must be fixed, in_sample, or reference_ld.")
  policy <- match.arg(tolower(policy), c("fixed", "in_sample", "reference_ld",
    if(eigen) "retained"))
  if(eigen && !policy %in% c("fixed","retained"))
    .gbayes_stop("mcmc-eigen residual learning uses the retained likelihood; choose retained or fixed.")
  if (policy == "fixed" && control$estimate_residual_variance)
    .gbayes_stop("Fixed residual policy conflicts with residual-variance learning.")
  if (policy != "fixed") control$estimate_residual_variance <- TRUE
  control$residual_policy <- policy
  if (policy == "reference_ld") {
    if (is.null(control$residual_adjustment)) control$residual_adjustment <- 0.9
    if (!is.numeric(control$residual_adjustment) ||
        length(control$residual_adjustment) != 1L ||
        !is.finite(control$residual_adjustment) || control$residual_adjustment < 0)
      .gbayes_stop("`control$residual_adjustment` must be one nonnegative number.")
    if (!is.null(control$normalization))
      .gbayes_stop("Reference-LD normalization is inferred; do not supply it.")
    if (control$sample_size != "common" || length(unique(stat$n)) != 1L)
      .gbayes_stop("Reference-LD residual learning requires common sample size.")
    n <- unique(stat$n)
    control$normalization <- list(response_ss = n,
      likelihood_dimension = n, in_sample_ld = FALSE)
  } else if (policy == "in_sample") {
    if (!is.null(control$residual_adjustment))
      .gbayes_stop("`control$residual_adjustment` is only used by reference-LD learning.")
    norm <- control$normalization
    if (!is.list(norm) || length(norm) != 3L ||
        !setequal(names(norm), c("response_ss", "likelihood_dimension", "in_sample_ld")) ||
        !identical(norm$in_sample_ld, TRUE))
      .gbayes_stop("In-sample residual learning requires normalization with response_ss, likelihood_dimension, and in_sample_ld=TRUE.")
    norm$response_ss <- .gbayes_positive(norm$response_ss,
      "control$normalization$response_ss")
    norm$likelihood_dimension <- .gbayes_count(norm$likelihood_dimension,
      "control$normalization$likelihood_dimension")
    if (control$sample_size != "common" || any(stat$n != Glist$sparseLD$n))
      .gbayes_stop("In-sample residual learning requires common n equal to the sparse-LD reference sample count.")
    metadata <- Glist$sparseLD$marker_metadata
    complete_variant_window <-
      (Glist$sparseLD$max_distance_variants == 0 &&
        isTRUE(Glist$sparseLD$provenance$allow_full_ld)) ||
      Glist$sparseLD$max_distance_variants >= nrow(metadata) - 1L
    if (length(unique(metadata$chromosome)) != 1L ||
        Glist$sparseLD$r2_threshold != 0 || Glist$sparseLD$max_distance_bp != 0 ||
        !complete_variant_window)
      .gbayes_stop("In-sample residual learning requires complete one-chromosome LD with no threshold or window truncation.")
    control$normalization <- norm
    control$residual_adjustment <- 0
  } else if(policy=="retained") {
    if(!is.null(control$normalization)||!is.null(control$residual_adjustment))
      .gbayes_stop("Retained eigen normalization is inferred; do not supply normalization or residual_adjustment.")
    # The native binder replaces these with the verified retained response/rank.
    control$normalization <- list(response_ss=1,likelihood_dimension=1)
    control$residual_adjustment <- 0
  } else {
    if (!is.null(control$normalization) || !is.null(control$residual_adjustment))
      .gbayes_stop("Normalization and residual adjustment require residual learning.")
    control$residual_adjustment <- 0
  }
  prior <- .gbayes_learning_prior(prior, control, method)
  metadata <- Glist$sparseLD$marker_metadata
  control$block_residual <- .gbayes_block_residual(control$block_residual,
    metadata$marker_id)
  if (!is.null(control$block_residual) && policy != "fixed")
    .gbayes_stop("Block residuals cannot be combined with global residual learning.")
  annotation <- .gbayes_annotations(annotation, metadata$marker_id, method,
    prior, control)
  posterior <- .gbayes_posterior(posterior, metadata, trait)
  transition_names <- c("estimate_effect_variance", "estimate_residual_variance",
    "estimate_weights", "residual_policy", "residual_adjustment",
    "normalization", "block_residual", "ld_swap", "sample_size")
  signature <- list(method = method, marker = metadata$marker_id,
    trait = trait, prior = prior, annotation = annotation,
    transition_control = control[transition_names],
    checksums = Glist$sparseLD$checksums)
  if(eigen) signature$eigen <- list(control=control$eigen_control,
    offsets=Glist$ldBlocks$offsets_0based)
  states <- NULL
  if (!is.null(continuation)) {
    if (!identical(continuation$signature, signature))
      .gbayes_stop("The continuation model, reference, prior, annotations, or transition controls differ from the saved state.")
    if (!identical(as.double(continuation$seeds), control$seeds))
      .gbayes_stop("Continuation seeds must retain saved chain order and values.")
    states <- continuation$states
  }
  native_control <- control
  native_control$scalar_initial_states <- states
  native_control$fitted_variance <- fitted_variance
  if(eigen) native_control$eigen_offsets <- as.double(Glist$ldBlocks$offsets_0based)
  native <- cpp_gbayes_summary_fit(Glist$sparseLD$prefix,
    as.character(stat$rsids), as.double(stat$beta_std), as.double(stat$n),
    trait, method, prior, native_control, annotation, posterior)
  if(eigen && control$estimate_residual_variance)
    control$normalization <- native$eigen_normalization
  if (!is.null(posterior$prediction))
    native$quantities$prediction$coverage <- posterior$prediction$coverage
  estimates <- data.frame(marker = metadata$marker_id,
    chromosome = metadata$chromosome, position = metadata$base_pair_position,
    effect_allele = metadata$allele1, other_allele = metadata$allele2,
    allele_frequency = metadata$allele_frequency, mean = native$mean,
    variance = native$variance, pip = native$pip, stringsAsFactors = FALSE)
  weights <- estimates[c("marker", "chromosome", "position", "effect_allele",
    "other_allele", "allele_frequency")]
  weights[[trait]] <- estimates$mean
  structure(list(call = call, method = method, trait = trait,
    likelihood = if(eigen) "retained_block_eigen" else "summary_statistics",
    algorithm = algorithm, fitted_variance = isTRUE(native$fitted_variance),
    estimates = estimates, weights = weights,
    component_probability = native$component_probability,
    parameter_mean = native$parameter_mean,
    posterior = if (nrow(native$quantity_posterior))
      rbind(native$posterior, native$quantity_posterior) else native$posterior,
    quantities = native$quantities,
    chains = native$chains, annotations = native$annotations,
    annotation = annotation, continuation = list(version = 1L,
      signature = signature, seeds = control$seeds,
      states = native$continuation_states),
    block_residual_variance_mean = if (is.null(control$block_residual))
      native$block_residual_variance_mean else stats::setNames(
        native$block_residual_variance_mean,
        control$block_residual$block_names),
    ld_swap = native$ld_swap,
    control = control, prior = prior,
    diagnostics = list(between_chain = native$between_chain,
      truncated_likelihood = native$truncated_likelihood,
      block_eigen = native$block_eigen),
    provenance = list(preparation = native$provenance,
      native_version = native$native_version,
      reference_sample_count = Glist$sparseLD$n,
      sample_size_range = range(stat$n), checksums = Glist$sparseLD$checksums,
      native = gbayes_native_info())), class = c("gbayes_fit", "list"))
}

#' @export
print.gbayes_fit <- function(x, ...) {
  cat("<gbayes_fit>", x$method, "|", x$trait, "|",
    nrow(x$estimates), "markers |", length(x$chains), "chains\n")
  invisible(x)
}

#' Fit a deterministic single-effect model
#' @param stat An ordinary data frame containing `rsids` and either `b`/`seb`
#'   or `score`/`information`.
#' @param trait,response_units Optional output labels.
#' @param residual_variance,effect_variance Positive variance parameters.
#' @param marker_weights Optional nonnegative marker prior weights.
#' @return Per-marker posterior assignment probabilities and moments.
#' @export
gbayes_single_effect <- function(stat, residual_variance=1, effect_variance=1,
    marker_weights=NULL, trait="trait", response_units=NA_character_) {
  if (!identical(class(stat), "data.frame") || !nrow(stat) ||
      !"rsids" %in% names(stat) || !is.character(stat$rsids) ||
      anyNA(stat$rsids) || any(!nzchar(stat$rsids)) || anyDuplicated(stat$rsids))
    stop("stat must be a nonempty ordinary data frame with unique rsids.", call.=FALSE)
  if (all(c("b", "seb") %in% names(stat))) {
    information <- 1 / stat$seb^2; score <- stat$b * information
  } else if (all(c("score", "information") %in% names(stat))) {
    information <- stat$information; score <- stat$score
  } else stop("stat must contain b/seb or score/information.", call.=FALSE)
  if (!is.numeric(score) || !is.numeric(information) || any(!is.finite(score)) ||
      any(!is.finite(information)) || any(information <= 0))
    stop("stat likelihood columns must be finite with positive information.", call.=FALSE)
  if (!is.character(trait) || length(trait)!=1L || is.na(trait) || !nzchar(trait) ||
      !is.character(response_units) || length(response_units)!=1L)
    stop("trait and response_units must be scalar character labels.", call.=FALSE)
  if (any(!is.finite(c(residual_variance,effect_variance))) || residual_variance <= 0 || effect_variance <= 0)
    stop("Variances must be positive finite values.", call.=FALSE)
  if (is.null(marker_weights)) marker_weights <- numeric()
  if (length(marker_weights) && (length(marker_weights) != nrow(stat) || any(!is.finite(marker_weights)) || any(marker_weights < 0) || !any(marker_weights > 0)))
    stop("marker_weights must be nonnegative with at least one positive value.", call.=FALSE)
  cpp_gbayes_single_effect(stat$rsids, score, information, trait,
    response_units, residual_variance, effect_variance, marker_weights)
}
