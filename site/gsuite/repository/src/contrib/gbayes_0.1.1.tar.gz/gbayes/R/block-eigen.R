.gbayes_block_eigen_control <- function(control) {
  defaults <- list(retained_positive_mass = 0.995,
    maximum_block_dimension = 2048,
    symmetry_tolerance = 64 * .Machine$double.eps,
    verification_tolerance = 1e-10)
  control <- .gbayes_named_list(control, defaults, "eigen_control")
  control$retained_positive_mass <- .gbayes_positive(
    control$retained_positive_mass, "eigen_control$retained_positive_mass")
  if (control$retained_positive_mass > 1)
    .gbayes_stop("`eigen_control$retained_positive_mass` must not exceed one.")
  control$maximum_block_dimension <- .gbayes_count(
    control$maximum_block_dimension, "eigen_control$maximum_block_dimension")
  for (name in c("symmetry_tolerance", "verification_tolerance"))
    control[[name]] <- .gbayes_positive(control[[name]],
      paste0("eigen_control$", name))
  control
}

.gbayes_block_eigen_residual <- function(control, residual_variance) {
  control <- .gbayes_named_list(control, list(mode = "all_mix", prior_df = 4,
    prior_scale = NULL, resample_threshold = 1.1,
    minimum_variance_ratio = 0.7), "control$block_eigen_residual")
  control$mode <- match.arg(tolower(control$mode),
    c("all_mix", "mix", "sample", "fixed"))
  control$prior_df <- .gbayes_positive(control$prior_df,
    "control$block_eigen_residual$prior_df")
  if (control$prior_df <= 2)
    .gbayes_stop("`control$block_eigen_residual$prior_df` must exceed two.")
  if (is.null(control$prior_scale))
    control$prior_scale <- (control$prior_df - 2) / control$prior_df *
      residual_variance
  control$prior_scale <- .gbayes_positive(control$prior_scale,
    "control$block_eigen_residual$prior_scale")
  control$resample_threshold <- .gbayes_positive(control$resample_threshold,
    "control$block_eigen_residual$resample_threshold")
  control$minimum_variance_ratio <- .gbayes_positive(
    control$minimum_variance_ratio,
    "control$block_eigen_residual$minimum_variance_ratio")
  control
}

.gbayes_prepare_block_eigen <- function(stat, Glist, eigen_control = list()) {
  gbase::validate_Glist(Glist)
  if (is.null(Glist$ldBlocks))
    .gbayes_stop("`Glist` requires verified blocks from gbase::define_ld_blocks().")
  if (is.data.frame(stat)) stat <- list(trait = stat)
  if (!is.list(stat) || !length(stat) || is.null(names(stat)) ||
      anyNA(names(stat)) || any(!nzchar(names(stat))) || anyDuplicated(names(stat)))
    .gbayes_stop("`stat` must be a data frame or a uniquely named list of data frames.")
  prepared <- lapply(stat, .gbayes_summary_stat, Glist = Glist)
  marker <- Glist$sparseLD$marker_metadata$marker_id
  beta <- vapply(prepared, function(value) value$beta_std, numeric(length(marker)))
  sample_size <- vapply(prepared, function(value) value$n, numeric(length(marker)))
  if (is.null(dim(beta))) beta <- matrix(beta, ncol = 1L)
  if (is.null(dim(sample_size))) sample_size <- matrix(sample_size, ncol = 1L)
  result <- cpp_gbayes_block_eigen_prepare(Glist$sparseLD$prefix,
    as.double(Glist$ldBlocks$offsets_0based), as.character(marker), beta,
    sample_size, names(prepared), .gbayes_block_eigen_control(eigen_control))
  dimnames(result$projected_score) <- list(marker, names(prepared))
  dimnames(result$response_coordinates) <- list(NULL, names(prepared))
  names(result$maximum_score_projection_change) <- names(prepared)
  names(result$relative_score_projection_change) <- names(prepared)
  result
}

.gbayes_sbayesrc_fit <- function(stat, Glist, prior, control, trait, call,
    annotation, posterior, continuation) {
  if (is.null(Glist$ldBlocks))
    .gbayes_stop("SBayesRC requires verified blocks from gbase::define_ld_blocks().")
  stat <- .gbayes_summary_stat(stat, Glist)
  if (length(unique(stat$n)) != 1L)
    .gbayes_stop("SBayesRC block-eigen fitting requires one common sample size.")
  continuation <- .gbayes_continuation(continuation)
  prior <- .gbayes_prior(prior, "bayesr")
  parsed <- .gbayes_chain_controls(control, prior, "bayesr", continuation,
    block_eigen = TRUE)
  control <- parsed$control; prior <- parsed$prior
  if (control$estimate_residual_variance)
    .gbayes_stop("SBayesRC uses block residual scales; do not enable global residual-variance learning.")
  prior <- .gbayes_learning_prior(prior, control, "bayesr")
  control$eigen_control <- .gbayes_block_eigen_control(control$eigen_control)
  control$block_eigen_residual <- .gbayes_block_eigen_residual(
    control$block_eigen_residual, prior$residual_variance)
  metadata <- Glist$sparseLD$marker_metadata
  annotation <- .gbayes_annotations(annotation, metadata$marker_id, "bayesr",
    prior, control)
  if (is.null(annotation$component))
    .gbayes_stop("SBayesRC requires `annotation$component`.")
  posterior <- .gbayes_posterior(posterior, metadata, trait)
  transition_names <- c("estimate_effect_variance", "estimate_weights",
    "ld_swap", "eigen_control", "block_eigen_residual")
  signature <- list(method = "sbayesrc", marker = metadata$marker_id,
    trait = trait, prior = prior, annotation = annotation,
    transition_control = control[transition_names],
    checksums = Glist$sparseLD$checksums,
    block_offsets = Glist$ldBlocks$offsets_0based)
  states <- NULL
  if (!is.null(continuation)) {
    if (!identical(continuation$signature, signature))
      .gbayes_stop("The continuation model, blocks, prior, annotations, or transition controls differ from the saved state.")
    if (!identical(as.double(continuation$seeds), control$seeds))
      .gbayes_stop("Continuation seeds must retain saved chain order and values.")
    states <- continuation$states
  }
  native_control <- control
  native_control$scalar_initial_states <- states
  native_control$estimate_residual_variance <- FALSE
  native_control$residual_policy <- NULL
  native_control$residual_adjustment <- NULL
  native_control$normalization <- NULL
  native_control$block_residual <- NULL
  native <- cpp_gbayes_sbayesrc_fit(Glist$sparseLD$prefix,
    as.double(Glist$ldBlocks$offsets_0based), as.character(stat$rsids),
    as.double(stat$beta_std), as.double(stat$n), trait, prior, native_control,
    annotation, posterior)
  if (!is.null(posterior$prediction))
    native$quantities$prediction$coverage <- posterior$prediction$coverage
  estimates <- data.frame(marker = metadata$marker_id,
    chromosome = metadata$chromosome, position = metadata$base_pair_position,
    effect_allele = metadata$allele1, other_allele = metadata$allele2,
    allele_frequency = metadata$allele_frequency, mean = native$mean,
    variance = native$variance, pip = native$pip, stringsAsFactors = FALSE)
  weights <- estimates[c("marker", "chromosome", "position", "effect_allele",
    "other_allele", "allele_frequency")]
  weights[[trait]] <- estimates$mean
  block_names <- as.character(Glist$ldBlocks$blocks$block_id)
  structure(list(call = call, method = "sbayesrc", trait = trait,
    likelihood = "retained_block_eigen", estimates = estimates,
    weights = weights, component_probability = native$component_probability,
    parameter_mean = native$parameter_mean,
    posterior = if (nrow(native$quantity_posterior))
      rbind(native$posterior, native$quantity_posterior) else native$posterior,
    quantities = native$quantities, chains = native$chains,
    annotations = native$annotations, annotation = annotation,
    continuation = list(version = 1L, signature = signature,
      seeds = control$seeds, states = native$continuation_states),
    block_residual_variance_mean = stats::setNames(
      native$block_residual_variance_mean, block_names),
    ld_swap = native$ld_swap, control = control, prior = prior,
    diagnostics = list(between_chain = native$between_chain,
      truncated_likelihood = native$truncated_likelihood,
      block_eigen = native$block_eigen),
    provenance = list(preparation = native$provenance,
      native_version = native$native_version,
      reference_sample_count = Glist$sparseLD$n,
      sample_size_range = range(stat$n), checksums = Glist$sparseLD$checksums,
      ld_blocks = Glist$ldBlocks, native = gbayes_native_info())),
    class = c("gbayes_fit", "list"))
}
