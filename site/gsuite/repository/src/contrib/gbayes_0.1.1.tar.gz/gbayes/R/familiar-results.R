.gbayes_familiar_post <- function(fit) {
  p <- fit$parameter_mean;weights <- p$weights
  vg <- if(isTRUE(fit$fitted_variance))
    as.double(fit$quantities$genetic$covariance_mean[1,1]) else NA_real_
  e <- fit$estimates
  out <- data.frame(ve=p$residual_variance,vg=vg,vb=p$effect_variance,
    pi=if(length(weights)) 1-weights[1L] else NA_real_,pip=sum(e$pip),
    minb=min(e$mean),maxb=max(e$mean),m=nrow(e),row.names=fit$trait)
  for(k in seq_along(weights)) out[[paste0("pi",k-1L)]] <- weights[k]
  attr(out,"definitions") <- c(vg="Posterior mean b' C b / common sample size on the fitted likelihood; unavailable with a distinct explicit posterior reference or variable sample sizes",
    pi="Posterior mean total non-null mixture probability",
    pip="Sum of marginal marker PIPs; expected active count")
  out
}

.gbayes_familiar_conv <- function(fit) {
  x <- fit$posterior
  out <- data.frame(nrun=length(fit$chains),
    draws=sum(vapply(fit$chains,`[[`,numeric(1),"retained_draws")),
    max_pip_range=if(length(fit$chains)>1L)
      max(fit$diagnostics$between_chain$pip_range) else NA_real_,row.names=fit$trait)
  labels <- c(ve="residual_variance",vg=paste0("genetic_covariance[",fit$trait,",",fit$trait,"]"),
    vb="effect_variance",pi="weight_0",pip="active_markers")
  for(name in names(labels)) {
    at <- match(labels[[name]],x$parameter)
    if(name=="vg" && !isTRUE(fit$fitted_variance)) at <- NA_integer_
    out[[paste0("rhat_",name)]] <- x$rhat[at]
    out[[paste0("ess_",name)]] <- x$ess_bulk[at]
    out[[paste0("mcse_",name)]] <- x$mcse_mean[at]
    out[[paste0("status_",name)]] <- if(is.na(at)) "not_available" else x$diagnostic_status[at]
  }
  attr(out,"diagnostics") <- "Native rank/split R-hat, bulk ESS and mean MCSE; statuses preserve single-chain, fixed and unavailable cases. These are not qgg Geweke z scores."
  out
}
