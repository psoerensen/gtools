.gbayes_alias <- function(settings,name,value,argument,explicit) {
  if(is.null(value)) return(settings)
  if(!is.null(settings[[name]])) {
    if(explicit) .gbayes_stop("Specify either `",argument,"` or its nested setting `",name,"`, not both.")
    return(settings)
  }
  settings[[name]] <- value;settings
}

#' Bayesian fitting with familiar summary-workflow controls
#' @param stat Ordinary checked summaries; named lists select advanced traits.
#' @param Glist Prepared reference; summary fitting requires sparse LD.
#' @param method Bayesian engine, including bayesC/bayesR aliases.
#' @param prior,control Existing nested prior/control settings.
#' @param trait,data,annotation,posterior,continuation,sampling Existing advanced
#'   trait, individual-data, annotation, posterior and continuation contracts.
#' @param algorithm `mcmc` or `mcmc-eigen` (verified Glist LD blocks).
#' @param nit,nburn,nthin,nrun,seed Post-burn sweeps, burn-in, thinning, chains and
#'   starting uint32 seed; subsequent chains use consecutive seeds.
#' @param h2,pi,gamma,vb,ve,nub,nue Starting variance/mixture settings on the
#'   standalone standardized summary likelihood scale. BayesC accepts scalar pi
#'   or c(null,active); BayesR accepts all component weights.
#' @param updateB,updateE,updatePi Slab, residual and mixture-weight learning.
#' @param verbose Print the final fit summary.
#' @return A gbayes_fit with existing native diagnostics and `stat$bm`/`stat$dm`
#'   aliases for posterior effect means/PIPs. Means retain the native model's
#'   effect scale. The familiar route defaults to 100 sweeps, zero burn-in and
#'   one chain, with reference-LD residual learning; it does not reproduce qgg's
#'   marker-specific residual adjustment or independent genetic-variance draw.
#' @export
gbayes <- function(stat = NULL, Glist, method = c("bayesr","bayesc","sbayesrc",
    "point_normal","continuous_shrinkage","variational","mixture_variational"),
    prior=list(),control=list(),trait=NULL,data=NULL,annotation=NULL,
    posterior=list(),continuation=NULL,sampling=NULL,algorithm=NULL,
    nit=NULL,nburn=NULL,nthin=NULL,nrun=NULL,seed=NULL,h2=NULL,pi=NULL,
    gamma=NULL,vb=NULL,ve=NULL,nub=NULL,nue=NULL,updateB=NULL,updateE=NULL,
    updatePi=NULL,verbose=FALSE) {
  call <- match.call()
  alias <- function(settings,name,value,argument) .gbayes_alias(settings,name,value,argument,
    any(strsplit(argument,"/",fixed=TRUE)[[1L]] %in% names(call)))
  familiar <- !is.null(algorithm) || length(method)==1L && method %in% c("bayesC","bayesR") ||
    any(!vapply(list(nit,nburn,nthin,nrun,seed,h2,pi,gamma,vb,ve,nub,nue,updateB,updateE,updatePi),is.null,logical(1)))
  if(familiar) {
    if(!is.null(data)||!is.data.frame(stat)||!is.null(continuation))
      .gbayes_stop("The qgg-style route supports a single summary fit; use nested controls for BED, multivariate or continuation fits.")
    if(length(method)>1L) method <- "bayesr"
    method <- match.arg(tolower(method),c("bayesc","bayesr"))
    if(is.null(algorithm)) algorithm <- "mcmc"
    algorithm <- match.arg(algorithm,c("mcmc","mcmc-eigen"))
    if(is.null(h2)) h2 <- .5
    if(!is.numeric(h2)||length(h2)!=1L||!is.finite(h2)||h2<=0||h2>=1)
      .gbayes_stop("h2 must lie strictly between zero and one.")
    if(is.null(pi)) pi <- if(method=="bayesc") .001 else c(.95,.02,.02,.01)
    if(method=="bayesc") {
      if(length(pi)==2L) {
        if(any(!is.finite(pi))||any(pi<0)||abs(sum(pi)-1)>1e-10) .gbayes_stop("BayesC pi weights must sum to one.")
        pi <- pi[2L]
      }
      if(!is.numeric(pi)||length(pi)!=1L||!is.finite(pi)||pi<=0||pi>=1)
        .gbayes_stop("BayesC pi must be an active probability strictly between zero and one.")
      if(!is.null(gamma)&&!identical(as.double(gamma),1)&&!identical(as.double(gamma),c(0,1)))
        .gbayes_stop("BayesC gamma must be 1 or c(0,1).")
      prior <- alias(prior,"inclusion_probability",pi,"pi")
      mass <- prior$inclusion_probability
    } else {
      if(is.null(gamma)) gamma <- c(0,.01,.1,1)
      if(!is.numeric(pi)||!is.numeric(gamma)||length(pi)!=length(gamma)||length(pi)<2L||
          any(!is.finite(c(pi,gamma)))||any(pi<0)||abs(sum(pi)-1)>1e-10||gamma[1]!=0||any(diff(gamma)<=0))
        .gbayes_stop("BayesR pi/gamma require normalized weights and increasing multipliers starting at zero.")
      prior <- alias(prior,"weights",pi,"pi")
      prior <- alias(prior,"variance_multipliers",gamma,"gamma")
      mass <- sum(prior$weights*prior$variance_multipliers)
    }
    if(is.null(vb)) vb <- h2/(nrow(stat)*mass)
    if(is.null(ve)) ve <- 1-h2
    prior <- alias(prior,"effect_variance",vb,"vb/h2/pi/gamma")
    prior <- alias(prior,"residual_variance",ve,"ve/h2")
    vb <- prior$effect_variance;ve <- prior$residual_variance
    if(is.null(nub)) nub <- 4
    if(is.null(nue)) nue <- 4
    if(!is.numeric(nub)||length(nub)!=1||!is.finite(nub)||nub<=2||
        !is.numeric(nue)||length(nue)!=1||!is.finite(nue)||nue<=2) .gbayes_stop("nub/nue must exceed 2.")
    control <- alias(control,"sampling_sweeps",if(is.null(nit)) 100L else nit,"nit")
    control <- alias(control,"burnin",if(is.null(nburn)) 0L else nburn,"nburn")
    control <- alias(control,"thinning",if(is.null(nthin)) 1L else nthin,"nthin")
    if(is.null(nrun)) nrun <- 1L
    .gbayes_count(nrun,"nrun")
    if(is.null(seed)) seed <- 10L
    control <- alias(control,"seeds",seed+seq_len(nrun)-1,"seed/nrun")
    control <- alias(control,"estimate_effect_variance",if(is.null(updateB)) TRUE else updateB,"updateB")
    control <- alias(control,"estimate_residual_variance",if(is.null(updateE)) TRUE else updateE,"updateE")
    control <- alias(control,"estimate_weights",if(is.null(updatePi)) TRUE else updatePi,"updatePi")
    for(name in c("estimate_effect_variance","estimate_residual_variance","estimate_weights"))
      control[[name]] <- .gbayes_flag(control[[name]],name)
    if(control$estimate_effect_variance) prior <- alias(prior,"effect_variance_prior",list(df=nub,scale=(nub-2)/nub*vb),"nub")
    if(control$estimate_residual_variance) {
      prior <- alias(prior,"residual_variance_prior",list(df=nue,scale=(nue-2)/nue*ve),"nue")
      if(is.null(control$residual_policy)) control$residual_policy <-
        if(algorithm=="mcmc-eigen") "retained" else "reference_ld"
      if(identical(control$residual_policy,"reference_ld")&&is.null(control$residual_adjustment)) control$residual_adjustment <- .9
    }
    if(control$estimate_weights) prior <- alias(prior,"weight_prior",rep(1,if(method=="bayesc") 2L else length(prior$weights)),"updatePi")
  }
  fit <- .gbayes_fit(stat,Glist,method,prior,control,trait,data,annotation,posterior,
    continuation,sampling,algorithm=if(is.null(algorithm)) "mcmc" else algorithm,
    fitted_variance=familiar)
  fit$call <- call
  fit$interface <- if(familiar) "qgg-style" else "native"
  if(familiar) {
    fit$post <- .gbayes_familiar_post(fit)
    fit$conv <- .gbayes_familiar_conv(fit)
  }
  if(is.data.frame(stat)&&!is.null(fit$estimates$marker)) {
    at <- match(fit$estimates$marker,stat$rsids)
    result <- stat[at,,drop=FALSE]
    swapped <- result$ea != fit$estimates$effect_allele
    for(name in intersect(c('b','wy','stat'),names(result)))
      if(is.numeric(result[[name]])) result[[name]][swapped] <- -result[[name]][swapped]
    if('eaf' %in% names(result)) result$eaf[swapped] <- 1-result$eaf[swapped]
    result$ea <- fit$estimates$effect_allele;result$nea <- fit$estimates$other_allele
    result$bm <- fit$estimates$mean;result$dm <- fit$estimates$pip
    attr(result,"effect_scale") <- "native standalone model; summary effects use standardized genotype/phenotype units"
    fit$stat <- result
  }
  verbose <- .gbayes_flag(verbose,"verbose")
  if(verbose) print(fit)
  fit
}
