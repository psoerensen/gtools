.gbayes_multi_named <- function(x, what) {
  if (!is.list(x) || !length(x) || is.null(names(x)) || anyNA(names(x)) ||
      any(!nzchar(names(x))) || anyDuplicated(names(x)))
    .gbayes_stop("`", what, "` must be a nonempty uniquely named list.")
  x
}

.gbayes_multi_matrix <- function(x, labels, what) {
  if (!is.matrix(x) || !is.numeric(x) || anyNA(x) || any(!is.finite(x)) ||
      !identical(dim(x), rep(length(labels), 2L)) ||
      !identical(rownames(x), labels) || !identical(colnames(x), labels))
    .gbayes_stop("`", what, "` must be a finite matrix labelled in trait order.")
  x
}

.gbayes_multi_vector <- function(x, labels, what, positive = TRUE,
    normalized = FALSE, named = FALSE) {
  if (!is.numeric(x) || length(x) != length(labels) || anyNA(x) ||
      any(!is.finite(x)) || any(if (positive) x <= 0 else x < 0) ||
      (named && !identical(names(x), labels)) ||
      (!is.null(names(x)) && !identical(names(x), labels)) ||
      (normalized && abs(sum(x) - 1) > 1e-10))
    .gbayes_stop("Invalid `", what, "` values or labels.")
  stats::setNames(as.double(x), labels)
}

.gbayes_multi_stat <- function(stat, Glist) {
  checked <- .gbayes_summary_stat(stat, Glist)
  data.frame(marker = checked$rsids, beta_std = checked$beta_std,
    n = checked$n, stringsAsFactors = FALSE)
}

.gbayes_multi_inputs <- function(stat, Glist, trait) {
  .gbayes_multi_named(stat, "stat")
  if (inherits(Glist, "Glist")) {
    gbase::validate_Glist(Glist)
    if (!is.list(Glist$sparseLD))
      .gbayes_stop("`Glist` must contain sparse LD from gprep(task = \"sparseld\").")
    traits <- names(stat)
    if (length(traits) < 2L)
      .gbayes_stop("Multivariate summary fitting requires at least two named traits.")
    if (!is.null(trait))
      .gbayes_stop("Use `names(stat)` for traits with one shared Glist; omit `trait`.")
    native <- lapply(stat, .gbayes_multi_stat, Glist = Glist)
    names(native) <- names(stat)
    metadata <- Glist$sparseLD$marker_metadata
    return(list(stat = native, traits = traits, study_traits = traits,
      studies = names(stat), prefixes = rep(Glist$sparseLD$prefix, length(stat)),
      metadata = metadata, references = list(shared = Glist),
      study_specific = FALSE))
  }
  .gbayes_multi_named(Glist, "Glist")
  if (!identical(names(Glist), names(stat)))
    .gbayes_stop("Study Glist names must match `stat` in the same order.")
  invisible(lapply(Glist, gbase::validate_Glist))
  if (any(!vapply(Glist, function(x) is.list(x$sparseLD), logical(1))))
    .gbayes_stop("Every study Glist must contain sparse LD.")
  if (!is.character(trait) || !identical(names(trait), names(stat)) ||
      anyNA(trait) || any(!nzchar(trait)))
    .gbayes_stop("For study-specific references, `trait` must be named in study order.")
  traits <- unique(unname(trait))
  if (length(traits) < 2L)
    .gbayes_stop("Study-specific fitting requires at least two distinct traits.")
  native <- Map(.gbayes_multi_stat, stat, Glist)
  names(native) <- names(stat)
  all <- do.call(rbind, lapply(Glist, function(x)
    x$sparseLD$marker_metadata[c("marker_id", "chromosome",
      "base_pair_position", "allele1", "allele2", "allele_frequency")]))
  metadata <- all[!duplicated(all$marker_id), , drop = FALSE]
  rownames(metadata) <- NULL
  mapped <- metadata[match(all$marker_id, metadata$marker_id), , drop = FALSE]
  for (name in c("chromosome", "base_pair_position", "allele1", "allele2"))
    if (!identical(unname(all[[name]]), unname(mapped[[name]])))
      .gbayes_stop("Shared study markers must have identical `", name,
        "` metadata; harmonise inputs separately.")
  list(stat = native, traits = traits, study_traits = unname(trait),
    studies = names(stat),
    prefixes = vapply(Glist, function(x) x$sparseLD$prefix, character(1)),
    metadata = metadata, references = Glist, study_specific = TRUE)
}

.gbayes_multi_prior <- function(prior, method, traits, control, bed = FALSE) {
  defaults <- list(effect_covariance = NULL, patterns = NULL,
    pattern_weights = NULL,
    component_scales = if (method == "bayesc") 1 else c(0.01, 0.1, 1),
    component_weights = if (method == "bayesc") 1 else rep(1 / 3, 3),
    covariance_prior = NULL, pattern_prior = NULL, component_prior = NULL)
  if (bed) defaults <- c(defaults,
    list(residual_covariance = NULL, residual_covariance_prior = NULL))
  else defaults <- c(defaults, list(sampling_covariance_prior = NULL))
  prior <- .gbayes_named_list(prior, defaults, "prior")
  prior$effect_covariance <- .gbayes_multi_matrix(prior$effect_covariance,
    traits, "prior$effect_covariance")
  if (is.null(prior$patterns)) prior$patterns <- cpp_gbayes_patterns(traits)
  patterns <- prior$patterns
  if (!is.matrix(patterns) || !(is.numeric(patterns) || is.logical(patterns)) ||
      nrow(patterns) < 2L || !identical(colnames(patterns), traits) ||
      anyNA(patterns) || any(!patterns %in% c(0, 1)) ||
      any(patterns[1L, ] != 0) || any(colSums(patterns) == 0))
    .gbayes_stop("`prior$patterns` must be a binary matrix with trait columns, null first, and every trait represented.")
  codes <- apply(patterns, 1L, paste0, collapse = "")
  if (anyDuplicated(codes)) .gbayes_stop("Trait patterns must be distinct.")
  if (is.null(rownames(patterns))) rownames(patterns) <- codes
  if (anyNA(rownames(patterns)) || any(!nzchar(rownames(patterns))) ||
      anyDuplicated(rownames(patterns)))
    .gbayes_stop("Pattern labels must be nonempty and unique.")
  storage.mode(patterns) <- "integer"; prior$patterns <- patterns
  pattern_names <- rownames(patterns)
  if (is.null(prior$pattern_weights))
    prior$pattern_weights <- rep(1 / nrow(patterns), nrow(patterns))
  prior$pattern_weights <- .gbayes_multi_vector(prior$pattern_weights,
    pattern_names, "prior$pattern_weights", positive = FALSE, normalized = TRUE)
  scales <- prior$component_scales
  if (!is.numeric(scales) || !length(scales) || anyNA(scales) ||
      any(!is.finite(scales)) || any(scales <= 0) || any(diff(scales) <= 0) ||
      (method == "bayesc" && !identical(as.double(scales), 1)) ||
      (method == "bayesr" && length(scales) < 2L))
    .gbayes_stop("BayesC needs component_scales=1; BayesR needs at least two increasing positive scales.")
  prior$component_scales <- as.double(scales)
  prior$component_names <- paste0("component_", seq_along(scales))
  prior$component_weights <- .gbayes_multi_vector(prior$component_weights,
    prior$component_names, "prior$component_weights", positive = FALSE,
    normalized = TRUE)
  inverse_wishart <- function(x, what) {
    if (!is.list(x) || !setequal(names(x), c("df", "scale")) ||
        length(x) != 2L || !is.numeric(x$df) || length(x$df) != 1L ||
        !is.finite(x$df) || x$df <= length(traits) - 1L)
      .gbayes_stop("`", what, "` requires df > traits-1 and a labelled scale matrix.")
    x$scale <- .gbayes_multi_matrix(x$scale, traits, paste0(what, "$scale")); x
  }
  if (control$estimate_covariance)
    prior$covariance_prior <- inverse_wishart(prior$covariance_prior,
      "prior$covariance_prior")
  else if (!is.null(prior$covariance_prior))
    .gbayes_stop("`prior$covariance_prior` requires covariance learning.")
  if (control$estimate_pattern_weights)
    prior$pattern_prior <- .gbayes_multi_vector(prior$pattern_prior,
      pattern_names, "prior$pattern_prior")
  else if (!is.null(prior$pattern_prior))
    .gbayes_stop("`prior$pattern_prior` requires pattern-weight learning.")
  if (control$estimate_component_weights)
    prior$component_prior <- .gbayes_multi_vector(prior$component_prior,
      prior$component_names, "prior$component_prior")
  else if (!is.null(prior$component_prior))
    .gbayes_stop("`prior$component_prior` requires component-weight learning.")
  if (bed) {
    prior$residual_covariance <- .gbayes_multi_matrix(
      prior$residual_covariance, traits, "prior$residual_covariance")
    if (control$estimate_sampling_covariance)
      prior$residual_covariance_prior <- inverse_wishart(
        prior$residual_covariance_prior, "prior$residual_covariance_prior")
    else if (!is.null(prior$residual_covariance_prior))
      .gbayes_stop("`prior$residual_covariance_prior` requires residual-covariance learning.")
  }
  prior
}

.gbayes_multi_annotations <- function(annotation, markers, prior, control) {
  if (is.null(annotation)) return(list())
  if (!is.list(annotation) || !length(annotation) || is.null(names(annotation)) ||
      anyNA(names(annotation)) || any(!nzchar(names(annotation))) ||
      anyDuplicated(names(annotation)))
    .gbayes_stop("`annotation` must be a nonempty uniquely named list.")
  if ("bayess" %in% names(annotation)) {
    if ("variance" %in% names(annotation))
      .gbayes_stop("Choose `annotation$bayess` or `annotation$variance`, not both.")
    s <- .gbayes_named_list(annotation$bayess,
      list(allele_frequency = NULL, learn = TRUE, initial_s = 0,
        coefficient_prior_sd = 1, update_every = 1L,
        maximum_evaluations = 10000L), "annotation$bayess")
    af <- s$allele_frequency
    if (!is.numeric(af) || length(af) != length(markers) || anyNA(af) ||
        any(!is.finite(af)) || any(af <= 0 | af >= 1) ||
        !identical(names(af), markers))
      .gbayes_stop("BayesS frequencies must be inside (0,1) and named in marker order.")
    annotation$variance <- list(design = matrix(log(2 * unname(af) *
        (1 - unname(af))), ncol = 1L,
        dimnames = list(markers, "maf_exponent_s")), learn = s$learn,
      initial = stats::setNames(s$initial_s, "maf_exponent_s"),
      coefficient_prior_sd = s$coefficient_prior_sd,
      update_every = s$update_every,
      maximum_evaluations = s$maximum_evaluations)
    annotation$bayess <- NULL
  }
  if (any(!names(annotation) %in% c("pattern", "component", "variance")))
    .gbayes_stop("Multivariate annotation roles are pattern, component, and variance.")
  out <- list()
  for (role in names(annotation)) {
    probit <- role %in% c("pattern", "component")
    defaults <- list(design = NULL, learn = TRUE, initial = NULL,
      coefficient_prior_sd = 1, update_every = 1L)
    if (probit) defaults <- c(defaults,
      list(intercept_prior_sd = 1, intercept_means = NULL))
    if (role == "variance") defaults$maximum_evaluations <- 10000L
    value <- .gbayes_named_list(annotation[[role]], defaults,
      paste0("annotation$", role))
    design <- value$design
    if (!is.matrix(design) || !is.numeric(design) || ncol(design) < 1L ||
        anyNA(design) || any(!is.finite(design)) ||
        !identical(rownames(design), markers) || is.null(colnames(design)) ||
        anyNA(colnames(design)) || any(!nzchar(colnames(design))) ||
        anyDuplicated(colnames(design)) || "(Intercept)" %in% colnames(design))
      .gbayes_stop("Annotation design must be finite with marker row names and unique non-intercept columns.")
    value$learn <- .gbayes_flag(value$learn,
      paste0("annotation$", role, "$learn"))
    value$update_every <- .gbayes_count(value$update_every,
      paste0("annotation$", role, "$update_every"))
    value$coefficient_prior_sd <- .gbayes_positive(
      value$coefficient_prior_sd,
      paste0("annotation$", role, "$coefficient_prior_sd"))
    if (role == "variance") {
      value$maximum_evaluations <- .gbayes_count(value$maximum_evaluations,
        "annotation$variance$maximum_evaluations")
      if (!is.null(value$initial) && (!is.numeric(value$initial) ||
          !identical(names(value$initial), colnames(design)) ||
          anyNA(value$initial) || any(!is.finite(value$initial))))
        .gbayes_stop("Variance annotation initial values must be named in design-column order.")
      value$coefficient_names <- colnames(design)
      value$categories <- character()
    } else {
      categories <- if (role == "pattern") rownames(prior$patterns) else
        prior$component_names
      sticks <- utils::head(categories, -1L)
      flag <- if (role == "pattern") "estimate_pattern_weights" else
        "estimate_component_weights"
      if (control[[flag]])
        .gbayes_stop("`annotation$", role,
          "` replaces global weight learning; disable `control$", flag, "`.")
      value$intercept_prior_sd <- .gbayes_positive(value$intercept_prior_sd,
        paste0("annotation$", role, "$intercept_prior_sd"))
      if (!is.null(value$intercept_means) &&
          (!is.numeric(value$intercept_means) ||
           !identical(names(value$intercept_means), sticks) ||
           anyNA(value$intercept_means) ||
           any(!is.finite(value$intercept_means))))
        .gbayes_stop("Annotation intercept means must be finite and named in stick order.")
      coefficient_rows <- c("(Intercept)", colnames(design))
      if (!is.null(value$initial) && (!is.matrix(value$initial) ||
          !is.numeric(value$initial) ||
          !identical(rownames(value$initial), coefficient_rows) ||
          !identical(colnames(value$initial), sticks) || anyNA(value$initial) ||
          any(!is.finite(value$initial))))
        .gbayes_stop("Probit annotation initial values must be a labelled coefficient-by-stick matrix.")
      value$coefficient_names <- unlist(lapply(sticks,
        function(x) paste0(x, ":", coefficient_rows)), use.names = FALSE)
      value$categories <- categories
    }
    out[[role]] <- value
  }
  out
}

.gbayes_multi_control <- function(control, continuation, bed = FALSE) {
  defaults <- list(burnin = if (is.null(continuation)) 100L else 0L,
    sampling_sweeps = 1000L, thinning = 1L,
    seeds = if (is.null(continuation)) c(1, 2) else continuation$seeds,
    threads = 1L, retain_diagnostics = TRUE, probability = 0.95,
    memory_limit_bytes = 256 * 1024^2, estimate_covariance = FALSE,
    estimate_sampling_covariance = FALSE, estimate_pattern_weights = FALSE,
    estimate_component_weights = FALSE, sample_size = "common",
    storage = "memory", max_ld_entries = 1e7, ld_swap = NULL)
  if (bed) defaults <- c(defaults,
    list(likelihood_dimension = NULL,
      packed_memory_limit_bytes = 256 * 1024^2))
  control <- .gbayes_named_list(control, defaults, "control")
  for (name in c("burnin", "sampling_sweeps", "thinning", "threads"))
    control[[name]] <- .gbayes_count(control[[name]], paste0("control$", name),
      if (name == "burnin") 0 else 1)
  if (!is.numeric(control$seeds) || !length(control$seeds) ||
      anyNA(control$seeds) || any(!is.finite(control$seeds)) ||
      any(control$seeds < 0 | control$seeds > 2^32 - 1 |
        control$seeds != floor(control$seeds)) || anyDuplicated(control$seeds))
    .gbayes_stop("`control$seeds` must contain distinct integers between 0 and 2^32-1.")
  control$seeds <- as.double(control$seeds)
  for (name in c("retain_diagnostics", "estimate_covariance",
      "estimate_sampling_covariance", "estimate_pattern_weights",
      "estimate_component_weights"))
    control[[name]] <- .gbayes_flag(control[[name]], paste0("control$", name))
  if (!is.numeric(control$probability) || length(control$probability) != 1L ||
      !is.finite(control$probability) || control$probability <= 0 ||
      control$probability >= 1)
    .gbayes_stop("`control$probability` must lie strictly between zero and one.")
  control$memory_limit_bytes <- .gbayes_count(control$memory_limit_bytes,
    "control$memory_limit_bytes")
  control$sample_size <- match.arg(control$sample_size, c("common", "variable"))
  control$storage <- match.arg(control$storage, c("memory", "disk"))
  control$max_ld_entries <- .gbayes_count(control$max_ld_entries,
    "control$max_ld_entries")
  if (control$storage == "disk" && control$threads != 1)
    .gbayes_stop("Disk sparse-LD storage requires `control$threads = 1`.")
  control$ld_swap <- .gbayes_ld_swap(control$ld_swap)
  if (bed) {
    control$packed_memory_limit_bytes <- .gbayes_count(
      control$packed_memory_limit_bytes,
      "control$packed_memory_limit_bytes")
  }
  control
}

.gbayes_multi_sampling <- function(sampling, inputs, control) {
  if (is.null(sampling))
    .gbayes_stop("Declare `sampling=list(dependence=...)` for multivariate summaries.")
  sampling <- .gbayes_named_list(sampling,
    list(dependence = NULL, residual_variance = NULL, covariance = NULL,
      response_crossproduct = NULL, likelihood_dimension = NULL,
      study_sample_size = NULL), "sampling")
  if (!is.character(sampling$dependence) || length(sampling$dependence) != 1L ||
      is.na(sampling$dependence) ||
      !sampling$dependence %in% c("independent", "shared_ld"))
    .gbayes_stop("Sampling dependence must be `independent` or `shared_ld`.")
  if (inputs$study_specific && sampling$dependence != "independent")
    .gbayes_stop("Study-specific references require independent sampling errors.")
  if (sampling$dependence == "independent") {
    if (control$estimate_sampling_covariance)
      .gbayes_stop("Sampling-covariance learning requires shared-LD summaries.")
    if (!is.null(sampling$covariance))
      .gbayes_stop("Independent sampling uses `residual_variance`, not covariance.")
    sampling$residual_variance <- .gbayes_multi_vector(
      sampling$residual_variance, inputs$studies,
      "sampling$residual_variance", named = TRUE)
  } else {
    if (!is.null(sampling$residual_variance))
      .gbayes_stop("Shared-LD sampling obtains residual variances from covariance.")
    sampling$covariance <- .gbayes_multi_matrix(sampling$covariance,
      inputs$traits, "sampling$covariance")
    sampling$residual_variance <- stats::setNames(
      diag(sampling$covariance), inputs$studies)
    first_n <- inputs$stat[[1L]]$n
    if (control$sample_size != "common" ||
        any(vapply(inputs$stat, function(x) !identical(x$n, first_n), logical(1))))
      .gbayes_stop("Shared-LD sampling requires common N equal across traits and markers.")
  }
  if (control$estimate_sampling_covariance) {
    sampling$response_crossproduct <- .gbayes_multi_matrix(
      sampling$response_crossproduct, inputs$traits,
      "sampling$response_crossproduct")
    sampling$likelihood_dimension <- .gbayes_positive(
      sampling$likelihood_dimension, "sampling$likelihood_dimension")
  } else if (!is.null(sampling$response_crossproduct) ||
      !is.null(sampling$likelihood_dimension))
    .gbayes_stop("Sampling sufficient statistics require covariance learning.")
  if (is.null(sampling$study_sample_size)) {
    if (control$sample_size == "variable")
      .gbayes_stop("Variable N requires named `sampling$study_sample_size`.")
    sampling$study_sample_size <- stats::setNames(vapply(inputs$stat,
      function(x) x$n[[1L]], numeric(1)), inputs$studies)
  } else sampling$study_sample_size <- .gbayes_multi_vector(
    sampling$study_sample_size, inputs$studies,
    "sampling$study_sample_size", named = TRUE)
  sampling
}

.gbayes_multi_continuation <- function(continuation, signature, control) {
  if (is.null(continuation)) return(NULL)
  if (!identical(continuation$signature, signature))
    .gbayes_stop("The continuation model, references, prior, or controls differ from the saved state.")
  if (!identical(as.double(continuation$seeds), control$seeds))
    .gbayes_stop("Continuation seeds must retain saved chain order and values.")
  continuation$states
}

.gbayes_multi_bed_data <- function(data, Glist, trait) {
  gbase::validate_Glist(Glist)
  if (!identical(class(data), "data.frame") || !nrow(data) ||
      anyDuplicated(names(data)) || !"id" %in% names(data) ||
      !is.character(data$id) || anyNA(data$id) || any(!nzchar(data$id)) ||
      anyDuplicated(data$id))
    .gbayes_stop("`data` must have unique character `id` values.")
  ids <- if (is.null(Glist$study_ids)) Glist$ids else Glist$study_ids
  if (nrow(data) != length(ids) || !setequal(data$id, ids))
    .gbayes_stop("`data` must contain every selected Glist individual.")
  if (is.null(trait)) trait <- setdiff(names(data), "id")
  if (!is.character(trait) || length(trait) < 2L || anyNA(trait) ||
      any(!nzchar(trait)) || anyDuplicated(trait) ||
      any(!trait %in% setdiff(names(data), "id")))
    .gbayes_stop("Multivariate BED fitting requires at least two unique phenotype column names in `trait`.")
  data <- data[match(ids, data$id), , drop = FALSE]
  phenotypes <- lapply(trait, function(name) {
    value <- data[[name]]
    if (!is.numeric(value) || anyNA(value) || any(!is.finite(value)))
      .gbayes_stop("Phenotype `", name, "` must be finite numeric values.")
    as.double(value)
  })
  names(phenotypes) <- trait
  active <- which(lengths(Glist$rsids) > 0L)
  if (!length(active)) .gbayes_stop("`Glist` contains no selected markers.")
  list(traits = trait, phenotypes = phenotypes, ids = ids, active = active,
    paths = unname(Glist$bedfiles[active]),
    physical_marker_count = as.double(Glist$physical_marker_counts[active]),
    marker_indices = unname(Glist$source_marker_indices_0based[active]),
    marker = unlist(Glist$rsids[active], use.names = FALSE),
    chromosome = unlist(Glist$chr[active], use.names = FALSE),
    position = as.double(unlist(Glist$pos[active], use.names = FALSE)),
    allele1 = unlist(Glist$a1[active], use.names = FALSE),
    allele2 = unlist(Glist$a2[active], use.names = FALSE),
    allele_frequency = as.double(unlist(Glist$af[active], use.names = FALSE)))
}

.gbayes_multivariate_fit <- function(stat, Glist, data, method, prior,
    control, sampling, trait, call, annotation, posterior, continuation) {
  if (!method %in% c("bayesc", "bayesr"))
    .gbayes_stop("Multivariate fitting supports only BayesC and BayesR.")
  continuation <- .gbayes_continuation(continuation)
  bed <- !is.null(data)
  control <- .gbayes_multi_control(control, continuation, bed)
  if (method == "bayesc" && control$estimate_component_weights)
    .gbayes_stop("BayesC has one magnitude component; component-weight learning is not applicable.")
  if (bed) {
    parsed <- .gbayes_multi_bed_data(data, Glist, trait)
    if (is.null(control$likelihood_dimension))
      control$likelihood_dimension <- length(parsed$ids)
    control$likelihood_dimension <- .gbayes_positive(
      control$likelihood_dimension, "control$likelihood_dimension")
    if (control$likelihood_dimension > length(parsed$ids))
      .gbayes_stop("`control$likelihood_dimension` cannot exceed selected samples.")
    prior <- .gbayes_multi_prior(prior, method, parsed$traits, control, TRUE)
    annotation <- .gbayes_multi_annotations(annotation, parsed$marker, prior,
      control)
    metadata <- data.frame(marker_id = parsed$marker,
      chromosome = parsed$chromosome, base_pair_position = parsed$position,
      allele1 = parsed$allele1, allele2 = parsed$allele2,
      allele_frequency = parsed$allele_frequency, stringsAsFactors = FALSE)
    posterior <- .gbayes_posterior(posterior, metadata, parsed$traits)
    signature <- list(method = method, traits = parsed$traits,
      marker = parsed$marker, selected_ids = parsed$ids, prior = prior,
      annotation = annotation,
      transition_control = control[c("estimate_covariance",
        "estimate_sampling_covariance", "estimate_pattern_weights",
        "estimate_component_weights")],
      bedfiles = normalizePath(parsed$paths, winslash = "/", mustWork = TRUE))
    control$multivariate_initial_states <- .gbayes_multi_continuation(
      continuation, signature, control)
    native <- cpp_gbayes_bed_multivariate(as.double(Glist$n),
      as.double(Glist$sample_source_indices_0based), parsed$paths,
      parsed$physical_marker_count, parsed$marker_indices, parsed$phenotypes,
      parsed$marker, parsed$allele_frequency, parsed$traits, prior, control,
      annotation, posterior)
    weights <- data.frame(marker = parsed$marker,
      chromosome = parsed$chromosome, position = parsed$position,
      effect_allele = parsed$allele1, other_allele = parsed$allele2,
      allele_frequency = native$coding$allele_frequency,
      stringsAsFactors = FALSE)
    weights[parsed$traits] <- as.data.frame(native$mean)
    provenance <- list(preparation = "individual PLINK BED",
      bedfiles = parsed$paths, selected_ids = parsed$ids,
      native_version = native$native_version, native = gbayes_native_info())
    sampling_out <- list(dependence = "individual_level",
      residual_covariance = prior$residual_covariance)
    studies <- stats::setNames(lapply(parsed$traits,
      function(x) list(trait = x, selected_ids = parsed$ids)), parsed$traits)
    likelihood <- "individual_bed"
  } else {
    inputs <- .gbayes_multi_inputs(stat, Glist, trait)
    if (control$sample_size == "common" &&
        any(vapply(inputs$stat, function(x) length(unique(x$n)) != 1L,
          logical(1))))
      .gbayes_stop("Different marker sample sizes require `control$sample_size = \"variable\"`.")
    sampling <- .gbayes_multi_sampling(sampling, inputs, control)
    prior <- .gbayes_multi_prior(prior, method, inputs$traits, control, FALSE)
    annotation <- .gbayes_multi_annotations(annotation,
      inputs$metadata$marker_id, prior, control)
    posterior <- .gbayes_posterior(posterior, inputs$metadata, inputs$traits)
    if (control$estimate_sampling_covariance) {
      iw <- prior$sampling_covariance_prior
      if (!is.list(iw) || !setequal(names(iw), c("df", "scale")) ||
          length(iw) != 2L || !is.numeric(iw$df) || length(iw$df) != 1L ||
          !is.finite(iw$df) || iw$df <= length(inputs$traits) - 1L)
        .gbayes_stop("`prior$sampling_covariance_prior` requires df > traits-1 and a labelled scale matrix.")
      prior$sampling_covariance_prior$scale <- .gbayes_multi_matrix(iw$scale,
        inputs$traits, "prior$sampling_covariance_prior$scale")
    } else if (!is.null(prior$sampling_covariance_prior))
      .gbayes_stop("`prior$sampling_covariance_prior` requires sampling-covariance learning.")
    checksums <- if (inputs$study_specific)
      lapply(inputs$references, function(x) x$sparseLD$checksums) else
      inputs$references$shared$sparseLD$checksums
    signature <- list(method = method, marker = inputs$metadata$marker_id,
      traits = inputs$traits, study_traits = inputs$study_traits, prior = prior,
      annotation = annotation,
      sampling = sampling, transition_control = control[c("estimate_covariance",
        "estimate_sampling_covariance", "estimate_pattern_weights",
        "estimate_component_weights", "sample_size")], checksums = checksums)
    control$multivariate_initial_states <- .gbayes_multi_continuation(
      continuation, signature, control)
    native <- cpp_gbayes_multivariate(inputs$prefixes, inputs$stat,
      inputs$traits, inputs$study_traits, inputs$metadata, prior, control,
      sampling, annotation, posterior)
    weights <- NULL
    if (!inputs$study_specific) {
      metadata <- inputs$metadata
      weights <- data.frame(marker = metadata$marker_id,
        chromosome = metadata$chromosome,
        position = metadata$base_pair_position,
        effect_allele = metadata$allele1, other_allele = metadata$allele2,
        allele_frequency = metadata$allele_frequency,
        stringsAsFactors = FALSE)
      weights[inputs$traits] <- as.data.frame(native$mean)
    }
    provenance <- list(preparation = paste("summary-statistic",
      control$sample_size, "N Gaussian pseudo-likelihood;",
      sampling$dependence), checksums = checksums,
      sample_size_ranges = lapply(inputs$stat, function(x) range(x$n)),
      study_specific_references = inputs$study_specific,
      native_version = native$native_version, native = gbayes_native_info())
    sampling_out <- sampling;studies <- native$studies
    parsed <- list(traits = inputs$traits, marker = inputs$metadata$marker_id)
    likelihood <- "summary_statistics"
  }
  if (!is.null(posterior$prediction))
    native$quantities$prediction$coverage <- posterior$prediction$coverage
  structure(list(call = call, method = method, traits = parsed$traits,
    likelihood = likelihood,
    estimates = native[c("mean", "variance", "pip", "any_pip",
      "chain_pip_range")], weights = weights, studies = studies,
    parameter_mean = native$parameter_mean,
    quantities = native$quantities,
    posterior = do.call(rbind, Filter(nrow, list(native$posterior,
      native$annotation_posterior, native$quantity_posterior))),
    annotations = native$annotations, annotation = annotation,
    chains = native$chains, prior = prior, control = control,
    sampling = sampling_out,
    continuation = list(version = 1L, signature = signature,
      seeds = control$seeds, states = native$continuation_states),
    diagnostics = list(threads_used = native$threads_used,
      estimated_native_memory_bytes = native$estimated_native_memory_bytes,
      expected_pattern_count = native$expected_pattern_count,
      expected_component_count = native$expected_component_count,
      expected_trait_sharing = native$expected_trait_sharing),
    individual_bed = if (bed) native$individual_bed else NULL,
    coding = if (bed) native$coding else NULL,
    provenance = provenance),
    class = c("gbayes_multivariate_fit", "gbayes_fit", "list"))
}

#' @export
print.gbayes_multivariate_fit <- function(x, ...) {
  cat("<gbayes_multivariate_fit>", x$method, "|",
    paste(x$traits, collapse = ", "), "|", nrow(x$estimates$mean),
    "markers |", length(x$chains), "chains\n")
  invisible(x)
}
