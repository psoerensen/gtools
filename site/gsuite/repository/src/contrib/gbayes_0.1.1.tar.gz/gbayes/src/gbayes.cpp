#include <Rcpp.h>
#include <gbayes/bayesr.hpp>
#include <gbayes/continuous_shrinkage.hpp>
#include <gbayes/diagnostics.hpp>
#include <gbayes/individual_bed.hpp>
#include <gbayes/multivariate_summary.hpp>
#include <gbayes/point_normal_gibbs.hpp>
#include <gbayes/posterior_summary.hpp>
#include <gbayes/single_effect.hpp>
#include <gbayes/summary_mixture_variational.hpp>
#include <gbayes/summary_statistics.hpp>
#include <gbayes/summary_variational.hpp>
#include <gmat/sparse_ld_disk.hpp>
#include <gmat/version.hpp>
#include <gsolve/version.hpp>
#include <gbits/c_api.h>
#include <gscore/prediction_targets.hpp>
#include <gscore/version.hpp>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <map>

namespace {
void check_markers(const gmat::SparseLdDiskResource&,
  const std::vector<std::string>&);
class GlistPrediction final : public gbayes::PredictionProjection {
  std::vector<std::shared_ptr<const gbayes::PredictionProjection>> targets_;
  gbayes::PredictionTargetInfo info_;
  std::vector<std::vector<std::size_t>> fit_indices_;
 public:
  GlistPrediction(
      std::vector<std::shared_ptr<const gbayes::PredictionProjection>> targets,
      std::vector<std::string> fit_marker,std::vector<std::string> fit_allele,
      std::vector<double> fit_frequency,
      std::vector<std::vector<std::size_t>> fit_indices):
      targets_(std::move(targets)),fit_indices_(std::move(fit_indices)) {
    if(targets_.empty())
      throw std::invalid_argument("Prediction Glist has no active BED components.");
    info_=targets_.front()->info();info_.marker_ids=std::move(fit_marker);
    info_.counted_alleles=std::move(fit_allele);
    info_.effect_multipliers.assign(info_.marker_ids.size(),1.0);
    info_.allele_frequencies=std::move(fit_frequency);
    info_.provenance+="; active Glist BED components mapped into fitted marker order";
  }
  const gbayes::PredictionTargetInfo& info() const noexcept override {return info_;}
  bool concurrent_reads() const noexcept override {
    for(const auto& target:targets_) if(!target->concurrent_reads()) return false;
    return true;
  }
  unsigned projection_threads() const noexcept override {return 1;}
  std::size_t workspace_bytes(std::size_t traits,std::size_t batch) const override {
    const std::size_t aggregate=batch*traits*sizeof(double);
    std::size_t peak=aggregate;
    for(std::size_t k=0;k<targets_.size();++k)
      peak=std::max(peak,aggregate+targets_[k]->workspace_bytes(traits,batch)+
        fit_indices_[k].size()*traits*sizeof(double));
    return peak;
  }
  std::vector<double> project(const std::vector<double>& effects,
      std::size_t traits,std::size_t begin,std::size_t count) const override {
    std::vector<double> out(count*traits,0.0);
    for(std::size_t k=0;k<targets_.size();++k) {
      std::vector<double> selected(fit_indices_[k].size()*traits);
      for(std::size_t j=0;j<fit_indices_[k].size();++j)
        for(std::size_t t=0;t<traits;++t)
          selected[j*traits+t]=effects[fit_indices_[k][j]*traits+t];
      const auto part=targets_[k]->project(selected,traits,begin,count);
      if(part.size()!=out.size())
        throw std::runtime_error("Glist prediction component returned an incompatible target projection.");
      for(std::size_t j=0;j<out.size();++j) out[j]+=part[j];
    }
    return out;
  }
};

gbayes::MarkerPartition marker_partition(const Rcpp::List& x) {
  gbayes::MarkerPartition out;
  out.marker_ids=Rcpp::as<std::vector<std::string>>(x["marker_ids"]);
  out.group_ids=Rcpp::as<std::vector<std::string>>(x["group_ids"]);
  for(int value:Rcpp::as<Rcpp::IntegerVector>(x["marker_group"]))
    out.marker_group.push_back(value);
  gbayes::validate_partition(out);return out;
}

struct PosteriorCapture {
  gbayes::ScalarPosteriorControls controls;
  std::shared_ptr<gmat::SparseLdDiskReader> reader;
  std::shared_ptr<gmat::SparseLdCsr> ld;
  PosteriorCapture(const Rcpp::List& pp,const Rcpp::List& control) {
    controls.memory_limit_bytes=Rcpp::as<double>(pp["memory_limit_bytes"]);
    const auto marker=Rcpp::as<std::vector<std::string>>(pp["fit_marker"]);
    const auto allele=Rcpp::as<std::vector<std::string>>(pp["fit_allele"]);
    if(!Rf_isNull(pp["reference"])) {
      Rcpp::List r=pp["reference"];
      reader=std::make_shared<gmat::SparseLdDiskReader>(Rcpp::as<std::string>(r["prefix"]));
      check_markers(reader->resource(),marker);
      std::shared_ptr<const gbayes::CrossProducts> products;
      const std::vector<double> one(marker.size(),1.0);
      const bool disk=control.containsElementNamed("storage") &&
        Rcpp::as<std::string>(control["storage"])=="disk";
      if(disk)
        products=gbayes::disk_ld_cross_products(reader,one);
      else {
        ld=std::make_shared<gmat::SparseLdCsr>(
          gmat::load_sparse_ld_csr_from_disk(Rcpp::as<std::string>(r["prefix"])));
        products=gbayes::ld_cross_products(ld,one);
      }
      auto reference=std::make_shared<gbayes::GeneticCovarianceReference>();
      reference->cross_products=products;reference->marker_ids=marker;
      reference->counted_alleles=allele;
      reference->effect_multipliers.assign(marker.size(),1.0);
      reference->divisor=1;reference->reference_id=Rcpp::as<std::string>(r["id"]);
      reference->genotype_coding="standardized counted-allele dosage";
      reference->provenance="Explicit aligned Glist sparse-LD reference; fixed LD uncertainty";
      controls.genetic_reference=reference;
    }
    if(!Rf_isNull(pp["partition"]))
      controls.partition=std::make_shared<gbayes::MarkerPartition>(
        marker_partition(Rcpp::as<Rcpp::List>(pp["partition"])));
    if(!Rf_isNull(pp["prediction"])) {
      Rcpp::List p=pp["prediction"],components=p["components"];
      std::vector<std::shared_ptr<const gbayes::PredictionProjection>> targets;
      std::vector<std::vector<std::size_t>> indices;
      for(const auto& value:components) {
        Rcpp::List component=value;gscore::PredictionTargetRequest request;
        auto& s=request.scoring;
        s.bed.bed_path=Rcpp::as<std::string>(component["bed_path"]);
        s.bed.sample_count=Rcpp::as<double>(component["sample_count"]);
        s.bed.physical_marker_count=Rcpp::as<double>(component["physical_marker_count"]);
        for(double index:Rcpp::as<Rcpp::NumericVector>(component["marker_indices"]))
          s.bed.marker_indices.push_back(index);
        s.bed.allele_frequencies=Rcpp::as<std::vector<double>>(component["allele_frequencies"]);
        s.bed.coding=gscore::GenotypeCoding::standardized;s.bed.thread_count=1;
        s.marker_ids=Rcpp::as<std::vector<std::string>>(component["marker"]);
        s.effect_counted_alleles=s.bed_counted_alleles=
          Rcpp::as<std::vector<std::string>>(component["counted_allele"]);
        s.effect_multipliers=Rcpp::as<std::vector<double>>(component["effect_multipliers"]);
        s.sample_ids=Rcpp::as<std::vector<std::string>>(p["sample_ids"]);
        for(int index:Rcpp::as<Rcpp::IntegerVector>(p["sample_indices"]))
          request.sample_indices.push_back(index);
        request.target_ids=Rcpp::as<std::vector<std::string>>(p["target_ids"]);
        request.target_set_id=Rcpp::as<std::string>(p["target_set"]);
        request.provenance="Explicit qgg/sblr-style active Glist target subset";
        request.preparation_memory_limit_bytes=Rcpp::as<double>(p["preparation_memory_limit_bytes"]);
        targets.push_back(gscore::prepare_prediction_targets(request));
        std::vector<std::size_t> fit_index;
        for(int index:Rcpp::as<Rcpp::IntegerVector>(component["fit_index"]))
          fit_index.push_back(index);
        indices.push_back(std::move(fit_index));
      }
      controls.prediction.targets=std::make_shared<GlistPrediction>(
        std::move(targets),marker,allele,
        Rcpp::as<std::vector<double>>(pp["fit_frequency"]),std::move(indices));
      controls.prediction.batch_size=Rcpp::as<int>(p["batch_size"]);
      controls.prediction.retain_draws=Rcpp::as<bool>(p["retain_draws"]);
    }
  }
  void check_unchanged() const {if(reader) reader->check_unchanged();}
};
Rcpp::List parameters(const gbayes::GaussianParameters& x) {
  return Rcpp::List::create(Rcpp::Named("residual_variance")=x.residual_variance,
    Rcpp::Named("effect_variance")=x.slab_variance,
    Rcpp::Named("weights")=x.weights);
}

const gbayes::BayesCChain& posterior(const gbayes::BayesCChain& x) { return x; }
const gbayes::BayesCChain& posterior(const gbayes::BayesRChain& x) { return x.posterior; }

Rcpp::List chain_state(const gbayes::ScalarChainState& x) {
  Rcpp::IntegerVector selected(x.block_selected.size());
  for(std::size_t j=0;j<x.block_selected.size();++j) selected[j]=x.block_selected[j];
  return Rcpp::List::create(Rcpp::Named("seed")=double(x.seed),
    Rcpp::Named("completed_sweeps")=double(x.completed_sweeps),
    Rcpp::Named("rng_state")=x.rng_state,Rcpp::Named("effects")=x.effects,
    Rcpp::Named("working_residual")=x.working_residual,
    Rcpp::Named("components")=x.components,
    Rcpp::Named("marker_order")=x.marker_order,
    Rcpp::Named("parameters")=parameters(x.parameters),
    Rcpp::Named("genetic_variance")=x.genetic_variance,
    Rcpp::Named("working_residual_variance")=x.working_residual_variance,
    Rcpp::Named("block_residual_variance")=x.block_residual_variance,
    Rcpp::Named("block_selected")=selected,
    Rcpp::Named("inclusion_coefficients")=x.inclusion_coefficients,
    Rcpp::Named("component_coefficients")=x.component_coefficients,
    Rcpp::Named("variance_coefficients")=x.variance_coefficients);
}

Rcpp::DataFrame posterior_rows(
    const std::vector<gbayes::LabelledPosteriorSummary>& summaries) {
  const std::size_t n=summaries.size();
  Rcpp::CharacterVector parameter(n),status(n),diagnostic_status(n);
  Rcpp::LogicalVector estimated(n);Rcpp::NumericVector draws(n),mean(n),sd(n),
    median(n),lower(n),upper(n),hpd_lower(n),hpd_upper(n),rhat(n),ess(n),mcse(n);
  for(std::size_t j=0;j<n;++j) {
    const auto& s=summaries[j];const auto& x=s.summary;const auto& d=x.diagnostics;
    parameter[j]=s.selection.label;estimated[j]=x.estimated;status[j]=x.status;
    draws[j]=double(x.finite_draws);mean[j]=x.mean;sd[j]=x.sd;median[j]=x.median;
    lower[j]=x.lower;upper[j]=x.upper;hpd_lower[j]=x.hpd_lower;
    hpd_upper[j]=x.hpd_upper;diagnostic_status[j]=d.status;rhat[j]=d.rhat;
    ess[j]=d.ess_bulk;mcse[j]=d.mcse_mean;
  }
  return Rcpp::DataFrame::create(Rcpp::Named("parameter")=parameter,
    Rcpp::Named("estimated")=estimated,Rcpp::Named("status")=status,
    Rcpp::Named("draws")=draws,Rcpp::Named("mean")=mean,Rcpp::Named("sd")=sd,
    Rcpp::Named("median")=median,Rcpp::Named("lower")=lower,
    Rcpp::Named("upper")=upper,Rcpp::Named("hpd_lower")=hpd_lower,
    Rcpp::Named("hpd_upper")=hpd_upper,
    Rcpp::Named("diagnostic_status")=diagnostic_status,
    Rcpp::Named("rhat")=rhat,Rcpp::Named("ess_bulk")=ess,
    Rcpp::Named("mcse_mean")=mcse);
}

Rcpp::NumericMatrix square_matrix(const std::vector<double>& x,
    const Rcpp::CharacterVector& labels) {
  if(x.empty()) return Rcpp::NumericMatrix(0,0);
  Rcpp::NumericMatrix out(labels.size(),labels.size());
  std::copy(x.begin(),x.end(),out.begin());
  out.attr("dimnames")=Rcpp::List::create(labels,labels);return out;
}
Rcpp::NumericMatrix trace_matrix(const std::vector<std::vector<double>>& x,
    const Rcpp::CharacterVector& labels) {
  Rcpp::NumericMatrix out(x.size(),labels.size());Rcpp::colnames(out)=labels;
  for(std::size_t i=0;i<x.size();++i)
    for(R_xlen_t j=0;j<labels.size();++j) out(i,j)=x[i][j];
  return out;
}
Rcpp::CharacterVector covariance_labels(const Rcpp::CharacterVector& traits) {
  Rcpp::CharacterVector out;
  for(const auto& b:traits) for(const auto& a:traits)
    out.push_back(Rcpp::as<std::string>(a)+","+Rcpp::as<std::string>(b));
  return out;
}
Rcpp::List genetic_result(const gbayes::GeneticCovariancePosterior& x,
    const Rcpp::CharacterVector& traits) {
  if(!x.draws) return Rcpp::List();
  std::vector<double> counts(x.correlation_draws.begin(),x.correlation_draws.end());
  return Rcpp::List::create(Rcpp::Named("covariance_mean")=square_matrix(x.covariance_mean,traits),
    Rcpp::Named("covariance_variance")=square_matrix(x.covariance_variance,traits),
    Rcpp::Named("correlation_mean")=square_matrix(x.correlation_mean,traits),
    Rcpp::Named("correlation_variance")=square_matrix(x.correlation_variance,traits),
    Rcpp::Named("correlation_draws")=square_matrix(counts,traits),
    Rcpp::Named("draws")=double(x.draws),Rcpp::Named("reference_id")=x.reference_id,
    Rcpp::Named("reference_truncated")=x.reference_truncated,
    Rcpp::Named("covariance_trace")=trace_matrix(x.covariance_trace,covariance_labels(traits)));
}
Rcpp::NumericMatrix row_matrix(const std::vector<double>& x,
    const Rcpp::CharacterVector& rows,const Rcpp::CharacterVector& columns) {
  Rcpp::NumericMatrix out(rows.size(),columns.size());
  for(R_xlen_t i=0;i<rows.size();++i) for(R_xlen_t j=0;j<columns.size();++j)
    out(i,j)=x[i*columns.size()+j];
  out.attr("dimnames")=Rcpp::List::create(rows,columns);return out;
}
Rcpp::NumericVector group_array(const std::vector<double>& x,
    const Rcpp::CharacterVector& traits,const Rcpp::CharacterVector& groups) {
  Rcpp::NumericVector out=Rcpp::wrap(x);
  out.attr("dim")=Rcpp::IntegerVector::create(traits.size(),traits.size(),groups.size());
  out.attr("dimnames")=Rcpp::List::create(traits,traits,groups);return out;
}
Rcpp::CharacterVector group_trait_labels(const Rcpp::CharacterVector& groups,
    const Rcpp::CharacterVector& traits) {
  Rcpp::CharacterVector out;for(const auto& group:groups) for(const auto& trait:traits)
    out.push_back(Rcpp::as<std::string>(group)+"::"+Rcpp::as<std::string>(trait));
  return out;
}
Rcpp::List partition_result(const gbayes::PartitionPosterior& x,
    const Rcpp::CharacterVector& traits) {
  if(!x.draws) return Rcpp::List();
  Rcpp::CharacterVector groups=Rcpp::wrap(x.partition.group_ids);
  const auto gt=group_trait_labels(groups,traits);Rcpp::CharacterVector activity;
  for(const auto& label:gt) activity.push_back("count["+Rcpp::as<std::string>(label)+"]");
  for(const auto& role:std::vector<std::string>{"both","shared"})
    for(const auto& group:groups) for(const auto& pair:covariance_labels(traits))
      activity.push_back(role+"["+Rcpp::as<std::string>(group)+","+
        Rcpp::as<std::string>(pair)+"]");
  return Rcpp::List::create(Rcpp::Named("groups")=groups,
    Rcpp::Named("expected_active")=row_matrix(x.expected_active,groups,traits),
    Rcpp::Named("both_active")=group_array(x.both_active,traits,groups),
    Rcpp::Named("shared_active")=group_array(x.shared_active,traits,groups),
    Rcpp::Named("genetic")=genetic_result(x.covariance,gt),
    Rcpp::Named("activity_trace")=trace_matrix(x.activity_trace,activity));
}
Rcpp::List prediction_result(const gbayes::PredictionPosterior& x,
    const Rcpp::CharacterVector& traits) {
  if(!x.draws) return Rcpp::List();
  Rcpp::CharacterVector ids=Rcpp::wrap(x.targets.target_ids);
  return Rcpp::List::create(Rcpp::Named("mean")=row_matrix(x.mean,ids,traits),
    Rcpp::Named("covariance")=group_array(x.covariance,traits,ids),
    Rcpp::Named("score_trace")=trace_matrix(x.score_trace,group_trait_labels(ids,traits)),
    Rcpp::Named("draws")=double(x.draws),Rcpp::Named("target_set")=x.targets.target_set_id,
    Rcpp::Named("coding")=x.targets.genotype_coding,
    Rcpp::Named("provenance")=x.targets.provenance);
}
const gbayes::BayesCChain& quantity_chain(const gbayes::BayesRChain& x) {return x.posterior;}
template<class Chain> const Chain& quantity_chain(const Chain& x) {return x;}

template<class Fit> void add_quantities(Rcpp::List& out,const Fit& fit,
    const Rcpp::List& pp,const Rcpp::CharacterVector& traits,double probability) {
  using Q=gbayes::PosteriorQuantity;std::vector<gbayes::PosteriorSelection> selected;
  const auto pairs=covariance_labels(traits);
  if(fit.genetic_covariance.draws) for(R_xlen_t j=0;j<pairs.size();++j)
    selected.push_back({"genetic_covariance["+Rcpp::as<std::string>(pairs[j])+"]",
      Q::genetic_covariance,std::size_t(j)});
  Rcpp::List partition=partition_result(fit.partition,traits);
  if(fit.partition.draws) {
    Rcpp::NumericMatrix trace=partition["activity_trace"];
    Rcpp::CharacterVector labels=Rcpp::colnames(trace);
    for(R_xlen_t j=0;j<labels.size();++j)
      selected.push_back({"partition_"+Rcpp::as<std::string>(labels[j]),
        Q::partition_activity,std::size_t(j)});
    if(fit.partition.covariance.draws) {
      const auto labels2=covariance_labels(group_trait_labels(
        Rcpp::wrap(fit.partition.partition.group_ids),traits));
      for(R_xlen_t j=0;j<labels2.size();++j)
        selected.push_back({"partition_covariance["+
          Rcpp::as<std::string>(labels2[j])+"]",Q::partition_covariance,
          std::size_t(j)});
    }
  }
  if(fit.prediction.draws) {
    const auto labels=group_trait_labels(Rcpp::wrap(fit.prediction.targets.target_ids),traits);
    for(R_xlen_t j=0;j<labels.size();++j)
      selected.push_back({"score["+Rcpp::as<std::string>(labels[j])+"]",
        Q::prediction_score,std::size_t(j)});
  }
  gbayes::PosteriorSummaryControls settings;settings.probability=probability;
  settings.memory_limit_bytes=Rcpp::as<double>(pp["memory_limit_bytes"]);
  auto summaries=gbayes::summarize_posterior(fit,selected,settings);
  Rcpp::List quantities=Rcpp::List::create(
    Rcpp::Named("genetic")=genetic_result(fit.genetic_covariance,traits),
    Rcpp::Named("partition")=partition,
    Rcpp::Named("prediction")=prediction_result(fit.prediction,traits));
  if(!Rf_isNull(pp["phenotype_variance"])) {
    Rcpp::NumericVector vp=pp["phenotype_variance"],mean(traits.size()),variance(traits.size());
    mean.names()=variance.names()=traits;
    for(R_xlen_t t=0;t<traits.size();++t) {
      const auto index=std::size_t(t+t*traits.size());
      mean[t]=fit.genetic_covariance.covariance_mean[index]/vp[t];
      variance[t]=fit.genetic_covariance.covariance_variance[index]/(vp[t]*vp[t]);
      auto draws=gbayes::extract_posterior(fit,{"h2",Q::genetic_covariance,index},
        settings.memory_limit_bytes);
      for(auto& chain:draws.chains) for(auto& value:chain) value/=vp[t];
      gbayes::LabelledPosteriorSummary summary;
      summary.selection={"h2["+Rcpp::as<std::string>(traits[t])+"]",
        Q::genetic_covariance,index};
      summary.summary=gbayes::summarize_trace(draws.chains,settings);
      summaries.push_back(summary);
    }
    quantities["heritability"]=Rcpp::List::create(Rcpp::Named("mean")=mean,
      Rcpp::Named("variance")=variance,Rcpp::Named("phenotype_variance")=vp);
  }
  Rcpp::List chains(fit.chains.size());
  for(std::size_t k=0;k<fit.chains.size();++k) {
    const auto& chain=quantity_chain(fit.chains[k]);
    chains[k]=Rcpp::List::create(
      Rcpp::Named("genetic")=genetic_result(chain.genetic_covariance,traits),
      Rcpp::Named("partition")=partition_result(chain.partition,traits),
      Rcpp::Named("prediction")=prediction_result(chain.prediction,traits));
  }
  quantities["chains"]=chains;out["quantities"]=quantities;
  out["quantity_posterior"]=posterior_rows(summaries);
}

std::shared_ptr<const gbayes::CenteredAnnotations> annotation_design(
    const Rcpp::List& x) {
  Rcpp::NumericMatrix design=x["design"];
  return std::make_shared<gbayes::CenteredAnnotations>(design.nrow(),
    Rcpp::as<std::vector<std::string>>(Rcpp::colnames(design)),
    Rcpp::as<std::vector<double>>(design));
}

template<class Prior> void annotation_common(Prior& p,const Rcpp::List& x) {
  p.design=annotation_design(x);p.learn_coefficients=Rcpp::as<bool>(x["learn"]);
  p.coefficient_prior_sd=Rcpp::as<double>(x["coefficient_prior_sd"]);
  p.update_every=std::size_t(Rcpp::as<double>(x["update_every"]));
  if(!Rf_isNull(x["initial"]))
    p.initial_coefficients=Rcpp::as<std::vector<double>>(x["initial"]);
}

std::shared_ptr<const gbayes::LogisticAnnotationPrior> inclusion_annotation(
    const Rcpp::List& annotation) {
  if(!annotation.containsElementNamed("inclusion")) return {};
  Rcpp::List x=annotation["inclusion"];
  auto p=std::make_shared<gbayes::LogisticAnnotationPrior>();annotation_common(*p,x);
  p->proposal_sd=Rcpp::as<double>(x["proposal_sd"]);return p;
}

std::shared_ptr<const gbayes::ProbitStickPrior> component_annotation(
    const Rcpp::List& annotation) {
  if(!annotation.containsElementNamed("component")) return {};
  Rcpp::List x=annotation["component"];
  auto p=std::make_shared<gbayes::ProbitStickPrior>();annotation_common(*p,x);
  p->intercept_prior_sd=Rcpp::as<double>(x["intercept_prior_sd"]);
  if(!Rf_isNull(x["intercept_means"]))
    p->intercept_means=Rcpp::as<std::vector<double>>(x["intercept_means"]);
  return p;
}

std::shared_ptr<const gbayes::LogVariancePrior> variance_annotation(
    const Rcpp::List& annotation) {
  if(!annotation.containsElementNamed("variance")) return {};
  Rcpp::List x=annotation["variance"];
  auto p=std::make_shared<gbayes::LogVariancePrior>();annotation_common(*p,x);
  p->maximum_evaluations=std::size_t(Rcpp::as<double>(x["maximum_evaluations"]));
  return p;
}

const gbayes::AnnotationSummary& annotation_summary(
    const gbayes::BayesCResult& fit,const std::string& role) {
  return role=="inclusion" ? fit.annotation : fit.variance_annotation;
}
const gbayes::AnnotationSummary& annotation_summary(
    const gbayes::BayesRResult& fit,const std::string& role) {
  return role=="component" ? fit.component_annotation : fit.variance_annotation;
}
const gbayes::AnnotationChain& annotation_chain(
    const gbayes::BayesCChain& chain,const std::string& role) {
  return role=="inclusion" ? chain.annotation : chain.variance_annotation;
}
const gbayes::AnnotationChain& annotation_chain(
    const gbayes::BayesRChain& chain,const std::string& role) {
  return role=="component" ? chain.component_annotation :
    chain.posterior.variance_annotation;
}

template<class Fit> Rcpp::List annotation_results(const Fit& fit,
    const Rcpp::List& annotation,
    std::vector<gbayes::PosteriorSelection>& selections) {
  Rcpp::List out;
  if(annotation.size()==0) return out;
  Rcpp::CharacterVector roles=annotation.names();
  for(R_xlen_t i=0;i<annotation.size();++i) {
    const std::string role=Rcpp::as<std::string>(roles[i]);Rcpp::List spec=annotation[i];
    Rcpp::CharacterVector labels=spec["coefficient_names"];
    const auto& summary=annotation_summary(fit,role);Rcpp::List chains(fit.chains.size());
    const auto quantity=role=="inclusion" ? gbayes::PosteriorQuantity::inclusion_coefficient :
      role=="component" ? gbayes::PosteriorQuantity::component_coefficient :
      gbayes::PosteriorQuantity::variance_coefficient;
    for(R_xlen_t j=0;j<labels.size();++j)
      selections.push_back({role+"["+Rcpp::as<std::string>(labels[j])+"]",
        quantity,std::size_t(j)});
    for(std::size_t k=0;k<fit.chains.size();++k) {
      const auto& x=annotation_chain(fit.chains[k],role);
      Rcpp::NumericMatrix trace(x.coefficient_trace.size(),labels.size());
      Rcpp::colnames(trace)=labels;
      for(std::size_t r=0;r<x.coefficient_trace.size();++r)
        for(R_xlen_t j=0;j<labels.size();++j) trace(r,j)=x.coefficient_trace[r][j];
      chains[k]=Rcpp::List::create(Rcpp::Named("coefficient_mean")=x.coefficient_mean,
        Rcpp::Named("final_coefficients")=x.final_coefficients,
        Rcpp::Named("trace")=trace,Rcpp::Named("updates")=double(x.updates),
        Rcpp::Named("accepted")=double(x.accepted),
        Rcpp::Named("proposed")=double(x.proposed),
        Rcpp::Named("likelihood_evaluations")=double(x.likelihood_evaluations));
    }
    const auto design=annotation_design(spec);
    out[role]=Rcpp::List::create(
      Rcpp::Named("coefficient_names")=labels,
      Rcpp::Named("coefficient_mean")=summary.coefficient_mean,
      Rcpp::Named("coefficient_variance")=summary.coefficient_variance,
      Rcpp::Named("design_means")=design->column_means(),
      Rcpp::Named("prior_probability_mean")=summary.prior_probability_mean,
      Rcpp::Named("multiplier_mean")=summary.multiplier_mean,
      Rcpp::Named("chains")=chains);
  }
  return out;
}

template<class Fit>
Rcpp::List summary_result(const Fit& fit,double probability,
    const Rcpp::List& annotation,std::size_t posterior_memory) {
  using Q=gbayes::PosteriorQuantity;
  std::vector<gbayes::PosteriorSelection> selections{
    {"residual_variance",Q::residual_variance,0},
    {"effect_variance",Q::slab_variance,0},
    {"active_markers",Q::active_markers,0}};
  for(std::size_t k=0;k<fit.parameter_mean.weights.size();++k)
    selections.push_back({"weight_"+std::to_string(k),Q::mixture_weight,k});
  for(std::size_t g=0;g<fit.block_residual_variance_mean.size();++g)
    selections.push_back({"block_residual_variance["+std::to_string(g+1)+"]",
      Q::block_residual_variance,g});
  Rcpp::List annotations=annotation_results(fit,annotation,selections);
  gbayes::PosteriorSummaryControls summary_controls;
  summary_controls.probability=probability;
  summary_controls.memory_limit_bytes=posterior_memory;
  Rcpp::DataFrame summaries=posterior_rows(
    gbayes::summarize_posterior(fit,selections,summary_controls));
  Rcpp::List chains(fit.chains.size()),states(fit.chains.size());
  const bool reference_adjusted=
    fit.learning.residual_policy==gbayes::ResidualPolicy::reference_ld_adjusted;
  for(std::size_t i=0;i<fit.chains.size();++i) {
    const auto& x=posterior(fit.chains[i]);
    const std::size_t weights=fit.parameter_mean.weights.size();
    const std::size_t blocks=x.block_residual_variance_mean.size();
    Rcpp::NumericMatrix trace(x.trace.parameters.size(),
      3+weights+(reference_adjusted ? 2:0)+blocks);
    Rcpp::CharacterVector columns=Rcpp::CharacterVector::create(
      "residual_variance","effect_variance","active_markers");
    if(reference_adjusted) {columns.push_back("genetic_variance");
      columns.push_back("working_residual_variance");}
    for(std::size_t k=0;k<weights;++k) columns.push_back("weight_"+std::to_string(k));
    for(std::size_t g=0;g<blocks;++g)
      columns.push_back("block_residual_variance["+std::to_string(g+1)+"]");
    Rcpp::colnames(trace)=columns;
    for(std::size_t r=0;r<x.trace.parameters.size();++r) {
      trace(r,0)=x.trace.parameters[r].residual_variance;
      trace(r,1)=x.trace.parameters[r].slab_variance;
      trace(r,2)=x.trace.active_markers[r];std::size_t offset=3;
      if(reference_adjusted) {trace(r,offset++)=x.trace.genetic_variance[r];
        trace(r,offset++)=x.trace.working_residual_variance[r];}
      for(std::size_t k=0;k<weights;++k)
        trace(r,offset+k)=x.trace.parameters[r].weights[k];
      offset+=weights;
      for(std::size_t g=0;g<blocks;++g)
        trace(r,offset+g)=x.trace.block_residual_variance[r][g];
    }
    chains[i]=Rcpp::List::create(Rcpp::Named("seed")=double(x.seed),
      Rcpp::Named("retained_draws")=double(x.retained_draws),
      Rcpp::Named("mean")=x.mean, Rcpp::Named("pip")=x.pip,
      Rcpp::Named("parameter_mean")=parameters(x.parameter_mean),
      Rcpp::Named("trace")=trace,
      Rcpp::Named("maximum_residual_drift")=x.maximum_residual_drift,
      Rcpp::Named("ld_swap_attempted")=double(x.ld_swap_attempted),
      Rcpp::Named("ld_swap_accepted")=double(x.ld_swap_accepted));
    states[i]=chain_state(x.continuation_state);
  }
  const auto agreement=gbayes::summarize_chains(fit);
  std::vector<double> effect_range(agreement.effect.size()), pip_range(agreement.pip.size());
  for(std::size_t j=0;j<agreement.effect.size();++j) {
    effect_range[j]=agreement.effect[j].maximum-agreement.effect[j].minimum;
    pip_range[j]=agreement.pip[j].maximum-agreement.pip[j].minimum;
  }
  double attempted=0,accepted=0;
  for(const auto& value:fit.chains) {const auto& x=posterior(value);
    attempted+=x.ld_swap_attempted;accepted+=x.ld_swap_accepted;}
  return Rcpp::List::create(Rcpp::Named("mean")=fit.mean,
    Rcpp::Named("variance")=fit.variance, Rcpp::Named("pip")=fit.pip,
    Rcpp::Named("parameter_mean")=parameters(fit.parameter_mean),
    Rcpp::Named("posterior")=summaries,Rcpp::Named("chains")=chains,
    Rcpp::Named("continuation_states")=states,
    Rcpp::Named("annotations")=annotations,
    Rcpp::Named("block_residual_variance_mean")=fit.block_residual_variance_mean,
    Rcpp::Named("ld_swap")=Rcpp::List::create(
      Rcpp::Named("attempted")=attempted,Rcpp::Named("accepted")=accepted,
      Rcpp::Named("acceptance_rate")=attempted ? accepted/attempted : NA_REAL),
    Rcpp::Named("between_chain")=Rcpp::List::create(
      Rcpp::Named("effect_range")=effect_range,
      Rcpp::Named("pip_range")=pip_range),
    Rcpp::Named("truncated_likelihood")=fit.truncated_likelihood,
    Rcpp::Named("provenance")=fit.provenance,
    Rcpp::Named("native_version")=gbayes::version_string());
}

void check_markers(const gmat::SparseLdDiskResource& resource,
                   const std::vector<std::string>& markers) {
  if(resource.markers.size()!=markers.size())
    Rcpp::stop("Sparse-LD marker count differs from summary statistics.");
  for(std::size_t j=0;j<markers.size();++j)
    if(resource.markers[j].marker_id!=markers[j])
      Rcpp::stop("Sparse-LD marker order differs from summary statistics.");
}

gbayes::BayesCControls chain_controls(const Rcpp::List& control) {
  gbayes::BayesCControls out;
  out.burnin=std::size_t(Rcpp::as<double>(control["burnin"]));
  out.sampling_sweeps=std::size_t(Rcpp::as<double>(control["sampling_sweeps"]));
  out.thinning=std::size_t(Rcpp::as<double>(control["thinning"]));
  out.threads=unsigned(Rcpp::as<double>(control["threads"]));
  out.retain_diagnostics=Rcpp::as<bool>(control["retain_diagnostics"]);
  out.chain_seeds.clear();
  for(double seed:Rcpp::as<std::vector<double>>(control["seeds"]))
    out.chain_seeds.push_back(std::uint32_t(seed));
  Rcpp::List swap=control["ld_swap"];
  out.ld_swap.probability=Rcpp::as<double>(swap["probability"]);
  out.ld_swap.minimum_r2=Rcpp::as<double>(swap["minimum_r2"]);
  out.ld_swap.maximum_friends=std::size_t(Rcpp::as<double>(swap["maximum_friends"]));
  out.ld_swap.moves=std::size_t(Rcpp::as<double>(swap["moves"]));
  if(control.containsElementNamed("scalar_initial_states") &&
      !Rf_isNull(control["scalar_initial_states"])) {
    Rcpp::List states=control["scalar_initial_states"];
    for(R_xlen_t i=0;i<states.size();++i) {
      Rcpp::List x=states[i];gbayes::ScalarChainState state;
      state.seed=std::uint32_t(Rcpp::as<double>(x["seed"]));
      state.completed_sweeps=std::size_t(Rcpp::as<double>(x["completed_sweeps"]));
      state.rng_state=Rcpp::as<std::string>(x["rng_state"]);
      state.effects=Rcpp::as<std::vector<double>>(x["effects"]);
      state.working_residual=Rcpp::as<std::vector<double>>(x["working_residual"]);
      state.components=Rcpp::as<std::vector<std::size_t>>(x["components"]);
      state.marker_order=Rcpp::as<std::vector<std::size_t>>(x["marker_order"]);
      Rcpp::List p=x["parameters"];
      state.parameters={Rcpp::as<double>(p["residual_variance"]),
        Rcpp::as<double>(p["effect_variance"]),
        Rcpp::as<std::vector<double>>(p["weights"])};
      state.genetic_variance=Rcpp::as<double>(x["genetic_variance"]);
      state.working_residual_variance=Rcpp::as<double>(x["working_residual_variance"]);
      state.block_residual_variance=Rcpp::as<std::vector<double>>(x["block_residual_variance"]);
      for(int value:Rcpp::as<std::vector<int>>(x["block_selected"]))
        state.block_selected.push_back(static_cast<unsigned char>(value));
      state.inclusion_coefficients=Rcpp::as<std::vector<double>>(x["inclusion_coefficients"]);
      state.component_coefficients=Rcpp::as<std::vector<double>>(x["component_coefficients"]);
      state.variance_coefficients=Rcpp::as<std::vector<double>>(x["variance_coefficients"]);
      out.initial_states.push_back(std::move(state));
    }
  }
  return out;
}

gbayes::GaussianLearning learning_controls(const Rcpp::List& prior,
    const Rcpp::List& control,bool bed,
    const gbayes::GaussianNormalization& bed_normalization={}) {
  gbayes::GaussianLearning out;out.normalization=bed_normalization;
  out.slab_variance=Rcpp::as<bool>(control["estimate_effect_variance"]);
  out.residual_variance=Rcpp::as<bool>(control["estimate_residual_variance"]);
  out.mixture_weights=Rcpp::as<bool>(control["estimate_weights"]);
  if(out.slab_variance) {Rcpp::List p=prior["effect_variance_prior"];
    out.slab_prior={Rcpp::as<double>(p["df"]),Rcpp::as<double>(p["scale"])};}
  if(out.residual_variance) {
    Rcpp::List p=prior["residual_variance_prior"];
    out.residual_prior={Rcpp::as<double>(p["df"]),Rcpp::as<double>(p["scale"])};
    if(!bed) {
      Rcpp::List norm=control["normalization"];
      out.normalization.phenotype_sum_squares=Rcpp::as<double>(norm["response_ss"]);
      out.normalization.likelihood_dimension=Rcpp::as<double>(norm["likelihood_dimension"]);
      out.normalization.space=gbayes::GaussianSpace::full;
      if(Rcpp::as<std::string>(control["residual_policy"])=="reference_ld") {
        out.residual_policy=gbayes::ResidualPolicy::reference_ld_adjusted;
        out.residual_adjustment=Rcpp::as<double>(control["residual_adjustment"]);
      }
    }
  }
  if(out.mixture_weights)
    out.weight_prior=Rcpp::as<std::vector<double>>(prior["weight_prior"]);
  if(!bed && control.containsElementNamed("block_residual") &&
      !Rf_isNull(control["block_residual"])) {
    Rcpp::List block=control["block_residual"];
    out.block_residual.marker_block=
      Rcpp::as<std::vector<std::size_t>>(block["block"]);
    const auto response=Rcpp::as<std::vector<double>>(block["response_ss"]);
    const auto dimension=Rcpp::as<std::vector<double>>(block["likelihood_dimension"]);
    const auto space=Rcpp::as<std::string>(block["space"])=="retained" ?
      gbayes::GaussianSpace::retained : gbayes::GaussianSpace::full;
    for(std::size_t g=0;g<response.size();++g)
      out.block_residual.normalization.push_back({response[g],dimension[g],space});
    const auto df=Rcpp::as<std::vector<double>>(block["prior_df"]);
    const auto scale=Rcpp::as<std::vector<double>>(block["prior_scale"]);
    for(std::size_t g=0;g<df.size();++g)
      out.block_residual.prior.push_back({df[g],scale[g]});
    out.block_residual.initial_variance=
      Rcpp::as<std::vector<double>>(block["initial_variance"]);
    out.block_residual.genetic_variance_denominator=
      Rcpp::as<std::vector<double>>(block["genetic_variance_denominator"]);
    const std::string mode=Rcpp::as<std::string>(block["mode"]);
    out.block_residual.mode=mode=="fixed" ? gbayes::BlockResidualMode::fixed :
      mode=="mix" ? gbayes::BlockResidualMode::mix :
      mode=="all_mix" ? gbayes::BlockResidualMode::all_mix :
      gbayes::BlockResidualMode::sample;
    out.block_residual.resample_threshold=Rcpp::as<double>(block["resample_threshold"]);
    out.block_residual.minimum_variance_ratio=
      Rcpp::as<double>(block["minimum_variance_ratio"]);
  }
  return out;
}

Rcpp::NumericMatrix component_probability(const gbayes::BayesRResult& fit) {
  const std::size_t columns=fit.prior.weights.size();
  Rcpp::NumericMatrix out(fit.component_probability.size(),columns);
  for(std::size_t j=0;j<fit.component_probability.size();++j)
    for(std::size_t k=0;k<fit.component_probability[j].size();++k)
      out(j,k)=fit.component_probability[j][k];
  return out;
}

void require_positive_retained_marker_diagonal(
    const gbayes::PreparedBlockEigensystems& prepared) {
  for(const auto& block:prepared.blocks) {
    const auto dimension=block.end-block.begin;
    const auto rank=block.eigenvalues.size();
    for(std::size_t j=0;j<dimension;++j) {
      double diagonal=0;
      for(std::size_t k=0;k<rank;++k) {
        const double loading=block.eigenvectors[k*dimension+j];
        diagonal+=block.eigenvalues[k]*loading*loading;
      }
      if(!std::isfinite(diagonal)||diagonal<=0)
        Rcpp::stop("Eigen retention leaves a marker with zero working variance; increase eigen_control$retained_positive_mass.");
    }
  }
}

Rcpp::List variational_result(const gbayes::SummaryVariationalResult& fit,
                              const std::string& provenance) {
  return Rcpp::List::create(Rcpp::Named("mean")=fit.mean,
    Rcpp::Named("variance")=fit.variance, Rcpp::Named("pip")=fit.pip,
    Rcpp::Named("diagnostics")=Rcpp::List::create(
      Rcpp::Named("initial_elbo")=fit.initial_elbo,
      Rcpp::Named("final_elbo")=fit.final_elbo,
      Rcpp::Named("globally_converged")=fit.globally_converged,
      Rcpp::Named("window_sweeps")=fit.window_sweeps,
      Rcpp::Named("maximum_residual_drift")=fit.maximum_residual_drift),
    Rcpp::Named("provenance")=provenance,
    Rcpp::Named("native_version")=gbayes::version_string());
}
}

// [[Rcpp::export]]
Rcpp::List cpp_gbayes_native_info() {
  return Rcpp::List::create(
    Rcpp::Named("header_version")="0.1.0", Rcpp::Named("runtime_version")=gbayes::version_string(),
    Rcpp::Named("abi_contract")=0, Rcpp::Named("headers_match_runtime")=std::string(gbayes::version_string())=="0.1.0" &&
      std::string(gsolve::version_string())==std::to_string(gsolve::version_major)+"."+
      std::to_string(gsolve::version_minor)+"."+std::to_string(gsolve::version_patch) &&
      gsolve::abi_version()==gsolve::experimental_abi,
    Rcpp::Named("gmat_version")=gmat::version_string(), Rcpp::Named("gmat_abi")=gmat::abi_version(),
    Rcpp::Named("gsolve_version")=gsolve::version_string(), Rcpp::Named("gsolve_abi")=gsolve::abi_version(),
    Rcpp::Named("gbits_version")=gbits_library_version(), Rcpp::Named("gbits_abi")=gbits_abi_version(),
    Rcpp::Named("gscore_version")=gscore::version_string(),
    Rcpp::Named("gscore_abi")=gscore::abi_version());
}

// Internal preparation bridge for future block-eigen consumers. It returns
// ordinary R diagnostics/arrays and does not expose a persistent external pointer.
// [[Rcpp::export]]
Rcpp::List cpp_gbayes_block_eigen_prepare(std::string prefix,
    std::vector<double> offsets, std::vector<std::string> marker,
    Rcpp::NumericMatrix beta_std, Rcpp::NumericMatrix sample_size,
    std::vector<std::string> traits, Rcpp::List control) {
  if(beta_std.nrow()!=static_cast<int>(marker.size())||
     sample_size.nrow()!=beta_std.nrow()||sample_size.ncol()!=beta_std.ncol()||
     traits.size()!=static_cast<std::size_t>(beta_std.ncol())||traits.empty())
    Rcpp::stop("Invalid block-eigen trait dimensions.");
  std::vector<std::uint64_t> native_offsets;native_offsets.reserve(offsets.size());
  for(double value:offsets) {
    if(!std::isfinite(value)||value<0||value!=std::floor(value))
      Rcpp::stop("Invalid block-eigen offsets.");
    native_offsets.push_back(static_cast<std::uint64_t>(value));
  }
  gmat::SparseLdBlockProvider provider(prefix,std::move(native_offsets));
  check_markers(provider.resource(),marker);
  gbayes::BlockEigenPreparationControls settings;
  settings.retained_positive_mass=Rcpp::as<double>(control["retained_positive_mass"]);
  settings.maximum_block_dimension=static_cast<std::size_t>(
    Rcpp::as<double>(control["maximum_block_dimension"]));
  settings.symmetry_tolerance=Rcpp::as<double>(control["symmetry_tolerance"]);
  settings.verification_tolerance=Rcpp::as<double>(control["verification_tolerance"]);
  auto prepared=gbayes::prepare_block_eigensystems(provider,settings);
  require_positive_retained_marker_diagonal(prepared);
  Rcpp::NumericMatrix projected(beta_std.nrow(),beta_std.ncol());
  Rcpp::NumericMatrix response(
    static_cast<int>(prepared.diagnostics.retained_rank),beta_std.ncol());
  Rcpp::NumericVector maximum_change(beta_std.ncol()),relative_change(beta_std.ncol());
  for(int trait=0;trait<beta_std.ncol();++trait) {
    std::vector<double> effects(marker.size()),sizes(marker.size());
    for(int j=0;j<beta_std.nrow();++j) {
      effects[static_cast<std::size_t>(j)]=beta_std(j,trait);
      sizes[static_cast<std::size_t>(j)]=sample_size(j,trait);
    }
    const bool common_n=std::all_of(sizes.begin()+1,sizes.end(),
      [&](double value){return value==sizes.front();});
    auto bound=gbayes::bind_block_summary_gaussian(prepared,effects,sizes,
      traits[static_cast<std::size_t>(trait)],
      common_n?gbayes::SummaryGaussianConvention::common_n:
        gbayes::SummaryGaussianConvention::variable_n);
    for(std::size_t j=0;j<marker.size();++j)
      projected(static_cast<int>(j),trait)=bound.statistics.score[j];
    for(std::size_t k=0;k<bound.statistics.response_coordinates.size();++k)
      response(static_cast<int>(k),trait)=bound.statistics.response_coordinates[k];
    maximum_change[trait]=bound.maximum_score_projection_change;
    relative_change[trait]=bound.relative_score_projection_change;
  }
  Rcpp::IntegerVector ranks(prepared.blocks.size());
  Rcpp::NumericVector retained_mass(prepared.blocks.size()),minimum_eigenvalue(prepared.blocks.size());
  for(std::size_t b=0;b<prepared.blocks.size();++b) {
    ranks[static_cast<R_xlen_t>(b)]=static_cast<int>(prepared.blocks[b].eigenvalues.size());
    retained_mass[static_cast<R_xlen_t>(b)]=prepared.blocks[b].retained_positive_mass/
      prepared.blocks[b].total_positive_mass;
    minimum_eigenvalue[static_cast<R_xlen_t>(b)]=prepared.blocks[b].minimum_eigenvalue;
  }
  const auto& d=prepared.diagnostics;
  return Rcpp::List::create(
    Rcpp::Named("projected_score")=projected,
    Rcpp::Named("response_coordinates")=response,
    Rcpp::Named("block_rank")=ranks,
    Rcpp::Named("retained_positive_mass")=retained_mass,
    Rcpp::Named("minimum_eigenvalue")=minimum_eigenvalue,
    Rcpp::Named("maximum_score_projection_change")=maximum_change,
    Rcpp::Named("relative_score_projection_change")=relative_change,
    Rcpp::Named("diagnostics")=Rcpp::List::create(
      Rcpp::Named("blocks")=double(d.blocks),
      Rcpp::Named("eigensystem_decompositions")=double(d.eigensystem_decompositions),
      Rcpp::Named("total_markers")=double(d.total_markers),
      Rcpp::Named("retained_rank")=double(d.retained_rank),
      Rcpp::Named("peak_block_markers")=double(d.peak_block_markers),
      Rcpp::Named("largest_dense_block_bytes")=
        double(d.largest_dense_block_bytes),
      Rcpp::Named("retained_eigen_bytes")=double(d.retained_eigen_bytes),
      Rcpp::Named("block_loads")=double(d.block_loads),
      Rcpp::Named("block_cache_hits")=double(d.block_cache_hits),
      Rcpp::Named("maximum_discarded_positive_mass")=d.maximum_discarded_positive_mass,
      Rcpp::Named("minimum_eigenvalue")=d.minimum_eigenvalue));
}

// [[Rcpp::export]]
Rcpp::List cpp_gbayes_sbayesrc_fit(std::string prefix,
    std::vector<double> offsets, std::vector<std::string> marker,
    std::vector<double> beta_std, std::vector<double> sample_size,
    std::string trait, Rcpp::List prior, Rcpp::List control,
    Rcpp::List annotation, Rcpp::List posterior_control) {
  if(marker.empty()||beta_std.size()!=marker.size()||
     sample_size.size()!=marker.size())
    Rcpp::stop("Invalid SBayesRC summary dimensions.");
  std::vector<std::uint64_t> native_offsets;native_offsets.reserve(offsets.size());
  for(double value:offsets) {
    if(!std::isfinite(value)||value<0||value!=std::floor(value))
      Rcpp::stop("Invalid SBayesRC block offsets.");
    native_offsets.push_back(static_cast<std::uint64_t>(value));
  }
  gmat::SparseLdBlockProvider provider(prefix,std::move(native_offsets));
  check_markers(provider.resource(),marker);
  Rcpp::List eigen=control["eigen_control"];
  gbayes::BlockEigenPreparationControls settings;
  settings.retained_positive_mass=Rcpp::as<double>(eigen["retained_positive_mass"]);
  settings.maximum_block_dimension=static_cast<std::size_t>(
    Rcpp::as<double>(eigen["maximum_block_dimension"]));
  settings.symmetry_tolerance=Rcpp::as<double>(eigen["symmetry_tolerance"]);
  settings.verification_tolerance=Rcpp::as<double>(eigen["verification_tolerance"]);
  auto prepared=gbayes::prepare_block_eigensystems(provider,settings);
  require_positive_retained_marker_diagonal(prepared);
  auto bound=gbayes::bind_block_summary_gaussian(prepared,beta_std,sample_size,
    trait,gbayes::SummaryGaussianConvention::common_n);
  bound.statistics.provenance=
    "verified Glist retained block-eigen SBayesRC likelihood";

  auto controls=chain_controls(control);
  auto learning=learning_controls(prior,control,false);
  Rcpp::List residual=control["block_eigen_residual"];
  const double initial=Rcpp::as<double>(prior["residual_variance"]);
  const double prior_df=Rcpp::as<double>(residual["prior_df"]);
  const double prior_scale=Rcpp::as<double>(residual["prior_scale"]);
  const double denominator=sample_size.front();
  learning.block_residual.marker_block.resize(marker.size());
  std::size_t coordinate=0;
  for(std::size_t b=0;b<prepared.blocks.size();++b) {
    const auto& block=prepared.blocks[b];
    std::fill(learning.block_residual.marker_block.begin()+
        static_cast<std::ptrdiff_t>(block.begin),
      learning.block_residual.marker_block.begin()+
        static_cast<std::ptrdiff_t>(block.end),b);
    const auto rank=block.eigenvalues.size();double response_ss=0;
    for(std::size_t k=0;k<rank;++k) {
      const double value=bound.statistics.response_coordinates[coordinate+k];
      response_ss+=value*value;
    }
    coordinate+=rank;
    learning.block_residual.normalization.push_back(
      {response_ss,static_cast<double>(rank),gbayes::GaussianSpace::retained});
    learning.block_residual.prior.push_back({prior_df,prior_scale});
    learning.block_residual.initial_variance.push_back(initial);
    learning.block_residual.genetic_variance_denominator.push_back(denominator);
  }
  if(coordinate!=bound.statistics.response_coordinates.size())
    Rcpp::stop("Invalid retained block-coordinate extent.");
  const std::string mode=Rcpp::as<std::string>(residual["mode"]);
  learning.block_residual.mode=mode=="fixed" ? gbayes::BlockResidualMode::fixed :
    mode=="sample" ? gbayes::BlockResidualMode::sample :
    mode=="mix" ? gbayes::BlockResidualMode::mix :
    gbayes::BlockResidualMode::all_mix;
  learning.block_residual.resample_threshold=
    Rcpp::as<double>(residual["resample_threshold"]);
  learning.block_residual.minimum_variance_ratio=
    Rcpp::as<double>(residual["minimum_variance_ratio"]);

  gbayes::BayesRPrior model;
  model.residual_variance=initial;
  model.slab_variance=Rcpp::as<double>(prior["effect_variance"]);
  model.weights=Rcpp::as<std::vector<double>>(prior["weights"]);
  model.variance_multipliers=
    Rcpp::as<std::vector<double>>(prior["variance_multipliers"]);
  model.component_annotation=component_annotation(annotation);
  model.variance_annotation=variance_annotation(annotation);
  const double probability=Rcpp::as<double>(control["probability"]);
  const auto posterior_memory=std::size_t(
    Rcpp::as<double>(posterior_control["memory_limit_bytes"]));
  PosteriorCapture capture(posterior_control,control);
  const auto fit=gbayes::fit_bayesr(bound.statistics,model,controls,learning,
    capture.controls);
  auto out=summary_result(fit,probability,annotation,posterior_memory);
  add_quantities(out,fit,posterior_control,
    Rcpp::CharacterVector::create(trait),probability);
  out["component_probability"]=component_probability(fit);
  const auto& d=prepared.diagnostics;
  Rcpp::IntegerVector ranks(prepared.blocks.size());
  Rcpp::NumericVector retained_mass(prepared.blocks.size());
  for(std::size_t b=0;b<prepared.blocks.size();++b) {
    ranks[static_cast<R_xlen_t>(b)]=
      static_cast<int>(prepared.blocks[b].eigenvalues.size());
    retained_mass[static_cast<R_xlen_t>(b)]=
      prepared.blocks[b].retained_positive_mass/
      prepared.blocks[b].total_positive_mass;
  }
  out["block_eigen"]=Rcpp::List::create(
    Rcpp::Named("block_rank")=ranks,
    Rcpp::Named("retained_positive_mass")=retained_mass,
    Rcpp::Named("blocks")=double(d.blocks),
    Rcpp::Named("block_loads")=double(d.block_loads),
    Rcpp::Named("block_cache_hits")=double(d.block_cache_hits),
    Rcpp::Named("eigensystem_decompositions")=
      double(d.eigensystem_decompositions),
    Rcpp::Named("retained_rank")=double(d.retained_rank),
    Rcpp::Named("peak_block_markers")=double(d.peak_block_markers),
    Rcpp::Named("largest_dense_block_bytes")=
      double(d.largest_dense_block_bytes),
    Rcpp::Named("retained_eigen_bytes")=double(d.retained_eigen_bytes),
    Rcpp::Named("maximum_discarded_positive_mass")=
      d.maximum_discarded_positive_mass,
    Rcpp::Named("minimum_eigenvalue")=d.minimum_eigenvalue,
    Rcpp::Named("maximum_score_projection_change")=
      bound.maximum_score_projection_change,
    Rcpp::Named("relative_score_projection_change")=
      bound.relative_score_projection_change);
  capture.check_unchanged();
  return out;
}

// [[Rcpp::export]]
Rcpp::DataFrame cpp_gbayes_single_effect(std::vector<std::string> marker, std::vector<double> score,
    std::vector<double> information, std::string trait, std::string units,
    double residual_variance, double effect_variance, std::vector<double> weights) {
  const std::size_t n=marker.size(); std::vector<double> cross(n*n,0.0);
  for(std::size_t i=0;i<n;++i) cross[i*n+i]=information[i];
  gbayes::FixedGaussianStatistics data{gbayes::dense_cross_products(n,std::move(cross)), score, marker, trait, units, "gbayes R task package", {}};
  gbayes::SingleEffectPrior prior{residual_variance,effect_variance,weights};
  const auto x=gbayes::fit_single_effect(data,prior);
  return Rcpp::DataFrame::create(Rcpp::Named("marker")=x.marker_ids,
    Rcpp::Named("prior_probability")=x.prior_probability,
    Rcpp::Named("posterior_probability")=x.assignment_probability,
    Rcpp::Named("mean")=x.mean, Rcpp::Named("variance")=x.variance,
    Rcpp::Named("log_bayes_factor")=x.log_bayes_factor);
}

// [[Rcpp::export]]
Rcpp::List cpp_gbayes_summary_fit(std::string prefix,
    std::vector<std::string> marker, std::vector<double> beta_std,
    std::vector<double> sample_size, std::string trait, std::string method,
    Rcpp::List prior, Rcpp::List control, Rcpp::List annotation,
    Rcpp::List posterior_control) {
  std::shared_ptr<const gbayes::CrossProducts> products;
  std::shared_ptr<const gmat::SparseLdDiskReader> disk;
  std::shared_ptr<const gmat::SparseLdCsr> memory;
  const std::string storage=Rcpp::as<std::string>(control["storage"]);
  const bool eigen=control.containsElementNamed("eigen_offsets");
  std::unique_ptr<gmat::SparseLdBlockProvider> provider;
  gbayes::PreparedBlockEigensystems prepared;
  gbayes::BoundBlockSummary bound;
  if(eigen) {
    std::vector<std::uint64_t> offsets;
    for(double x:Rcpp::as<std::vector<double>>(control["eigen_offsets"]))
      offsets.push_back(static_cast<std::uint64_t>(x));
    provider=std::make_unique<gmat::SparseLdBlockProvider>(prefix,std::move(offsets));
    check_markers(provider->resource(),marker);
    Rcpp::List e=control["eigen_control"];
    gbayes::BlockEigenPreparationControls settings;
    settings.retained_positive_mass=Rcpp::as<double>(e["retained_positive_mass"]);
    settings.maximum_block_dimension=Rcpp::as<double>(e["maximum_block_dimension"]);
    settings.symmetry_tolerance=Rcpp::as<double>(e["symmetry_tolerance"]);
    settings.verification_tolerance=Rcpp::as<double>(e["verification_tolerance"]);
    prepared=gbayes::prepare_block_eigensystems(*provider,settings);
    require_positive_retained_marker_diagonal(prepared);
    bound=gbayes::bind_block_summary_gaussian(prepared,beta_std,sample_size,trait,
      gbayes::SummaryGaussianConvention::common_n);
    products=bound.statistics.cross_products;
  } else if(storage=="disk") {
    disk=std::make_shared<const gmat::SparseLdDiskReader>(prefix);
    check_markers(disk->resource(),marker);
    products=gbayes::disk_ld_cross_products(disk,sample_size);
  } else {
    auto loaded=gmat::load_sparse_ld_csr_with_resource_from_disk(prefix);
    check_markers(loaded.resource,marker);
    const double maximum=Rcpp::as<double>(control["max_ld_entries"]);
    if(double(loaded.resource.stored_entry_count)>maximum)
      Rcpp::stop("Sparse-LD entries exceed control$max_ld_entries.");
    memory=std::make_shared<const gmat::SparseLdCsr>(std::move(loaded.ld));
    products=gbayes::ld_cross_products(memory,sample_size);
  }
  const auto convention=Rcpp::as<std::string>(control["sample_size"])=="common" ?
    gbayes::SummaryGaussianConvention::common_n :
    gbayes::SummaryGaussianConvention::variable_n;
  auto data=eigen ? bound.statistics : gbayes::prepare_summary_gaussian(
    products,beta_std,sample_size,marker,trait,convention);
  auto controls=chain_controls(control);
  auto learning=learning_controls(prior,control,false);
  if(eigen && learning.residual_variance) {
    double ss=0;for(double x:data.response_coordinates) ss+=x*x;
    learning.normalization={ss,double(data.response_coordinates.size()),gbayes::GaussianSpace::retained};
    data.provenance="verified retained block-eigen BayesC/BayesR pseudo-likelihood; cross-block LD omitted";
  } else if(learning.residual_policy==gbayes::ResidualPolicy::reference_ld_adjusted) {
    learning.genetic_variance_denominator=sample_size.front();
    data.provenance="standalone gbayes reference-LD residual adjustment with inferred y'y=N";
  } else if(learning.residual_variance)
    data.provenance="standalone gbayes caller-declared complete in-sample sufficient statistics";
  const double probability=Rcpp::as<double>(control["probability"]);
  const auto posterior_memory=std::size_t(
    Rcpp::as<double>(posterior_control["memory_limit_bytes"]));
  PosteriorCapture capture(posterior_control,control);
  const bool fitted_variance=control.containsElementNamed("fitted_variance") &&
    Rcpp::as<bool>(control["fitted_variance"]) && !capture.controls.genetic_reference &&
    std::all_of(sample_size.begin(),sample_size.end(),[&](double n){return n==sample_size.front();});
  if(fitted_variance) {
    auto ref=std::make_shared<gbayes::GeneticCovarianceReference>();
    ref->cross_products=data.cross_products;ref->marker_ids=marker;
    ref->counted_alleles=Rcpp::as<std::vector<std::string>>(posterior_control["fit_allele"]);
    ref->effect_multipliers.assign(marker.size(),1.0);ref->divisor=sample_size.front();
    ref->reference_id="fitted-likelihood";ref->genotype_coding="standardized dosage";
    ref->provenance=data.provenance;capture.controls.genetic_reference=ref;
  }
  auto decorate=[&](Rcpp::List out) {
    out["fitted_variance"]=fitted_variance;
    if(eigen) {
      Rcpp::NumericVector mass(prepared.blocks.size());
      Rcpp::IntegerVector rank(prepared.blocks.size());
      for(std::size_t b=0;b<prepared.blocks.size();++b) {
        rank[b]=prepared.blocks[b].eigenvalues.size();
        mass[b]=prepared.blocks[b].retained_positive_mass/prepared.blocks[b].total_positive_mass;
      }
      out["block_eigen"]=Rcpp::List::create(
        Rcpp::Named("block_rank")=rank,Rcpp::Named("retained_positive_mass")=mass,
        Rcpp::Named("eigensystem_decompositions")=double(prepared.diagnostics.eigensystem_decompositions),
        Rcpp::Named("retained_rank")=double(prepared.diagnostics.retained_rank),
        Rcpp::Named("retained_eigen_bytes")=double(prepared.diagnostics.retained_eigen_bytes),
        Rcpp::Named("maximum_score_projection_change")=bound.maximum_score_projection_change,
        Rcpp::Named("cross_block_ld")="verified zero retained edges between declared blocks");
      out["eigen_normalization"]=Rcpp::List::create(
        Rcpp::Named("response_ss")=learning.normalization.phenotype_sum_squares,
        Rcpp::Named("likelihood_dimension")=learning.normalization.likelihood_dimension,
        Rcpp::Named("space")="retained");
    }
    return out;
  };
  if(method=="bayesc") {
    gbayes::BayesCPrior p;
    p.residual_variance=Rcpp::as<double>(prior["residual_variance"]);
    p.slab_variance=Rcpp::as<double>(prior["effect_variance"]);
    p.inclusion_probability=Rcpp::as<double>(prior["inclusion_probability"]);
    p.inclusion_annotation=inclusion_annotation(annotation);
    p.variance_annotation=variance_annotation(annotation);
    const auto fit=gbayes::fit_bayesc(data,p,controls,learning,capture.controls);
    auto out=summary_result(fit,probability,annotation,posterior_memory);
    add_quantities(out,fit,posterior_control,Rcpp::CharacterVector::create(trait),probability);
    out["component_probability"]=R_NilValue;
    capture.check_unchanged();
    if(disk) disk->check_unchanged();
    return decorate(out);
  }
  gbayes::BayesRPrior p;
  p.residual_variance=Rcpp::as<double>(prior["residual_variance"]);
  p.slab_variance=Rcpp::as<double>(prior["effect_variance"]);
  p.weights=Rcpp::as<std::vector<double>>(prior["weights"]);
  p.variance_multipliers=Rcpp::as<std::vector<double>>(prior["variance_multipliers"]);
  p.component_annotation=component_annotation(annotation);
  p.variance_annotation=variance_annotation(annotation);
  const auto fit=gbayes::fit_bayesr(data,p,controls,learning,capture.controls);
  auto out=summary_result(fit,probability,annotation,posterior_memory);
  add_quantities(out,fit,posterior_control,Rcpp::CharacterVector::create(trait),probability);
  out["component_probability"]=component_probability(fit);
  capture.check_unchanged();
  if(disk) disk->check_unchanged();
  return decorate(out);
}

// [[Rcpp::export]]
Rcpp::List cpp_gbayes_bed_fit(double physical_sample_count,
    std::vector<double> sample_indices, std::vector<std::string> paths,
    std::vector<double> physical_marker_count, Rcpp::List marker_indices,
    std::vector<double> phenotype, std::vector<std::string> marker,
    std::vector<double> allele_frequency, std::string trait, std::string method,
    Rcpp::List prior, Rcpp::List control, Rcpp::List annotation,
    Rcpp::List posterior_control) {
  gbayes::IndividualBedInput input;
  input.physical_sample_count=std::uint64_t(physical_sample_count);
  for(double index:sample_indices) input.sample_indices.push_back(std::uint64_t(index));
  for(std::size_t i=0;i<paths.size();++i) {
    gbayes::IndividualBedFile file;
    file.path=paths[std::size_t(i)];
    file.physical_marker_count=std::uint64_t(physical_marker_count[std::size_t(i)]);
    const auto indices=Rcpp::as<std::vector<double>>(
      marker_indices[static_cast<R_xlen_t>(i)]);
    for(double index:indices) file.marker_indices.push_back(std::uint64_t(index));
    input.files.push_back(std::move(file));
  }
  input.phenotype=std::move(phenotype);
  input.marker_ids=std::move(marker);
  input.allele_frequency=std::move(allele_frequency);
  input.trait=std::move(trait);
  input.standardize=true;
  input.likelihood_dimension=Rcpp::as<double>(control["likelihood_dimension"]);
  input.packed_memory_limit_bytes=std::size_t(
    Rcpp::as<double>(control["packed_memory_limit_bytes"]));
  auto prepared=gbayes::prepare_individual_bed(input);
  auto controls=chain_controls(control);
  auto learning=learning_controls(prior,control,true,prepared.normalization);
  const double probability=Rcpp::as<double>(control["probability"]);
  const auto posterior_memory=std::size_t(
    Rcpp::as<double>(posterior_control["memory_limit_bytes"]));
  PosteriorCapture capture(posterior_control,control);
  Rcpp::List out;
  if(method=="bayesc") {
    gbayes::BayesCPrior p;
    p.residual_variance=Rcpp::as<double>(prior["residual_variance"]);
    p.slab_variance=Rcpp::as<double>(prior["effect_variance"]);
    p.inclusion_probability=Rcpp::as<double>(prior["inclusion_probability"]);
    p.inclusion_annotation=inclusion_annotation(annotation);
    p.variance_annotation=variance_annotation(annotation);
    const auto fit=gbayes::fit_bayesc(prepared.statistics,p,controls,learning,
      capture.controls);
    out=summary_result(fit,probability,annotation,posterior_memory);
    add_quantities(out,fit,posterior_control,Rcpp::CharacterVector::create(trait),probability);
    out["component_probability"]=R_NilValue;
  } else {
    gbayes::BayesRPrior p;
    p.residual_variance=Rcpp::as<double>(prior["residual_variance"]);
    p.slab_variance=Rcpp::as<double>(prior["effect_variance"]);
    p.weights=Rcpp::as<std::vector<double>>(prior["weights"]);
    p.variance_multipliers=Rcpp::as<std::vector<double>>(prior["variance_multipliers"]);
    p.component_annotation=component_annotation(annotation);
    p.variance_annotation=variance_annotation(annotation);
    const auto fit=gbayes::fit_bayesr(prepared.statistics,p,controls,learning,
      capture.controls);
    out=summary_result(fit,probability,annotation,posterior_memory);
    add_quantities(out,fit,posterior_control,Rcpp::CharacterVector::create(trait),probability);
    out["component_probability"]=component_probability(fit);
  }
  const auto coding=gbayes::individual_bed_coding(prepared.statistics);
  out["sample_count"]=double(prepared.sample_count);
  out["packed_memory_bytes"]=double(prepared.packed_memory_bytes);
  out["coding"]=Rcpp::List::create(
    Rcpp::Named("allele_frequency")=coding.allele_frequency,
    Rcpp::Named("centers")=coding.centers,
    Rcpp::Named("scales")=coding.scales,
    Rcpp::Named("sample_count")=double(coding.sample_count),
    Rcpp::Named("standardized")=coding.standardized);
  capture.check_unchanged();
  return out;
}

// [[Rcpp::export]]
Rcpp::List cpp_gbayes_engine(std::string prefix,
    std::vector<std::string> marker, std::vector<double> beta_std,
    std::vector<double> sample_size, std::string trait, std::string method,
    Rcpp::List prior, Rcpp::List control) {
  const double maximum=Rcpp::as<double>(control["max_ld_entries"]);
  const std::string provenance="standalone gbayes checked summary statistics; "+method;
  if(method=="continuous_shrinkage") {
    auto loaded=gmat::load_sparse_ld_csr_with_resource_from_disk(prefix);
    check_markers(loaded.resource,marker);
    if(double(loaded.resource.stored_entry_count)>maximum)
      Rcpp::stop("Sparse-LD entries exceed control$max_ld_entries.");
    auto ld=std::make_shared<const gmat::SparseLdCsr>(std::move(loaded.ld));
    gbayes::ContinuousShrinkageInput input;
    input.ld=ld; input.marker_ids=marker; input.marginal_effects=beta_std;
    input.effective_sample_size=sample_size.at(0); input.trait=trait;
    for(double value:Rcpp::as<std::vector<double>>(control["block_offsets"]))
      input.block_offsets.push_back(std::size_t(value));
    gbayes::ContinuousShrinkageControls settings;
    settings.burnin=std::size_t(Rcpp::as<double>(control["burnin"]));
    settings.sampling_sweeps=std::size_t(Rcpp::as<double>(control["sampling_sweeps"]));
    settings.thinning=std::size_t(Rcpp::as<double>(control["thinning"]));
    settings.seed=std::uint32_t(Rcpp::as<double>(control["seed"]));
    settings.global_scale=Rcpp::as<double>(prior["global_scale"]);
    settings.learn_global_scale=Rcpp::as<bool>(control["learn_global_scale"]);
    settings.maximum_block_dimension=std::size_t(
      Rcpp::as<double>(control["maximum_block_dimension"]));
    settings.dense_workspace_budget_bytes=std::size_t(
      Rcpp::as<double>(control["dense_workspace_budget_bytes"]));
    const auto fit=gbayes::fit_continuous_shrinkage(input,settings);
    Rcpp::NumericVector unavailable(marker.size(),NA_REAL);
    return Rcpp::List::create(Rcpp::Named("mean")=fit.mean,
      Rcpp::Named("variance")=unavailable,Rcpp::Named("pip")=unavailable,
      Rcpp::Named("diagnostics")=Rcpp::List::create(
        Rcpp::Named("local_scale_mean")=fit.local_scale_mean,
        Rcpp::Named("global_scale_mean")=fit.global_scale_mean,
        Rcpp::Named("residual_scale_mean")=fit.residual_scale_mean,
        Rcpp::Named("retained_draws")=double(fit.retained_draws),
        Rcpp::Named("dense_workspace")=Rcpp::List::create(
          Rcpp::Named("budget_bytes")=double(fit.dense_workspace.budget_bytes),
          Rcpp::Named("required_bytes")=double(fit.dense_workspace.required_bytes),
          Rcpp::Named("peak_reserved_bytes")=double(fit.dense_workspace.peak_reserved_bytes),
          Rcpp::Named("block_loads")=double(fit.dense_workspace.block_loads))),
      Rcpp::Named("provenance")=provenance,
      Rcpp::Named("native_version")=gbayes::version_string());
  }
  std::shared_ptr<const gbayes::CrossProducts> products;
  std::shared_ptr<const gmat::SparseLdDiskReader> disk;
  std::shared_ptr<const gmat::SparseLdCsr> memory;
  if(Rcpp::as<std::string>(control["storage"])=="disk") {
    disk=std::make_shared<const gmat::SparseLdDiskReader>(prefix);
    check_markers(disk->resource(),marker);
    products=gbayes::disk_ld_cross_products(disk,sample_size);
  } else {
    auto loaded=gmat::load_sparse_ld_csr_with_resource_from_disk(prefix);
    check_markers(loaded.resource,marker);
    if(double(loaded.resource.stored_entry_count)>maximum)
      Rcpp::stop("Sparse-LD entries exceed control$max_ld_entries.");
    memory=std::make_shared<const gmat::SparseLdCsr>(std::move(loaded.ld));
    products=gbayes::ld_cross_products(memory,sample_size);
  }
  auto data=gbayes::prepare_summary_gaussian(products,beta_std,sample_size,
    marker,trait,gbayes::SummaryGaussianConvention::common_n);
  Rcpp::List out;
  if(method=="point_normal") {
    gbayes::PointNormalGibbsControls settings;
    settings.burnin=std::size_t(Rcpp::as<double>(control["burnin"]));
    settings.sampling_sweeps=std::size_t(Rcpp::as<double>(control["sampling_sweeps"]));
    settings.seed=std::uint32_t(Rcpp::as<double>(control["seed"]));
    settings.sparse=Rcpp::as<bool>(control["sparse"]);
    settings.auto_update=Rcpp::as<bool>(control["auto_update"]);
    const auto fit=gbayes::fit_point_normal_gibbs(data,
      Rcpp::as<double>(prior["p"]),Rcpp::as<double>(prior["h2"]),settings);
    Rcpp::NumericVector unavailable(marker.size(),NA_REAL);
    out=Rcpp::List::create(Rcpp::Named("mean")=fit.mean,
      Rcpp::Named("variance")=unavailable,Rcpp::Named("pip")=fit.pip,
      Rcpp::Named("diagnostics")=Rcpp::List::create(
        Rcpp::Named("p_path")=fit.p_path,Rcpp::Named("h2_path")=fit.h2_path,
        Rcpp::Named("final_effect")=fit.final_effect),
      Rcpp::Named("provenance")=provenance,
      Rcpp::Named("native_version")=gbayes::version_string());
  } else {
    gbayes::SummaryVariationalControls settings;
    settings.maximum_sweeps_per_window=std::size_t(
      Rcpp::as<double>(control["maximum_iterations"]));
    settings.coordinate_tolerance=Rcpp::as<double>(control["tolerance"]);
    Rcpp::IntegerMatrix windows=control["windows"];
    for(int i=0;i<windows.nrow();++i)
      settings.windows.push_back({std::size_t(windows(i,0)-1),
                                  std::size_t(windows(i,1))});
    if(method=="variational")
      out=variational_result(gbayes::fit_summary_variational(data,
        Rcpp::as<double>(prior["p"]),Rcpp::as<double>(prior["h2"]),settings),
        provenance);
    else {
      gbayes::SummaryGaussianMixturePrior mixture;
      mixture.variances=Rcpp::as<std::vector<double>>(prior["variances"]);
      mixture.weights=Rcpp::as<std::vector<double>>(prior["weights"]);
      out=variational_result(
        gbayes::fit_summary_gaussian_mixture(data,mixture,settings),provenance);
    }
  }
  if(disk) disk->check_unchanged();
  return out;
}

namespace {
Rcpp::NumericMatrix multi_trait_matrix(const std::vector<double>& x,
    const Rcpp::CharacterVector& traits) {
  if(x.empty()) return Rcpp::NumericMatrix(0,0);
  Rcpp::NumericMatrix out(traits.size(),traits.size());
  std::copy(x.begin(),x.end(),out.begin());
  out.attr("dimnames")=Rcpp::List::create(traits,traits);
  return out;
}

Rcpp::NumericMatrix multi_marker_matrix(const std::vector<double>& x,
    const Rcpp::CharacterVector& markers,const Rcpp::CharacterVector& traits) {
  Rcpp::NumericMatrix out(markers.size(),traits.size());
  for(R_xlen_t j=0;j<markers.size();++j)
    for(R_xlen_t t=0;t<traits.size();++t)
      out(j,t)=x[std::size_t(j*traits.size()+t)];
  out.attr("dimnames")=Rcpp::List::create(markers,traits);
  return out;
}

Rcpp::NumericVector multi_labelled(const std::vector<double>& x,
    const Rcpp::CharacterVector& labels) {
  Rcpp::NumericVector out=Rcpp::wrap(x);
  if(!x.empty()) out.names()=labels;
  return out;
}

Rcpp::List multi_parameters(const gbayes::MultivariateParameters& p,
    const Rcpp::CharacterVector& traits,const Rcpp::CharacterVector& patterns,
    const Rcpp::CharacterVector& components) {
  return Rcpp::List::create(
    Rcpp::Named("effect_covariance")=multi_trait_matrix(p.marker_covariance,traits),
    Rcpp::Named("sampling_covariance")=multi_trait_matrix(
      p.sampling_error_covariance,traits),
    Rcpp::Named("pattern_weights")=multi_labelled(p.pattern_weights,patterns),
    Rcpp::Named("component_weights")=multi_labelled(
      p.component_weights,components),
    Rcpp::Named("group_covariance")=R_NilValue);
}

Rcpp::List multi_state(const gbayes::MultivariateChainState& x) {
  Rcpp::List residual(x.working_residual.size());
  for(std::size_t j=0;j<x.working_residual.size();++j)
    residual[j]=x.working_residual[j];
  return Rcpp::List::create(Rcpp::Named("seed")=double(x.seed),
    Rcpp::Named("completed_sweeps")=double(x.completed_sweeps),
    Rcpp::Named("rng_state")=x.rng_state,Rcpp::Named("effects")=x.effects,
    Rcpp::Named("working_residual")=residual,
    Rcpp::Named("completed_base_effect")=x.completed_base_effect,
    Rcpp::Named("patterns")=x.patterns,Rcpp::Named("components")=x.components,
    Rcpp::Named("parameters")=Rcpp::List::create(
      Rcpp::Named("marker_covariance")=x.parameters.marker_covariance,
      Rcpp::Named("pattern_weights")=x.parameters.pattern_weights,
      Rcpp::Named("component_weights")=x.parameters.component_weights,
      Rcpp::Named("group_covariance")=x.parameters.group_covariance,
      Rcpp::Named("sampling_error_covariance")=
        x.parameters.sampling_error_covariance),
    Rcpp::Named("pattern_coefficients")=x.pattern_coefficients,
    Rcpp::Named("component_coefficients")=x.component_coefficients,
    Rcpp::Named("variance_coefficients")=x.variance_coefficients);
}

gbayes::MultivariateChainState multi_state(const Rcpp::List& x) {
  gbayes::MultivariateChainState out;
  out.seed=std::uint32_t(Rcpp::as<double>(x["seed"]));
  out.completed_sweeps=std::size_t(Rcpp::as<double>(x["completed_sweeps"]));
  out.rng_state=Rcpp::as<std::string>(x["rng_state"]);
  out.effects=Rcpp::as<std::vector<double>>(x["effects"]);
  Rcpp::List residual=x["working_residual"];
  for(R_xlen_t j=0;j<residual.size();++j)
    out.working_residual.push_back(
      Rcpp::as<std::vector<double>>(residual[j]));
  out.completed_base_effect=
    Rcpp::as<std::vector<double>>(x["completed_base_effect"]);
  out.patterns=Rcpp::as<std::vector<std::size_t>>(x["patterns"]);
  out.components=Rcpp::as<std::vector<int>>(x["components"]);
  Rcpp::List p=x["parameters"];
  out.parameters.marker_covariance=
    Rcpp::as<std::vector<double>>(p["marker_covariance"]);
  out.parameters.pattern_weights=
    Rcpp::as<std::vector<double>>(p["pattern_weights"]);
  out.parameters.component_weights=
    Rcpp::as<std::vector<double>>(p["component_weights"]);
  out.parameters.group_covariance=
    Rcpp::as<std::vector<double>>(p["group_covariance"]);
  out.parameters.sampling_error_covariance=
    Rcpp::as<std::vector<double>>(p["sampling_error_covariance"]);
  out.pattern_coefficients=
    Rcpp::as<std::vector<double>>(x["pattern_coefficients"]);
  out.component_coefficients=
    Rcpp::as<std::vector<double>>(x["component_coefficients"]);
  out.variance_coefficients=
    Rcpp::as<std::vector<double>>(x["variance_coefficients"]);
  return out;
}

class MultiLdReference {
  std::shared_ptr<gmat::SparseLdDiskReader> reader_;
  std::shared_ptr<gmat::SparseLdCsr> memory_;
  std::vector<std::pair<std::vector<double>,
    std::shared_ptr<const gbayes::CrossProducts>>> cache_;
 public:
  MultiLdReference(const std::string& prefix,const Rcpp::List& control):
    reader_(std::make_shared<gmat::SparseLdDiskReader>(prefix)) {
    if(Rcpp::as<std::string>(control["storage"])=="memory") {
      if(double(reader_->resource().stored_entry_count)>
          Rcpp::as<double>(control["max_ld_entries"]))
        Rcpp::stop("Sparse-LD entries exceed control$max_ld_entries.");
      memory_=std::make_shared<gmat::SparseLdCsr>(
        gmat::load_sparse_ld_csr_from_disk(prefix));
      reader_->check_unchanged();
    }
  }
  void check(const Rcpp::DataFrame& stat) const {
    const auto ids=Rcpp::as<std::vector<std::string>>(stat["marker"]);
    const auto& resource=reader_->resource();
    if(ids.size()!=resource.marker_count)
      Rcpp::stop("Statistics and sparse-LD dimensions differ.");
    for(std::size_t j=0;j<ids.size();++j)
      if(ids[j]!=resource.markers[j].marker_id)
        Rcpp::stop("Statistics must match sparse-LD marker order exactly.");
  }
  std::shared_ptr<const gbayes::CrossProducts> products(
      const std::vector<double>& n) {
    for(const auto& entry:cache_) if(entry.first==n) return entry.second;
    auto value=memory_ ? gbayes::ld_cross_products(memory_,n) :
      gbayes::disk_ld_cross_products(reader_,n);
    cache_.push_back({n,value});
    return value;
  }
  void check_unchanged() const {reader_->check_unchanged();}
};

gbayes::MultivariatePrior multi_prior(const Rcpp::List& prior) {
  gbayes::MultivariatePrior out;
  out.marker_covariance=
    Rcpp::as<std::vector<double>>(prior["effect_covariance"]);
  Rcpp::IntegerMatrix patterns=prior["patterns"];
  for(int k=0;k<patterns.nrow();++k) {
    gbayes::TraitPattern pattern;
    for(int t=0;t<patterns.ncol();++t) pattern.push_back(patterns(k,t));
    out.patterns.push_back(std::move(pattern));
  }
  out.pattern_weights=Rcpp::as<std::vector<double>>(prior["pattern_weights"]);
  out.component_scales=Rcpp::as<std::vector<double>>(prior["component_scales"]);
  out.component_weights=
    Rcpp::as<std::vector<double>>(prior["component_weights"]);
  return out;
}

std::shared_ptr<const gbayes::ProbitStickPrior> multi_probit_annotation(
    const Rcpp::List& annotation,const char* role) {
  if(!annotation.containsElementNamed(role)) return {};
  Rcpp::List x=annotation[role];
  auto out=std::make_shared<gbayes::ProbitStickPrior>();
  annotation_common(*out,x);
  out->intercept_prior_sd=Rcpp::as<double>(x["intercept_prior_sd"]);
  if(!Rf_isNull(x["intercept_means"]))
    out->intercept_means=
      Rcpp::as<std::vector<double>>(x["intercept_means"]);
  return out;
}

gbayes::MultivariatePrior multi_prior(const Rcpp::List& prior,
    const Rcpp::List& annotation) {
  auto out=multi_prior(prior);
  out.pattern_annotation=multi_probit_annotation(annotation,"pattern");
  out.component_annotation=multi_probit_annotation(annotation,"component");
  out.variance_annotation=variance_annotation(annotation);
  return out;
}

gbayes::MultivariateLearning multi_learning(const Rcpp::List& prior,
    const Rcpp::List& control,const Rcpp::List& sampling,bool bed) {
  gbayes::MultivariateLearning out;
  out.marker_covariance=Rcpp::as<bool>(control["estimate_covariance"]);
  out.pattern_weights=Rcpp::as<bool>(control["estimate_pattern_weights"]);
  out.component_weights=Rcpp::as<bool>(control["estimate_component_weights"]);
  out.sampling_error_covariance=
    Rcpp::as<bool>(control["estimate_sampling_covariance"]);
  if(out.marker_covariance) {
    Rcpp::List p=prior["covariance_prior"];
    out.covariance_prior_df=Rcpp::as<double>(p["df"]);
    out.covariance_prior_scale=
      Rcpp::as<std::vector<double>>(p["scale"]);
  }
  if(out.pattern_weights)
    out.pattern_prior_counts=
      Rcpp::as<std::vector<double>>(prior["pattern_prior"]);
  if(out.component_weights)
    out.component_prior_counts=
      Rcpp::as<std::vector<double>>(prior["component_prior"]);
  if(out.sampling_error_covariance) {
    Rcpp::List p=prior[bed ? "residual_covariance_prior" :
      "sampling_covariance_prior"];
    out.sampling_error_prior={Rcpp::as<double>(p["df"]),
      Rcpp::as<std::vector<double>>(p["scale"])};
    if(!bed) {
      out.response_crossproduct=
        Rcpp::as<std::vector<double>>(sampling["response_crossproduct"]);
      out.sampling_likelihood_dimension=
        Rcpp::as<double>(sampling["likelihood_dimension"]);
    }
  }
  return out;
}

gbayes::MultivariateControls multi_controls(const Rcpp::List& control) {
  gbayes::MultivariateControls out;
  out.chains=chain_controls(control);
  out.memory_limit_bytes=
    std::size_t(Rcpp::as<double>(control["memory_limit_bytes"]));
  if(control.containsElementNamed("multivariate_initial_states") &&
      !Rf_isNull(control["multivariate_initial_states"])) {
    Rcpp::List states=control["multivariate_initial_states"];
    for(R_xlen_t i=0;i<states.size();++i)
      out.initial_states.push_back(multi_state(Rcpp::as<Rcpp::List>(states[i])));
  }
  return out;
}

Rcpp::List multi_result(const gbayes::MultivariateResult& fit,
    const Rcpp::CharacterVector& markers,const Rcpp::CharacterVector& traits,
    const Rcpp::CharacterVector& pattern_names,
    const Rcpp::CharacterVector& component_names,double probability,
    std::size_t memory_limit,const Rcpp::List& annotation) {
  using Q=gbayes::PosteriorQuantity;
  std::vector<gbayes::PosteriorSelection> selections;
  for(R_xlen_t j=0;j<traits.size();++j)
    for(R_xlen_t i=0;i<=j;++i)
      selections.push_back({"effect_covariance["+
        Rcpp::as<std::string>(traits[i])+","+
        Rcpp::as<std::string>(traits[j])+"]",Q::latent_covariance,
        std::size_t(i+j*traits.size())});
  if(!fit.sampling_error_covariance.empty())
    for(R_xlen_t j=0;j<traits.size();++j)
      for(R_xlen_t i=0;i<=j;++i)
        selections.push_back({"sampling_covariance["+
          Rcpp::as<std::string>(traits[i])+","+
          Rcpp::as<std::string>(traits[j])+"]",
          Q::sampling_error_covariance,std::size_t(i+j*traits.size())});
  for(std::size_t k=0;k<fit.parameter_mean.pattern_weights.size();++k)
    selections.push_back({"pattern_weight["+
      Rcpp::as<std::string>(pattern_names[R_xlen_t(k)])+"]",
      Q::pattern_weight,k});
  for(std::size_t k=0;k<fit.parameter_mean.component_weights.size();++k)
    selections.push_back({"component_weight["+
      Rcpp::as<std::string>(component_names[R_xlen_t(k)])+"]",
      Q::component_weight,k});
  gbayes::PosteriorSummaryControls settings;
  settings.probability=probability;settings.memory_limit_bytes=memory_limit;
  Rcpp::DataFrame summaries=posterior_rows(
    gbayes::summarize_posterior(fit,selections,settings));
  Rcpp::CharacterVector trace_names;
  for(const auto& s:selections) trace_names.push_back(s.label);
  Rcpp::List chains(fit.chains.size()),states(fit.chains.size());
  for(std::size_t k=0;k<fit.chains.size();++k) {
    const auto& chain=fit.chains[k];
    Rcpp::NumericMatrix trace(chain.trace.size(),selections.size());
    Rcpp::colnames(trace)=trace_names;
    for(std::size_t r=0;r<chain.trace.size();++r)
      for(std::size_t j=0;j<selections.size();++j) {
        const auto& s=selections[j];const auto& z=chain.trace[r];
        trace(r,j)=(s.quantity==Q::latent_covariance ? z.marker_covariance :
          s.quantity==Q::sampling_error_covariance ?
            z.sampling_error_covariance :
          s.quantity==Q::pattern_weight ? z.pattern_weights :
            z.component_weights)[s.index];
      }
    chains[k]=Rcpp::List::create(Rcpp::Named("seed")=double(chain.seed),
      Rcpp::Named("retained_draws")=double(chain.retained_draws),
      Rcpp::Named("mean")=multi_marker_matrix(chain.mean,markers,traits),
      Rcpp::Named("pip")=multi_marker_matrix(chain.pip,markers,traits),
      Rcpp::Named("parameter_mean")=multi_parameters(chain.parameter_mean,
        traits,pattern_names,component_names),Rcpp::Named("trace")=trace,
      Rcpp::Named("maximum_residual_drift")=
        chain.maximum_working_residual_drift);
    states[k]=multi_state(chain.continuation_state);
  }
  const auto agreement=gbayes::summarize_chains(fit);
  std::vector<double> ranges(fit.pip.size());
  for(std::size_t j=0;j<ranges.size();++j)
    ranges[j]=agreement.multiple_chains ?
      agreement.pip[j].maximum-agreement.pip[j].minimum : NA_REAL;
  Rcpp::List out=Rcpp::List::create(
    Rcpp::Named("mean")=multi_marker_matrix(fit.mean,markers,traits),
    Rcpp::Named("variance")=multi_marker_matrix(fit.variance,markers,traits),
    Rcpp::Named("pip")=multi_marker_matrix(fit.pip,markers,traits),
    Rcpp::Named("any_pip")=multi_labelled(fit.any_pip,markers),
    Rcpp::Named("chain_pip_range")=
      multi_marker_matrix(ranges,markers,traits),
    Rcpp::Named("parameter_mean")=multi_parameters(fit.parameter_mean,
      traits,pattern_names,component_names),
    Rcpp::Named("sampling_covariance")=
      multi_trait_matrix(fit.sampling_error_covariance,traits),
    Rcpp::Named("posterior")=summaries,Rcpp::Named("chains")=chains,
    Rcpp::Named("continuation_states")=states,
    Rcpp::Named("threads_used")=fit.threads_used,
    Rcpp::Named("estimated_native_memory_bytes")=
      double(fit.estimated_memory_bytes),
    Rcpp::Named("expected_pattern_count")=
      multi_labelled(fit.expected_pattern_count,pattern_names),
    Rcpp::Named("expected_component_count")=
      multi_labelled(fit.expected_component_count,component_names),
    Rcpp::Named("expected_trait_sharing")=
      multi_trait_matrix(fit.expected_trait_sharing,traits),
    Rcpp::Named("native_version")=gbayes::version_string());
  if(annotation.size()==0) {
    out["annotations"]=Rcpp::List();
    out["annotation_posterior"]=Rcpp::DataFrame::create();
    return out;
  }
  Rcpp::List annotation_results;std::vector<gbayes::PosteriorSelection> selected;
  Rcpp::CharacterVector roles=annotation.names();
  for(R_xlen_t i=0;i<annotation.size();++i) {
    const std::string role=Rcpp::as<std::string>(roles[i]);
    Rcpp::List spec=annotation[i];
    Rcpp::CharacterVector labels=spec["coefficient_names"],
      categories=spec["categories"];
    const auto& summary=role=="pattern" ? fit.pattern_annotation :
      role=="component" ? fit.component_annotation : fit.variance_annotation;
    const auto quantity=role=="pattern" ?
      gbayes::PosteriorQuantity::pattern_coefficient :
      role=="component" ? gbayes::PosteriorQuantity::component_coefficient :
      gbayes::PosteriorQuantity::variance_coefficient;
    for(R_xlen_t j=0;j<labels.size();++j)
      selected.push_back({role+"["+Rcpp::as<std::string>(labels[j])+"]",
        quantity,std::size_t(j)});
    Rcpp::List chain_results(fit.chains.size());
    for(std::size_t k=0;k<fit.chains.size();++k) {
      const auto& chain=role=="pattern" ? fit.chains[k].pattern_annotation :
        role=="component" ? fit.chains[k].component_annotation :
        fit.chains[k].variance_annotation;
      Rcpp::NumericMatrix trace(chain.coefficient_trace.size(),labels.size());
      Rcpp::colnames(trace)=labels;
      for(std::size_t r=0;r<chain.coefficient_trace.size();++r)
        for(R_xlen_t j=0;j<labels.size();++j)
          trace(r,j)=chain.coefficient_trace[r][std::size_t(j)];
      chain_results[R_xlen_t(k)]=Rcpp::List::create(
        Rcpp::Named("coefficient_mean")=chain.coefficient_mean,
        Rcpp::Named("final_coefficients")=chain.final_coefficients,
        Rcpp::Named("trace")=trace,Rcpp::Named("updates")=double(chain.updates),
        Rcpp::Named("accepted")=double(chain.accepted),
        Rcpp::Named("proposed")=double(chain.proposed));
    }
    Rcpp::NumericMatrix probabilities;
    if(!summary.prior_probability_mean.empty()) {
      probabilities=Rcpp::NumericMatrix(markers.size(),categories.size());
      probabilities.attr("dimnames")=Rcpp::List::create(markers,categories);
      for(R_xlen_t j=0;j<markers.size();++j)
        for(R_xlen_t k=0;k<categories.size();++k)
          probabilities(j,k)=summary.prior_probability_mean[
            std::size_t(j*categories.size()+k)];
    }
    annotation_results[role]=Rcpp::List::create(
      Rcpp::Named("coefficient_names")=labels,
      Rcpp::Named("coefficient_mean")=summary.coefficient_mean,
      Rcpp::Named("coefficient_variance")=summary.coefficient_variance,
      Rcpp::Named("prior_probability_mean")=probabilities,
      Rcpp::Named("multiplier_mean")=summary.multiplier_mean,
      Rcpp::Named("chains")=chain_results);
  }
  out["annotations"]=annotation_results;
  out["annotation_posterior"]=posterior_rows(
    gbayes::summarize_posterior(fit,selected,settings));
  return out;
}
}

// [[Rcpp::export]]
Rcpp::IntegerMatrix cpp_gbayes_patterns(Rcpp::CharacterVector traits) {
  const auto patterns=gbayes::complete_trait_patterns(traits.size());
  Rcpp::IntegerMatrix out(patterns.size(),traits.size());
  Rcpp::CharacterVector labels(patterns.size());
  for(std::size_t k=0;k<patterns.size();++k) {
    std::string label;
    for(R_xlen_t t=0;t<traits.size();++t) {
      out(k,t)=patterns[k][std::size_t(t)];
      label+=patterns[k][std::size_t(t)] ? '1' : '0';
    }
    labels[R_xlen_t(k)]=label;
  }
  out.attr("dimnames")=Rcpp::List::create(labels,traits);
  return out;
}

// [[Rcpp::export]]
Rcpp::List cpp_gbayes_multivariate(Rcpp::CharacterVector prefixes,
    Rcpp::List stat,Rcpp::CharacterVector traits,
    Rcpp::CharacterVector study_traits,Rcpp::DataFrame marker_metadata,
    Rcpp::List prior,Rcpp::List control,Rcpp::List sampling,
    Rcpp::List annotation,Rcpp::List posterior_control) {
  using namespace Rcpp;
  CharacterVector studies=stat.names(),markers=marker_metadata["marker_id"];
  std::map<std::string,std::shared_ptr<MultiLdReference>> references;
  std::vector<gbayes::SummaryGaussianProvider> providers;
  const auto residual=as<std::vector<double>>(sampling["residual_variance"]);
  const auto study_n=as<std::vector<double>>(sampling["study_sample_size"]);
  for(R_xlen_t i=0;i<stat.size();++i) {
    DataFrame s=stat[i];const auto prefix=as<std::string>(prefixes[i]);
    auto& reference=references[prefix];
    if(!reference) reference=std::make_shared<MultiLdReference>(prefix,control);
    reference->check(s);
    gbayes::SummaryGaussianProvider provider;
    provider.id=as<std::string>(studies[i]);
    provider.trait=as<std::string>(study_traits[i]);
    provider.marker_ids=as<std::vector<std::string>>(s["marker"]);
    provider.effective_sample_sizes=as<std::vector<double>>(s["n"]);
    provider.standardized_marginal_effects=
      as<std::vector<double>>(s["beta_std"]);
    provider.cross_products=reference->products(provider.effective_sample_sizes);
    provider.convention=as<std::string>(control["sample_size"])=="common" ?
      gbayes::SummaryGaussianConvention::common_n :
      gbayes::SummaryGaussianConvention::variable_n;
    provider.residual_variance=residual[std::size_t(i)];
    provider.study_sample_size=study_n[std::size_t(i)];
    provider.provenance="standalone gbayes aligned checked summaries";
    providers.push_back(std::move(provider));
  }
  const auto dependence=as<std::string>(sampling["dependence"]);
  auto prepared=gbayes::prepare_multivariate_summary_gaussian(
    as<std::vector<std::string>>(markers),as<std::vector<std::string>>(traits),
    providers,dependence=="independent" ?
      gbayes::SummaryDependence::independent :
      gbayes::SummaryDependence::shared_ld,
    dependence=="independent" ? std::vector<double>{} :
      as<std::vector<double>>(sampling["covariance"]));
  auto settings=multi_controls(control);
  PosteriorCapture capture(posterior_control,control);
  settings.genetic_reference=capture.controls.genetic_reference;
  settings.partition=capture.controls.partition;
  settings.prediction=capture.controls.prediction;
  auto fit=gbayes::fit_multivariate_mixture(prepared,
    multi_prior(prior,annotation),
    settings,multi_learning(prior,control,sampling,false));
  for(const auto& value:references) value.second->check_unchanged();
  CharacterVector pattern_names=rownames(as<IntegerMatrix>(prior["patterns"]));
  CharacterVector component_names=prior["component_names"];
  auto out=multi_result(fit,markers,traits,pattern_names,component_names,
    as<double>(control["probability"]),settings.memory_limit_bytes,annotation);
  add_quantities(out,fit,posterior_control,traits,as<double>(control["probability"]));
  capture.check_unchanged();
  List metadata(fit.providers.size());metadata.attr("names")=studies;
  for(std::size_t i=0;i<fit.providers.size();++i) {
    const auto& provider=fit.providers[i];IntegerVector map(provider.local_to_global.size());
    for(std::size_t j=0;j<provider.local_to_global.size();++j)
      map[R_xlen_t(j)]=int(provider.local_to_global[j]+1);
    metadata[R_xlen_t(i)]=List::create(
      Named("trait")=as<std::string>(traits[R_xlen_t(provider.trait)]),
      Named("study_sample_size")=provider.sample_size,
      Named("residual_variance")=provider.residual_variance,
      Named("local_to_global")=map,Named("effect_units")=provider.effect_units,
      Named("preparation")=provider.provenance);
  }
  out["studies"]=metadata;
  return out;
}

// [[Rcpp::export]]
Rcpp::List cpp_gbayes_bed_multivariate(double physical_sample_count,
    std::vector<double> sample_indices,std::vector<std::string> paths,
    std::vector<double> physical_marker_count,Rcpp::List marker_indices,
    Rcpp::List phenotypes,std::vector<std::string> marker,
    std::vector<double> allele_frequency,Rcpp::CharacterVector traits,
    Rcpp::List prior,Rcpp::List control,Rcpp::List annotation,
    Rcpp::List posterior_control) {
  gbayes::IndividualBedInput input;
  input.physical_sample_count=std::uint64_t(physical_sample_count);
  for(double value:sample_indices)
    input.sample_indices.push_back(std::uint64_t(value));
  for(std::size_t i=0;i<paths.size();++i) {
    gbayes::IndividualBedFile file;file.path=paths[i];
    file.physical_marker_count=std::uint64_t(physical_marker_count[i]);
    for(double value:Rcpp::as<std::vector<double>>(marker_indices[R_xlen_t(i)]))
      file.marker_indices.push_back(std::uint64_t(value));
    input.files.push_back(std::move(file));
  }
  input.phenotype=Rcpp::as<std::vector<double>>(phenotypes[0]);
  input.marker_ids=marker;input.allele_frequency=allele_frequency;
  input.trait=Rcpp::as<std::string>(traits[0]);input.standardize=true;
  input.likelihood_dimension=Rcpp::as<double>(control["likelihood_dimension"]);
  input.packed_memory_limit_bytes=
    std::size_t(Rcpp::as<double>(control["packed_memory_limit_bytes"]));
  std::vector<std::vector<double>> additional;
  for(R_xlen_t i=1;i<phenotypes.size();++i)
    additional.push_back(Rcpp::as<std::vector<double>>(phenotypes[i]));
  auto prepared=gbayes::prepare_individual_bed_multivariate(input,additional,
    Rcpp::as<std::vector<std::string>>(traits),
    Rcpp::as<std::vector<double>>(prior["residual_covariance"]));
  auto settings=multi_controls(control);Rcpp::List sampling;
  PosteriorCapture capture(posterior_control,control);
  settings.genetic_reference=capture.controls.genetic_reference;
  settings.partition=capture.controls.partition;
  settings.prediction=capture.controls.prediction;
  auto fit=gbayes::fit_multivariate_mixture(prepared.statistics,
    multi_prior(prior,annotation),settings,
    multi_learning(prior,control,sampling,true));
  Rcpp::CharacterVector markers=Rcpp::wrap(fit.marker_ids);
  Rcpp::CharacterVector pattern_names=
    Rcpp::rownames(Rcpp::as<Rcpp::IntegerMatrix>(prior["patterns"]));
  Rcpp::CharacterVector component_names=prior["component_names"];
  auto out=multi_result(fit,markers,traits,pattern_names,component_names,
    Rcpp::as<double>(control["probability"]),settings.memory_limit_bytes,
    annotation);
  add_quantities(out,fit,posterior_control,traits,
    Rcpp::as<double>(control["probability"]));
  capture.check_unchanged();
  const std::size_t selected_samples=input.sample_indices.empty() ?
    std::size_t(input.physical_sample_count) : input.sample_indices.size();
  std::vector<double> centers(allele_frequency.size()),
    scales(allele_frequency.size());
  for(std::size_t j=0;j<allele_frequency.size();++j) {
    centers[j]=2.0*allele_frequency[j];
    scales[j]=std::sqrt(2.0*allele_frequency[j]*(1.0-allele_frequency[j]));
  }
  out["coding"]=Rcpp::List::create(
    Rcpp::Named("allele_frequency")=allele_frequency,
    Rcpp::Named("centers")=centers,Rcpp::Named("scales")=scales,
    Rcpp::Named("sample_count")=double(selected_samples),
    Rcpp::Named("standardized")=true);
  out["sample_count"]=double(selected_samples);
  out["individual_bed"]=Rcpp::List::create(
    Rcpp::Named("available")=fit.individual_bed.available,
    Rcpp::Named("final_covg")=multi_trait_matrix(
      fit.individual_bed.final_covg,traits),
    Rcpp::Named("mean_covg")=multi_trait_matrix(
      fit.individual_bed.mean_covg,traits),
    Rcpp::Named("mean_vle")=fit.individual_bed.mean_vle,
    Rcpp::Named("mean_vld")=fit.individual_bed.mean_vld);
  return out;
}
