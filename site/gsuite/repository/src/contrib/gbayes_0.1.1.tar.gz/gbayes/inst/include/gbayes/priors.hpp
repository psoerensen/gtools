#pragma once
#include "gbayes/export.h"
#include <random>
#include <vector>
namespace gbayes {
// v = df * scale / chi_square(df); scale is not the prior mean.
struct ScaledInverseChiSquare { double df{4}, scale{1}; };
struct VarianceConditional { double df{}, sum_squares{}; };
GBAYES_EXPORT VarianceConditional variance_conditional(
    const ScaledInverseChiSquare&, double observation_df, double sum_squares);
GBAYES_EXPORT double draw_variance(const VarianceConditional&, std::mt19937&);
GBAYES_EXPORT std::vector<double> draw_mixture_weights(
    const std::vector<double>& prior_counts, const std::vector<double>& counts,
    std::mt19937&);
// Full Gaussian normalization, on exactly the scale of C and score.
// For residualized data, dimension is the residual likelihood dimension.
enum class GaussianSpace { full, retained };
struct GaussianNormalization {
  double phenotype_sum_squares{}, likelihood_dimension{};
  GaussianSpace space{GaussianSpace::full};
};
enum class BlockResidualMode { fixed, sample, mix, all_mix };
struct BlockResidualLearning {
  // Exhaustive zero-based block assignment in marker order.
  std::vector<std::size_t> marker_block;
  // One entry per block. initial_variance is also the phenotype-variance
  // fallback used by GCTB-style mix policies.
  std::vector<GaussianNormalization> normalization;
  std::vector<ScaledInverseChiSquare> prior;
  std::vector<double> initial_variance;
  std::vector<double> genetic_variance_denominator;
  BlockResidualMode mode{BlockResidualMode::sample};
  double resample_threshold{1.1}, minimum_variance_ratio{0.7};
};
enum class ResidualPolicy { exact_in_sample, reference_ld_adjusted };
struct GaussianLearning {
  bool slab_variance{false}, residual_variance{false}, mixture_weights{false};
  ScaledInverseChiSquare slab_prior{}, residual_prior{};
  std::vector<double> weight_prior; // null first; required only when learning weights
  GaussianNormalization normalization{}; // required only when learning residual variance
  ResidualPolicy residual_policy{ResidualPolicy::exact_in_sample};
  double residual_adjustment{}; // reference policy: working ve = ve + adjustment * vg
  double genetic_variance_denominator{}; // reference policy: vg = b'Cb / denominator
  // Optional disjoint-block likelihood. Excludes the global residual update.
  // Empty marker_block preserves the ordinary scalar policy.
  BlockResidualLearning block_residual;
};
struct GaussianParameters {
  double residual_variance{}, slab_variance{};
  // Empty when fixed marker-specific probabilities replace the global parameter.
  std::vector<double> weights;
};
}
