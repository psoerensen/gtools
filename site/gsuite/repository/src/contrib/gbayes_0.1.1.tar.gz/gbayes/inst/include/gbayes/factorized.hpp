#pragma once
#include "gbayes/bayesc.hpp"
namespace gbayes {
enum class Factorization { exact, truncated };
// C=F'F. F is rank-by-markers column-major; no dense C is stored.
class GBAYES_EXPORT FactorizedCrossProducts final : public CrossProducts {
  std::size_t rank_, markers_;
  std::vector<double> factor_, diagonal_;
  Factorization kind_;
 public:
  FactorizedCrossProducts(std::size_t rank,std::size_t markers,
      std::vector<double> factor,Factorization kind);
  std::size_t size() const noexcept override {return markers_;}
  bool concurrent_reads() const noexcept override {return true;}
  std::size_t rank() const noexcept {return rank_;}
  bool truncated() const noexcept override {return kind_==Factorization::truncated;}
  double diagonal(std::size_t j) const override;
  double entry(std::size_t row,std::size_t marker) const;
  std::vector<double> forward(const std::vector<double>& effects) const;
  std::vector<double> transpose(const std::vector<double>& coordinates) const;
  void add_column(std::size_t j,double scale,std::vector<double>& target) const override;
  std::vector<double> multiply(const std::vector<double>& x) const override;
  std::unique_ptr<GaussianResidual> make_residual(const std::vector<double>& score,
      const std::vector<double>& response_coordinates) const override;
  void validate_normalization(const GaussianNormalization&,
      const std::vector<double>& response_coordinates) const override;
};

// Block-diagonal factor representation. Each block stores only its retained
// coordinates; no genome-wide dense factor or cross-block zeros are allocated.
class GBAYES_EXPORT BlockFactorizedCrossProducts final : public CrossProducts {
  std::vector<std::size_t> offsets_, rank_offsets_;
  std::vector<std::shared_ptr<const FactorizedCrossProducts>> blocks_;
  bool truncated_{};
 public:
  BlockFactorizedCrossProducts(std::vector<std::size_t> offsets,
      std::vector<std::shared_ptr<const FactorizedCrossProducts>> blocks);
  std::size_t size() const noexcept override {return offsets_.back();}
  std::size_t rank() const noexcept {return rank_offsets_.back();}
  std::size_t block_count() const noexcept {return blocks_.size();}
  const std::vector<std::size_t>& offsets() const noexcept {return offsets_;}
  bool concurrent_reads() const noexcept override {return true;}
  bool truncated() const noexcept override {return truncated_;}
  double diagonal(std::size_t j) const override;
  double coordinate_dot(std::size_t j,const std::vector<double>& coordinates) const;
  void update_coordinates(std::size_t j,double difference,
      std::vector<double>& coordinates) const;
  std::vector<double> forward(const std::vector<double>& effects) const;
  std::vector<double> transpose(const std::vector<double>& coordinates) const;
  void add_column(std::size_t j,double scale,std::vector<double>& target) const override;
  std::vector<double> multiply(const std::vector<double>& x) const override;
  std::unique_ptr<GaussianResidual> make_residual(const std::vector<double>& score,
      const std::vector<double>& response_coordinates) const override;
  void validate_normalization(const GaussianNormalization&,
      const std::vector<double>& response_coordinates) const override;
};
// Prepared LD eigenpairs R=U diag(lambda) U', with r retained columns of U.
// Produces F_kj=sqrt(lambda_k)*U_jk*sqrt(marker_ss_j). No eigensolver/file I/O.
GBAYES_EXPORT std::shared_ptr<const FactorizedCrossProducts> eigen_cross_products(
    const std::vector<double>& eigenvalues,const std::vector<double>& eigenvectors,
    const std::vector<double>& marker_ss,Factorization kind);
// z_k = sum_j U_jk * score_j/sqrt(marker_ss_j) / sqrt(lambda_k).
// Caller sets data.score = factor->transpose(z), explicitly projecting discarded directions.
GBAYES_EXPORT std::vector<double> eigen_response(const std::vector<double>& eigenvalues,
    const std::vector<double>& eigenvectors,const std::vector<double>& marker_ss,
    const std::vector<double>& score);
}
