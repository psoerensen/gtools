#pragma once
#include "gbayes/bayesc.hpp"
#include <gsolve/pcg.hpp>
namespace gbayes {
struct GaussianRidgeResult {
  std::vector<double> effects, deviation;
  double lambda{}, normal_equation_residual{}, convergence_threshold{};
  gsolve::PcgResult solver;
};
// Minimize .5||y-Xb||² + .5*lambda||b-mean||², with exact unnormalized
// local C=X'X and score=X'y. Empty mean means zero. No implicit intercept,
// residual-variance scaling, posterior intervals or hyperparameter fitting.
// Uses existing gsolve PCG; throws on invalid input or nonconvergence.
GBAYES_EXPORT GaussianRidgeResult fit_gaussian_ridge(
    const FixedGaussianStatistics&,const std::vector<double>& mean,double lambda,
    const gsolve::PcgOptions& = {});
}
