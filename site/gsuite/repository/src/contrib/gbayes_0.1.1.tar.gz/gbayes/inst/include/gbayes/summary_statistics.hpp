#pragma once
#include "gbayes/bayesc.hpp"
#include <limits>

namespace gmat { class SparseLdBlockProvider; }
namespace gbayes {
// Both conventions describe a reference-LD Gaussian pseudo-likelihood, not
// exact individual-data sufficient statistics. Effects must already be on the
// standardized phenotype / standardized allele-dosage scale.
enum class SummaryGaussianConvention { common_n, variable_n };

// cross_products represents C = sqrt(N) R sqrt(N), in marker order; diag(C)=N.
// effective_sample_sizes has one finite positive value per marker. common_n
// requires all values equal. Marker/allele alignment is the caller's job.
// Returns score_j=N_j*effect_j with fixed scale and explicit provenance.
// Supplies no y'y or likelihood dimension and does not enable residual learning.
// No PSD repair, retained-factor projection, or genotype access is performed.
GBAYES_EXPORT FixedGaussianStatistics prepare_summary_gaussian(
    std::shared_ptr<const CrossProducts> cross_products,
    const std::vector<double>& standardized_marginal_effects,
    const std::vector<double>& effective_sample_sizes,
    const std::vector<std::string>& marker_ids, const std::string& trait,
    SummaryGaussianConvention convention);

struct BlockEigenPreparationControls {
  double retained_positive_mass{0.995};
  std::size_t maximum_block_dimension{2048};
  double symmetry_tolerance{64.0 * std::numeric_limits<double>::epsilon()};
  double verification_tolerance{1.e-10};
};

struct PreparedBlockEigen {
  std::size_t begin{}, end{};
  std::vector<double> eigenvalues;   // descending retained positive values
  std::vector<double> eigenvectors;  // block_dimension-by-rank, column-major
  double total_positive_mass{}, retained_positive_mass{};
  double minimum_eigenvalue{};
  double relative_reconstruction_error{};
};

struct BlockEigenPreparationDiagnostics {
  std::size_t blocks{}, eigensystem_decompositions{}, total_markers{};
  std::size_t retained_rank{}, peak_block_markers{}, largest_dense_block_bytes{};
  std::size_t retained_eigen_bytes{}, block_loads{}, block_cache_hits{};
  double maximum_discarded_positive_mass{};
  double minimum_eigenvalue{};
};

// Immutable retained block eigensystems. One preparation can be rebound to
// several traits; no sparse-LD read or eigendecomposition occurs during bind.
struct PreparedBlockEigensystems {
  std::vector<std::string> marker_ids;
  std::vector<std::size_t> offsets;
  std::vector<PreparedBlockEigen> blocks;
  BlockEigenPreparationDiagnostics diagnostics;
};

struct BoundBlockSummary {
  FixedGaussianStatistics statistics;
  double maximum_score_projection_change{};
  double relative_score_projection_change{};
};

GBAYES_EXPORT PreparedBlockEigensystems prepare_block_eigensystems(
    gmat::SparseLdBlockProvider& provider,
    const BlockEigenPreparationControls& controls = {});

GBAYES_EXPORT BoundBlockSummary bind_block_summary_gaussian(
    const PreparedBlockEigensystems& prepared,
    const std::vector<double>& standardized_marginal_effects,
    const std::vector<double>& effective_sample_sizes,
    const std::string& trait, SummaryGaussianConvention convention);
}  // namespace gbayes
