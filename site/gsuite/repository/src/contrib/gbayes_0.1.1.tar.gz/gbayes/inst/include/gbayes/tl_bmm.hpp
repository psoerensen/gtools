#pragma once
#include "gbayes/bayesc.hpp"
#include "gbayes/annotation.hpp"
#include <cstdint>
#include <memory>
#include <vector>

namespace gbayes {
// Every component is continuous. Marker-major means: means[j*K+k].
// Component zero is normally the local, zero-centred shrinkage component.
struct TLBmmPrior {
  std::vector<double> means, variances, weights;
  std::vector<double> weight_counts;
  std::vector<ScaledInverseChiSquare> variance_priors;
  double residual_variance{1};
  ScaledInverseChiSquare residual_prior{};
  GaussianNormalization normalization{};
  bool learn_weights{true}, learn_variances{true}, learn_residual{false};
  // Optional continuation-probit component probabilities. When present,
  // weights set the intercept-prior reference, not a sampled global simplex.
  std::shared_ptr<const ProbitStickPrior> component_annotation;
  // Shared, centred log-variance design; independent of membership annotations.
  std::shared_ptr<const LogVariancePrior> variance_annotation;
};
enum class TLBmmMembershipUpdate { augmented_probit, allocation_marginal_elliptical, automatic };
enum class TLBmmScaleUpdate { conjugate, allocation_marginal_slice };
// Optional pre-scale diagnostic snapshots; no random numbers are consumed.
struct TLBmmScaleState {
  std::size_t sweep{}; // one-based, including burn-in
  std::vector<double> effects,multipliers;
  std::vector<std::size_t> allocation;
};
struct TLBmmControls {
  std::size_t burnin{100}, sampling_sweeps{1000}, thinning{1};
  std::vector<std::uint32_t> chain_seeds{1};
  // Optional retained allocation snapshots for bounded sampler diagnostics.
  bool record_allocation_trace{false};
  // New learned-membership fits use the allocation-marginal block. Explicit
  // augmented_probit preserves the original route; global weights are unchanged.
  TLBmmMembershipUpdate membership_update{TLBmmMembershipUpdate::automatic};
  TLBmmScaleUpdate scale_update{TLBmmScaleUpdate::conjugate};
  std::vector<std::size_t> scale_state_sweeps;
  bool record_first_low_occupancy_scale_state{false};
};
// Resolve before persistence so defaults never silently change a saved fit.
GBAYES_EXPORT TLBmmMembershipUpdate resolve_tl_bmm_membership_update(
    const TLBmmPrior&,const TLBmmControls&);
struct TLBmmConditional {
  std::vector<double> probability, mean, variance;
};
// h=Cjj/Ve and t=(Xj'(y-X_-j beta_-j))/Ve.
GBAYES_EXPORT TLBmmConditional tl_bmm_conditional(double h,double t,
    const double* means,const std::vector<double>& variances,
    const std::vector<double>& weights);
struct TLBmmChain {
  std::uint32_t seed{};
  std::size_t retained_draws{};
  std::vector<double> effect_mean,effect_second,allocation_probability;
  std::vector<double> weight_mean,variance_mean;
  double residual_mean{};
  std::vector<std::vector<double>> weight_trace,variance_trace;
  std::vector<std::vector<std::size_t>> allocation_trace;
  std::vector<double> residual_trace;
  AnnotationChain component_annotation;
  AnnotationChain variance_annotation;
  std::vector<TLBmmScaleState> scale_states;
};
struct TLBmmResult {
  std::vector<std::string> marker_ids;
  std::string trait,effect_units,provenance;
  std::size_t components{};
  std::vector<double> effect_mean,effect_variance,allocation_probability;
  std::vector<double> weight_mean,variance_mean;
  double residual_mean{};
  std::vector<TLBmmChain> chains;
  AnnotationSummary component_annotation;
  AnnotationSummary variance_annotation;
  bool annotated_component_probabilities{};
  bool truncated_likelihood{};
  // Actual transition/policy, not "automatic": allocation_marginal_elliptical,
  // augmented_probit, fixed_probit, global_dirichlet or fixed_weights.
  std::string membership_sampler;
  std::string scale_sampler;
};
GBAYES_EXPORT TLBmmResult fit_tl_bmm(const FixedGaussianStatistics&,
    const TLBmmPrior&,const TLBmmControls& = {});
}
