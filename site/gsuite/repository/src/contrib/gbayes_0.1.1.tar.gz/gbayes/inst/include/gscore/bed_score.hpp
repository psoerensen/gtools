#ifndef GSCORE_BED_SCORE_HPP
#define GSCORE_BED_SCORE_HPP

#include <cstdint>
#include <string>
#include <vector>

#include "gscore/export.h"

namespace gscore {

enum class GenotypeCoding {
  standardized,
  raw_mean_imputed
};

struct BedScoreRequest {
  std::string bed_path;
  std::uint64_t sample_count{0};
  std::uint64_t physical_marker_count{0};
  std::vector<std::uint64_t> marker_indices;
  std::vector<double> allele_frequencies;
  std::vector<double> coefficients;
  std::uint64_t score_count{0};
  GenotypeCoding coding{GenotypeCoding::standardized};
  std::uint32_t thread_count{1};
  std::uint64_t marker_tile_size{64};
  std::uint64_t sample_tile_size{1024};
  std::uint64_t score_tile_size{32};
};

// Sparse marker-set scoring reuses one ordinary marker-by-score coefficient
// matrix and expands it through marker-to-set membership without materializing
// a dense marker-by-set matrix. Result columns are block-major: optional total
// scores first, then each set, with the base scores varying within each block.
struct BedSetScoreRequest {
  BedScoreRequest bed{};
  std::uint64_t set_count{0};
  std::vector<std::uint64_t> marker_set_offsets;
  std::vector<std::uint64_t> marker_sets;
  bool include_total{false};
};

class GSCORE_EXPORT ScoreResult {
 public:
  ScoreResult() = default;

  [[nodiscard]] std::uint64_t sample_count() const noexcept;
  [[nodiscard]] std::uint64_t score_count() const noexcept;
  [[nodiscard]] const std::vector<double>& values() const noexcept;
  [[nodiscard]] double at(std::uint64_t sample,
                          std::uint64_t score) const;

 private:
  friend ScoreResult score_bed(const BedScoreRequest& request);
  friend ScoreResult score_bed_sets(const BedSetScoreRequest& request);
  ScoreResult(std::uint64_t sample_count, std::uint64_t score_count,
              std::vector<double> values);

  std::uint64_t sample_count_{0};
  std::uint64_t score_count_{0};
  std::vector<double> values_{};
};

// coefficients[marker * score_count + score]
// result.values()[sample * score_count + score]
GSCORE_EXPORT ScoreResult score_bed(const BedScoreRequest& request);
GSCORE_EXPORT ScoreResult score_bed_sets(const BedSetScoreRequest& request);

}  // namespace gscore

#endif
