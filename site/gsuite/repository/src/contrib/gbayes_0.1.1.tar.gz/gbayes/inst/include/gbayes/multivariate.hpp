#pragma once
#include "gbayes/bayesc.hpp"
#include "gbayes/genetic_covariance.hpp"
#include "gbayes/partition.hpp"
#include "gbayes/prediction.hpp"
namespace gbayes {
// Patterns are in declared trait order. Exactly one null pattern must be first.
// A subset is a restricted model, not an approximation to complete enumeration.
using TraitPattern = std::vector<unsigned char>;
GBAYES_EXPORT std::vector<TraitPattern> complete_trait_patterns(std::size_t traits);
struct MultivariateProvider {
  std::string id;
  std::size_t trait{};
  FixedGaussianStatistics statistics;
  std::vector<std::size_t> local_to_global;
  double residual_variance{1}; // fixed likelihood scale
  double sample_size{}; // provenance; never applied again to C or score
};
struct MultivariateStatistics {
  std::vector<std::string> marker_ids, trait_ids;
  std::vector<MultivariateProvider> providers;
  // All providers must be independent, including multiple providers of one trait.
  bool independent_summaries{false};
  // Alternatively, Cov(vec(score)) = Omega (x) C, E(score)=C B.
  // Column-major T*T, fixed SPD, common C and sample size, one full provider/trait.
  // This is sampling-error covariance on the score scale, not genetic covariance.
  std::vector<double> sampling_error_covariance;
};
// Exhaustive disjoint groups in fit marker order. Matrices are T*T column-major.
struct GroupedMarkerCovariance {
  MarkerPartition partition;
  std::vector<std::vector<double>> covariance;
};
struct InverseWishartPrior {
  double df{};
  std::vector<double> scale; // scale, not mean; mean = scale / (df-T-1) if defined
};
struct MultivariatePrior {
  std::vector<double> marker_covariance; // T by T, column major, latent base effects
  std::vector<TraitPattern> patterns;
  std::vector<double> pattern_weights;
  // BayesC is exactly one positive scale {1}; BayesR uses a positive scale ladder.
  // Null is represented once by patterns[0], never by a zero component scale.
  std::vector<double> component_scales{1}, component_weights{1};
  std::vector<double> marker_variance_multipliers; // empty means one
  std::shared_ptr<const ProbitStickPrior> pattern_annotation;
  std::shared_ptr<const LogVariancePrior> variance_annotation;
  // Probabilities over positive scales, conditional on a nonnull trait pattern.
  // Requires >=2 scales; excludes global component-weight learning.
  std::shared_ptr<const ProbitStickPrior> component_annotation;
  // Alternative to marker_covariance (which must be empty in grouped mode).
  std::shared_ptr<const GroupedMarkerCovariance> group_covariance;
};
struct MultivariateLearning {
  bool marker_covariance{false}, pattern_weights{false}, component_weights{false};
  double covariance_prior_df{};
  std::vector<double> covariance_prior_scale; // inverse-Wishart scale, not mean
  std::vector<double> pattern_prior_counts, component_prior_counts;
  // Empty fixes all group matrices; otherwise one proper IW prior per group.
  // Cannot be combined with global marker_covariance learning.
  std::vector<InverseWishartPrior> group_covariance;
  // Optional full sampling-error covariance update for the shared-LD route.
  // response_crossproduct is T*T column-major Y'Y on the same residualized
  // scale as every provider's C and score. The likelihood dimension is the
  // residual degrees of freedom represented by that cross-product.
  bool sampling_error_covariance{false};
  InverseWishartPrior sampling_error_prior;
  std::vector<double> response_crossproduct;
  double sampling_likelihood_dimension{};
};
struct MultivariateParameters {
  std::vector<double> marker_covariance, pattern_weights, component_weights;
  std::vector<double> group_covariance; // group-major T*T; global covariance empty
  std::vector<double> sampling_error_covariance;
};
// Complete mutable state required to continue one multivariate chain exactly.
struct MultivariateChainState {
  std::uint32_t seed{};
  std::size_t completed_sweeps{};
  std::string rng_state;
  std::vector<double> effects, completed_base_effect;
  std::vector<std::vector<double>> working_residual;
  std::vector<std::size_t> patterns;
  std::vector<int> components;
  MultivariateParameters parameters;
  std::vector<double> pattern_coefficients, component_coefficients,
      variance_coefficients;
  MarkerScheduleState marker_schedule;
};
struct MultivariateControls {
  BayesCControls chains;
  bool retain_pattern_probabilities{false}; // potentially M * 2^T per chain
  std::size_t memory_limit_bytes{256u * 1024u * 1024u}; // incremental estimate
  // Optional explicit reference; evaluated at every retained draw.
  std::shared_ptr<const GeneticCovarianceReference> genetic_reference;
  std::shared_ptr<const MarkerPartition> partition; // optional exhaustive disjoint groups
  PredictionControls prediction;
  // Empty starts seeded chains. Otherwise one complete state per chain.
  std::vector<MultivariateChainState> initial_states;
};
// Covariance of fitted values is distinct from the learned marker-effect
// covariance. Available only for aligned individual-level BED providers.
struct IndividualBedMultivariateOutput {
  bool available{false};
  std::vector<double> final_covg, mean_covg; // T*T, column-major
  std::vector<double> final_vle, final_vld; // one value per trait
  std::vector<double> mean_vle, mean_vld; // all post-burnin sweeps
  std::vector<std::vector<double>> covg_trace; // every sweep, including burnin
  std::vector<std::vector<double>> vle_trace, vld_trace;
  std::vector<std::vector<double>> marker_covariance_trace; // all covariance groups
  std::vector<std::vector<double>> residual_covariance_trace;
  std::vector<std::vector<double>> pattern_weight_trace, component_weight_trace;
  std::vector<double> postburn_pattern_weight_mean, postburn_component_weight_mean;
};
struct MultivariateChain {
  std::uint32_t seed{};
  std::size_t retained_draws{};
  // Marker-major, trait changes fastest. PIP means activity, not nonzero rounding.
  std::vector<double> mean, second_moment, pip, any_pip, final_effect;
  std::vector<std::size_t> final_pattern;
  std::vector<int> final_component; // -1 for null
  // Marker-major; component probability is unconditional (sums to any_pip).
  std::vector<double> pattern_probability, component_probability;
  MultivariateParameters parameter_mean, final_parameters;
  AnnotationChain pattern_annotation, variance_annotation, component_annotation;
  // Expected number of markers per pattern/component and per trait pair.
  // Sharing and latent correlation are T*T column-major, averaged over draws.
  std::vector<double> expected_pattern_count, expected_component_count;
  std::vector<double> expected_trait_sharing, latent_correlation;
  std::vector<double> group_latent_correlation; // group-major T*T; global empty
  GeneticCovariancePosterior genetic_covariance; // empty unless requested
  PartitionPosterior partition;
  PredictionPosterior prediction;
  std::vector<std::size_t> working_residual_dimensions;
  double elapsed_seconds{};
  std::vector<MultivariateParameters> trace;
  std::vector<std::vector<double>> final_score_residual; // provider order
  double maximum_working_residual_drift{};
  std::size_t scheduled_marker_updates{}, scheduled_full_sweeps{};
  IndividualBedMultivariateOutput individual_bed;
  MultivariateChainState continuation_state;
};
struct MultivariateProviderMetadata {
  std::string id, effect_units, provenance;
  std::size_t trait{};
  double residual_variance{}, sample_size{};
  std::vector<std::size_t> local_to_global;
};
struct MultivariateResult {
  std::vector<std::string> marker_ids, trait_ids, provider_ids;
  MultivariatePrior prior;
  MultivariateLearning learning;
  MultivariateControls controls;
  std::vector<MultivariateProviderMetadata> providers;
  std::vector<bool> truncated_likelihood; // provider order
  std::vector<double> mean, variance, pip, any_pip;
  std::vector<double> pattern_probability, component_probability;
  MultivariateParameters parameter_mean;
  IndividualBedMultivariateOutput individual_bed; // pooled across chains
  BetweenChainMarkerSummary between_chain; // marker-major, trait-fastest; all providers
  std::vector<MultivariateChain> chains;
  unsigned threads_used{1};
  std::size_t estimated_memory_bytes{};
  std::vector<double> sampling_error_covariance;
  std::vector<double> final_sampling_error_covariance;
  AnnotationSummary pattern_annotation, variance_annotation, component_annotation;
  std::vector<double> expected_pattern_count, expected_component_count;
  std::vector<double> expected_trait_sharing, latent_correlation;
  std::vector<double> group_latent_correlation; // group-major T*T; global empty
  GeneticCovariancePosterior genetic_covariance; // empty unless requested
  PartitionPosterior partition;
  PredictionPosterior prediction;
  double elapsed_seconds{};
};
// Reusable integrated marker conditional in base-effect coordinates.
// These conditionals take a single covariance: for grouped fits pass a prior
// with marker_covariance set to the selected matrix and group_covariance reset.
struct MultivariateState {
  std::size_t pattern{};
  int component{-1};
  double probability{};
  std::vector<std::size_t> active_traits;
  std::vector<double> base_mean, base_covariance; // active coordinates, column major
};
GBAYES_EXPORT std::vector<MultivariateState> multivariate_marker_conditional(
    const std::vector<double>& score, const std::vector<double>& information_diagonal,
    const MultivariatePrior&, double marker_variance_multiplier = 1);
// General symmetric PSD information matrix, T*T column-major.
GBAYES_EXPORT std::vector<MultivariateState> multivariate_marker_conditional_information(
    const std::vector<double>& score,const std::vector<double>& information,
    const MultivariatePrior&,double marker_variance_multiplier=1);
// Native independent or shared-LD correlated-summary BayesC / BayesR.
GBAYES_EXPORT MultivariateResult fit_multivariate_mixture(
    const MultivariateStatistics&, const MultivariatePrior&,
    const MultivariateControls& = {}, const MultivariateLearning& = {});
}
