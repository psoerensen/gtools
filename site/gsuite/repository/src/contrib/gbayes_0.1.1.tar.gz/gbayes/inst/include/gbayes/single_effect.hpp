#pragma once
#include "gbayes/bayesc.hpp"
#include <optional>
namespace gbayes {
// Exactly one marker is active. Weights are relative prior masses; empty=uniform.
struct SingleEffectPrior {
  double residual_variance{1}, effect_variance{1};
  std::vector<double> marker_weights;
};
struct SingleEffectVarianceControls {
  std::size_t max_updates{200};
  double relative_tolerance{1e-8};
};
struct SingleEffectResult {
  std::vector<std::string> marker_ids;
  std::string trait, effect_units, provenance;
  SingleEffectPrior prior; // includes original relative weights
  bool truncated_likelihood{false};
  bool active{true}; // false only for the learned zero-variance boundary
  std::optional<bool> variance_learning_converged; // selected variance: EM or certified null boundary; absent when fixed
  std::size_t variance_updates{};
  std::vector<double> prior_probability, assignment_probability;
  std::vector<double> log_bayes_factor; // marker against no effect
  std::vector<double> conditional_mean, conditional_variance;
  std::vector<double> mean, second_moment, variance; // averaged over assignments
  double model_log_bayes_factor{}; // weighted single-effect mixture against no effect
};
// Deterministic finite-mixture calculation; no variance learning or null component.
GBAYES_EXPORT SingleEffectResult fit_single_effect(const FixedGaussianStatistics&,
                                                   const SingleEffectPrior& = {});
// Empirical-Bayes EM with an explicit zero-variance comparison; residual variance fixed.
GBAYES_EXPORT SingleEffectResult fit_single_effect_learned(const FixedGaussianStatistics&,
    const SingleEffectPrior& = {}, const SingleEffectVarianceControls& = {});
}
