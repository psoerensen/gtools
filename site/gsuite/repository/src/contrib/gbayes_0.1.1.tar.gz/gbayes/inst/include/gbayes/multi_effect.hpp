#pragma once
#include "gbayes/single_effect.hpp"
namespace gbayes {
struct MultiEffectControls {
  std::size_t effects{10}, max_sweeps{200};
  double objective_tolerance{1e-8}; // absolute change in ELBO relative to fixed initial null
  bool estimate_effect_variance{false};
  SingleEffectVarianceControls variance_learning{};
  bool estimate_residual_variance{false};
  GaussianNormalization normalization{}; // required only for residual learning
  double residual_relative_tolerance{1e-8};
};
struct MultiEffectResult {
  std::vector<std::string> marker_ids;
  std::string trait, effect_units, provenance;
  SingleEffectPrior prior;
  MultiEffectControls controls;
  bool truncated_likelihood{false}, converged{false};
  std::size_t sweeps{};
  double residual_variance{}; // fitted value; prior retains starting parameters
  std::vector<double> residual_variance_trace; // initial value plus each sweep
  std::optional<bool> residual_variance_converged; // absent when fixed
  // Conditional-on-other-component-means single-effect fits, not independent signals.
  std::vector<SingleEffectResult> components;
  std::vector<double> mean, variance, pip;
  // Initial prior bound then one entry per sweep; fixed initial-null reference.
  // With residual learning this includes Gaussian normalization. Not a model log BF.
  std::vector<double> objective;
  std::vector<double> final_score_residual;
};
// Expected Gaussian residual quadratic for independent single-effect components.
// Includes within-component assignment covariance; not just marginal variances.
GBAYES_EXPORT double expected_residual_sum_squares(const FixedGaussianStatistics&,
    const std::vector<SingleEffectResult>&, const GaussianNormalization&);
// Mean-field sum of single effects; deterministic sequential IBSS.
GBAYES_EXPORT MultiEffectResult fit_multi_effect(const FixedGaussianStatistics&,
    const SingleEffectPrior& = {}, const MultiEffectControls& = {});
}
