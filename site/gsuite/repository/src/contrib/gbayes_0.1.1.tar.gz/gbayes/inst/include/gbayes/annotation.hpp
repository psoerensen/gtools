#pragma once
#include "gbayes/export.h"
#include <cstddef>
#include <memory>
#include <random>
#include <string>
#include <vector>
namespace gbayes {
// Immutable centred columns; caller aligns rows with the statistics' marker IDs.
class GBAYES_EXPORT CenteredAnnotations {
 std::size_t markers_;
 std::vector<std::string> names_;
 std::vector<double> values_, means_;
 public:
 CenteredAnnotations(std::size_t markers,std::vector<std::string> names,
                     std::vector<double> column_major_values);
 std::size_t markers() const noexcept {return markers_;}
 const std::vector<std::string>& names() const noexcept {return names_;}
 const std::vector<double>& column_means() const noexcept {return means_;}
 double entry(std::size_t marker,std::size_t column) const;
 std::vector<double> offsets(const std::vector<double>& coefficients) const;
};
struct LogisticAnnotationPrior {
 std::shared_ptr<const CenteredAnnotations> design;
 std::vector<double> initial_coefficients; // empty starts at zero
 double coefficient_prior_sd{1}, proposal_sd{.1};
 bool learn_coefficients{true};
 std::size_t update_every{1}; // complete sweeps, including burn-in
};
struct ProbitStickPrior {
 std::shared_ptr<const CenteredAnnotations> design;
 // Empty means derive proper intercept-prior means from the global weights.
 std::vector<double> intercept_means;
 // Stick-major: intercept, then centred annotation coefficients for each stick.
 std::vector<double> initial_coefficients;
 double intercept_prior_sd{1}, coefficient_prior_sd{1};
 bool learn_coefficients{true};
 bool learn_intercepts{true}; // false holds initial stick intercepts fixed
 std::size_t update_every{1};
};
struct LogVariancePrior {
 std::shared_ptr<const CenteredAnnotations> design;
 std::vector<double> initial_coefficients; // empty starts at zero
 double coefficient_prior_sd{1};
 bool learn_coefficients{true};
 std::size_t update_every{1}, maximum_evaluations{10000};
};
// BayesS specialization of the general log-variance annotation. For marker
// allele frequency p_j, Var(b_j | active) is proportional to
// [2 p_j (1-p_j)]^S after geometric-mean centring. The single returned
// coefficient is therefore the MAF exponent S.
GBAYES_EXPORT std::shared_ptr<LogVariancePrior> bayess_variance_prior(
    const std::vector<double>& allele_frequency,double initial_s=0,
    double prior_sd=1,bool learn=true,std::size_t update_every=1,
    std::size_t maximum_evaluations=10000);
struct AnnotationChain {
 std::vector<double> coefficient_mean, coefficient_second_moment, final_coefficients;
 std::vector<double> prior_probability_mean, final_prior_probability;
 std::vector<std::vector<double>> coefficient_trace; // only if retain_diagnostics
 std::vector<double> multiplier_mean, final_multiplier; // variance route only
 std::size_t updates{}, likelihood_evaluations{}; // Gibbs/elliptical slice diagnostics
 std::size_t accepted{}, proposed{}; // all coefficient proposals, including burn-in
};
struct AnnotationSummary {
 std::vector<double> coefficient_mean, coefficient_variance, prior_probability_mean, multiplier_mean;
};
// Reusable Bernoulli-logistic target and Gaussian random-walk update.
// States must be 0/1; sigma is a fixed zero-centred Gaussian coefficient prior SD.
GBAYES_EXPORT double logistic_annotation_log_posterior(const CenteredAnnotations&,
    const std::vector<double>& coefficients,const std::vector<std::size_t>& states,
    double baseline_probability,double sigma);
GBAYES_EXPORT bool update_logistic_annotation(const CenteredAnnotations&,
    std::vector<double>& coefficients,const std::vector<std::size_t>& states,
    double baseline_probability,double sigma,double proposal_sd,std::mt19937&);
// Beta prior on baseline pi: shapes are null, active, matching mixture weights.
// Nonzero offsets use a logit-space slice update including the Jacobian.
GBAYES_EXPORT std::vector<double> draw_logistic_baseline(
    const std::vector<double>& offsets,const std::vector<std::size_t>& states,
    double current_probability,double null_shape,double active_shape,std::mt19937&);

// Continuation-probit sticks: stop in k or continue to the next component.
GBAYES_EXPORT std::vector<double> probit_intercepts(const std::vector<double>& weights);
GBAYES_EXPORT std::vector<std::vector<double>> probit_stick_probabilities(
    const CenteredAnnotations&,const std::vector<double>& coefficients,std::size_t components);
GBAYES_EXPORT void update_probit_sticks(const CenteredAnnotations&,std::vector<double>& coefficients,
    const std::vector<std::size_t>& states,const std::vector<double>& intercept_means,
    double intercept_sd,double coefficient_sd,std::mt19937&);
// Update annotation slopes while retaining the supplied stick intercepts.
GBAYES_EXPORT void update_probit_sticks_fixed_intercepts(const CenteredAnnotations&,
    std::vector<double>& coefficients,const std::vector<std::size_t>& states,
    const std::vector<double>& intercept_means,double intercept_sd,
    double coefficient_sd,std::mt19937&);
// Update using selected rows without subsetting/recentring the annotation design.
// selected is 0/1 in marker order. Unselected states are ignored (may be sentinel).
// An empty selected set draws every stick coefficient from its proper prior.
GBAYES_EXPORT void update_probit_sticks_selected(const CenteredAnnotations&,
    std::vector<double>& coefficients,const std::vector<std::size_t>& states,
    const std::vector<unsigned char>& selected,const std::vector<double>& intercept_means,
    double intercept_sd,double coefficient_sd,std::mt19937&);
GBAYES_EXPORT void update_probit_sticks_selected_fixed_intercepts(
    const CenteredAnnotations&,std::vector<double>& coefficients,
    const std::vector<std::size_t>& states,const std::vector<unsigned char>& selected,
    const std::vector<double>& intercept_means,double intercept_sd,
    double coefficient_sd,std::mt19937&);
GBAYES_EXPORT std::vector<double> annotation_variance_multipliers(
    const CenteredAnnotations&,const std::vector<double>& coefficients);
// Theta-dependent active-effect log likelihood, omitting theta-independent constants.
GBAYES_EXPORT double log_variance_likelihood(const CenteredAnnotations&,const std::vector<double>& coefficients,
    const std::vector<double>& effects,const std::vector<std::size_t>& components,double slab_variance,
    const std::vector<double>& component_multipliers,const std::vector<double>& fixed_marker_multipliers={});
// General Gaussian scale target: -.5 sum_j [dimension_j * eta_j + quadratic_j exp(-eta_j)].
// Quadratics already remove fixed marker/component scales. Zero dimensions require
// zero quadratic and represent null markers. Supports scalar and vector effects.
GBAYES_EXPORT double gaussian_scale_log_likelihood(const CenteredAnnotations&,
    const std::vector<double>& coefficients,const std::vector<double>& dimensions,
    const std::vector<double>& quadratics);
GBAYES_EXPORT std::size_t update_gaussian_scale(const CenteredAnnotations&,
    std::vector<double>& coefficients,const std::vector<double>& dimensions,
    const std::vector<double>& quadratics,double prior_sd,
    std::size_t maximum_evaluations,std::mt19937&);
// Returns proposal evaluation count; zero means an exact prior-only draw.
GBAYES_EXPORT std::size_t update_log_variance(const CenteredAnnotations&,std::vector<double>& coefficients,
    const std::vector<double>& effects,const std::vector<std::size_t>& components,double slab_variance,
    const std::vector<double>& component_multipliers,const std::vector<double>& fixed_marker_multipliers,
    double prior_sd,std::size_t maximum_evaluations,std::mt19937&);
}
