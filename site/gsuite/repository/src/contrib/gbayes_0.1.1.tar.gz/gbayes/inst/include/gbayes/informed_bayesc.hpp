#pragma once
#include "gbayes/bayesc.hpp"
#include "gbayes/summary_variational.hpp"
namespace gbayes {
struct InformedBayesCResult {
  BayesCResult posterior;
  std::vector<double> slab_means;
};
struct InformedVariationalResult {
  SummaryVariationalResult posterior;
  BayesCPrior prior;
  std::vector<double> slab_means;
};
// Fixed per-marker prior N(slab_means[j], slab_variance*q[j]) when active.
// Reuses the scalar mixture sampler. Optional exact residual learning only;
// no slab/probability learning, annotations, swaps or adaptive scheduling.
GBAYES_EXPORT InformedBayesCResult fit_informed_bayesc(
    const FixedGaussianStatistics&, const BayesCPrior&, const std::vector<double>& slab_means,
    const BayesCControls& = {}, const GaussianLearning& = {});
// The same likelihood/prior, with a product spike-and-normal variational family.
// Reuses the summary-mixture coordinate engine; residual variance is fixed.
GBAYES_EXPORT InformedVariationalResult fit_informed_bayesc_variational(
    const FixedGaussianStatistics&, const BayesCPrior&, const std::vector<double>& slab_means,
    const SummaryVariationalControls& = {});
}
