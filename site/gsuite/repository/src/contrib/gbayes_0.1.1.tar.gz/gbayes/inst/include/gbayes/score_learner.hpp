#pragma once
#include "gbayes/penalized_gaussian.hpp"
namespace gbayes {
enum class ScoreLearner { ols, ridge_gcv, lasso_cv };
struct ScoreLinearFit {
  std::vector<double> coefficients;
  double intercept{}, penalty{}, training_loss{}, max_kkt{};
};
struct ScoreLearnerPath {
  std::vector<ScoreLinearFit> fits;
  std::vector<double> centers, scales;
};
// Small, column-major prediction matrix, not a genomic design. Unit row
// weights. Ridge: MASS normalized columns and GCV; lasso: Gaussian glmnet path
// convention.
GBAYES_EXPORT ScoreLearnerPath
fit_score_learner_path(const std::vector<double> &x,
                       const std::vector<double> &y, ScoreLearner method);
GBAYES_EXPORT ScoreLinearFit interpolate_score_path(const ScoreLearnerPath &,
                                                    double penalty);
GBAYES_EXPORT std::vector<double>
apply_score_linear(const ScoreLinearFit &, const std::vector<double> &x,
                   std::size_t n);
struct ScoreMetaFit {
  std::vector<double> raw_weights, weights;
  double objective{}, max_kkt{};
  bool rank_deficient{};
};
// Exactly three learner columns. NNLS, then normalize positive weights to
// sum 1.
GBAYES_EXPORT ScoreMetaFit fit_score_meta(
    const std::vector<double> &predictions, const std::vector<double> &y);
} // namespace gbayes
