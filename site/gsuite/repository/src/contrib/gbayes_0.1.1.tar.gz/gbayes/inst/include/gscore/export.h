#ifndef GSCORE_EXPORT_H
#define GSCORE_EXPORT_H

#if defined(GSCORE_STATIC_DEFINE)
#  define GSCORE_EXPORT
#elif defined(_WIN32) || defined(__CYGWIN__)
#  if defined(GSCORE_BUILDING_LIBRARY)
#    define GSCORE_EXPORT __declspec(dllexport)
#  else
#    define GSCORE_EXPORT __declspec(dllimport)
#  endif
#elif defined(__GNUC__) && __GNUC__ >= 4
#  define GSCORE_EXPORT __attribute__((visibility("default")))
#else
#  define GSCORE_EXPORT
#endif

#endif

