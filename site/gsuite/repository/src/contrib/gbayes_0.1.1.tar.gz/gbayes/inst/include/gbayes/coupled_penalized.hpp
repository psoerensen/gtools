#pragma once
#include "gbayes/penalized_gaussian.hpp"
namespace gbayes {
// Population-specific normalized quadratic likelihoods, identical marker order.
// Objective=sum_t[.5 b_t'R_t b_t-r_t'b_t+lambda_t|b_t|+.5 delta_t b_t'b_t]
//          +.5 sum_{t<u} coupling[t,u] ||b_t-b_u||^2.
// coupling is symmetric, column-major with zero diagonal. No population matrix
// or genome-wide cross-product is materialized; delegates to fit_l1_quadratic.
GBAYES_EXPORT L1QuadraticResult fit_coupled_penalized(
    const std::vector<FixedGaussianStatistics> &,
    const std::vector<double> &lambda, const std::vector<double> &delta,
    const std::vector<double> &coupling, const L1QuadraticControls & = {});
} // namespace gbayes
