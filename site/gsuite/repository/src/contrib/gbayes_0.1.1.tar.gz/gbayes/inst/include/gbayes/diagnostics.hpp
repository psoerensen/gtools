#pragma once
#include "gbayes/bayesr.hpp"
#include "gbayes/multivariate.hpp"
namespace gbayes {
// Unweighted between-chain summaries, not Monte Carlo standard errors.
struct ChainSpread { double mean{}, sd{}, minimum{}, maximum{}; };
struct ChainAgreement {
  std::vector<std::string> marker_ids;
  std::vector<std::uint32_t> seeds;
  std::vector<std::size_t> retained_draws;
  std::vector<ChainSpread> effect, pip;
  ChainSpread residual_variance, slab_variance, expected_active;
  std::vector<ChainSpread> weights;
  std::vector<ChainSpread> region_inclusion; // empty without traces; otherwise one entry
  std::vector<std::size_t> flagged_markers;
  bool multiple_chains{false};
  double pip_range_threshold{};
};
struct MultivariateChainAgreement {
  std::vector<std::string> marker_ids, trait_ids;
  std::vector<TraitPattern> patterns;
  std::vector<double> component_scales;
  std::vector<std::uint32_t> seeds;
  std::vector<std::size_t> retained_draws;
  std::vector<ChainSpread> effect, pip; // marker-major, trait fastest
  std::vector<ChainSpread> expected_pattern_count, expected_component_count;
  std::vector<ChainSpread> expected_trait_sharing, latent_covariance, latent_correlation; // T*T column-major
  std::vector<std::string> covariance_group_ids;
  std::vector<ChainSpread> group_latent_covariance, group_latent_correlation; // group-major T*T
  std::vector<ChainSpread> pattern_coefficients, variance_coefficients, component_coefficients;
  std::vector<std::size_t> flagged_marker_traits; // same flattened order as pip
  bool multiple_chains{false};
  double pip_range_threshold{};
};
GBAYES_EXPORT MultivariateChainAgreement summarize_chains(const MultivariateResult&,double pip_range_threshold=.1);
GBAYES_EXPORT ChainAgreement summarize_chains(const BayesCResult&, double pip_range_threshold=.1);
GBAYES_EXPORT ChainAgreement summarize_chains(const BayesRResult&, double pip_range_threshold=.1);
}
