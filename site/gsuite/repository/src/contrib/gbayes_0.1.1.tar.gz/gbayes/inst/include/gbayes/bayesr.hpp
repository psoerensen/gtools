#pragma once
#include "gbayes/bayesc.hpp"
namespace gbayes {
struct BayesRPrior {
  double residual_variance{1}, slab_variance{1};
  std::vector<double> variance_multipliers{0, .01, .1, 1};
  std::vector<double> weights{.7, .1, .1, .1};
  // Optional marker x component probabilities, in data.marker_ids order.
  // Each row is positive and sums to one; empty uses global weights.
  std::vector<std::vector<double>> marker_weights{};
  // Fixed q_j >0: Var(b_j | component k) = q_j * slab_variance * multiplier_k.
  std::vector<double> marker_variance_multipliers{};
  std::shared_ptr<const ProbitStickPrior> component_annotation{};
  std::shared_ptr<const LogVariancePrior> variance_annotation{};
};
struct BayesRChain {
  BayesCChain posterior;
  AnnotationChain component_annotation;
  std::vector<std::size_t> final_component, marker_order; // order drawn once per chain
  std::vector<std::vector<double>> component_probability; // marker x component
};
struct BayesRResult {
  std::vector<std::string> marker_ids;
  std::string trait, effect_units, provenance;
  BayesRPrior prior;
  BayesCControls controls;
  GaussianLearning learning;
  bool truncated_likelihood{false};
  GaussianParameters parameter_mean;
  std::vector<double> block_residual_variance_mean;
  std::vector<double> mean, variance, pip;
  IndividualBedScalarOutput individual_bed;
  BetweenChainMarkerSummary between_chain;
  std::vector<std::vector<double>> component_probability;
  std::vector<BayesRChain> chains;
  unsigned threads_used{1};
  AnnotationSummary component_annotation, variance_annotation;
  ScalarPosteriorControls posterior_controls;
  std::size_t estimated_posterior_memory_bytes{};
  GeneticCovariancePosterior genetic_covariance;
  PartitionPosterior partition;
  PredictionPosterior prediction;
};
GBAYES_EXPORT BayesRResult fit_bayesr(const FixedGaussianStatistics&,
    const BayesRPrior& = {}, const BayesCControls& = {}, const GaussianLearning& = {});
GBAYES_EXPORT BayesRResult fit_bayesr(const FixedGaussianStatistics&,
    const BayesRPrior&, const BayesCControls&, const GaussianLearning&,
    const ScalarPosteriorControls&);
}
