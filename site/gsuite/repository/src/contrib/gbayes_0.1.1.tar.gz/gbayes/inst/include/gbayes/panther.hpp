#pragma once
#include "gbayes/population_shrinkage.hpp"
namespace gbayes {
struct PantherControls {
  ContinuousShrinkageControls sampling;
  bool target_route{false};
  std::size_t output_population{};
  // One LOGODetect category per population/marker, common ordered intersection.
  // Non-output populations are category 0 in the source-specific route.
  std::vector<std::vector<int>> sharing_groups;
};
struct PantherResult {
  PantherControls controls;
  PopulationPosterior posterior;
  std::vector<std::vector<double>> group_scale_mean;
};
GBAYES_EXPORT PantherResult fit_panther_reference(
    const std::vector<ContinuousShrinkageInput> &, const PantherControls &);
} // namespace gbayes
