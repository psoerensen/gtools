#pragma once
#include "gbayes/export.h"
#include <vector>
namespace gbayes {
struct NormalSpikeConditional {
  double mean{}, variance{}, inclusion_probability{}, log_bayes_factor{};
};
// score = s_j - sum_{k != j} C_jk b_k; parameters are fixed and positive.
GBAYES_EXPORT NormalSpikeConditional normal_spike_conditional(
    double diagonal, double score, double residual_variance,
    double slab_variance, double prior_inclusion);
// Log-odds entry avoids rounding extreme annotation probabilities before fitting.
GBAYES_EXPORT NormalSpikeConditional normal_spike_conditional_logit(
    double diagonal,double score,double residual_variance,double slab_variance,double prior_logit);
struct NormalMixtureConditional {
  std::vector<double> probability, mean, variance;
};
GBAYES_EXPORT NormalSpikeConditional normal_spike_conditional_mean(
    double diagonal,double score,double residual_variance,double slab_variance,
    double prior_inclusion,double slab_mean);
// Nonzero Gaussian means; a point mass, if present, must remain at zero.
GBAYES_EXPORT NormalMixtureConditional gaussian_components_conditional(
    double diagonal,double score,double residual_variance,
    const std::vector<double>& variances,const std::vector<double>& weights,
    const std::vector<double>& means);
// Arbitrary mixture of zero-mean Gaussian slabs, optionally with one point
// mass at zero. Variances are actual effect-scale variances, not multipliers.
GBAYES_EXPORT NormalMixtureConditional gaussian_components_conditional(
    double diagonal, double score, double residual_variance,
    const std::vector<double>& component_variances,
    const std::vector<double>& component_weights);
// First multiplier is zero (spike); others positive. Weights positive, sum one.
GBAYES_EXPORT NormalMixtureConditional normal_mixture_conditional(
    double diagonal, double score, double residual_variance, double slab_variance,
    const std::vector<double>& multipliers, const std::vector<double>& weights);
}
