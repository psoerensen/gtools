#pragma once

#include <vector>

#include "gbayes/summary_variational.hpp"

namespace gbayes {

struct SummaryGaussianMixturePrior {
  std::vector<double> variances;  // effect-scale; at most one zero spike
  std::vector<double> weights;  // positive, sum to one
};

// Fixed-prior mean-field fitting of Gaussian effect mixtures using summary
// cross-products. Supports one Gaussian, two or more Gaussian slabs, and an
// optional zero component. Windows follow SummaryVariationalControls.
GBAYES_EXPORT SummaryVariationalResult fit_summary_gaussian_mixture(
    const FixedGaussianStatistics&, const SummaryGaussianMixturePrior&,
    const SummaryVariationalControls& = {});

}  // namespace gbayes
