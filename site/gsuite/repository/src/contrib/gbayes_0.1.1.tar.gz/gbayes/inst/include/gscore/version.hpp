#ifndef GSCORE_VERSION_HPP
#define GSCORE_VERSION_HPP

#include <cstdint>

#include "gscore/export.h"

namespace gscore {

inline constexpr std::uint32_t version_major = 0;
inline constexpr std::uint32_t version_minor = 1;
inline constexpr std::uint32_t version_patch = 0;
inline constexpr std::uint32_t experimental_abi = 0;

GSCORE_EXPORT const char* version_string() noexcept;
GSCORE_EXPORT std::uint32_t abi_version() noexcept;
GSCORE_EXPORT bool openmp_enabled() noexcept;

}  // namespace gscore

#endif

