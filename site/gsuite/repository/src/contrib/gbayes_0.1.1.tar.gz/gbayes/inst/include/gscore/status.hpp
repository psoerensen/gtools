#ifndef GSCORE_STATUS_HPP
#define GSCORE_STATUS_HPP

#include <string>
#include <utility>

namespace gscore {

enum class StatusCode {
  success = 0,
  invalid_argument,
  invalid_extent,
  dimension_mismatch,
  duplicate_marker_index,
  marker_index_out_of_range,
  non_finite_value,
  integer_overflow,
  allocation_failure,
  file_open_failure,
  file_io_failure,
  invalid_bed_header,
  invalid_bed_mode,
  bed_size_mismatch,
  unsupported_file_offset,
  openmp_unavailable,
  result_index_out_of_range,
  internal_error
};

class Status {
 public:
  Status() = default;
  Status(StatusCode code, std::string message)
      : code_(code), message_(std::move(message)) {}

  static Status ok() { return {}; }

  [[nodiscard]] bool is_ok() const noexcept {
    return code_ == StatusCode::success;
  }
  explicit operator bool() const noexcept { return is_ok(); }
  [[nodiscard]] StatusCode code() const noexcept { return code_; }
  [[nodiscard]] const std::string& message() const noexcept { return message_; }

 private:
  StatusCode code_{StatusCode::success};
  std::string message_{};
};

}  // namespace gscore

#endif

