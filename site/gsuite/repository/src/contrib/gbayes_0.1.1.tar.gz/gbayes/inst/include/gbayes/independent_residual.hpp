#pragma once
#include "gbayes/multivariate.hpp"
namespace gbayes {
struct ProviderResidualLearning {
  GaussianNormalization normalization;
  ScaledInverseChiSquare prior;
};
struct ProviderResidualChain {
  std::vector<double> mean, final_variance; // provider order
  std::vector<std::vector<double>> trace;
};
struct IndependentResidualResult {
  MultivariateResult posterior;
  std::vector<double> residual_mean;
  std::vector<ProviderResidualChain> residual_chains;
};
// One explicit normalization/prior per independent provider. No cross-site
// residual covariance. Existing MultivariateResult layouts remain unchanged.
// Continuation is excluded until provider residual states can be supplied.
GBAYES_EXPORT IndependentResidualResult fit_multivariate_residual(
    const MultivariateStatistics&, const MultivariatePrior&,
    const std::vector<ProviderResidualLearning>&,
    const MultivariateControls& = {}, const MultivariateLearning& = {});
}
