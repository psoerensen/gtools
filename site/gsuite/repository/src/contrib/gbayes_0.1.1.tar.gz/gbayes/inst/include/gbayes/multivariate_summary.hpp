#pragma once
#include "gbayes/summary_statistics.hpp"
#include "gbayes/multivariate.hpp"
namespace gbayes {
struct SummaryGaussianProvider {
  std::string id, trait;
  std::shared_ptr<const CrossProducts> cross_products; // C = sqrt(N) R sqrt(N), not R
  std::vector<std::string> marker_ids; // local order of C, effects and N
  std::vector<double> standardized_marginal_effects, effective_sample_sizes;
  SummaryGaussianConvention convention{SummaryGaussianConvention::common_n};
  double residual_variance{1}; // fixed likelihood scale
  // Common-N: zero derives N, otherwise must equal N. Variable-N: explicitly positive.
  // Metadata only; never substitutes for marker-specific effective N.
  double study_sample_size{};
  std::string provenance;
};
enum class SummaryDependence { independent, shared_ld };
// Labels/maps only: no allele harmonization, reordering of C, LD access or PSD repair.
// Shared-LD preparation requires common N, one full provider/trait and the same C
// object; supply a justified fixed SPD sampling-error covariance in trait order.
GBAYES_EXPORT MultivariateStatistics prepare_multivariate_summary_gaussian(
    const std::vector<std::string>& marker_ids,const std::vector<std::string>& trait_ids,
    const std::vector<SummaryGaussianProvider>&,SummaryDependence,
    const std::vector<double>& sampling_error_covariance = {});
}
