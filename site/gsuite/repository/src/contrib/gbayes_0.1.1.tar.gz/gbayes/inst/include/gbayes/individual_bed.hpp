#pragma once
#include "gbayes/bayesc.hpp"
#include "gbayes/multivariate.hpp"
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace gbayes {

// Physical BED indices are zero-based. Files and selected markers are kept in
// this order; sample_indices applies to every file and matches phenotype order.
struct IndividualBedFile {
  std::string path;
  std::uint64_t physical_marker_count{};
  std::vector<std::uint64_t> marker_indices;
};

struct IndividualBedInput {
  std::uint64_t physical_sample_count{};
  std::vector<std::uint64_t> sample_indices; // empty selects every BED sample
  std::vector<IndividualBedFile> files;
  std::vector<double> phenotype; // pre-adjusted, finite, in selected sample order
  std::vector<std::string> marker_ids; // required, in selected marker order
  std::vector<double> allele_frequency; // counted BED A1 frequency, not dosage centre; empty estimates on selected samples
  std::string trait;
  bool standardize{true}; // sblr BED coding; missing dosage is mean-imputed
  double likelihood_dimension{}; // zero uses selected sample count
  std::size_t packed_memory_limit_bytes{}; // zero disables packed-storage preflight
};

struct IndividualBedStatistics {
  FixedGaussianStatistics statistics;
  GaussianNormalization normalization;
  std::size_t sample_count{};
  std::size_t packed_memory_bytes{}; // three bit planes, excludes sampler state
};

// Prepares immutable packed genotypes once. The returned statistics feed the
// existing native fit_bayesc/fit_bayesr samplers; BayesRC uses the BayesR
// annotation prior. No full decoded X or dense marker cross-product is formed.
GBAYES_EXPORT IndividualBedStatistics prepare_individual_bed(
    const IndividualBedInput& input);

// Apply the already prepared packed design in selected-sample order. No new
// decoding/storage system; rejects non-BED statistics and nonfinite effects.
GBAYES_EXPORT std::vector<double> predict_individual_bed(
    const FixedGaussianStatistics&,const std::vector<double>& effects);

// Actual prepared coding, in selected marker order. Missing raw dosage is 2f.
// Standardized: (dosage - centers[j])/scales[j], missing -> 0.
// Raw: centers=0, scales=1, missing -> 2f. Rejects non-BED operators.
struct IndividualBedCoding {
  std::vector<double> allele_frequency,centers,scales;
  std::size_t sample_count{};
  bool standardized{};
};
GBAYES_EXPORT IndividualBedCoding individual_bed_coding(const FixedGaussianStatistics&);

struct IndividualBedMultivariateStatistics {
  MultivariateStatistics statistics;
  std::vector<double> response_crossproduct; // Y'Y, T by T column-major
  double likelihood_dimension{};
};

// first_trait contains the shared BED selection and the first phenotype.
// Each additional phenotype has the identical ordered selected samples.
// Packing occurs once; each trait receives an independent individual residual.
// sampling_error_covariance is a fixed initial full residual covariance and
// may subsequently be learned by fit_multivariate_mixture().
GBAYES_EXPORT IndividualBedMultivariateStatistics prepare_individual_bed_multivariate(
    const IndividualBedInput& first_trait,
    const std::vector<std::vector<double>>& additional_phenotypes,
    const std::vector<std::string>& trait_ids,
    const std::vector<double>& sampling_error_covariance);

}
