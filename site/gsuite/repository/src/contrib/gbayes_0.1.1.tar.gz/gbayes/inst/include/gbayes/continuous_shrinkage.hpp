#pragma once

#include <cstddef>
#include <cstdint>
#include <memory>
#include <random>
#include <string>
#include <vector>

#include "gbayes/export.h"

namespace gmat { class SparseLdCsr; }

namespace gbayes {

// GIG(1/2, A, B): density proportional to x^(-1/2)
// exp(-(A*x+B/x)/2), x>0. A>0, B>=0.
GBAYES_EXPORT double draw_gig_half(double a, double b, std::mt19937& generator);

struct ContinuousShrinkageInput {
  std::shared_ptr<const gmat::SparseLdCsr> ld;
  std::vector<double> marginal_effects;  // standardized genotype/phenotype scale
  std::vector<std::size_t> block_offsets;  // 0,...,M; no retained cross-block edges
  std::vector<std::string> marker_ids;
  double effective_sample_size{0};
  std::string trait;
};

// Conservative managed reservations, not OS RSS or allocation metadata.
struct DenseBlockDiagnostics {
  bool available{false}; // false for legacy persisted results
  std::size_t budget_bytes{}, required_bytes{}, peak_reserved_bytes{};
  std::size_t peak_ld_payload_bytes{}, block_loads{}, block_releases{};
  std::size_t current_reserved_bytes{}, extracted_entries{};
  double extraction_seconds{};
};
// Checked upper envelope: LD, precision, LLT plus matrix/vector scratch and
// the small population covariance calculations. Throws on arithmetic overflow.
GBAYES_EXPORT std::size_t dense_block_workspace_requirement(
    std::size_t block_dimension, std::size_t populations = 1);
struct ContinuousShrinkageControls {
  std::size_t burnin{500};
  std::size_t sampling_sweeps{500};
  std::size_t thinning{5};
  std::uint32_t seed{1};
  double global_scale{1};
  bool learn_global_scale{false};
  std::size_t maximum_block_dimension{2048};
  std::size_t dense_workspace_budget_bytes{256u * 1024u * 1024u};
};

struct ContinuousShrinkageResult {
  DenseBlockDiagnostics dense_workspace;
  std::vector<double> mean, local_scale_mean, final_effect;
  double residual_scale_mean{}, global_scale_mean{};
  std::size_t retained_draws{};
  ContinuousShrinkageControls controls;
};

// Global-local a=1,b=0.5 hierarchy with fixed phi or an updated global scale
// update. Uses dense Gaussian updates within declared LD blocks and GIG local
// updates. Output effects remain on the standardized genotype scale.
GBAYES_EXPORT ContinuousShrinkageResult fit_continuous_shrinkage(
    const ContinuousShrinkageInput&, const ContinuousShrinkageControls& = {});

}  // namespace gbayes
