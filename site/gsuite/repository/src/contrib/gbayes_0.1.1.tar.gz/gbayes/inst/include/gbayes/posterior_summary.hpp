#pragma once
#include "gbayes/posterior_diagnostics.hpp"
namespace gbayes {
struct PosteriorSummaryControls {
  double probability{.95};
  bool hpd{true}, diagnostics{true};
  std::size_t memory_limit_bytes{64u*1024u*1024u};
};
struct PosteriorSummary {
  std::string status; // available, not_retained, nonfinite, or partially_nonfinite
  std::size_t draws{}, finite_draws{}, omitted_draws{};
  bool estimated{true}; // preserved even when diagnostics are disabled
  double mean{std::numeric_limits<double>::quiet_NaN()}, sd{std::numeric_limits<double>::quiet_NaN()}, median{std::numeric_limits<double>::quiet_NaN()}, minimum{std::numeric_limits<double>::quiet_NaN()}, maximum{std::numeric_limits<double>::quiet_NaN()};
  double probability{std::numeric_limits<double>::quiet_NaN()}, lower{std::numeric_limits<double>::quiet_NaN()}, upper{std::numeric_limits<double>::quiet_NaN()}; // R type-8 equal-tail quantiles
  std::string hpd_method{"disabled"};
  double hpd_lower{std::numeric_limits<double>::quiet_NaN()}, hpd_upper{std::numeric_limits<double>::quiet_NaN()}, hpd_probability{std::numeric_limits<double>::quiet_NaN()};
  std::vector<double> lag1_by_chain; // R acf convention within each original chain
  PosteriorDiagnostics diagnostics; // original chain positions, no nonfinite filtering
};
// Explicit selected post-burn-in draws; no new sampler or automatic retention.
struct PosteriorDraws {
  std::string label, units;
  std::vector<std::string> coordinates;
  std::vector<std::uint32_t> chain_seeds;
  std::size_t first_sweep{}, thinning{1};
  std::vector<std::vector<double>> chains;
  bool estimated{true};
};
struct LabelledPosteriorSummary {
  PosteriorSelection selection;
  std::vector<std::string> coordinates;
  std::string units;
  PosteriorSummary summary;
};
GBAYES_EXPORT PosteriorSummary summarize_trace(const std::vector<std::vector<double>>&,
    const PosteriorSummaryControls& = {},bool estimated=true);
GBAYES_EXPORT PosteriorDraws extract_posterior(const MultivariateResult&,const PosteriorSelection&,std::size_t memory_limit_bytes=64u*1024u*1024u);
GBAYES_EXPORT PosteriorDraws extract_posterior(const BayesCResult&,const PosteriorSelection&,std::size_t memory_limit_bytes=64u*1024u*1024u);
GBAYES_EXPORT PosteriorDraws extract_posterior(const BayesRResult&,const PosteriorSelection&,std::size_t memory_limit_bytes=64u*1024u*1024u);
GBAYES_EXPORT std::vector<LabelledPosteriorSummary> summarize_posterior(const MultivariateResult&,
    const std::vector<PosteriorSelection>&,const PosteriorSummaryControls& = {});
GBAYES_EXPORT std::vector<LabelledPosteriorSummary> summarize_posterior(const BayesCResult&,
    const std::vector<PosteriorSelection>&,const PosteriorSummaryControls& = {});
GBAYES_EXPORT std::vector<LabelledPosteriorSummary> summarize_posterior(const BayesRResult&,
    const std::vector<PosteriorSelection>&,const PosteriorSummaryControls& = {});
// Inputs must be corresponding draws from the SAME fit. Seeds/sweeps are checked
// but cannot prove scientific compatibility. No recycling, reordering or pooling.
// Explicit scale confirmation is required: equal unit strings are not sufficient.
GBAYES_EXPORT PosteriorDraws posterior_ratio(const PosteriorDraws& numerator,const PosteriorDraws& denominator,
    const std::string& label,bool compatible_scales);
GBAYES_EXPORT PosteriorDraws posterior_variance_fraction(const PosteriorDraws& numerator_variance,const PosteriorDraws& other_variance,
    const std::string& label,bool compatible_scales);
GBAYES_EXPORT PosteriorDraws posterior_expected_active(const PosteriorDraws& inclusion_probability,
    std::size_t marker_count,const std::string& label);
// Scalar homogeneous BayesC architecture: M*pi*slab_variance. The caller must
// explicitly confirm that its coding/prior makes this the intended architecture.
GBAYES_EXPORT PosteriorDraws posterior_architecture_variance(const PosteriorDraws& slab_variance,
    const PosteriorDraws& inclusion_probability,std::size_t marker_count,const std::string& label,bool homogeneous_bayesc);
}
