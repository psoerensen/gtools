#pragma once

#include <cstddef>
#include <cstdint>
#include <vector>

#include "gbayes/bayesc.hpp"
#include "gbayes/export.h"

namespace gbayes {

struct PointNormalGibbsControls {
  std::size_t burnin{500};
  std::size_t sampling_sweeps{200};
  std::uint32_t seed{1};
  bool sparse{false};
  bool auto_update{false};  // 2020 paper: sample p, set h2 = b' R b
};

struct PointNormalGibbsResult {
  std::vector<double> mean, pip, final_effect;
  std::vector<double> p_path, h2_path;
  double initial_p{}, initial_h2{};
  PointNormalGibbsControls controls;
};

// C_jj=N_j and score_j=N_j*standardized_marginal_beta_j. The cross-products
// must represent sqrt(N) R sqrt(N) for the same marker order and alleles.
// Posterior means average conditional expectations after burn-in, as in the
// Point-normal posterior means average conditional expectations after burn-in.
// auto_update samples the inclusion fraction and updates h2 from b' R b.
// Caller supplies a PSD-compatible LD operator.
GBAYES_EXPORT PointNormalGibbsResult fit_point_normal_gibbs(
    const FixedGaussianStatistics& data, double p, double h2,
    const PointNormalGibbsControls& controls = {});

}  // namespace gbayes
