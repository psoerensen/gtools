#pragma once

#include <cstddef>
#include <vector>

#include "gbayes/bayesc.hpp"
#include "gbayes/export.h"

namespace gbayes {

struct SummaryVariationalWindow {
  std::size_t begin{}, end{};  // half-open marker range
};

struct SummaryVariationalControls {
  std::size_t maximum_sweeps_per_window{200};
  double coordinate_tolerance{1e-8};
  // Empty means one whole-panel window. Nonempty windows must cover every
  // marker in nondecreasing order and may overlap. Duplicate windows fail.
  std::vector<SummaryVariationalWindow> windows;
};

struct SummaryVariationalResult {
  std::vector<double> mean, variance, pip;
  std::vector<std::size_t> window_sweeps;
  double initial_elbo{}, final_elbo{}, maximum_residual_drift{};
  bool globally_converged{false};  // true only for a single whole-panel window
};

// Fixed p/h2 point-normal mean-field fit on s and C=sqrt(N) R sqrt(N).
// Each window is optimized once, in caller order, while retaining the global
// residual. Sliding windows approximate the full-panel optimum; the single
// whole-panel window has the ordinary coordinate-wise VB fixed point.
GBAYES_EXPORT SummaryVariationalResult fit_summary_variational(
    const FixedGaussianStatistics&, double p, double h2,
    const SummaryVariationalControls& = {});

}  // namespace gbayes
