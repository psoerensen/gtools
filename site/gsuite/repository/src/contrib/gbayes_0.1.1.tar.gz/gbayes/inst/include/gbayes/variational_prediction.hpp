#pragma once
#include <gbayes/export.h>

#include <gsolve/chunk_ridge.hpp>
#include <memory>
#include <functional>
#include <limits>
#include <string>
#include <vector>
namespace gbayes {
struct VariationalPredictionOptions;
struct VariationalPredictionBatch;
struct VariationalPredictionModel;
// Bounded projected chunk Grams, reusable for an immutable design across fits.
// Invalidated when source identity, fixed values, chunk size, cache allowance
// or product thread count changes. Calls sharing a cache are serialized.
// Its numeric storage is included in each fit's memory allowance.
class GBAYES_EXPORT PredictionGramCache {
 public:
  struct ProjectedChunkSeed {
    std::vector<double> diagonal, fixed_coefficients, gram;
  };
  PredictionGramCache();
  ~PredictionGramCache();
  PredictionGramCache(const PredictionGramCache&) = delete;
  PredictionGramCache& operator=(const PredictionGramCache&) = delete;
  // Seed a complete projected-design initialization from a prior traversal.
  // Grams may be empty after the bounded cache fills; diagonal and fixed
  // coefficients must cover every marker. Source/fixed values are immutable.
  void seed_projected_chunks(
      std::shared_ptr<const gsolve::RidgeDesignSource> source,
      gsolve::ConstMatrixView fixed, std::uint64_t chunk_size,
      std::uint64_t limit_bytes, std::uint32_t threads,
      std::vector<ProjectedChunkSeed> chunks);
 private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
  friend VariationalPredictionBatch fit_variational_prediction(
      std::shared_ptr<const gsolve::RidgeDesignSource>, gsolve::ConstMatrixView,
      gsolve::ConstMatrixView, const std::vector<VariationalPredictionModel>&,
      const VariationalPredictionOptions&);
};
// A single normal, or a leading point mass followed by normal components.
// Multipliers are normalized internally to weighted mean one: genetic_variance
// is the total prior variance across active standardized marker effects.
enum class PredictionPriorFamily { normal_mixture, elastic };
struct PredictionPrior {
  std::string name{"ridge"};
  std::vector<double> multipliers{1}, weights{1};
  // Elastic: a symmetric Laplace component with total probability p and a
  // normal component with probability 1-p. f2 is the normal variance share.
  PredictionPriorFamily family{PredictionPriorFamily::normal_mixture};
  double elastic_probability{0}, elastic_normal_variance_fraction{1};
};
struct VariationalPredictionModel {
  PredictionPrior prior{};
  double genetic_variance{1}, residual_variance{1};
  // Strictly increasing source-column indices; empty means all.
  std::vector<std::uint64_t> active_columns{};
  // Full source order; excluded entries are ignored. Means initialize a valid
  // variational distribution and residuals are reconstructed for this design.
  std::vector<double> initial_coefficients{};
  // Optional model-specific response in source row order (e.g. MC probes).
  // Empty uses the common phenotype. Covariates are projected identically.
  std::vector<double> response{};
  // Projected full-row residual matching initial_coefficients; optional.
  std::vector<double> initial_projected_residual{};
};
// Views and callback arguments are borrowed for the synchronous fit only.
// Validation models are the first model_count models and use the common y.
struct PredictionValidation {
  std::shared_ptr<const gsolve::RidgeDesignSource> source{};
  gsolve::ConstMatrixView phenotype{}, fixed{};
  std::size_t model_count{0};
};
enum class PredictionProductBackend { automatic, decoded, packed };
enum class PredictionMarkerSchedule { full, adaptive };
struct VariationalPredictionOptions {
  // Automatic conservatively resolves to decoded; packed is opt-in.
  PredictionProductBackend product_backend{PredictionProductBackend::decoded};
  // Full retains the existing chunk policy. Adaptive schedules individual
  // markers per model and only accepts after a complete marker refresh.
  PredictionMarkerSchedule marker_schedule{PredictionMarkerSchedule::full};
  std::uint64_t marker_refresh_interval{4};
  std::uint64_t chunk_size{128}, maximum_sweeps{100};
  std::uint64_t local_iterations{20}, full_sweep_interval{8};
  bool skip_settled_chunks{true};
  // Maximum uint64 selects the largest cache that fits the numeric budget;
  // zero disables Gram retention. An explicit value caps retained Grams.
  std::uint64_t gram_cache_limit_bytes{
      std::numeric_limits<std::uint64_t>::max()};
  std::uint64_t numeric_memory_limit_bytes{512ULL * 1024 * 1024};
  double objective_tolerance_per_sample{1e-4};
  std::uint32_t threads{1};
  // Empty uses a temporary per-call cache. No source mutations are permitted
  // while retaining a shared cache; use a new source object after changes.
  std::shared_ptr<PredictionGramCache> gram_cache{};
  // Experimental: tol*N local/chunk activity, joint chunk retirement, no
  // forced full revisits. Default retains strict per-model ELBO acceptance.
  bool adaptive_chunk_schedule{false};
  // Shared positive marker weights; normalized to mean one internally.
  std::vector<double> marker_prior_weights{};
  // Reuse matching projected residuals and retained chunk metadata.
  // Skips the final panel reconstruction and monotone-objective audit.
  bool trust_projected_state{false};
  PredictionValidation validation{};
  // Called after each sweep with normalized held-out MSE (empty when no
  // validation source is supplied) and projected residuals. True accepts ALL
  // models under this external rule;
  // never interpreted as strict ELBO convergence. Exceptions propagate.
  std::function<bool(std::uint64_t, const std::vector<double>&,
                     gsolve::ConstMatrixView)> prediction_stop{};
};
struct VariationalPredictionMemoryPlan {
  std::uint64_t working_bytes{0}, gram_cache_bytes{0};
};
// Resolve the Gram allowance against the fit's numeric budget. Automatic
// retention uses all remaining room up to the complete set of chunk Grams.
GBAYES_EXPORT VariationalPredictionMemoryPlan plan_variational_prediction_memory(
    std::uint64_t rows, std::uint64_t columns, std::uint64_t fixed_columns,
    std::size_t model_count, std::uint64_t validation_rows,
    std::size_t validation_model_count,
    const VariationalPredictionOptions& options);
struct VariationalPredictionFit {
  bool converged{false};
  std::uint64_t sweeps{0};
  bool warm_start_used{false};
  bool prediction_stopped{false};
  // Negative ELBO, omitting the common Gaussian likelihood constant.
  std::vector<double> objective_history{};
  std::vector<double> coefficients{}, variances{}, fixed_effects{}, residual{};
};
struct PredictionPhaseTimes {
  // Disjoint wall-time categories, except coordinate_ridge/mixture: these
  // sum worker durations and are subdivisions only with one model thread.
  double total{0}, decode{0}, projection{0}, gram{0}, score{0},
      coordinate{0}, residual{0}, bookkeeping{0};
  double coordinate_ridge{0}, coordinate_mixture{0};
};
struct VariationalPredictionBatch {
  PredictionProductBackend resolved_product_backend{PredictionProductBackend::decoded};
  std::uint64_t decoded_marker_columns{0}, packed_score_marker_columns{0},
      packed_update_marker_columns{0}, marker_model_visits{0},
      skipped_model_markers{0}, full_marker_sweeps{0};
  std::vector<VariationalPredictionFit> fits{};
  std::uint64_t block_reads{0}, gram_builds{0}, gram_cache_bytes{0};
  std::uint64_t gram_cache_reuses{0}; // chunks retained from previous fits
  std::uint64_t skipped_model_chunks{0}, local_updates{0};
  std::uint32_t coordinate_threads{1};
  // Wall time inside source->read_columns only; excludes allocation,
  // covariate projection, Gram construction and matrix products.
  double source_read_seconds{0};
  PredictionPhaseTimes phase_seconds{};
  std::uint64_t validation_block_reads{0};
  // Weighted sum of fixed-effect-projected column squared norms from initialization
  // pass, available without another panel traversal.
  double projected_design_squared_norm{0};
  std::vector<double> validation_normalized_mse{};
};
// Deterministic mean-field Gaussian-mixture updates. Models share a fixed
// design, with optional separate responses; no implicit intercept. Decoding and matrix
// products are shared. Each model retires on per-sample ELBO stabilization.
// Maximum-sweep results remain provisional. Invalid input/arithmetic throws;
// no partial result is published on exception. Source/caller/runtime memory is
// excluded from the conservative numeric budget. Source must remain immutable.
GBAYES_EXPORT VariationalPredictionBatch fit_variational_prediction(
    std::shared_ptr<const gsolve::RidgeDesignSource> source,
    gsolve::ConstMatrixView phenotype, gsolve::ConstMatrixView fixed,
    const std::vector<VariationalPredictionModel>& models,
    const VariationalPredictionOptions& options = {});
}  // namespace gbayes
