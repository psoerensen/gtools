#ifndef GSCORE_ERROR_HPP
#define GSCORE_ERROR_HPP

#include <stdexcept>
#include <string>

#include "gscore/export.h"
#include "gscore/status.hpp"

namespace gscore {

class GSCORE_EXPORT Error : public std::runtime_error {
 public:
  Error(StatusCode code, const std::string& message)
      : std::runtime_error(message), code_(code) {}

  [[nodiscard]] StatusCode code() const noexcept { return code_; }

 private:
  StatusCode code_;
};

}  // namespace gscore

#endif

