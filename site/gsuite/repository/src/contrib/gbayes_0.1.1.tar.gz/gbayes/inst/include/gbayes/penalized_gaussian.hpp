#pragma once
#include "gbayes/gaussian_ridge.hpp"
namespace gbayes {
struct L1QuadraticControls {
  std::size_t maximum_sweeps{10000};
  double tolerance{1e-10}; // max coordinate shift and scaled KKT threshold
};
struct L1QuadraticResult {
  std::vector<double> effects, deviation;
  std::size_t sweeps{};
  double maximum_kkt{}, objective{}; // objective omits y'y/2
};
// Exact PSD local C and score on caller coordinates; no automatic centering.
// Penalties are per-marker nonnegative L1 and L2 coefficients on b-mean.
// Extracted/generalized from gscore::fit_l1_quadratic_summary.
GBAYES_EXPORT L1QuadraticResult fit_l1_quadratic(
    const FixedGaussianStatistics&,const std::vector<double>& mean,
    const std::vector<double>& l1,const std::vector<double>& l2,
    const L1QuadraticControls& = {});
// alpha=0 delegates to the qualified ridge solver. Positive lambda, alpha in [0,1].
GBAYES_EXPORT L1QuadraticResult fit_elastic_net(
    const FixedGaussianStatistics&,const std::vector<double>& mean,double lambda,
    double alpha,const L1QuadraticControls& = {},const gsolve::PcgOptions& = {});
}
