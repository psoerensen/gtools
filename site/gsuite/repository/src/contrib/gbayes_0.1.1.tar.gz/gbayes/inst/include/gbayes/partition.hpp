#pragma once
#include "gbayes/genetic_covariance.hpp"
namespace gbayes {
// Exhaustive disjoint groups in fitted marker order; each group must be nonempty.
struct MarkerPartition {
  std::vector<std::string> marker_ids, group_ids;
  std::vector<std::size_t> marker_group;
};
GBAYES_EXPORT void validate_partition(const MarkerPartition&);
struct PartitionPosterior {
  MarkerPartition partition;
  std::vector<std::string> trait_ids;
  std::size_t draws{};
  // Group-major, trait fastest; expected count, not number of independent signals.
  std::vector<double> expected_active;
  // Group-major T*T, column-major within group.
  // both_active: at least one active marker for each trait, possibly different.
  // shared_active: at least one marker active for both traits.
  std::vector<double> both_active, shared_active;
  // Covariance of the G*T group/trait scores, group-major trait fastest.
  // Contains diagonal AND cross-group blocks, not an additive variance allocation.
  GeneticCovariancePosterior covariance;
  // Optional rows: expected_active draw counts, then both_active, then shared_active.
  std::vector<std::vector<double>> activity_trace;
};
class GBAYES_EXPORT PartitionAccumulator {
  PartitionPosterior state_;
  bool retain_;
  std::unique_ptr<GeneticCovarianceAccumulator> covariance_;
 public:
  PartitionAccumulator(MarkerPartition,std::vector<std::string> traits,
      std::shared_ptr<const GeneticCovarianceReference> reference={},bool retain=false);
  void add(const std::vector<double>& effects,const std::vector<unsigned char>& activity);
  PartitionPosterior summary() const;
};
GBAYES_EXPORT PartitionPosterior combine_partitions(const std::vector<PartitionPosterior>&);
}
