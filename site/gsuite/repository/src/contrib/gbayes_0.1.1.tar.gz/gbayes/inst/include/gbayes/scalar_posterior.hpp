#pragma once
#include "gbayes/partition.hpp"
#include "gbayes/prediction.hpp"
namespace gbayes {
// Optional consumers of retained scalar joint-effect draws; no sampler changes.
struct ScalarPosteriorControls {
  std::shared_ptr<const GeneticCovarianceReference> genetic_reference;
  std::shared_ptr<const MarkerPartition> partition;
  PredictionControls prediction;
  // Estimate for additional summaries/traces/workspace, not the base fit or LD.
  std::size_t memory_limit_bytes{256u*1024u*1024u};
};
}
