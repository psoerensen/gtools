#ifndef GBAYES_EXPORT_H
#define GBAYES_EXPORT_H

#if defined(GBAYES_STATIC_DEFINE)
#  define GBAYES_EXPORT
#elif defined(_WIN32) || defined(__CYGWIN__)
#  if defined(GBAYES_BUILDING_LIBRARY)
#    define GBAYES_EXPORT __declspec(dllexport)
#  else
#    define GBAYES_EXPORT __declspec(dllimport)
#  endif
#elif defined(__GNUC__) && __GNUC__ >= 4
#  define GBAYES_EXPORT __attribute__((visibility("default")))
#else
#  define GBAYES_EXPORT
#endif

#endif
