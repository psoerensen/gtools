#ifndef GSCORE_SUMMARY_FIT_HPP
#define GSCORE_SUMMARY_FIT_HPP

#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "gbayes/bayesc.hpp"
#include "gbayes/bayesr.hpp"
#include "gbayes/point_normal_gibbs.hpp"
#include "gbayes/continuous_shrinkage.hpp"
#include "gbayes/summary_variational.hpp"
#include "gbayes/summary_mixture_variational.hpp"
#include "gmat/sparse_ld_compute.hpp"
#include "gmat/sparse_ld_disk.hpp"
#include "gsolve/chunk_ridge.hpp"
#include "gscore/export.h"

namespace gscore {

// Effects are per standardized genotype and standardized quantitative trait.
// Effects use one reference dosage allele. Per-marker N is optional; methods
// requiring common N reject heterogeneous effective_sample_sizes.
struct SummaryStatistics {
  std::vector<std::string> marker_ids;
  std::vector<std::string> chromosomes;
  std::vector<std::uint64_t> positions_bp;
  std::vector<double> marginal_effects;
  std::vector<double> p_values;
  double effective_sample_size{0};
  std::string trait;
  std::vector<double> effective_sample_sizes;  // optional per-marker N
  std::vector<std::string> allele1, allele2;  // reference dosage alleles
};

// Bounded BED-backed source for pseudo-summary noise. It owns the selected
// panel identity and uses gbits' centered/scaled chunk reader with the same
// observed-mean, missing-as-zero and HWE scaling contract as gmat sparse LD.
class GSCORE_EXPORT CheckedPseudoReference final
    : public gsolve::RidgeDesignSource {
 public:
  CheckedPseudoReference(std::shared_ptr<const gmat::BedPanel> panel,
                         const SummaryStatistics& aligned_summary,
                         std::string sample_set_id);
  ~CheckedPseudoReference() override;
  CheckedPseudoReference(const CheckedPseudoReference&) = delete;
  CheckedPseudoReference& operator=(const CheckedPseudoReference&) = delete;
  std::uint64_t rows() const noexcept override;
  std::uint64_t columns() const noexcept override;
  gsolve::Status read_columns(std::uint64_t begin,
                              gsolve::MatrixView output) const override;
  void validate_summary(const SummaryStatistics&) const;
  const std::string& sample_set_id() const noexcept;
 private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};

// Reported effects may use either allele. Input order may differ from LD order;
// every LD marker must have one exact ID/chromosome/position match.
struct ReportedGwasSummary {
  std::vector<std::string> marker_ids, chromosomes;
  std::vector<std::uint64_t> positions_bp;
  std::vector<std::string> effect_alleles, other_alleles;
  std::vector<double> effects, standard_errors, effective_sample_sizes;
  std::vector<double> p_values;  // optional
  std::string trait;
};

struct SummaryLd {
  std::shared_ptr<const gmat::SparseLdCsr> correlations;
  // The exact options used to construct correlations, supplied by the caller.
  gmat::SparseLdOptions construction;
  // Set by disk loaders/openers; binds marker/coding metadata to LD.
  std::shared_ptr<const gmat::SparseLdDiskResource> disk_resource{};
  // Caller-declared identity of the reference sample set, not a file name.
  std::string sample_set_id{};
  // Alternative to correlations: checked disk reader, no full CSR allocation.
  std::shared_ptr<const gmat::SparseLdDiskReader> disk_reader{};
};

struct ScoreWeights {
  std::vector<std::string> marker_ids;  // immutable ordering identity
  std::vector<double> effects;  // summary marker order; usable by score_bed
  std::uint64_t nonzero_count{0};
};

struct ClumpControls {
  double p_threshold{1};
  double r2_threshold{0.1};
  std::uint64_t window_bp{250000};
};

struct ClumpPathControls {
  double r2_threshold{0.1};
  std::uint64_t window_bp{250000};
};

struct RidgeControls {
  double penalty{1};  // (R + penalty I) effects = marginal_effects
  double relative_tolerance{1e-8};
  std::uint64_t maximum_iterations{1000};
};

struct L1QuadraticControls {
  double lambda{0.01};
  double delta{0.1};
  double tolerance{1e-8};
  std::uint64_t maximum_sweeps{1000};
};

struct L1QuadraticFit {
  ScoreWeights weights;
  std::uint64_t sweeps{0};
  double maximum_kkt_violation{0};
};

struct PointNormalGibbsScoreFit {
  ScoreWeights weights;
  gbayes::PointNormalGibbsResult posterior;
};

struct ContinuousShrinkageScoreFit {
  ScoreWeights weights;
  gbayes::ContinuousShrinkageResult posterior;
};

struct SummaryVariationalScoreFit {
  ScoreWeights weights;
  gbayes::SummaryVariationalResult posterior;
};

struct SummaryWindowOptions {
  double width_cm{1};
  double step_cm{0.125};
};

enum class SummaryModelKind {
  gaussian_ridge,
  l1_quadratic_penalty,
  gaussian_mixture
};

struct SummaryModelCandidate {
  SummaryModelKind kind{SummaryModelKind::gaussian_mixture};
  double penalty{};  // ridge penalty or L1 coefficient
  double quadratic_penalty{};  // used for L1 + quadratic only
  gbayes::SummaryGaussianMixturePrior mixture{};
};

struct SummaryScoreGridOptions {
  SummaryWindowOptions windows{};
  std::size_t maximum_sweeps{200};  // per window for Gaussian mixtures
  double coordinate_tolerance{1e-8};
  std::vector<unsigned char> excluded_test_markers;  // optional 1=exclude
};

struct SummaryScoreGridFit {
  std::vector<gbayes::SummaryVariationalWindow> windows;
  std::vector<double> heldout_correlations;
  std::size_t selected_candidate{};
  ScoreWeights selected_training, selected_full;
};

struct PseudoSummaryOptions {
  double training_fraction{0.9};
  std::uint32_t seed{1};
  std::size_t marker_chunk_size{128};
  std::string noise_reference_sample_set_id{};  // caller-declared provenance
};

struct PseudoSummarySplit {
  SummaryStatistics training, test;
};

// No LD adjustment. Thresholding includes p == threshold.
GSCORE_EXPORT ScoreWeights marginal_weights(const SummaryStatistics&);
// Match reference marker order, flip swapped-allele effects, and convert
// reported effects to standardized marginal effects using
// beta / sqrt(N * se^2 + beta^2). Ambiguous A/T and C/G pairs are rejected.
GSCORE_EXPORT SummaryStatistics prepare_gwas_summary(
    const ReportedGwasSummary&,
    const std::vector<gmat::SparseLdDiskMarker>& reference_markers);
// Load and validate gmat's complete disk CSR. Exact marker identity, position,
// allele coding and construction options are checked when binding the input.
// sample_set_id is supplied by the caller because the disk resource stores
// sample counts but not the selected sample identities.
GSCORE_EXPORT SummaryLd load_summary_ld_from_disk(
    const SummaryStatistics&, const std::string& prefix,
    const std::string& sample_set_id);
// Open once with O(markers) indices and bounded active-column storage. Reuses
// the same fit/grid entry points for ridge, L1 and Gaussian-mixture candidates.
// Files must remain immutable. Each concurrent workflow needs its own reader.
GSCORE_EXPORT SummaryLd open_summary_ld_from_disk(
    const SummaryStatistics&, const std::string& prefix,
    const std::string& sample_set_id, const gmat::SparseLdDiskReadOptions& = {});
GSCORE_EXPORT void validate_summary_ld(
    const SummaryStatistics&, const SummaryLd&);
GSCORE_EXPORT ScoreWeights threshold_weights(const SummaryStatistics&,
                                             double p_threshold);
// Return score columns in caller threshold order. Sorts markers by p once and
// accumulates each newly eligible marker only once across the path.
GSCORE_EXPORT std::vector<ScoreWeights> threshold_weights_path(
    const SummaryStatistics&, const std::vector<double>& p_thresholds);
// Greedy ascending-p clumping; ties use summary order. Accepts materialized or
// indexed disk LD retaining all pairs eligible for the requested window/r2 rule.
GSCORE_EXPORT ScoreWeights clump_threshold_weights(
    const SummaryStatistics&, const SummaryLd&, const ClumpControls&);
// Clump once at the largest threshold, then form every requested prefix.
GSCORE_EXPORT std::vector<ScoreWeights> clump_threshold_weights_path(
    const SummaryStatistics&, const SummaryLd&, const ClumpPathControls&,
    const std::vector<double>& p_thresholds);
// LD-aware Gaussian shrinkage. An indefinite sparsified R can cause a checked
// non-positive-curvature failure; no implicit LD repair is performed.
GSCORE_EXPORT ScoreWeights ridge_weights(const SummaryStatistics&,
                                         const SummaryLd&, const RidgeControls&);
// Coordinate descent for 0.5 b' R b - beta_hat' b + sum(lambda_j |b_j| +
// 0.5 delta_j b_j^2), with lambda_j and delta_j multiplied by
// sqrt(max(N)/N_j). Fails rather than returning an unconverged path.
GSCORE_EXPORT L1QuadraticFit fit_l1_quadratic_summary(const SummaryStatistics&,
                                        const SummaryLd&,
                                        const L1QuadraticControls&);
GSCORE_EXPORT PointNormalGibbsScoreFit fit_point_normal_gibbs_score(
    const SummaryStatistics&, const SummaryLd&, double p, double h2,
    const gbayes::PointNormalGibbsControls&);
GSCORE_EXPORT SummaryVariationalScoreFit fit_summary_variational_score(
    const SummaryStatistics&, const SummaryLd&, double p, double h2,
    const gbayes::SummaryVariationalControls&);
GSCORE_EXPORT SummaryVariationalScoreFit fit_summary_gaussian_mixture_score(
    const SummaryStatistics&, const SummaryLd&,
    const gbayes::SummaryGaussianMixturePrior&,
    const gbayes::SummaryVariationalControls&);
// Exact block-diagonal fixed-prior fit using one validated disk LD block at a
// time. Rejects retained cross-block edges; does not implement overlapping
// windows or the global-residual grid estimator.
GSCORE_EXPORT ScoreWeights fit_summary_gaussian_mixture_blocks_from_disk(
    const SummaryStatistics&, const std::string& ld_prefix,
    const std::string& reference_sample_set_id,
    const std::vector<std::uint64_t>& block_offsets,
    const gbayes::SummaryGaussianMixturePrior&,
    const gbayes::SummaryVariationalControls& = {},
    std::uint64_t maximum_block_size = 2048);
// Contiguous chromosome groups, nondecreasing genetic cM within each.
// Windows are half-open in marker index and may overlap.
GSCORE_EXPORT std::vector<gbayes::SummaryVariationalWindow>
make_summary_genetic_windows(const SummaryStatistics&,
                             const std::vector<double>& positions_cm,
                             const SummaryWindowOptions& = {});
// Fit Gaussian, L1+quadratic, or Gaussian-mixture candidates on training
// summaries; select by beta_test' w / sqrt(w' R_test w), then fit the winner
// on full summaries. Caller establishes train/test independence. A separate
// test LD reference is particularly important for pseudo-summary selection.
GSCORE_EXPORT SummaryScoreGridFit fit_summary_score_grid(
    const SummaryStatistics& training, const SummaryStatistics& test,
    const SummaryStatistics& full, const SummaryLd& fitting_ld,
    const SummaryLd& test_ld,
    const std::vector<double>& positions_cm,
    const std::vector<SummaryModelCandidate>&,
    const SummaryScoreGridOptions& = {});
// Draw correlated pseudo training/test summaries from one full summary and
// a centered, standardized, marker-aligned reference design. The two outputs
// preserve the full sample-size-weighted marginal effect exactly.
GSCORE_EXPORT PseudoSummarySplit make_pseudo_summary_split(
    const SummaryStatistics& full,
    const gsolve::RidgeDesignSource& noise_reference,
    const PseudoSummaryOptions& = {});
// Checked panel overload verifies marker coding and the caller-declared
// selected-sample label. Cohort independence still requires caller evidence.
GSCORE_EXPORT PseudoSummarySplit make_pseudo_summary_split(
    const SummaryStatistics& full,
    const CheckedPseudoReference& noise_reference,
    const PseudoSummaryOptions& = {});
GSCORE_EXPORT SummaryScoreGridFit fit_summary_score_grid_from_full(
    const SummaryStatistics& full,
    const gsolve::RidgeDesignSource& noise_reference,
    const SummaryLd& fitting_ld, const SummaryLd& test_ld,
    const std::vector<double>& positions_cm,
    const std::vector<SummaryModelCandidate>&,
    const PseudoSummaryOptions& = {},
    const SummaryScoreGridOptions& = {});
GSCORE_EXPORT SummaryScoreGridFit fit_summary_score_grid_from_full(
    const SummaryStatistics& full,
    const CheckedPseudoReference& noise_reference,
    const SummaryLd& fitting_ld, const SummaryLd& test_ld,
    const std::vector<double>& positions_cm,
    const std::vector<SummaryModelCandidate>&,
    const PseudoSummaryOptions& = {},
    const SummaryScoreGridOptions& = {});
GSCORE_EXPORT ContinuousShrinkageScoreFit fit_continuous_shrinkage_score(
    const SummaryStatistics&, const SummaryLd&,
    const std::vector<std::size_t>& block_offsets,
    const gbayes::ContinuousShrinkageControls&);
// Fixed-prior BayesC/BayesR posterior mean effects. The full gbayes result is
// available by calling gbayes directly using the same prepared statistics.
GSCORE_EXPORT ScoreWeights bayesc_weights(
    const SummaryStatistics&, const SummaryLd&, const gbayes::BayesCPrior&,
    const gbayes::BayesCControls&);
GSCORE_EXPORT ScoreWeights bayesr_weights(
    const SummaryStatistics&, const SummaryLd&, const gbayes::BayesRPrior&,
    const gbayes::BayesCControls&);

}  // namespace gscore

#endif
