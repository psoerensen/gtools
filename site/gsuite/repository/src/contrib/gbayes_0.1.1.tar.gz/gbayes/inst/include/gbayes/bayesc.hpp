#pragma once
#include <cstddef>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>
#include "gbayes/export.h"
#include "gbayes/priors.hpp"
#include "gbayes/annotation.hpp"
#include "gbayes/scalar_posterior.hpp"
namespace gmat { class SparseLdCsr; class SparseLdDiskReader; }
namespace gbayes {
// Per-chain likelihood state; implementations may work in marker, factor or
// individual observation space. Keep each chain's mutable residual independent.
class GBAYES_EXPORT GaussianResidual {
 public:
  virtual ~GaussianResidual() = default;
  virtual std::size_t dimension() const noexcept = 0;
  virtual double conditional_score(std::size_t marker, double old_effect) const = 0;
  virtual void update(std::size_t marker, double difference) = 0;
  virtual void validate() const = 0;
  virtual double rebuild(const std::vector<double>& effects) = 0;
  virtual std::vector<double> marker_residual() const = 0;
  // Exact implementation-coordinate state for deterministic continuation.
  virtual std::vector<double> working_state() const = 0;
  virtual void restore_working_state(const std::vector<double>&) = 0;
  virtual double residual_sse(double yy,const std::vector<double>& effects) const = 0;
  virtual double fitted_quadratic(const std::vector<double>& effects) const = 0;
};
// Immutable cross-products. Implementations must represent a symmetric PSD C.
class GBAYES_EXPORT CrossProducts {
 public:
  virtual ~CrossProducts() = default;
  virtual std::size_t size() const noexcept = 0;
  virtual double diagonal(std::size_t j) const = 0;
  virtual void add_column(std::size_t j, double scale, std::vector<double>& target) const = 0;
  virtual std::vector<double> multiply(const std::vector<double>& x) const = 0;
  // Default implementation preserves the original dense/LD marker-space path.
  virtual std::unique_ptr<GaussianResidual> make_residual(const std::vector<double>& score,
      const std::vector<double>& response_coordinates = {}) const;
  virtual void validate_normalization(const GaussianNormalization&,
      const std::vector<double>& response_coordinates) const;
  // Strong-LD neighbours for optional reversible active/null relocation moves.
  // Implementations may override this to avoid dense column scans.
  virtual std::vector<std::vector<std::size_t>> ld_friends(
      double minimum_r2,std::size_t maximum_friends) const;
  // Opt in only if concurrent const calls and independent residuals are safe.
  // Callers must not mutate shared backing storage during a fit.
  virtual bool concurrent_reads() const noexcept { return false; }
  virtual bool truncated() const noexcept { return false; }
  // Optional storage hint; must not change the represented matrix or residual.
  // Disk implementations may enforce an explicit active-column memory limit.
  virtual void prepare_window(std::size_t, std::size_t) const {}
  // Verifies that entries joining distinct declared blocks are numerically zero.
  // This is a one-time contract check for block-specific likelihood scales.
  void validate_disjoint_blocks(const std::vector<std::size_t>& marker_block,
      double relative_tolerance=1e-10) const;
};
// Dense column-major C; validates dimensions, finiteness and symmetry.
GBAYES_EXPORT std::shared_ptr<const CrossProducts> dense_cross_products(
    std::size_t dimension, std::vector<double> matrix);
// Owns a shared reference to installed gmat storage; C = sqrt(D) R sqrt(D).
GBAYES_EXPORT std::shared_ptr<const CrossProducts> ld_cross_products(
    std::shared_ptr<const gmat::SparseLdCsr> ld, std::vector<double> marker_ss);
// Uses a checked gmat reader and one incident-column cache. Each fit needs its
// own operator; the cache/reader diagnostics are not safe for concurrent calls.
GBAYES_EXPORT std::shared_ptr<const CrossProducts> disk_ld_cross_products(
    std::shared_ptr<const gmat::SparseLdDiskReader> ld, std::vector<double> marker_ss);
struct FixedGaussianStatistics {
  std::shared_ptr<const CrossProducts> cross_products;
  std::vector<double> score; // X'y, already centered/residualized on declared scale
  std::vector<std::string> marker_ids;
  std::string trait, effect_units, provenance;
  std::vector<double> response_coordinates; // factor-space response; empty for ordinary C
};
struct BayesCPrior {
  double residual_variance{1.0};
  double slab_variance{1.0};
  double inclusion_probability{0.5};
  // Optional fixed values in data.marker_ids order; empty uses the global prior.
  // Inclusion probabilities lie strictly inside (0,1); variance multipliers >0.
  std::vector<double> marker_inclusion_probabilities{};
  std::vector<double> marker_variance_multipliers{};
  // Optional centred logistic inclusion model; excludes fixed marker probabilities.
  std::shared_ptr<const LogisticAnnotationPrior> inclusion_annotation{};
  std::shared_ptr<const LogVariancePrior> variance_annotation{};
};
// Complete mutable state required to continue one scalar chain exactly.
// Cross-products and priors remain caller-owned immutable model inputs.
struct ScalarChainState {
  std::uint32_t seed{};
  std::size_t completed_sweeps{};
  std::string rng_state;
  std::vector<double> effects;
  std::vector<double> working_residual;
  std::vector<std::size_t> components, marker_order;
  GaussianParameters parameters;
  double genetic_variance{}, working_residual_variance{};
  std::vector<double> block_residual_variance;
  std::vector<unsigned char> block_selected;
  std::vector<double> inclusion_coefficients, component_coefficients,
      variance_coefficients;
  // Present only when the BED null-marker scheduler was enabled.
  struct MarkerScheduleState {
    std::size_t full_sweep_every{}, base_interval{}, maximum_interval{}, candidate_lifetime{};
    double candidate_threshold{};
    bool burnin_only{};
    std::vector<std::size_t> next_due, candidate_until;
    std::vector<unsigned char> hot;
    std::size_t marker_updates{}, full_sweeps{};
  } marker_schedule;
};
using MarkerScheduleState = ScalarChainState::MarkerScheduleState;
struct BayesCControls {
  std::size_t burnin{100};
  std::size_t sampling_sweeps{1000}; // excludes burnin
  std::size_t thinning{1}; // retain post-burn sweeps 0, thinning, ...
  std::vector<std::uint32_t> chain_seeds{1}; // exact mt19937 seeds; no hidden mapping
  bool retain_diagnostics{false}; // parameter/active-count traces at retained sweeps
  bool conditional_moments{false}; // Rao-Blackwellized BayesC marker summaries
  unsigned threads{1}; // positive upper bound on concurrent chains, not marker updates
  struct LdSwap {
    double probability{0.0};
    double minimum_r2{0.8};
    std::size_t maximum_friends{50};
    std::size_t moves{1};
  } ld_swap;
  struct MarkerSchedule {
    bool enabled{false}; // exact full sweeps remain the default
    std::size_t full_sweep_every{10}; // zero also requests full sweeps
    std::size_t base_interval{50}, maximum_interval{200};
    double candidate_threshold{1e-3};
    std::size_t candidate_lifetime{20};
    bool burnin_only{false};
  } marker_schedule;
  // Empty starts seeded chains. Otherwise one state per seed; burnin must be 0.
  std::vector<ScalarChainState> initial_states;
};
struct ChainTrace {
  std::vector<GaussianParameters> parameters;
  std::vector<double> active_markers;
  std::vector<double> genetic_variance;
  std::vector<double> working_residual_variance;
  std::vector<std::vector<double>> block_residual_variance;
};
// Individual-level quantities use the selected observation scale. Traces cover
// every sweep, including burnin, as in sblr; CPO uses retained draws only.
struct IndividualBedScalarOutput {
  bool available{false};
  double final_vg{}, final_vle{}, final_vld{};
  double mean_vg{}, mean_vle{}, mean_vld{}; // all post-burnin sweeps
  double log_cpo{}, mean_log_cpo{};
  std::vector<double> postburn_weight_mean;
  std::vector<double> vb_trace, ve_trace, vg_trace, vle_trace, vld_trace;
  std::vector<std::vector<double>> weight_trace; // sweep x component
};
struct BetweenChainMarkerSummary {
  // Available for every likelihood provider. Sample SD, min and max of each
  // chain's posterior marker mean/PIP; one chain has SD zero.
  std::vector<double> mean_sd, mean_min, mean_max;
  std::vector<double> pip_sd, pip_min, pip_max;
};
struct BayesCChain {
  std::uint32_t seed{};
  std::size_t retained_draws{};
  std::vector<double> mean, second_moment, pip, final_effect, final_score_residual;
  // Rao-Blackwellized retained-sweep expectations under the full conditional.
  // First/second moments include the spike at zero.
  std::vector<double> conditional_inclusion, conditional_first_moment,
      conditional_second_moment;
  std::vector<unsigned char> final_inclusion;
  double maximum_residual_drift{}; // final marker-space residual discrepancy
  double maximum_working_residual_drift{}; // rebuilds in implementation coordinates
  std::size_t working_residual_dimension{};
  GaussianParameters parameter_mean, final_parameters;
  double final_genetic_variance{};
  double final_working_residual_variance{};
  std::vector<double> block_residual_variance_mean, final_block_residual_variance;
  std::size_t ld_swap_attempted{}, ld_swap_accepted{};
  std::size_t scheduled_marker_updates{}, scheduled_full_sweeps{};
  IndividualBedScalarOutput individual_bed;
  ScalarChainState continuation_state;
  ChainTrace trace;
  AnnotationChain annotation; // empty when no annotation model
  AnnotationChain variance_annotation;
  GeneticCovariancePosterior genetic_covariance;
  PartitionPosterior partition;
  PredictionPosterior prediction;
};
struct BayesCResult {
  std::vector<std::string> marker_ids;
  std::string trait, effect_units, provenance;
  BayesCPrior prior;
  BayesCControls controls;
  GaussianLearning learning;
  bool truncated_likelihood{false};
  GaussianParameters parameter_mean;
  std::vector<double> block_residual_variance_mean;
  std::vector<double> mean, variance, pip;
  std::vector<double> conditional_inclusion, conditional_first_moment,
      conditional_second_moment;
  IndividualBedScalarOutput individual_bed; // pooled final values and traces
  BetweenChainMarkerSummary between_chain;
  std::vector<BayesCChain> chains;
  unsigned threads_used{1}; // actual OpenMP team size, bounded by threads and chains
  AnnotationSummary annotation, variance_annotation;
  ScalarPosteriorControls posterior_controls;
  std::size_t estimated_posterior_memory_bytes{};
  GeneticCovariancePosterior genetic_covariance;
  PartitionPosterior partition;
  PredictionPosterior prediction;
  // Selected retained traces support separate diagnostics, not a convergence certificate.
};
GBAYES_EXPORT BayesCResult fit_bayesc(const FixedGaussianStatistics& data,
                                    const BayesCPrior& prior = {},
                                    const BayesCControls& controls = {});
// Learning is explicit; the three-argument entry point remains fixed-parameter.
GBAYES_EXPORT BayesCResult fit_bayesc(const FixedGaussianStatistics& data,
    const BayesCPrior& prior, const BayesCControls& controls,
    const GaussianLearning& learning);
// Optional posterior capture; existing overloads leave it disabled.
GBAYES_EXPORT BayesCResult fit_bayesc(const FixedGaussianStatistics&,
    const BayesCPrior&, const BayesCControls&, const GaussianLearning&,
    const ScalarPosteriorControls&);
GBAYES_EXPORT bool parallel_chains_available() noexcept;
GBAYES_EXPORT const char* version_string() noexcept;
}
