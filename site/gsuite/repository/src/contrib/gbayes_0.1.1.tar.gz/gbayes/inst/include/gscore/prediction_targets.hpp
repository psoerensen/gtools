#pragma once
#include "gscore/multivariate_score.hpp"
#include "gbayes/prediction.hpp"
namespace gscore {
struct PredictionTargetRequest {
  MultivariateScoreRequest scoring; // coefficients empty, score_count zero
  std::vector<std::uint64_t> sample_indices; // explicit ordered physical BED subset
  std::vector<std::string> target_ids; // same subset order
  std::string target_set_id, provenance;
  std::size_t preparation_memory_limit_bytes{256u*1024u*1024u};
};
// Optional gscore::summary. Read selected BED targets once into immutable gbits
// packed storage. Uses declared frequencies, never frequencies of target batches.
GSCORE_EXPORT std::shared_ptr<const gbayes::PredictionProjection> prepare_prediction_targets(
    const PredictionTargetRequest&);
}
