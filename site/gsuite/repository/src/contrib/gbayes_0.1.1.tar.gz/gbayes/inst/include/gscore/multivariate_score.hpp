#pragma once
#include "gscore/bed_score.hpp"
#include "gbayes/multivariate.hpp"
namespace gscore {
// The caller supplies already aligned marker/allele metadata and scale conversion.
// No harmonisation, strand inference or allele flipping is performed here.
struct MultivariateScoreRequest {
  BedScoreRequest bed; // leave coefficients empty and score_count zero
  std::vector<std::string> marker_ids; // selected BED markers, in fit order
  std::vector<std::string> effect_counted_alleles, bed_counted_alleles;
  std::vector<double> effect_multipliers; // explicit fit -> BED coding conversion
  std::vector<std::string> sample_ids; // optional, in physical BED sample order
};
struct MultivariateScoreResult {
  ScoreResult scores; // posterior mean genetic scores; no phenotype intercept
  std::vector<std::string> trait_ids, sample_ids;
};
// In the optional gscore::summary target. All traits share one tiled BED pass.
GSCORE_EXPORT MultivariateScoreResult score_multivariate_mean(
    const gbayes::MultivariateResult&, const MultivariateScoreRequest&);
}
