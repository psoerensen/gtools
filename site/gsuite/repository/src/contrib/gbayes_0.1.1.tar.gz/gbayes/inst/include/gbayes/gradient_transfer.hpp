#pragma once
#include "gbayes/bayesc.hpp"
#include <functional>
namespace gbayes {
struct GradientDescentControls { std::size_t maximum_sweeps{100};double learning_rate{0.02}; };
enum class GradientStop { iteration_limit, validation_decline };
struct GradientDescentResult {
 std::vector<double> effects;
 std::vector<double> training_objective,validation_correlation; // includes iteration zero
 std::size_t completed_sweeps{},selected_sweep{};
 double effective_step{};
 GradientStop stop{GradientStop::iteration_limit};
};
// Cyclic coordinate gradients, eta=learning_rate/mean(Cjj), source initialization.
// No penalty. Optional deterministic validation correlation selects preceding
// iterate on first strict decline; otherwise return last budgeted iterate.
// Callback must use receiver validation data, never held-out test outcomes.
// Throws on invalid/unstable step or numerical failure; no failed fit returned.
GBAYES_EXPORT GradientDescentResult fit_gradient_early_stopping(
 const FixedGaussianStatistics&,const std::vector<double>& initial,
 const GradientDescentControls& = {},
 const std::function<double(const std::vector<double>&)>& validation = {});
}
