#pragma once
#include "gbayes/continuous_shrinkage.hpp"
namespace gbayes {
enum class PopulationShrinkageHierarchy { prs_csx, jointprs_reference };
// density x^(p-1) exp(-(A*x+B/x)/2), A>0,B>0; B=0 allowed for p>0.
GBAYES_EXPORT double draw_gig(double p, double a, double b, std::mt19937 &);
struct PopulationShrinkageControls {
  ContinuousShrinkageControls sampling;
  double local_shape{1}, auxiliary_shape{.5};
  // Reference PRS-CSx applies min(psi,1) after the GIG draw; this is recorded,
  // not represented as an exact draw from a truncated full conditional.
  bool reference_local_cap{true};
  PopulationShrinkageHierarchy hierarchy{PopulationShrinkageHierarchy::prs_csx};
  // JointPRS reference: pairwise rho bound=min(cap_t*cap_u,.99), RW width .02.
  std::vector<double> correlation_caps;
};
struct PopulationPosterior {
  DenseBlockDiagnostics dense_workspace;
  std::vector<std::vector<double>> mean, second_moment, final_effect;
  std::vector<double> local_scale_mean, residual_scale_mean;
  double global_scale_mean{};
  std::size_t retained_draws{};
  std::vector<std::string> monitored_names;
  // Draw-major: sigma for each population, phi, mean(psi), first beta/pop.
  std::vector<double> monitored_draws;
  std::vector<double> correlation_mean,
      correlation_acceptance; // column-major P x P
};
struct PopulationShrinkageResult : PopulationPosterior {
  PopulationShrinkageControls controls;
};
// First route: common ordered marker intersection; population-specific LD/n.
GBAYES_EXPORT PopulationShrinkageResult
fit_population_shrinkage(const std::vector<ContinuousShrinkageInput> &,
                         const PopulationShrinkageControls & = {});

// Diagnostic-only starts: empty vectors retain the reference defaults.
struct PopulationShrinkageStart {
  std::vector<std::vector<double>> effects;
  std::vector<double> residual_scales, local_scales, correlation;
};
// The same reference transition with dispersed starts and extra monitored
// moments. Callers must retain these starts alongside diagnostic output;
// ordinary fit and result persistence contracts are unchanged.
GBAYES_EXPORT PopulationShrinkageResult diagnose_population_shrinkage(
    const std::vector<ContinuousShrinkageInput> &,
    const PopulationShrinkageControls &, const PopulationShrinkageStart &);
GBAYES_EXPORT double jointprs_pair_log_target(double rho,
                                              const std::vector<double> &b0,
                                              const std::vector<double> &b1,
                                              const std::vector<double> &psi,
                                              double n0, double n1,
                                              double sigma0, double sigma1);
} // namespace gbayes
