#pragma once
#include "gbayes/multivariate.hpp"
#include "gbayes/bayesr.hpp"
#include <limits>
namespace gbayes {
struct PosteriorDiagnostics {
  std::string status;
  std::size_t chains{}, draws_per_chain{};
  double rhat{std::numeric_limits<double>::quiet_NaN()};
  double ess_bulk{std::numeric_limits<double>::quiet_NaN()};
  double ess_mean{std::numeric_limits<double>::quiet_NaN()};
  double posterior_sd{std::numeric_limits<double>::quiet_NaN()};
  double mcse_mean{std::numeric_limits<double>::quiet_NaN()};
  bool ess_stability_bound_applied{false};
};
// Chains of post-burn-in retained scalar draws, equal length. No silent truncation
// except dropping the middle draw of odd-length chains when splitting.
// estimated=false identifies fixed quantities, not evidence of convergence.
GBAYES_EXPORT PosteriorDiagnostics diagnose_trace(const std::vector<std::vector<double>>&,
    bool estimated=true,std::size_t memory_limit_bytes=64u*1024u*1024u);
enum class PosteriorQuantity {
  latent_covariance, pattern_weight, component_weight,
  pattern_coefficient, variance_coefficient, component_coefficient,
  genetic_covariance, partition_covariance, partition_activity, prediction_score,
  residual_variance, slab_variance, mixture_weight, inclusion_coefficient,
  active_markers, group_covariance, sampling_error_covariance,
  block_residual_variance
};
struct PosteriorSelection {std::string label;PosteriorQuantity quantity;std::size_t index{};};
struct LabelledPosteriorDiagnostics {PosteriorSelection selection;PosteriorDiagnostics diagnostics;};
// Select compact traces explicitly; no all-marker trace capture or automatic stopping.
GBAYES_EXPORT std::vector<LabelledPosteriorDiagnostics> diagnose_posterior(
    const MultivariateResult&,const std::vector<PosteriorSelection>&,
    std::size_t memory_limit_bytes=64u*1024u*1024u);
GBAYES_EXPORT std::vector<LabelledPosteriorDiagnostics> diagnose_posterior(
    const BayesCResult&,const std::vector<PosteriorSelection>&,
    std::size_t memory_limit_bytes=64u*1024u*1024u);
GBAYES_EXPORT std::vector<LabelledPosteriorDiagnostics> diagnose_posterior(
    const BayesRResult&,const std::vector<PosteriorSelection>&,
    std::size_t memory_limit_bytes=64u*1024u*1024u);
}
