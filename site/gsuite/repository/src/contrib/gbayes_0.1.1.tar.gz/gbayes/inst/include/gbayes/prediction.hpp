#pragma once
#include "gbayes/export.h"
#include <cstddef>
#include <memory>
#include <string>
#include <vector>
namespace gbayes {
struct PredictionTargetInfo {
  std::vector<std::string> marker_ids, target_ids, counted_alleles;
  std::vector<double> effect_multipliers;
  std::string target_set_id, genotype_coding, provenance;
  std::vector<double> allele_frequencies; // optional for general projections; fixed BED coding frequencies
};
// Immutable caller-owned projection. Genotype application belongs to gscore;
// gbayes only requires aligned effects -> selected target genetic scores.
// Must be a deterministic linear projection with immutable coding/metadata.
// workspace_bytes reports peak per-call transient storage, excluding shared targets.
class GBAYES_EXPORT PredictionProjection {
 public:
  virtual ~PredictionProjection()=default;
  virtual const PredictionTargetInfo& info() const noexcept=0;
  // Effects marker-major/trait-fastest; output target-major/trait-fastest.
  virtual std::vector<double> project(const std::vector<double>& effects,
      std::size_t traits,std::size_t begin,std::size_t count) const=0;
  virtual std::size_t workspace_bytes(std::size_t traits,std::size_t batch_size) const=0;
  virtual bool concurrent_reads() const noexcept {return false;}
  virtual unsigned projection_threads() const noexcept {return 1;}
};
struct PredictionControls {
  std::shared_ptr<const PredictionProjection> targets;
  std::size_t batch_size{64};
  bool retain_draws{false}; // explicit opt-in for selected SCORE draws, not effects
};
struct PredictionPosterior {
  PredictionTargetInfo targets;
  std::vector<std::string> trait_ids;
  std::size_t draws{};
  std::vector<double> mean; // N*T, target-major
  // N*T*T; within-target cross-trait posterior covariance, column-major per target.
  // Divisor draws. Diagonal = individual genetic-score posterior variance.
  std::vector<double> covariance;
  std::vector<std::vector<double>> score_trace; // optional rows N*T
};
GBAYES_EXPORT void validate_prediction_targets(const PredictionTargetInfo&);
class GBAYES_EXPORT PredictionAccumulator {
  PredictionControls controls_;
  PredictionPosterior state_;
  bool failed_{false};
 public:
  PredictionAccumulator(PredictionControls,std::vector<std::string> trait_ids);
  // After a projection failure, discard this accumulator; partial output is unavailable.
  void add(const std::vector<double>& effects);
  PredictionPosterior summary() const;
};
GBAYES_EXPORT PredictionPosterior combine_predictions(const std::vector<PredictionPosterior>&);
}
