test_that("panel validation audits parsed identities including unused components", {
  first <- write_tiny_plink(matrix(c(0,1,2), ncol=1L), "first-a")
  second <- write_tiny_plink(matrix(c(2,1,0), ncol=1L), "second-a")
  on.exit({unlink_tiny_plink(first); unlink_tiny_plink(second)}, add=TRUE)
  G <- gprep(bedfiles=c(first$paths[["bed"]],second$paths[["bed"]]),rsids="first-a")
  fam <- read.table(second$paths[["fam"]], stringsAsFactors=FALSE)
  changed <- fam; changed$V1[[1L]] <- "changed-family"
  write.table(changed,second$paths[["fam"]],quote=FALSE,row.names=FALSE,col.names=FALSE)
  expect_error(validate_Glist(G), "identical ordered FAM identities")
  expect_error(gprep(bedfiles=G$bedfiles, rsids="first-a"),
               "identical ordered FAM identities")
  write.table(fam,second$paths[["fam"]],quote=FALSE,row.names=FALSE,col.names=FALSE)
  bim <- read.table(second$paths[["bim"]], stringsAsFactors=FALSE)
  bim$V2[[1L]] <- "first-a"
  write.table(bim,second$paths[["bim"]],quote=FALSE,row.names=FALSE,col.names=FALSE)
  expect_error(validate_Glist(G), "source marker IDs must be globally unique")
})

test_that("gbase checks its exact native contracts", {
  info <- gbase_native_info()
  expect_identical(info$gmat$header_version, info$gmat$runtime_version)
  expect_equal(info$gmat$header_abi, 0)
  expect_equal(info$gmat$runtime_abi, 0)
  expect_identical(info$gbits$header_version, "0.21.0")
  expect_equal(info$gbits$header_abi, 4)
  expect_identical(info$gbits$runtime_version, "0.21.0")
  expect_equal(info$gbits$runtime_abi, 4)
  expect_identical(info$gsolve$header_version, info$gsolve$runtime_version)
  expect_equal(info$gsolve$header_abi, 4)
  expect_equal(info$gsolve$runtime_abi, 4)
})

test_that("gprep prepares deterministic canonical summaries", {
  fixture <- write_tiny_plink(matrix(c(
    0, 1, 2,
    1, 2, NA,
    2, 0, 1,
    0, 1, 2
  ), nrow = 4L, byrow = TRUE), c("rs-a", "rs-b", "rs-c"))
  on.exit(unlink_tiny_plink(fixture), add = TRUE)
  value <- gprep(study = "tiny", bedfiles = fixture$paths[["bed"]],
    ids = c("I3", "I1", "I0"), rsids = c("rs-c", "rs-a"))
  expect_s3_class(value, "gs_genotypes")
  expect_identical(class(value), c("gs_genotypes", "Glist"))
  expect_identical(value$study_ids, c("I3", "I1", "I0"))
  expect_identical(value$rsids, list(c("rs-a", "rs-c")))
  expect_equal(value$source_marker_indices_0based, list(c(0, 2)))
  expect_equal(value$physical_marker_counts, 3)
  expect_equal(value$n0, list(c(2, 0)))
  expect_equal(value$n1, list(c(1, 0)))
  expect_equal(value$n2, list(c(0, 2)))
  expect_equal(value$nmiss, list(c(0, 1)))
  expect_equal(value$af, list(c(1 / 6, 1)))
  expect_invisible(validate_Glist(value))

  saved <- tempfile(fileext = ".rds")
  on.exit(unlink(saved), add = TRUE)
  saveRDS(value, saved)
  expect_identical(readRDS(saved), value)
})

test_that("full-panel preparation keeps every physical row across files", {
  first <- write_tiny_plink(matrix(c(0,1,2,1,2,0), ncol=2L), c("z", "a"))
  second <- write_tiny_plink(matrix(c(2,1,NA,1,0,0), ncol=2L), c("d", "b"))
  on.exit({ unlink_tiny_plink(first); unlink_tiny_plink(second) }, add=TRUE)
  paths <- c(first$paths[["bed"]], second$paths[["bed"]])
  full <- gprep(bedfiles=paths)
  reference <- gprep(bedfiles=paths, rsids=c("a", "b", "d", "z"))
  expect_identical(full, reference)
  expect_identical(full$rsids, list(c("z", "a"), c("d", "b")))
  expect_identical(full$ids, c("I0", "I1", "I2"))
  expect_identical(full$source_marker_indices_0based, list(c(0, 1), c(0, 1)))
  expect_identical(full$sample_source_indices_0based, c(0, 1, 2))
  expect_identical(full$nmiss, list(c(0, 0), c(1, 0)))

  bim <- read.table(second$paths[["bim"]], stringsAsFactors=FALSE)
  duplicate <- bim
  duplicate$V2[1L] <- "z"
  write.table(duplicate, second$paths[["bim"]], quote=FALSE,
              row.names=FALSE, col.names=FALSE)
  expect_error(gprep(bedfiles=paths), "Marker IDs must be globally unique")
  write.table(bim[1L,,drop=FALSE], second$paths[["bim"]], quote=FALSE,
              row.names=FALSE, col.names=FALSE)
  expect_error(gprep(bedfiles=paths), "BIM row count does not match BED")
})

test_that("gprep retains empty components after marker selection", {
  first <- write_tiny_plink(matrix(c(0, 1, 2, 1, 2, 0), ncol = 2L),
    c("first-a", "first-b"))
  second <- write_tiny_plink(matrix(c(2, 1, 0), ncol = 1L), "second-a")
  on.exit({ unlink_tiny_plink(first); unlink_tiny_plink(second) }, add = TRUE)

  value <- gprep(
    bedfiles = c(first$paths[["bed"]], second$paths[["bed"]]),
    rsids = "second-a")

  expect_identical(value$rsids, list(character(), "second-a"))
  expect_identical(value$mchr, c(0L, 1L))
  expect_identical(value$n0[[1L]], numeric())
  expect_identical(value$n1[[1L]], numeric())
  expect_identical(value$n2[[1L]], numeric())
  expect_identical(value$nmiss[[1L]], numeric())
  expect_invisible(validate_Glist(value))
})

test_that("sparseld augments Glist and publishes deterministic LD", {
  fixture <- write_tiny_plink(matrix(c(
    0, 0, 2,
    0, 0, 2,
    1, 1, 1,
    1, 1, 1,
    2, 2, 0,
    2, 2, 0
  ), nrow = 6L, byrow = TRUE), c("a", "a-copy", "negative"))
  prefix <- tempfile("gbase-sparseld-")
  on.exit({ unlink_tiny_plink(fixture); unlink_sparse_ld(prefix) }, add = TRUE)
  prepared <- gprep(bedfiles = fixture$paths[["bed"]],
    ids = c("I5", "I1", "I3", "I0"))
  value <- gprep(Glist = prepared, task = "sparseld", out_prefix = prefix,
    rsids = c("negative", "a"),
    max_distance_bp = 0, max_distance_variants = 3, r2 = 0,
    block_size = 2, nthreads = 1)
  expect_identical(value$idsLD, prepared$study_ids)
  expect_identical(value$rsidsLD, list(c("a", "negative")))
  expect_equal(value$sparseLD$sample_indices_0based, c(5, 1, 3, 0))
  expect_equal(value$sparseLD$marker_indices_0based, list(c(0, 2)))
  expect_equal(value$sparseLD$m, 2)
  expect_equal(value$sparseLD$nnz, 1)
  expect_equal(unname(value$ldscores[[1]]), rep(2, 2), tolerance = 3e-6)
  expect_true(all(file.exists(unlist(value$sparseLD$paths))))
  expect_identical(value$ldfiles, value$sparseLD$paths)
  expect_identical(names(value$sparseLD$checksums), names(value$sparseLD$paths))
  expect_invisible(validate_Glist(value))
  expect_invisible(verify_ld(value))
  changed <- value
  changed$sparseLD$checksums[[1L]] <- paste0("changed-", changed$sparseLD$checksums[[1L]])
  expect_invisible(validate_Glist(changed))
  expect_error(verify_ld(changed), "changed after preparation")

  wrong_samples <- value
  wrong_samples$idsLD <- rev(wrong_samples$idsLD)
  expect_error(validate_Glist(wrong_samples), "idsLD")
  wrong_markers <- value
  wrong_markers$rsidsLD[[1L]] <- rev(wrong_markers$rsidsLD[[1L]])
  expect_error(validate_Glist(wrong_markers), "rsidsLD")
  wrong_files <- value
  wrong_files$ldfiles$values <- wrong_files$ldfiles$row_ptr
  expect_error(validate_Glist(wrong_files), "ldfiles")

  writeBin(as.raw(0), value$sparseLD$paths$values)
  expect_invisible(validate_Glist(value))
  expect_error(verify_ld(value))
})
