test_that("mapped Glist columns and gfilter match the ordinary full descriptor", {
  calls <- cbind(c(0, 0, 0, 0, 0), c(0, 1, 2, NA, 2),
    c(1, 1, 1, 1, 1), c(2, 0, 1, 0, 2), c(0, 2, 0, 2, 0))
  a <- write_tiny_plink(calls, c("z", "b", "m", "a", "c"), "6")
  b <- write_tiny_plink(calls[, c(4, 2)], c("last", "first"), "X")
  out <- tempfile("gbase-mapped-")
  on.exit({
    unlink_tiny_plink(a)
    unlink_tiny_plink(b)
    unlink(out, recursive = TRUE)
  })
  bim <- read.table(a$paths[["bim"]])
  bim[[4]] <- c(1e6, 28477797, 33448397, 1e10, 33448398)
  bim[[5]] <- c("A", "T", "C", "AT", "a")
  bim[[6]] <- c("G", "A", "G", "G", "G")
  bim[[4]] <- format(bim[[4]], scientific = FALSE, trim = TRUE)
  write.table(bim, a$paths[["bim"]], quote = FALSE, row.names = FALSE, col.names = FALSE)
  bed <- c(a$paths[["bed"]], b$paths[["bed"]])
  plain <- gprep(bedfiles = bed, study = 'Fixture "study"')
  mapped <- gprep(bedfiles = bed, mapped_dir = out, study = plain$study)
  expect_s3_class(mapped, "Glist")
  expect_s3_class(mapped, "gs_genotypes")
  expect_silent(validate_Glist(mapped))
  expect_identical(open_mapped_Glist(out), mapped)
  expect_identical(unserialize(serialize(mapped, NULL)), mapped)
  for (field in c("study", "bedfiles", "bimfiles", "famfiles", "ids", "n", "mchr", "nchr"))
    expect_identical(mapped[[field]], plain[[field]], info = field)
  fields <- c("rsids", "a1", "a2", "pos", "chr", "cpra", "map", "nmiss",
    "af", "af1", "af2", "maf", "hom", "het", "n0", "n1", "n2")
  for (i in seq_along(bed)) {
    expected <- lapply(plain[fields], `[[`, i)
    expect_identical(read_mapped_Glist(mapped, fields, i), expected)
    expect_identical(lapply(mapped[fields], `[[`, i), expected)
  }
  expect_identical(mapped$source_marker_indices_0based, plain$source_marker_indices_0based)
  expect_identical(mapped$sample_source_indices_0based, plain$sample_source_indices_0based)
  expect_identical(mapSets(list(c("last", "z")), Glist = mapped),
    mapSets(list(c("last", "z")), Glist = plain))
  edited <- mapped
  edited$rsids[[1]][1] <- "renamed"
  edited$pos[[1]][1] <- 2
  expect_identical(mapped$rsids[[1]][1], "z")
  expect_identical(mapped$pos[[1]][1], 1e6)
  expect_identical(unserialize(serialize(edited$rsids, NULL))[[1]][1], "renamed")
  expect_identical(unserialize(serialize(edited$pos, NULL))[[1]][1], 2)
  expect_error(validate_Glist(edited), "rsids.*no longer matches")
  edited <- mapped
  edited$af[[2]][1] <- 0
  expect_error(validate_Glist(edited), "af.*no longer matches")
  expect_identical(read_mapped_Glist(mapped, c("rsids", "cpra"), 2, 2, 1),
    list(rsids = "first", cpra = "X_200_A_G"))
  expect_identical(read_mapped_Glist(mapped, "pos", 2, 3, 0), list(pos = numeric()))
  expect_error(read_mapped_Glist(mapped, "rsids", 2, 2, 2), "out of range")
  expect_error(gprep_mapped(bed, out), "already exists")

  plain$info <- mapped$info <- setNames(seq(0.1, 0.7, by = 0.1),
    rev(unlist(plain$rsids, use.names = FALSE)))
  audit <- function(panel, ...) {
    messages <- capture.output(rsids <- gfilter(panel, ...), type = "message")
    list(rsids = rsids, messages = messages)
  }
  expect_identical(audit(mapped), audit(plain))
  expect_identical(audit(mapped, mhc = TRUE, assembly = "GRCh37", excludeINFO = 0.4,
    excludeHWE = 0.5, excludeMISS = 0.2, excludeMAF = 0.5),
    audit(plain, mhc = TRUE, assembly = "GRCh37", excludeINFO = 0.4,
      excludeHWE = 0.5, excludeMISS = 0.2, excludeMAF = 0.5))
  boundary <- gbase:::.gfilter_exact_hwe_one(2, 1, 2)
  expect_identical(audit(mapped, hwe = boundary), audit(plain, hwe = boundary))
  expect_identical(audit(mapped, maf = NULL, missing = NULL, hwe = NULL,
    ambiguous = FALSE, indels = FALSE)$rsids, c("z", "b", "m", "a", "c", "last", "first"))

  # Reopened mapped QC uses only the prepared resource.
  unlink_tiny_plink(a)
  unlink_tiny_plink(b)
  expect_identical(audit(open_mapped_Glist(out)), audit(mapped))
  corrupt <- tempfile("gbase-corrupt-")
  dir.create(corrupt)
  on.exit(unlink(corrupt, recursive = TRUE), add = TRUE)
  expect_true(all(file.copy(list.files(out, full.names = TRUE), corrupt, recursive = TRUE)))
  writeBin(as.raw(0), file.path(corrupt, "0", "maf"))
  expect_error(gfilter(open_mapped_Glist(corrupt)), "column length")
})

test_that("mapped LD uses the filtered IDs and exact physical BED rows", {
  calls <- cbind(c(0, 1, 2, NA, 2), c(0, 0, 0, 0, 0),
    c(0, 1, 1, 2, 0), c(2, 0, 1, 0, 2))
  a <- write_tiny_plink(calls[, 1:2], c("unused1", "unused2"), "1")
  b <- write_tiny_plink(calls, c("b", "monomorphic", "a", "c"), "2")
  out <- tempfile("gbase-mapped-")
  prefix <- tempfile("gbase-mapped-ld-")
  ordinary_prefix <- tempfile("gbase-ordinary-ld-")
  subset_prefix <- tempfile("gbase-mapped-ld-subset-")
  on.exit({
    unlink_tiny_plink(a)
    unlink_tiny_plink(b)
    unlink(out, recursive = TRUE)
    for (p in c(prefix, ordinary_prefix, subset_prefix)) unlink_sparse_ld(p)
  })
  bed <- c(a$paths[["bed"]], b$paths[["bed"]])
  plain <- gprep(bedfiles = bed)
  panel <- gprep_mapped(bed, out)
  retained_rsids <- intersect(gfilter(panel, missing = NULL, verbose = FALSE), c("c", "b", "a"))
  expect_identical(retained_rsids, c("b", "a", "c"))
  direct <- gprep(panel, task = "sparseld", rsids = rev(retained_rsids), out_prefix = prefix, r2 = 0)
  ordinary <- gprep(plain, task = "sparseld", rsids = retained_rsids, out_prefix = ordinary_prefix, r2 = 0)
  expect_silent(verify_ld(direct))
  expect_identical(direct$mchr, panel$mchr)
  for (field in c("bedfiles", "bimfiles", "famfiles", "rsids", "cpra", "af"))
    expect_identical(direct[[field]], panel[[field]], info = field)
  expect_identical(direct$idsLD, panel$ids)
  expect_identical(direct$ldfiles, direct$sparseLD$paths)
  expect_identical(direct$ldscores, ordinary$ldscores)
  expect_identical(getLDscores(direct), getLDscores(ordinary))
  restored <- unserialize(serialize(direct, NULL))
  expect_silent(verify_ld(restored))
  expect_identical(restored$cpra, plain$cpra)
  expect_identical(restored$ldscores, direct$ldscores)
  # Serialize a fresh copy so the lookup cannot rely on a prior column read.
  offline_dir <- tempfile("gbase-offline-")
  dir.create(offline_dir)
  on.exit(unlink(offline_dir, recursive = TRUE), add = TRUE)
  expect_true(all(file.copy(list.files(out, full.names = TRUE), offline_dir, recursive = TRUE)))
  saved <- serialize(open_mapped_Glist(offline_dir), NULL)
  unlink(offline_dir, recursive = TRUE)
  expect_false(dir.exists(offline_dir))
  offline <- unserialize(saved)
  expect_identical(match(c("c", "b", "absent", "a"), offline$rsids[[2L]]),
    c(4L, 1L, NA_integer_, 3L))
  expect_identical(offline$bedfiles, plain$bedfiles)
  expect_error(offline$cpra[[2L]][1], "Mapped PLINK panel")
  expect_identical(direct$rsidsLD, list(character(), retained_rsids))
  expect_identical(direct$sparseLD$chr, 2L)
  expect_identical(direct$sparseLD$marker_indices_0based, list(c(0, 2, 3)))
  expect_identical(direct$sparseLD$marker_metadata, ordinary$sparseLD$marker_metadata)
  expect_identical(ld_region(direct, retained_rsids), ld_region(ordinary, retained_rsids))
  direct_bed <- getLD(direct, rev(retained_rsids))
  ordinary_bed <- getLD(ordinary, rev(retained_rsids))
  attr(direct_bed, "timings_seconds") <- attr(ordinary_bed, "timings_seconds") <- NULL
  expect_equal(direct_bed, ordinary_bed, tolerance = 1e-14)
  expect_identical(ld_scores(direct), ld_scores(ordinary))
  mapped_eigen <- gprep(direct, task = "eigen", sets = list(region = rev(retained_rsids)))
  ordinary_eigen <- gprep(ordinary, task = "eigen", sets = list(region = rev(retained_rsids)))
  expect_identical(mapped_eigen$eigen$sets, ordinary_eigen$eigen$sets)
  expect_equal(mapped_eigen$eigen$values, ordinary_eigen$eigen$values, tolerance = 1e-14)
  expect_silent(validate_Glist(mapped_eigen))
  mapped_scores <- gprep(panel, task = "ldscores", rsids = retained_rsids)
  ordinary_scores <- gprep(plain, task = "ldscores", rsids = retained_rsids)
  expect_identical(getLDscores(mapped_scores), getLDscores(ordinary_scores))
  bad <- direct
  bad$sparseLD$marker_indices_0based[[1]][2] <- 1
  bad$sparseLD$marker_metadata$source_marker_index_0based[2] <- 1
  expect_error(verify_ld(bad), "do not match the mapped panel")
  expect_error(gprep(panel, task = "sparseld", rsids = c(retained_rsids, "absent"),
    out_prefix = tempfile()), "marker ID not found")

  subset <- c(5L, 1L, 4L, 3L)
  sub <- gprep(panel, task = "sparseld", ids = panel$ids[subset], rsids = retained_rsids,
    out_prefix = subset_prefix, r2 = 0)
  expect_identical(sub$idsLD, panel$ids[subset])
  expect_identical(sub$sparseLD$sample_indices_0based, as.double(subset - 1L))
  expect_identical(unlist(sub$sparseLD$af), unname(colMeans(calls[subset, c(1, 3, 4)], na.rm = TRUE) / 2))
  expect_silent(verify_ld(sub))
})

test_that("mapped writer validates cross-component identity and keeps all-missing rows", {
  a <- write_tiny_plink(cbind(c(0, NA, 2), c(NA, NA, NA)), c("seen", "missing"))
  b <- write_tiny_plink(matrix(c(0, 1, 2), 3), "seen")
  out <- tempfile("gbase-mapped-")
  on.exit({
    unlink_tiny_plink(a)
    unlink_tiny_plink(b)
    unlink(out, recursive = TRUE)
  })
  bed <- c(a$paths[["bed"]], b$paths[["bed"]])
  expect_error(gprep_mapped(bed, out), "marker IDs must be globally unique")
  expect_false(file.exists(out))
  writeLines(rev(readLines(b$paths[["fam"]])), b$paths[["fam"]])
  expect_error(gprep_mapped(bed, out), "identical ordered FAM")
  expect_false(file.exists(out))
  mapped <- gprep_mapped(bed[1], out)
  expect_identical(read_mapped_Glist(mapped, c("rsids", "nmiss", "maf")),
    list(rsids = c("seen", "missing"), nmiss = c(1, 3), maf = c(0.5, NaN)))
  expect_error(gfilter(mapped), "no observed")
})
