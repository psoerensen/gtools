test_that("linear, conditional and batched scans honour a Glist", {
  set.seed(26092026)
  n <- 16L
  genotype <- matrix(sample(0:2, n * 5L, replace = TRUE), n, 5L)
  genotype[3L, 2L] <- NA_real_
  first <- write_glma_plink(genotype[, 1:3, drop = FALSE],
    paste0("m", 1:3), chromosome = "1")
  second <- write_glma_plink(genotype[, 4:5, drop = FALSE],
    paste0("m", 4:5), chromosome = "2")
  on.exit(unlink(c(first, second)), add = TRUE)
  ids <- paste0("I", c(12L, 2L, 7L, 1L, 5L, 3L, 11L, 4L, 9L, 6L, 14L, 16L))
  Glist <- gbase::gprep(bedfiles = c(first[["bed"]], second[["bed"]]),
    ids = ids, rsids = c("m2", "m4", "m5"))
  selected <- match(ids, paste0("I", seq_len(n)))
  cov <- seq_len(n) / n
  y <- 1 + 0.4 * cov + 0.7 * genotype[, 4L] +
    rep(c(-0.15, 0.1, 0.05, -0.05), length.out = n)
  names(y) <- paste0("I", seq_len(n))
  covariates <- matrix(cov, ncol = 1L,
    dimnames = list(names(y), "covariate"))

  result <- glma(y = y, Glist = Glist, covariates = covariates,
    method = "linear", block_size = 2L)
  expect_s3_class(result, "glma_fit")
  expect_identical(result$diagnostics$threads_used, 1L)
  expect_identical(result$associations$marker, c("m2", "m4", "m5"))
  expect_identical(result$associations$file, c(1L, 2L, 2L))
  for (j in seq_along(result$associations$marker)) {
    source <- match(result$associations$marker[[j]], paste0("m", 1:5))
    observed <- selected[!is.na(genotype[selected, source])]
    reference <- summary(lm(y[observed] ~ cov[observed] +
      genotype[observed, source]))$coefficients[3L, ]
    expect_equal(result$associations$beta[[j]], unname(reference[[1L]]),
      tolerance = 1e-9)
    expect_equal(result$associations$se[[j]], unname(reference[[2L]]),
      tolerance = 1e-9)
  }

  conditional <- glma_linear(y, Glist, covariates, condition_on = 1L,
    block_size = 2L)
  expect_identical(conditional$method, "linear_conditional")
  expect_identical(conditional$associations$status[[1L]], "collinear_marker")
  expect_equal(conditional$diagnostics$conditioning_complete_samples,
    as.numeric(length(selected) - 1L))

  traits <- cbind(first = y, second = 2 * y + 0.1 * cov)
  rownames(traits) <- names(y)
  batched <- glma_linear(traits, Glist, covariates, block_size = 2L)
  expect_s3_class(batched, "glma_multi_fit")
  expect_identical(names(batched), c("first", "second"))
  expect_equal(batched$first$associations, result$associations)
  expect_equal(batched$second$associations,
    glma_linear(traits[, "second"], Glist, covariates,
      block_size = 2L)$associations)
  expect_error(glma_linear(y, Glist, condition_on = c(1L, 1L)), "condition_on")
})

test_that("logistic scan matches an ordinary glm and reports failures", {
  set.seed(26092027)
  n <- 80L
  covariate <- rnorm(n)
  ordinary <- sample(0:2, n, replace = TRUE)
  phenotype <- rbinom(n, 1L, plogis(-0.3 + 0.45 * ordinary + 0.5 * covariate))
  sparse <- sample(0:2, n, replace = TRUE)
  retained <- c(which(phenotype == 1L)[1:2], which(phenotype == 0L)[1:8])
  sparse[-retained] <- NA_real_
  genotype <- cbind(ordinary, perfect = 2 * phenotype, sparse)
  paths <- write_glma_plink(genotype, c("ordinary", "perfect", "sparse"))
  on.exit(unlink(paths), add = TRUE)
  Glist <- gbase::gprep(bedfiles = paths[["bed"]])

  result <- glma_logistic(phenotype, Glist, matrix(covariate, ncol = 1L))
  reference <- glm(phenotype ~ covariate + ordinary, family = binomial())
  design <- model.matrix(reference)
  probability <- plogis(drop(design %*% coef(reference)))
  information <- crossprod(design,
    design * as.vector(probability * (1 - probability)))
  beta <- unname(coef(reference)[[3L]])
  se <- sqrt(solve(information)[3L, 3L])
  expect_s3_class(result, "glma_fit")
  expect_identical(result$effect_type, "log_odds")
  expect_equal(result$associations$beta[[1L]], beta, tolerance = 1e-6)
  expect_equal(result$associations$se[[1L]], se, tolerance = 1e-6)
  expect_identical(result$associations$status,
    c("ok", "separated", "sparse_outcome"))
  expect_error(glma_logistic(replace(phenotype, 1L, 2), Glist), "zero and one")
  expect_error(glma(cbind(a = phenotype, b = phenotype), Glist,
    method = "logistic"), "one phenotype vector")
})

test_that("native closure contracts are checked", {
  info <- glma_native_info()
  expect_identical(names(info), c("glma", "gbayes", "gbits", "gmat", "greml", "gsolve"))
  expect_true(all(vapply(info, function(x) isTRUE(x$compatible), logical(1))))
})
