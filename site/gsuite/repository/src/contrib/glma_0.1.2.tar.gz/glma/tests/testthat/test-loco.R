test_that("focused LOCO scans retain diagnostics and dispatcher routes", {
  set.seed(1910)
  n <- 64L
  m <- 48L
  genotype <- matrix(rbinom(n * m, 2L, 0.35), n, m)
  paths <- write_glma_plink(genotype, paste0("l", seq_len(m)),
    chromosome = rep(c("1", "2"), each = m / 2L))
  on.exit(unlink(paths), add = TRUE)
  Glist <- gbase::gprep(bedfiles = paths[["bed"]])
  covariate <- matrix(rnorm(n), ncol = 1L)
  phenotype <- 0.25 * covariate[, 1L] + 0.4 * genotype[, 2L] +
    0.3 * genotype[, 29L] + rnorm(n)
  controls <- list(scaling_factor = 1)

  infinitesimal <- glma_infinitesimal_loco(phenotype, Glist, covariate,
    block_size = 16L, controls = controls)
  expect_s3_class(infinitesimal, "glma_fit")
  expect_identical(infinitesimal$method, "infinitesimal_loco")
  expect_identical(infinitesimal$associations$marker,
    unlist(Glist$rsids, use.names = FALSE))
  expect_true(any(is.finite(infinitesimal$associations$p)))
  expect_equal(nrow(infinitesimal$fit$loco), 2L)
  expect_identical(infinitesimal$fit$selected_prior, "ridge")
  expect_equal(infinitesimal$diagnostics$candidate_model_count, 1)
  expect_equal(infinitesimal$diagnostics$marker_power, -1)
  expect_identical(infinitesimal$diagnostics$variance_estimator, "blocked_rhe_mc_grid")
  expect_true(infinitesimal$diagnostics$variance_shared_across_chromosomes)
  expect_equal(infinitesimal$fit$loco$genetic_variance,
    rep(infinitesimal$fit$genetic_variance, 2L))

  threaded <- glma_infinitesimal_loco(phenotype, Glist, covariate,
    threads = 4L, block_size = 16L, controls = controls)
  expect_equal(threaded$associations$p, infinitesimal$associations$p,
    tolerance = 1e-7)
  expect_equal(threaded$fit$loco$genetic_variance,
    infinitesimal$fit$loco$genetic_variance, tolerance = 1e-7)

  prior <- glma(phenotype, Glist, covariate,
    method = "prior_selected_loco", block_size = 16L,
    controls = list(scaling_factor = 1))
  expect_s3_class(prior, "glma_fit")
  expect_identical(prior$diagnostics$scaling_source, "caller_supplied")
  expect_true(nzchar(prior$fit$selected_prior))
  expect_true(any(is.finite(prior$associations$p)))

  prior_threaded <- glma(phenotype, Glist, covariate,
    method = "prior_selected_loco", threads = 4L, block_size = 16L,
    controls = list(scaling_factor = 1))
  expect_equal(prior_threaded$associations$p, prior$associations$p,
    tolerance = 1e-7)
  expect_identical(prior_threaded$fit$selected_prior, prior$fit$selected_prior)
  expect_true(all(vapply(prior$diagnostics[c("initial_variance_seconds",
    "candidate_seconds", "refit_seconds")], function(x) is.finite(x) && x >= 0,
    logical(1))))

  traits <- cbind(primary = phenotype,
    secondary = phenotype + 0.1 * genotype[, 7L])
  multi_infinitesimal <- glma_infinitesimal_loco(traits, Glist, covariate,
    block_size = 16L, controls = controls)
  expect_s3_class(multi_infinitesimal, "glma_multi_fit")
  expect_identical(names(multi_infinitesimal), c("primary", "secondary"))
  expect_true(multi_infinitesimal$secondary$diagnostics$shared_prepared_genotypes)
  multi_prior <- glma_prior_selected_loco(traits, Glist, covariate,
    block_size = 16L, controls = list(scaling_factor = 1))
  expect_s3_class(multi_prior, "glma_multi_fit")
  expect_true(multi_prior$primary$diagnostics$shared_prepared_genotypes)

  background <- c(seq_len(20L), 25:44)
  subset <- glma_infinitesimal_loco(phenotype, Glist, covariate,
    background_markers = rev(background), storage = "streamed",
    block_size = 16L, controls = list(scaling_factor = 1))
  expect_equal(subset$diagnostics$background_marker_count, length(background))
  expect_identical(nrow(subset$associations), m)
  expect_error(glma_infinitesimal_loco(phenotype, Glist,
    algorithm = "observation_pcg"), "arg")
  expect_error(glma_infinitesimal_loco(phenotype, Glist,
    controls = list(simulation_count = 4)), "retired")
  expect_error(glma_prior_selected_loco(phenotype, Glist,
    algorithm = "packed_full", storage = "streamed",
    controls = list(scaling_factor = 1)), "prepared")
  expect_error(glma_prior_selected_loco(phenotype, Glist,
    background_markers = c(1L, 1L)), "background_markers")
})

test_that("disjoint marker sets fit joint genetic components with a background", {
  set.seed(538)
  n <- 128L
  m <- 48L
  genotype <- matrix(rbinom(n*m, 2L, .35), n, m)
  marker_ids <- paste0("component", seq_len(m))
  paths <- write_glma_plink(genotype, marker_ids,
    chromosome=rep(c("1", "2", "3"), each=16L))
  on.exit(unlink(paths), add=TRUE)
  Glist <- gbase::gprep(bedfiles=paths[["bed"]])
  y <- .4*genotype[,2] + .3*genotype[,30] + rnorm(n)
  sets <- list(selected=marker_ids[1:16])
  for (method in c("infinitesimal_loco", "prior_selected_loco")) {
    fit <- glma(y, Glist, sets=sets, method=method, block_size=8L,
                controls=list(scaling_factor=1))
    expect_identical(fit$associations$marker, marker_ids)
    expect_true(all(fit$associations$status=="ok"))
    expect_identical(fit$fit$components$component, c("selected", "background"))
    expect_equal(fit$fit$components$markers, c(16,32))
    expect_equal(sum(fit$fit$components$genetic_variance), fit$fit$genetic_variance)
    expect_identical(fit$diagnostics$variance_estimator, "component_rhe_profile_mc_grid")
    expect_true(fit$diagnostics$component_ratios_fixed_after_rhe)
    loco <- fit$fit$loco_components
    expect_equal(loco$active_markers[loco$excluded_chromosome=="1" &
      loco$component=="selected"], 0)
    expect_equal(loco$active_prior_variance[loco$excluded_chromosome=="1" &
      loco$component=="selected"], 0)
    expect_equal(aggregate(active_prior_variance ~ excluded_chromosome, loco, sum)$active_prior_variance,
                 fit$fit$loco$genetic_variance)
  }
  expect_error(glma(y, Glist, sets=list(a=marker_ids[1:8], b=marker_ids[8:20]),
    method="infinitesimal_loco"), "disjoint")
  expect_error(glma(y, Glist, sets=list(a="unknown"),
    method="infinitesimal_loco"), "Unknown")
  expect_error(glma(y, Glist, sets=sets, background_markers=17:48,
    method="infinitesimal_loco"), "retain")
  expect_error(glma(y, Glist, sets=sets, storage="streamed",
    method="infinitesimal_loco"), "prepared")
})

test_that("joint RHE initialization retains strong-marker association", {
  set.seed(6281)
  n <- 256L
  m <- 48L
  genotype <- matrix(rbinom(n * m, 2L, 0.35), n, m)
  paths <- write_glma_plink(genotype, paste0("strong", seq_len(m)),
    chromosome = rep(c("1", "2", "3"), each = m / 3L))
  on.exit(unlink(paths), add = TRUE)
  Glist <- gbase::gprep(bedfiles = paths[["bed"]])
  phenotype <- 3 * genotype[, 1L] + rnorm(n, sd = 0.5)
  fit <- glma(phenotype, Glist, method = "infinitesimal_loco",
    block_size = 8L, controls = list(scaling_factor = 1))
  expect_equal(nrow(fit$associations), m)
  expect_identical(fit$associations$marker, paste0("strong", seq_len(m)))
  expect_true(all(fit$associations$status == "ok"))
  expect_lt(fit$associations$p[1L], 1e-8)
  expect_true(is.finite(fit$fit$genetic_variance) &&
    fit$fit$genetic_variance > 0)
  threaded <- glma(phenotype, Glist, method = "infinitesimal_loco",
    threads = 4L, block_size = 8L, controls = list(scaling_factor = 1))
  expect_equal(threaded$associations$statistic, fit$associations$statistic,
    tolerance = 1e-6)
  expect_equal(threaded$fit$genetic_variance, fit$fit$genetic_variance,
    tolerance = 1e-6)
})
