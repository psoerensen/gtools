#include <Rcpp.h>

#include <gbayes/bayesc.hpp>
#include <gbits/c_api.h>
#include <gbits/bed_reader.hpp>
#include <glma/linear_scan.hpp>
#include <glma/logistic_scan.hpp>
#include <glma/mixed_scan.hpp>
#include <glma/version.hpp>
#include <gmat/bed_panel.hpp>
#include <gmat/version.hpp>
#include <greml/version.hpp>
#include <gsolve/version.hpp>

#include <cmath>
#include <cstdint>
#include <memory>
#include <limits>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>

namespace {

struct AssociationOutput {
  std::string status;
  double n{NA_REAL}, observed{NA_REAL}, cases{NA_REAL}, controls{NA_REAL};
  double af{NA_REAL}, beta{NA_REAL}, se{NA_REAL}, statistic{NA_REAL}, p{NA_REAL};
};

template <typename T>
T control_or(const Rcpp::List& controls, const char* name, T fallback) {
  return controls.containsElementNamed(name) ?
      Rcpp::as<T>(controls[name]) : fallback;
}

std::uint64_t byte_limit(double value) {
  if (!std::isfinite(value) || value < 1 ||
      value > static_cast<double>(std::numeric_limits<std::uint64_t>::max()))
    throw std::invalid_argument("memory_limit_bytes must be positive and finite");
  return static_cast<std::uint64_t>(value);
}

std::uint64_t exact_index(double value, const char* name) {
  if (!std::isfinite(value) || value < 0 || value != std::floor(value) ||
      value > 9007199254740992.0)
    throw std::invalid_argument(std::string(name) + " must be a nonnegative exact integer");
  return static_cast<std::uint64_t>(value);
}

std::string path_field(const Rcpp::List& path, const char* name) {
  if (!path.containsElementNamed(name))
    throw std::invalid_argument(std::string("missing Glist path field ") + name);
  return Rcpp::as<std::string>(path[name]);
}

std::shared_ptr<const gmat::BedPanel> panel_from_glist(
    const Rcpp::List& paths, const Rcpp::NumericVector& sample_indices,
    const Rcpp::CharacterVector& individual_ids, const Rcpp::List& marker_ids) {
  if (!paths.size() || paths.size() != marker_ids.size() ||
      sample_indices.size() != individual_ids.size() || !sample_indices.size())
    throw std::invalid_argument("Glist paths, samples and markers are inconsistent");
  std::vector<std::shared_ptr<const gmat::BedMatrix>> components;
  components.reserve(static_cast<std::size_t>(paths.size()));
  for (R_xlen_t k = 0; k < paths.size(); ++k) {
    const auto path = Rcpp::as<Rcpp::List>(paths[k]);
    components.push_back(std::make_shared<const gmat::BedMatrix>(
        path_field(path, "bed"), path_field(path, "bim"), path_field(path, "fam")));
  }
  gmat::BedPanelSelection selection;
  const auto& source_samples = components.front()->samples();
  for (R_xlen_t i = 0; i < sample_indices.size(); ++i) {
    const auto source = exact_index(sample_indices[i], "Glist sample index");
    if (source >= source_samples.size() ||
        Rcpp::CharacterVector::is_na(individual_ids[i]))
      throw std::invalid_argument("Glist sample selection is invalid");
    const auto& sample = source_samples[static_cast<std::size_t>(source)];
    const auto individual = Rcpp::as<std::string>(individual_ids[i]);
    if (sample.individual_id != individual)
      throw std::invalid_argument("Glist sample identity does not match its FAM row");
    selection.samples.push_back({sample.family_id, sample.individual_id});
  }
  for (R_xlen_t k = 0; k < marker_ids.size(); ++k) {
    const auto names = Rcpp::as<Rcpp::CharacterVector>(marker_ids[k]);
    if (!names.size()) throw std::invalid_argument("empty Glist component");
    std::vector<std::string> selected;
    selected.reserve(static_cast<std::size_t>(names.size()));
    for (auto name : names) {
      if (Rcpp::CharacterVector::is_na(name))
        throw std::invalid_argument("missing Glist marker ID");
      selected.push_back(Rcpp::as<std::string>(name));
    }
    selection.markers_by_component.push_back(std::move(selected));
  }
  return std::make_shared<const gmat::BedPanel>(
      std::move(components), std::move(selection));
}

Rcpp::DataFrame association_table(const gmat::BedPanel& panel,
                                  const std::vector<AssociationOutput>& rows) {
  const auto count = static_cast<R_xlen_t>(rows.size());
  Rcpp::IntegerVector file(count);
  Rcpp::NumericVector source_marker(count), position(count), n(count), observed(count),
      cases(count), controls(count), af(count), beta(count), se(count), statistic(count), p(count);
  Rcpp::CharacterVector marker(count), chromosome(count), a1(count), a2(count), status(count);
  for (R_xlen_t i = 0; i < count; ++i) {
    const auto& located = panel.marker(static_cast<std::uint64_t>(i));
    const auto& metadata = located.metadata;
    const auto& row = rows[static_cast<std::size_t>(i)];
    file[i] = static_cast<int>(located.component_index + 1);
    source_marker[i] = static_cast<double>(located.source_marker_index);
    marker[i] = metadata.marker_id; chromosome[i] = metadata.chromosome;
    position[i] = static_cast<double>(metadata.base_pair_position);
    a1[i] = metadata.allele1; a2[i] = metadata.allele2; status[i] = row.status;
    n[i] = row.n; observed[i] = row.observed; cases[i] = row.cases;
    controls[i] = row.controls; af[i] = row.af; beta[i] = row.beta;
    se[i] = row.se; statistic[i] = row.statistic; p[i] = row.p;
  }
  return Rcpp::DataFrame::create(
      Rcpp::_ ["file"] = file,
      Rcpp::_ ["source_marker_index_0based"] = source_marker,
      Rcpp::_ ["marker"] = marker, Rcpp::_ ["chromosome"] = chromosome,
      Rcpp::_ ["position"] = position, Rcpp::_ ["a1"] = a1, Rcpp::_ ["a2"] = a2,
      Rcpp::_ ["n"] = n, Rcpp::_ ["observed_n"] = observed,
      Rcpp::_ ["case_n"] = cases, Rcpp::_ ["control_n"] = controls,
      Rcpp::_ ["allele_frequency"] = af, Rcpp::_ ["beta"] = beta,
      Rcpp::_ ["se"] = se, Rcpp::_ ["statistic"] = statistic,
      Rcpp::_ ["p"] = p, Rcpp::_ ["status"] = status,
      Rcpp::_ ["stringsAsFactors"] = false);
}


Rcpp::List finish_loco(
    const std::shared_ptr<const gmat::BedPanel>& panel,
    glma::GenomicBackground& background, const std::string& method,
    const std::string& algorithm, const std::string& storage, int threads,
    int block_size, std::uint64_t memory, const Rcpp::List& controls,
    const glma::PredictionMarkerGroups& groups);

Rcpp::List version(const char* expected_version, std::uint32_t expected_abi,
                   const char* runtime_version, std::uint32_t runtime_abi) {
  return Rcpp::List::create(
      Rcpp::_ ["expected_version"] = expected_version,
      Rcpp::_ ["expected_abi"] = expected_abi,
      Rcpp::_ ["runtime_version"] = runtime_version,
      Rcpp::_ ["runtime_abi"] = runtime_abi,
      Rcpp::_ ["compatible"] = std::string(runtime_version) == expected_version &&
          runtime_abi == expected_abi);
}

}  // namespace

// [[Rcpp::export]]
Rcpp::List cpp_glma_native_info() {
  return Rcpp::List::create(
      Rcpp::_ ["glma"] = version("0.1.2", 0, glma::version_string(), glma::abi_version()),
      Rcpp::_ ["gbayes"] = Rcpp::List::create(
          Rcpp::_ ["expected_version"] = "0.1.0", Rcpp::_ ["expected_abi"] = 0,
          Rcpp::_ ["runtime_version"] = gbayes::version_string(),
          Rcpp::_ ["runtime_abi"] = 0,
          Rcpp::_ ["compatible"] = std::string(gbayes::version_string()) == "0.1.0"),
      Rcpp::_ ["gbits"] = version("0.21.0", 4, gbits_library_version(), gbits_abi_version()),
      Rcpp::_ ["gmat"] = version("0.6.0", 0, gmat::version_string(), gmat::abi_version()),
      Rcpp::_ ["greml"] = version((std::to_string(greml::version_major) + "." +
          std::to_string(greml::version_minor) + "." + std::to_string(greml::version_patch)).c_str(),
          greml::experimental_abi, greml::version_string(), greml::abi_version()),
      Rcpp::_ ["gsolve"] = version((std::to_string(gsolve::version_major) + "." +
          std::to_string(gsolve::version_minor) + "." + std::to_string(gsolve::version_patch)).c_str(),
          gsolve::experimental_abi, gsolve::version_string(), gsolve::abi_version()));
}

// [[Rcpp::export]]
Rcpp::List cpp_glma_linear_glist(
    Rcpp::List paths, Rcpp::NumericVector sample_indices,
    Rcpp::CharacterVector individual_ids, Rcpp::List marker_ids,
    Rcpp::NumericMatrix phenotypes, Rcpp::NumericMatrix covariates,
    Rcpp::NumericVector conditioning_indices, int threads, int block_size) {
  auto panel = panel_from_glist(paths, sample_indices, individual_ids, marker_ids);
  if (phenotypes.nrow() != static_cast<int>(panel->sample_count()) ||
      phenotypes.ncol() < 1 || covariates.nrow() != phenotypes.nrow() ||
      threads < 1 || block_size < 1)
    throw std::invalid_argument("invalid linear scan dimensions or controls");
  const auto full_n = static_cast<std::size_t>(panel->sample_count());
  const auto selected_samples = panel->sample_source_indices();
  std::vector<unsigned char> complete(full_n, 1);
  std::vector<std::vector<double>> conditioned;
  for (double value : conditioning_indices) {
    const auto index = exact_index(value, "conditioning marker index");
    if (index >= panel->marker_count())
      throw std::invalid_argument("conditioning marker index is out of range");
    const auto& marker = panel->marker(index);
    const auto& bed = panel->component(marker.component_index);
    gbits::BedReader reader(bed.bed_path(), bed.sample_count(), bed.marker_count());
    std::vector<std::int8_t> raw(static_cast<std::size_t>(bed.sample_count()));
    reader.read_variant(marker.source_marker_index, raw.data(), bed.sample_count());
    std::vector<double> column(full_n);
    for (std::size_t i = 0; i < full_n; ++i) {
      const auto dosage = raw[static_cast<std::size_t>(selected_samples[i])];
      if (dosage == gbits::missing_dosage) complete[i] = 0;
      else column[i] = static_cast<double>(dosage);
    }
    conditioned.push_back(std::move(column));
  }
  std::vector<std::size_t> retained;
  for (std::size_t i = 0; i < full_n; ++i) if (complete[i]) retained.push_back(i);
  std::vector<std::uint64_t> scan_samples;
  for (auto i : retained) scan_samples.push_back(selected_samples[i]);
  const auto effective_n = retained.size();
  const auto covariate_count = static_cast<std::size_t>(covariates.ncol()) + conditioned.size();
  std::vector<double> cov(effective_n * covariate_count);
  for (int column = 0; column < covariates.ncol(); ++column)
    for (std::size_t row = 0; row < effective_n; ++row)
      cov[static_cast<std::size_t>(column) * effective_n + row] =
          covariates(static_cast<int>(retained[row]), column);
  for (std::size_t column = 0; column < conditioned.size(); ++column)
    for (std::size_t row = 0; row < effective_n; ++row)
      cov[(static_cast<std::size_t>(covariates.ncol()) + column) * effective_n + row] =
          conditioned[column][retained[row]];
  std::vector<glma::LinearModel> models;
  for (int trait = 0; trait < phenotypes.ncol(); ++trait) {
    std::vector<double> phenotype(effective_n);
    for (std::size_t row = 0; row < effective_n; ++row)
      phenotype[row] = phenotypes(static_cast<int>(retained[row]), trait);
    models.emplace_back(phenotype, cov, covariate_count);
  }
  std::vector<std::vector<AssociationOutput>> rows(
      models.size(), std::vector<AssociationOutput>(static_cast<std::size_t>(panel->marker_count())));
  std::vector<std::size_t> offsets(models.size(), 0);
  double scan_seconds = 0;
  unsigned threads_used = 1;
  for (std::uint64_t k = 0; k < panel->component_count(); ++k) {
    glma::ScanOptions options;
    options.sample_indices = scan_samples;
    options.marker_indices = panel->component_marker_indices(k);
    options.block_size = static_cast<std::size_t>(block_size);
    options.threads = static_cast<unsigned>(threads);
    const auto scans = glma::scan_bed_multi(models, panel->component(k), options);
    scan_seconds += scans.front().scan_seconds;
    threads_used = scans.front().threads_used;
    for (std::size_t trait = 0; trait < scans.size(); ++trait)
      for (const auto& result : scans[trait].rows) {
        auto& output = rows[trait].at(offsets[trait]++);
        output.status = glma::status_name(result.result.status);
        output.n = static_cast<double>(result.result.n); output.observed = output.n;
        output.af = result.result.allele_frequency; output.beta = result.result.beta;
        output.se = result.result.se; output.statistic = result.result.t;
        output.p = result.result.p;
      }
  }
  Rcpp::List output(models.size());
  for (std::size_t trait = 0; trait < models.size(); ++trait)
    output[trait] = Rcpp::List::create(
        Rcpp::_ ["method"] = conditioned.empty() ? "linear" : "linear_conditional",
        Rcpp::_ ["statistic_type"] = "t",
        Rcpp::_ ["associations"] = association_table(*panel, rows[trait]),
        Rcpp::_ ["fit"] = Rcpp::List::create(),
        Rcpp::_ ["diagnostics"] = Rcpp::List::create(
            Rcpp::_ ["scan_seconds"] = scan_seconds,
            Rcpp::_ ["threads_used"] = static_cast<int>(threads_used),
            Rcpp::_ ["conditioning_markers"] = conditioned.size(),
            Rcpp::_ ["conditioning_complete_samples"] = effective_n));
  return output;
}

// [[Rcpp::export]]
Rcpp::List cpp_glma_logistic_glist(
    Rcpp::List paths, Rcpp::NumericVector sample_indices,
    Rcpp::CharacterVector individual_ids, Rcpp::List marker_ids,
    Rcpp::NumericVector phenotype, Rcpp::NumericMatrix covariates,
    int threads, int block_size) {
  auto panel = panel_from_glist(paths, sample_indices, individual_ids, marker_ids);
  if (phenotype.size() != static_cast<R_xlen_t>(panel->sample_count()) ||
      covariates.nrow() != phenotype.size() || threads < 1 || block_size < 1)
    throw std::invalid_argument("invalid logistic scan dimensions or controls");
  const glma::LogisticModel model(
      std::vector<double>(phenotype.begin(), phenotype.end()),
      std::vector<double>(covariates.begin(), covariates.end()),
      static_cast<std::size_t>(covariates.ncol()));
  std::vector<AssociationOutput> rows(static_cast<std::size_t>(panel->marker_count()));
  std::size_t offset = 0;
  double scan_seconds = 0;
  for (std::uint64_t k = 0; k < panel->component_count(); ++k) {
    glma::ScanOptions options;
    options.sample_indices = panel->sample_source_indices();
    options.marker_indices = panel->component_marker_indices(k);
    options.block_size = static_cast<std::size_t>(block_size);
    options.threads = static_cast<unsigned>(threads);
    const auto scan = glma::scan_bed_logistic(model, panel->component(k), options);
    scan_seconds += scan.scan_seconds;
    for (const auto& result : scan.rows) {
      auto& output = rows.at(offset++);
      output.status = glma::logistic_status_name(result.result.status);
      output.n = static_cast<double>(result.result.n); output.observed = output.n;
      output.cases = static_cast<double>(result.result.cases);
      output.controls = static_cast<double>(result.result.controls);
      output.af = result.result.allele_frequency; output.beta = result.result.beta;
      output.se = result.result.se; output.statistic = result.result.z;
      output.p = result.result.p;
    }
  }
  return Rcpp::List::create(
      Rcpp::_ ["method"] = "logistic", Rcpp::_ ["statistic_type"] = "wald_z",
      Rcpp::_ ["effect_type"] = "log_odds",
      Rcpp::_ ["associations"] = association_table(*panel, rows),
      Rcpp::_ ["fit"] = Rcpp::List::create(),
      Rcpp::_ ["diagnostics"] = Rcpp::List::create(
          Rcpp::_ ["scan_seconds"] = scan_seconds, Rcpp::_ ["test_type"] = "wald"));
}

// [[Rcpp::export]]
Rcpp::List cpp_glma_loco_glist(
    Rcpp::List paths, Rcpp::NumericVector sample_indices,
    Rcpp::CharacterVector individual_ids, Rcpp::List marker_ids,
    Rcpp::NumericVector background_indices, Rcpp::NumericMatrix phenotypes,
    Rcpp::NumericMatrix covariates, std::string method, std::string algorithm,
    std::string storage, int threads, int block_size,
    double memory_limit_bytes, Rcpp::List controls, Rcpp::List component_groups) {
  auto panel = panel_from_glist(paths, sample_indices, individual_ids, marker_ids);
  if (method != "infinitesimal_loco" && method != "prior_selected_loco")
    throw std::invalid_argument("mixed association requires a LOCO method");
  if (phenotypes.nrow() != static_cast<int>(panel->sample_count()) ||
      phenotypes.ncol() < 1 || covariates.nrow() != phenotypes.nrow() ||
      threads < 1 || block_size < 1)
    throw std::invalid_argument("invalid LOCO scan dimensions or controls");
  const auto memory = byte_limit(memory_limit_bytes);
  std::vector<std::uint64_t> fit_markers;
  fit_markers.reserve(static_cast<std::size_t>(background_indices.size()));
  for (double value : background_indices) {
    const auto index = exact_index(value, "background marker index");
    if (index >= panel->marker_count())
      throw std::invalid_argument("background marker index is out of range");
    fit_markers.push_back(index);
  }
  glma::PredictionMarkerGroups groups;
  groups.names = Rcpp::as<std::vector<std::string>>(component_groups["names"]);
  const Rcpp::NumericVector group_ids = component_groups["group"];
  for (double value : group_ids) groups.marker_group.push_back(exact_index(value, "marker group"));
  glma::MixedOptions options;
  options.threads = static_cast<unsigned>(threads);
  options.block_size = static_cast<std::size_t>(block_size);
  options.memory_limit_bytes = memory;
  if (storage == "prepared")
    options.genotype_storage = glma::GenotypeStorage::prepared;
  else if (storage == "streamed")
    options.genotype_storage = glma::GenotypeStorage::streamed;
  else throw std::invalid_argument("unknown glma genotype storage");
  const std::vector<double> cov(covariates.begin(), covariates.end());
  const auto n = static_cast<std::size_t>(phenotypes.nrow());
  const auto* first = phenotypes.begin();
  glma::GenomicBackground prepared(panel, std::vector<double>(first, first + n),
      cov, static_cast<std::size_t>(covariates.ncol()), {}, fit_markers, options);
  Rcpp::List output(phenotypes.ncol());
  for (int trait = 0; trait < phenotypes.ncol(); ++trait) {
    const auto* values = phenotypes.begin() + static_cast<std::size_t>(trait) * n;
    auto background = prepared.with_phenotype(
        std::vector<double>(values, values + n));
    Rcpp::List result = finish_loco(panel, *background, method, algorithm,
        storage, threads, block_size, memory, controls, groups);
    Rcpp::List diagnostics = result["diagnostics"];
    diagnostics["shared_prepared_genotypes"] =
        background->shares_prepared_genotypes_with(prepared);
    result["diagnostics"] = diagnostics;
    output[trait] = result;
  }
  return output;
}

namespace {

Rcpp::List finish_loco(
    const std::shared_ptr<const gmat::BedPanel>& panel,
    glma::GenomicBackground& background, const std::string& method,
    const std::string& algorithm, const std::string& storage, int threads,
    int block_size, std::uint64_t memory, const Rcpp::List& controls,
    const glma::PredictionMarkerGroups& groups) {
  std::set<std::string> fitted_chromosomes;
  for (auto index : background.background_indices())
    fitted_chromosomes.insert(panel->marker(index).metadata.chromosome);
  for (const auto& marker : panel->markers())
    if (!fitted_chromosomes.count(marker.metadata.chromosome))
      throw std::invalid_argument("test chromosome absent from background markers");
  std::vector<AssociationOutput> rows(
      static_cast<std::size_t>(panel->marker_count()));
  if (method == "infinitesimal_loco" || method == "prior_selected_loco") {
    if (algorithm != "decoded_full" && algorithm != "packed_full" &&
        algorithm != "decoded_adaptive" && algorithm != "packed_adaptive")
      throw std::invalid_argument("unknown joint LOCO algorithm");
    if (storage == "streamed" && algorithm.rfind("packed_", 0) == 0)
      throw std::invalid_argument("packed products require prepared genotype storage");
    const bool gaussian = method == "infinitesimal_loco";
    const bool automatic = !controls.containsElementNamed("scaling_factor");
    glma::PredictionBackgroundOptions fit_options;
    fit_options.mode = gaussian ? glma::PredictionFitMode::joint_full_panel_ridge :
        glma::PredictionFitMode::joint_full_panel;
    fit_options.variational.product_backend =
        algorithm.rfind("packed_", 0) == 0 ?
          gbayes::PredictionProductBackend::packed :
          gbayes::PredictionProductBackend::decoded;
    fit_options.variational.marker_schedule =
        algorithm.find("_adaptive") != std::string::npos ?
          gbayes::PredictionMarkerSchedule::adaptive :
          gbayes::PredictionMarkerSchedule::full;
    fit_options.variational.threads = static_cast<unsigned>(threads);
    fit_options.variational.chunk_size = static_cast<std::size_t>(block_size);
    fit_options.decode_threads = control_or<int>(controls, "decode_threads", 1);
    fit_options.stream_read_gap_bytes =
        control_or<double>(controls, "stream_read_gap_bytes", 16384);
    fit_options.split_seed = control_or<double>(controls, "split_seed", 17092026);
    if (controls.containsElementNamed("validation_fraction"))
      fit_options.validation_fraction = Rcpp::as<double>(controls["validation_fraction"]);
    if (controls.containsElementNamed("maximum_sweeps"))
      fit_options.variational.maximum_sweeps = Rcpp::as<int>(controls["maximum_sweeps"]);
    glma::PriorSelectedStructure structure;
    if (automatic) {
      structure = background.prior_selected_structure(fit_options.split_seed);
      fit_options.retain_ridge_reference = structure.strong;
    }
    glma::PredictionComponentDiagnostics component_diagnostics;
    const auto fitted = background.fit_prediction(fit_options, groups, component_diagnostics);
    const bool grouped = !groups.names.empty();
    glma::PriorSelectedScanOptions scan_options;
    scan_options.block_size = static_cast<std::size_t>(block_size);
    scan_options.threads = static_cast<unsigned>(threads);
    glma::PriorSelectedCalibration calibration;
    if (automatic && structure.strong)
      calibration = background.calibrate_prior_selected(
          fitted, *panel, fit_options.split_seed, grouped);
    scan_options.scaling_factor = automatic ? calibration.scaling_factor :
      Rcpp::as<double>(controls["scaling_factor"]);
    const auto run = background.scan_prior_selected(fitted, *panel,
        [&](const glma::PriorSelectedRow& row) {
          auto& output = rows.at(static_cast<std::size_t>(row.marker_index));
          output.status = glma::status_name(row.status);
          output.n = static_cast<double>(row.n);
          output.observed = static_cast<double>(row.observed_n);
          output.af = row.allele_frequency; output.beta = row.beta;
          output.se = row.se; output.statistic = row.chi_square; output.p = row.p;
        }, scan_options);
    const auto& selected = fitted.candidates.at(fitted.selected_candidate);
    const auto count = fitted.models.size() - 1;
    Rcpp::CharacterVector excluded(count);
    Rcpp::NumericVector active(count), genetic(count, fitted.genetic_variance),
        residual(count, fitted.residual_variance), sweeps(count);
    std::size_t k = 0;
    for (const auto& model : fitted.models) {
      if (model.excluded_chromosome.empty()) continue;
      excluded[k] = model.excluded_chromosome;
      active[k] = std::count_if(fitted.marker_indices.begin(), fitted.marker_indices.end(),
          [&](auto j) { return panel->marker(j).metadata.chromosome != model.excluded_chromosome; });
      sweeps[k] = model.fit.sweeps;
      if (grouped) {
        genetic[k] = 0;
        for (std::size_t j = 0; j < fitted.marker_indices.size(); ++j)
          if (panel->marker(fitted.marker_indices[j]).metadata.chromosome != model.excluded_chromosome) {
            const auto c = groups.marker_group[j];
            genetic[k] += component_diagnostics.genetic_variances[c] /
                static_cast<double>(component_diagnostics.marker_counts[c]);
          }
      }
      ++k;
    }
    const auto component_count = component_diagnostics.names.size();
    Rcpp::CharacterVector component_name = Rcpp::wrap(component_diagnostics.names);
    Rcpp::NumericVector component_markers(component_count);
    Rcpp::LogicalVector adjusted(component_count);
    for (std::size_t c = 0; c < component_count; ++c) {
      component_markers[c] = component_diagnostics.marker_counts[c];
      adjusted[c] = component_diagnostics.initial_variances[c] !=
                    component_diagnostics.raw_initial_variances[c];
    }
    const auto component_table = Rcpp::DataFrame::create(
        Rcpp::_ ["component"] = component_name, Rcpp::_ ["markers"] = component_markers,
        Rcpp::_ ["raw_initial_variance"] = component_diagnostics.raw_initial_variances,
        Rcpp::_ ["initial_variance"] = component_diagnostics.initial_variances,
        Rcpp::_ ["initial_adjusted"] = adjusted,
        Rcpp::_ ["genetic_variance"] = component_diagnostics.genetic_variances);
    const auto component_rows = count * component_count;
    Rcpp::CharacterVector component_chromosome(component_rows), loco_component_name(component_rows);
    Rcpp::NumericVector retained(component_rows), component_variance(component_rows),
        active_prior_variance(component_rows), normalization(component_rows);
    for (std::size_t chromosome = 0; chromosome < count; ++chromosome) {
      const std::string excluded_chromosome = Rcpp::as<std::string>(excluded[chromosome]);
      for (std::size_t c = 0; c < component_count; ++c) {
        const auto row = chromosome * component_count + c;
        component_chromosome[row] = excluded_chromosome;
        loco_component_name[row] = groups.names[c];
        normalization[row] = component_diagnostics.marker_counts[c];
        component_variance[row] = component_diagnostics.genetic_variances[c];
        for (std::size_t j = 0; j < fitted.marker_indices.size(); ++j)
          if (groups.marker_group[j] == c &&
              panel->marker(fitted.marker_indices[j]).metadata.chromosome != excluded_chromosome)
            retained[row] += 1;
        active_prior_variance[row] = component_variance[row] * retained[row] / normalization[row];
      }
    }
    const auto loco_component_table = Rcpp::DataFrame::create(
        Rcpp::_ ["excluded_chromosome"] = component_chromosome,
        Rcpp::_ ["component"] = loco_component_name,
        Rcpp::_ ["active_markers"] = retained,
        Rcpp::_ ["normalization_markers"] = normalization,
        Rcpp::_ ["genetic_variance"] = component_variance,
        Rcpp::_ ["active_prior_variance"] = active_prior_variance);
    const auto loco = Rcpp::DataFrame::create(
        Rcpp::_ ["excluded_chromosome"] = excluded, Rcpp::_ ["active_markers"] = active,
        Rcpp::_ ["genetic_variance"] = genetic, Rcpp::_ ["residual_variance"] = residual,
        Rcpp::_ ["sweeps"] = sweeps);

    return Rcpp::List::create(
        Rcpp::_ ["method"] = method, Rcpp::_ ["statistic_type"] = "chi_square_1",
        Rcpp::_ ["associations"] = association_table(*panel, rows),
        Rcpp::_ ["fit"] = Rcpp::List::create(
          Rcpp::_ ["selected_prior"] = selected.prior.name,
          Rcpp::_ ["components"] = component_table,
          Rcpp::_ ["loco_components"] = loco_component_table,
          Rcpp::_ ["loco"] = loco,
          Rcpp::_ ["validation_mse"] = selected.validation_mse,
          Rcpp::_ ["genetic_variance"] = fitted.genetic_variance,
          Rcpp::_ ["residual_variance"] = fitted.residual_variance),
        Rcpp::_ ["diagnostics"] = Rcpp::List::create(
          Rcpp::_ ["background_marker_count"] =
            static_cast<double>(background.background_indices().size()),
          Rcpp::_ ["fitting_engine"] = gaussian ? "joint_full_panel_ridge" : "joint_full_panel",
          Rcpp::_ ["variance_estimator"] = grouped ? "component_rhe_profile_mc_grid" : "blocked_rhe_mc_grid",
          Rcpp::_ ["component_count"] = grouped ? static_cast<double>(component_count) : 1.0,
          Rcpp::_ ["component_ratios_fixed_after_rhe"] = grouped,
          Rcpp::_ ["component_normalization"] = grouped ? "global_marker_count" : "active_marker_count",
          Rcpp::_ ["component_initial_variance_floor"] = component_diagnostics.positive_variance_floor,
          Rcpp::_ ["component_rhe_condition_estimate"] = component_diagnostics.moment_condition_estimate,
          Rcpp::_ ["variance_shared_across_chromosomes"] = true,
          Rcpp::_ ["candidate_model_count"] = static_cast<double>(fitted.candidate_model_count),
          Rcpp::_ ["marker_power"] = fitted.selected_power ? *fitted.selected_power : NA_REAL,
          Rcpp::_ ["heritability"] = fitted.heritability_grid.heritability,
          Rcpp::_ ["heritability_grid_used_initial"] = fitted.heritability_grid.used_initial,
          Rcpp::_ ["scaling_factor"] = run.scaling_factor,
          Rcpp::_ ["scaling_source"] = automatic ?
            (structure.strong ? "ridge_reference" : "low_structure") :
            "caller_supplied",
          Rcpp::_ ["structure_mean_excess_correlation_squared"] = automatic ?
            structure.mean_excess_squared_correlation : NA_REAL,
          Rcpp::_ ["structure_z_score"] = automatic ? structure.z_score : NA_REAL,
          Rcpp::_ ["structure_pairs"] = automatic ?
            static_cast<double>(structure.cross_chromosome_pairs) : NA_REAL,
          Rcpp::_ ["ridge_scaling_factor"] = automatic && structure.strong ?
            calibration.ridge_scaling_factor : NA_REAL,
          Rcpp::_ ["calibration_markers"] = automatic && structure.strong ?
            static_cast<double>(calibration.comparison_markers) : 0.0,
          Rcpp::_ ["gamma_markers"] = automatic && structure.strong ?
            static_cast<double>(calibration.gamma_markers) : 0.0,
          Rcpp::_ ["product_backend"] =
            fitted.resolved_product_backend == gbayes::PredictionProductBackend::packed ?
              "packed" : "decoded",
          Rcpp::_ ["marker_schedule"] =
            fit_options.variational.marker_schedule ==
              gbayes::PredictionMarkerSchedule::adaptive ? "adaptive" : "full",
          Rcpp::_ ["skipped_model_markers"] =
            static_cast<double>(fitted.skipped_model_markers),
          Rcpp::_ ["variational_block_reads"] =
            static_cast<double>(fitted.variational_block_reads),
          Rcpp::_ ["initial_variance_seconds"] = fitted.training_variance_seconds,
          Rcpp::_ ["candidate_seconds"] = fitted.candidate_seconds,
          Rcpp::_ ["refit_seconds"] = fitted.refit_seconds,
          Rcpp::_ ["candidate_score_seconds"] = fitted.candidate_phase_seconds.score,
          Rcpp::_ ["candidate_coordinate_seconds"] = fitted.candidate_phase_seconds.coordinate,
          Rcpp::_ ["refit_score_seconds"] = fitted.refit_phase_seconds.score,
          Rcpp::_ ["refit_coordinate_seconds"] = fitted.refit_phase_seconds.coordinate,
          Rcpp::_ ["fit_seconds"] = fitted.total_seconds,
          Rcpp::_ ["scan_seconds"] = run.scan_seconds));
  }
  throw std::invalid_argument("unknown glma association method");
}

}  // namespace
