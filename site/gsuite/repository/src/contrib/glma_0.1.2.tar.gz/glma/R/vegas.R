.vegas_named <- function(x, name) {
  if (!is.list(x) || !length(x) || is.null(names(x)) || anyNA(names(x)) ||
      any(!nzchar(names(x))) || anyDuplicated(names(x)))
    .glma_stop("`", name, "` must be a nonempty uniquely named list.")
  x
}

.vegas_ids <- function(x, name) {
  if (!is.character(x) || !length(x) || anyNA(x) || any(!nzchar(x)) ||
      anyDuplicated(x)) .glma_stop("`", name, "` must contain unique marker IDs.")
  x
}

.vegas_controls <- function(control) {
  defaults <- list(maximum_markers = 2048L,
    tail_method = "saddlepoint", tail_absolute_tolerance = 1e-10,
    tail_relative_tolerance = 1e-5, maximum_series_terms = 4096L,
    relative_psd_tolerance = 1e-10)
  if (!is.list(control) || is.object(control) || is.null(names(control)) && length(control) ||
      anyNA(names(control)) || any(!nzchar(names(control))) || anyDuplicated(names(control)))
    .glma_stop("`control` must be an ordinary uniquely named list.")
  extra <- setdiff(names(control), names(defaults))
  if (length(extra)) .glma_stop("Unsupported control: ", extra[[1L]], ".")
  values <- utils::modifyList(defaults, control)
  for (name in c("maximum_markers", "maximum_series_terms"))
    values[[name]] <- .glma_count(values[[name]], name)
  values$tail_method <- match.arg(values$tail_method,
    c("saddlepoint", "controlled_series"))
  for (name in c("tail_absolute_tolerance", "tail_relative_tolerance",
      "relative_psd_tolerance")) {
    value <- values[[name]]
    if (!is.numeric(value) || length(value) != 1L || !is.finite(value) || value < 0)
      .glma_stop("Invalid `", name, "`.")
  }
  if (values$relative_psd_tolerance > 1e-6)
    .glma_stop("`relative_psd_tolerance` cannot exceed 1e-6.")
  values
}

.vegas_statistics <- function(stat, markers) {
  if (identical(class(stat), "data.frame")) stat <- list(trait = stat)
  else .vegas_named(stat, "stat")
  lapply(stat, function(data) {
    if (!identical(class(data), "data.frame") || !nrow(data) || anyDuplicated(names(data)))
      .glma_stop("Every stat entry must be a nonempty ordinary data frame.")
    if (length(setdiff(c("rsids", "ea", "nea"), names(data))))
      .glma_stop("Every stat entry must contain rsids, ea and nea.")
    if (identical(data$rsids, markers$marker_id)) at <- seq_along(data$rsids)
    else {
      .vegas_ids(data$rsids, "stat$rsids")
      at <- match(markers$marker_id, data$rsids)
      if (anyNA(at)) .glma_stop("Statistics are missing prepared markers: ",
        markers$marker_id[which(is.na(at))[1L]], ".")
    }
    if (!identical(data$ea[at], markers$allele1) ||
        !identical(data$nea[at], markers$allele2))
      .glma_stop("Statistics must match the prepared marker and allele order after marker selection.")
    if ("stat" %in% names(data)) z <- data$stat[at]
    else if ("z" %in% names(data)) z <- data$z[at]
    else if (all(c("b", "seb") %in% names(data))) z <- data$b[at] / data$seb[at]
    else if (all(c("score", "information") %in% names(data)))
      z <- data$score[at] / sqrt(data$information[at])
    else .glma_stop("Every stat entry must contain stat, z, b/seb or score/information.")
    if (any(!is.finite(z))) .glma_stop("Derived z statistics must be finite.")
    data.frame(marker = markers$marker_id, allele1 = markers$allele1,
      allele2 = markers$allele2, z = as.double(z), stringsAsFactors = FALSE)
  })
}

.vegas_set_inputs <- function(sets, weights, markers, controls, bounded = TRUE) {
  sets <- lapply(.vegas_named(sets, "sets"), .vegas_ids, name = "set")
  if (any(!unlist(sets, use.names = FALSE) %in% markers$marker_id))
    .glma_stop("Every set marker must exist in the sparse-LD resource.")
  if (is.null(weights)) {
    weights <- lapply(sets, function(ids) stats::setNames(rep(1, length(ids)), ids))
  } else {
    .vegas_named(weights, "weights")
    if (!identical(names(weights), names(sets)))
      .glma_stop("`weights` names and order must match `sets`.")
    weights <- Map(function(value, ids) {
      if (!is.numeric(value) || !identical(names(value), ids) || anyNA(value) ||
          any(!is.finite(value)) || any(value < 0) || !any(value > 0))
        .glma_stop("Each weight vector must be named in set order, finite, nonnegative and not all zero.")
      value
    }, weights, sets)
  }
  flat_indices <- match(unlist(sets, use.names = FALSE), markers$marker_id)
  ends <- cumsum(lengths(sets))
  starts <- c(1L, head(ends, -1L) + 1L)
  positions <- lapply(seq_along(sets), function(i)
    as.integer(flat_indices[seq.int(starts[[i]], ends[[i]])]))
  indices <- lapply(positions, function(position) {
    index <- sort(position)
    if (bounded && length(index) > controls$maximum_markers)
      .glma_stop("A marker set exceeds `maximum_markers`.")
    as.integer(index)
  })
  list(sets = sets, weights = weights, indices = indices, positions = positions)
}

.vegas_from_eigen <- function(Glist, sets, weights, controls, call) {
  saved <- Glist$eigen
  sets <- if (is.null(sets)) saved$sets else lapply(.vegas_named(sets, "sets"), .vegas_ids, name = "set")
  positions <- match(names(sets), names(saved$sets))
  if (anyNA(positions) || any(!vapply(seq_along(sets), function(i)
      setequal(sets[[i]], saved$sets[[positions[[i]]]]), logical(1))))
    .glma_stop("Each requested set must match its named Glist eigen region exactly; recompute with gprep(task = 'eigen') for changed membership.")
  marker_ids <- unlist(Glist$rsids, use.names = FALSE)
  selected <- sort(unique(match(unlist(sets, use.names = FALSE), marker_ids)))
  markers <- data.frame(marker_id = marker_ids[selected],
    allele1 = unlist(Glist$a1, use.names = FALSE)[selected],
    allele2 = unlist(Glist$a2, use.names = FALSE)[selected], stringsAsFactors = FALSE)
  inputs <- .vegas_set_inputs(sets, weights, markers, controls, bounded = FALSE)
  spectra <- Map(function(name, ids, w, position, index) {
    if (any(w != w[[1L]]) || w[[1L]] <= 0)
      .glma_stop("Stored unweighted eigenvalues require constant positive weights within each set; use sparse LD for nonuniform weights.")
    values <- saved$values[[position]] * w[[1L]]
    tolerance <- controls$relative_psd_tolerance * max(1, max(values))
    if (min(values) < -tolerance)
      .glma_stop("Stored spectrum is not positive semidefinite: ", name, ".")
    positive <- values[values > 0]
    if (!length(positive)) .glma_stop("Stored spectrum has zero variance: ", name, ".")
    list(set = name, markers = ids, allele1 = markers$allele1[index],
      allele2 = markers$allele2[index], indices = as.integer(index),
      weights = unname(w), eigenvalues = positive,
      null_mean = sum(w), null_variance = 2 * sum(positive^2),
      effective_rank = length(positive), clipped_eigenvalues = sum(values < 0),
      reference_sample_count = saved$n)
  }, names(sets), inputs$sets, inputs$weights, positions, inputs$positions)
  names(spectra) <- names(sets)
  structure(list(call = call, sets = inputs$sets, weights = inputs$weights,
    spectra = spectra, markers = markers, control = controls,
    reference = list(study = Glist$study, assembly = Glist$assembly,
      reference_sample_count = saved$n, sample_ids = saved$sample_ids,
      eigen_provenance = saved$provenance),
    diagnostics = list(threads_used = 0L, peak_batch_size = 0L,
      memory_budget_bytes = 0, eigen_reused = TRUE),
    execution = list(order = "stored regional spectra", reader_reused = FALSE,
      eigenvalues_only = TRUE, batch_size = 0L, eigen_reused = TRUE)),
    class = c("vegas_prepared", "list"))
}

.validate_vegas_prepared <- function(prepared) {
  if (!inherits(prepared, "vegas_prepared") || !is.list(prepared))
    .glma_stop("`prepared` must be a `vegas_prepared` object.")
  required <- c("sets", "weights", "spectra", "markers", "control",
    "reference", "diagnostics", "execution")
  if (length(setdiff(required, names(prepared))))
    .glma_stop("`prepared` is incomplete.")
  .vegas_named(prepared$sets, "prepared$sets")
  .vegas_named(prepared$spectra, "prepared$spectra")
  if (!identical(names(prepared$sets), names(prepared$spectra)))
    .glma_stop("Prepared set and spectrum identities differ.")
  marker_fields <- c("marker_id", "allele1", "allele2")
  if (!identical(class(prepared$markers), "data.frame") ||
      length(setdiff(marker_fields, names(prepared$markers))) ||
      !nrow(prepared$markers))
    .glma_stop("Prepared sparse-LD marker metadata are invalid.")
  prepared
}

#' Prepare reusable LD-aware VEGAS marker-set spectra
#'
#' @param Glist A `gbase::gprep()` Glist augmented by
#'   `gbase::gprep(Glist=, task="sparseld")` or `task="eigen"`.
#' @param sets A uniquely named list of marker-ID vectors. Defaults to the saved
#'   regional sets when Glist contains eigenvalues.
#' @param weights Optional uniquely named list matching `sets`; each entry is a
#'   named nonnegative numeric vector in the exact order of its set markers.
#' @param control Numerical limits and eigenspectrum controls.
#' @param threads Positive operation-local thread count used across marker sets.
#' @param verbose Whether to report preparation progress.
#' @return A serializable `vegas_prepared` object reusable for checked traits.
#' @export
prepare_vegas <- function(Glist, sets = NULL, weights = NULL, control = list(),
                          threads = 1L, verbose = FALSE) {
  call <- match.call()
  gbase::validate_Glist(Glist)
  controls <- .vegas_controls(control)
  threads <- .glma_count(threads, "threads")
  if (threads > 64L) .glma_stop("`threads` cannot exceed 64.")
  if (!is.logical(verbose) || length(verbose) != 1L || is.na(verbose))
    .glma_stop("`verbose` must be TRUE or FALSE.")
  if (!is.null(Glist$eigen)) {
    prepared <- .vegas_from_eigen(Glist, sets, weights, controls, call)
    if (verbose) message("VEGAS reused ", length(prepared$sets), " stored regional spectra.")
    return(prepared)
  }
  if (!is.list(Glist$sparseLD))
    .glma_stop("`Glist` must be augmented with `gprep(task = 'sparseld')`.")
  markers <- Glist$sparseLD$marker_metadata
  inputs <- .vegas_set_inputs(sets, weights, markers, controls)
  native_sets <- Map(function(ids, value) {
    list(markers = ids, weights = unname(value))
  }, inputs$sets, inputs$weights)
  native <- cpp_glma_prepare_vegas(Glist$sparseLD$prefix, native_sets,
    inputs$indices, controls, threads, verbose)
  structure(list(call = call, sets = inputs$sets, weights = inputs$weights,
    spectra = native$spectra, markers = markers, control = controls,
    reference = list(study = Glist$study, assembly = Glist$assembly,
      reference_sample_count = Glist$sparseLD$n,
      checksums = Glist$sparseLD$checksums),
    diagnostics = list(threads_used = native$threads_used,
      peak_batch_size = native$peak_batch_size,
      memory_budget_bytes = native$memory_budget_bytes),
    execution = list(order = "set batches", reader_reused = TRUE,
      eigenvalues_only = TRUE, batch_size = native$peak_batch_size)),
    class = c("vegas_prepared", "list"))
}

#' Fit LD-aware weighted quadratic VEGAS marker-set tests
#'
#' @param stat One ordinary checked data frame or a uniquely named list of data
#'   frames. Prepared markers are selected by rsids; additional rows and another
#'   row order are accepted. Required alleles must already match the reference.
#' @param Glist A sparse-LD or regional-eigen Glist. May be omitted with `prepared`.
#' @param sets A uniquely named list of marker-ID vectors. May be omitted with
#'   `prepared`.
#' @param weights Optional marker weights used during transient preparation.
#' @param metadata Optional set-level metadata, either one data frame or a list
#'   following trait names.
#' @param control Numerical limits and tail-evaluation controls.
#' @param verbose Whether to report transient preparation progress.
#' @param prepared Optional reusable object returned by [prepare_vegas()].
#' @param threads Positive operation-local preparation thread count.
#' @return A `vegas_fit` with per-trait set evidence and diagnostics.
#' @export
vegas <- function(stat, Glist = NULL, sets = NULL, weights = NULL,
                  metadata = NULL, control = list(), verbose = FALSE,
                  prepared = NULL, threads = 1L) {
  call <- match.call()
  reused <- !is.null(prepared)
  if (!reused) {
    if (is.null(Glist) || (is.null(sets) && is.null(Glist$eigen)))
      .glma_stop("Supply `Glist` and `sets`, or supply `prepared`.")
    prepared <- prepare_vegas(Glist, sets, weights, control, threads, verbose)
  } else {
    prepared <- .validate_vegas_prepared(prepared)
    if (!is.null(Glist) || !is.null(sets) || !is.null(weights))
      .glma_stop("Do not supply `Glist`, `sets` or `weights` with `prepared`.")
    if (!identical(threads, 1L) || !identical(verbose, FALSE))
      .glma_stop("`threads` and `verbose` apply only to VEGAS preparation.")
  }
  controls <- .vegas_controls(control)
  statistics <- .vegas_statistics(stat, prepared$markers)
  if (!is.null(metadata)) {
    if (is.data.frame(metadata)) metadata <- stats::setNames(rep(list(metadata),
      length(statistics)), names(statistics))
    .vegas_named(metadata, "metadata")
    if (!identical(names(metadata), names(statistics)))
      .glma_stop("`metadata` must follow trait names and order.")
    for (data in metadata) {
      required <- c("set", "sample_size", "mean_minor_allele_count")
      if (!is.data.frame(data) || !identical(names(data), required) ||
          !identical(data$set, names(prepared$sets)) ||
          any(!is.finite(data$sample_size)) || any(data$sample_size <= 0) ||
          any(!is.finite(data$mean_minor_allele_count)) ||
          any(data$mean_minor_allele_count <= 0))
        .glma_stop("`metadata` must contain positive set-level values in set order.")
    }
  }
  fits <- cpp_glma_evaluate_vegas(statistics, prepared$spectra, controls)
  result <- stats::setNames(lapply(seq_along(statistics), function(trait) {
    data <- do.call(rbind, lapply(fits, function(set) set$statistics[[trait]]))
    data <- data[match(names(prepared$sets), data$set), , drop = FALSE]
    rownames(data) <- NULL
    if (!is.null(metadata)) {
      data$sample_size <- metadata[[trait]]$sample_size
      data$mean_minor_allele_count <- metadata[[trait]]$mean_minor_allele_count
    }
    data
  }), names(statistics))
  structure(list(call = call, method = "vegas", stat = result,
    sets = prepared$sets, weights = prepared$weights, control = controls,
    reference = prepared$reference,
    diagnostics = lapply(fits, `[[`, "diagnostics"),
    execution = list(order = "set-major, trait-minor", reader_reused = TRUE,
      prepared_reused = reused,
      preparation_threads = prepared$diagnostics$threads_used)),
    class = c("vegas_fit", "list"))
}

#' @export
print.vegas_fit <- function(x, ...) {
  cat("<vegas_fit>", length(x$sets), "sets |", length(x$stat), "trait(s) |",
    "prepared LD spectra\n")
  for (trait in names(x$stat)) cat(trait, ":",
    sum(!x$stat[[trait]]$p_available), "unavailable set p-values\n")
  invisible(x)
}
