#' Report the loaded genotype-native contracts
#'
#' @return Nested build-header and runtime version and ABI information for
#'   `gmat`, `gbits`, and `gsolve`.
#' @export
gbase_native_info <- function() cpp_gbase_native_info()

.onLoad <- function(libname, pkgname) {
  info <- cpp_gbase_native_info()
  # Both the portable source closure and qualified external prefix must load
  # exactly the versions used at compilation; neither may mix native versions.
  ok <- identical(as.character(info$gmat$runtime_abi), "0") &&
    identical(as.character(info$gbits$runtime_abi), "4") &&
    identical(as.character(info$gsolve$runtime_abi), "4") &&
    all(vapply(info,function(x) identical(x$header_version,x$runtime_version) &&
      identical(as.character(x$header_abi),as.character(x$runtime_abi)),logical(1)))
  if (!ok) .gbase_stop("Loaded gmat/gbits/gsolve versions or ABIs are incompatible with gbase.")
}

.gprep_path <- function(x, name) {
  if (!is.character(x) || !length(x) || anyNA(x) || any(!nzchar(x)))
    .gbase_stop("`", name, "` must contain nonempty file paths.")
  missing <- !file.exists(x) | dir.exists(x)
  if (any(missing)) .gbase_stop("Missing `", name, "` file: ", x[which(missing)[1L]])
  unname(normalizePath(x, winslash = "/", mustWork = TRUE))
}
.gprep_companion <- function(x, extension) {
  if (any(!grepl("\\.bed$", x, ignore.case = TRUE)))
    .gbase_stop("Cannot infer companion path from a non-.bed file.")
  sub("\\.bed$", paste0(".", extension), x, ignore.case = TRUE)
}
.gprep_selection <- function(x, name) {
  if (is.null(x)) return(NULL)
  if (!is.character(x) || !length(x) || anyNA(x) || any(!nzchar(x)) || anyDuplicated(x))
    .gbase_stop("`", name, "` must contain unique nonempty identifiers.")
  x
}
.gprep_count <- function(x, name, minimum = 1L) {
  if (!is.numeric(x) || length(x) != 1L || !is.finite(x) || x != floor(x) ||
      x < minimum || x > .Machine$integer.max)
    .gbase_stop("`", name, "` must be an integer of at least ", minimum, ".")
  as.integer(x)
}
.gprep_number <- function(x, name, lower = 0) {
  if (!is.numeric(x) || length(x) != 1L || !is.finite(x) || x < lower)
    .gbase_stop("`", name, "` must be finite and at least ", lower, ".")
  as.double(x)
}
.gprep_flag <- function(x, name) {
  if (!is.logical(x) || length(x) != 1L || is.na(x))
    .gbase_stop("`", name, "` must be TRUE or FALSE.")
  x
}
.gprep_prefix <- function(x) {
  if (!is.character(x) || length(x) != 1L || is.na(x) || !nzchar(x))
    .gbase_stop("`out_prefix` must be one nonempty path.")
  if (!dir.exists(dirname(x))) .gbase_stop("The output-prefix directory does not exist.")
  file.path(normalizePath(dirname(x), winslash = "/", mustWork = TRUE), basename(x))
}
.gprep_paths <- function(resources) lapply(resources, `[[`, "paths")

#' Prepare a serializable PLINK genotype descriptor
#'
#' `task = "prepare"` validates PLINK BED/BIM/FAM triplets and computes exact
#' selected-sample marker summaries. `task = "sparseld"` returns the supplied
#' Glist augmented with a disk-backed sparse signed-LD resource.
#' `task = "eigen"` computes reusable full regional LD eigenvalues from BED,
#' without using the sparse-LD windows or cutoff.
#' @param Glist A prepared Glist for `task = "subset"`, `"sparseld"`, `"eigen"`,
#'   or `"ldscores"`.
#'   Sparse LD also accepts a full-panel descriptor from [gprep_mapped()].
#' @param study Optional study label.
#' @param bedfiles,bimfiles,famfiles PLINK file paths.
#' @param ids,rsids Optional ordered sample IDs and marker IDs.
#' @param task One of `"prepare"`, `"subset"`, `"sparseld"`, `"eigen"`, or `"ldscores"`.
#' @param nthreads Positive local thread count. Writing `.ext` files uses one thread.
#' @param out_prefix Output prefix. For sparse LD, this defaults to the BED stem
#'   for a single-file Glist. For multiple BED files, supply `out_prefix` or
#'   `ldfiles`. For a PLINK subset, the default is the first input BED stem
#'   with a `.subset` suffix.
#' @param companion Full-panel preparation and the subset task use a same-stem
#'   `.ext` per BED by default. Set to `NULL` explicitly for an in-memory Glist.
#'   `"binary"` explicitly requests `.ext` storage. Preparation with `ids` or
#'   `rsids` uses in-memory summaries for the selected rows.
#' @param mapped_dir Optional legacy output directory for mapped panel metadata.
#'   Also applies to the Glist returned by the subset task. Marker rsids are
#'   kept in memory and other per-marker columns are read on demand.
#' @param max_distance_bp,max_distance_variants Sparse-LD windows; zero disables a window.
#' @param r2 Compatibility alias for `min_r2`; do not supply both.
#' @param min_r2 Minimum raw squared correlation. Defaults to 0.01 for
#'   `sparseld`, or 0 for `ldscores`. The `msize`-only alias retains its zero cutoff.
#' @param powers Named architecture powers for `ldscores`; U = -1 and D = -0.25.
#' @param corrected Apply finite-reference-sample correction to direct scores.
#' @param hwe_heritability Use Hardy-Weinberg variance for architecture weights.
#' @param annotation Marker-named annotation matrix for direct scores; NULL uses
#'   one all-ones Base column.
#' @param window_cm Optional positive genetic-distance window for direct scores,
#'   using the BIM map. Mutually exclusive with nonzero physical/marker windows.
#' @param write_ld Also save sparse pairwise LD for direct scores. Requires
#'   physical/marker windows and out_prefix; uses a separate sparse-LD pass.
#' @param block_size Positive marker block size.
#' @param overwrite Replace an existing owned sparse-LD resource.
#' @param progress Report sparse-LD progress. Prints one line per completed
#'   chromosome and an update after 10 minutes without a line, at the next
#'   completed block. Use `FALSE` for quiet operation.
#' @param allow_full_ld Authorize both distance windows being disabled.
#' @param sets Named list of nonempty unique marker-ID vectors for `task = "eigen"`.
#' Each set must resolve to one chromosome; membership is stored in reference order.
#' @param eigen_control Named numerical controls as in [ld_eigen()]. The dimension
#' limit applies to the smaller of the sample and marker dimensions.
#' @param msize Familiar alias for max_distance_variants. When supplied alone,
#'   uses a marker-count-only window and retains all correlations (r2 = 0).
#' @param ldfiles Familiar single output name; its .ld suffix is removed to form
#'   the sparse-resource prefix. The native resource layout remains unchanged.
#' @param reference_groups Optional named ancestry sample selections as in
#'   setReferenceGroups; stored as indices for summary checking and imputation.
#' @details
#' Full-panel preparation reuses matching `.ext` files when present. An
#' existing file must describe the supplied triplet and, if supplied, study.
#' Keep the `.ext` files with a saved Glist to read its on-disk fields.
#'
#' `task = "subset"` writes new BED/BIM/FAM files in physical source order,
#' with a matching `.ext` per output BED by default.
#' It returns a Glist for the output files and records absent marker identifiers
#' in `Glist$missing_rsids`. Supply `rsids` by name. `ids = NULL` keeps all
#' physical FAM samples. Existing LD fields are calculated for the original
#' panel and are not carried into the new Glist.
#'
#' `task = "ldscores"` records ordinary per-component `Glist$ldscores` when
#' no sparse resource is present, and adds `Glist$ldscore_models`, containing scores, tagging,
#' expected heritability and resolved settings. Its default window is 1 Mb with
#' no marker-count limit. No pairwise LD is written unless write_ld = TRUE.
#' min_r2 filters architecture scores; tagging includes every in-window pair.
#' @return A serializable Glist. Disk-backed descriptors also inherit from
#'   `gs_mapped_genotypes`.
#' @md
#' @export
gprep <- function(Glist = NULL, study = NULL, bedfiles = NULL,
    bimfiles = NULL, famfiles = NULL, ids = NULL, rsids = NULL,
    task = "prepare", nthreads = 1L, out_prefix = NULL,
    max_distance_bp = 1000000, max_distance_variants = 1000L,
    r2 = 0.01, block_size = 1024L, overwrite = FALSE,
    allow_full_ld = FALSE, sets = NULL, eigen_control = list(),
    msize = NULL, ldfiles = NULL, reference_groups = NULL, min_r2 = NULL,
    powers = c(U = -1, D = -0.25), corrected = TRUE,
    hwe_heritability = TRUE, annotation = NULL, window_cm = NULL,
    write_ld = FALSE, mapped_dir = NULL, companion = NULL, progress = TRUE) {
  # Keep the positional subset call gprep(Glist, task = "subset", rsids, ids = ...).
  if (identical(task, "subset") && !missing(study) && missing(rsids) &&
      !("study" %in% names(sys.call()))) {
    rsids <- study
    study <- NULL
  }
  if (!missing(r2) && !missing(min_r2))
    .gbase_stop("Specify either `min_r2` or `r2`, not both.")
  threshold_supplied <- !missing(r2) || !missing(min_r2)
  if (!is.null(min_r2)) r2 <- min_r2
  else if (identical(task, "ldscores") && missing(r2)) r2 <- 0
  if (!is.null(reference_groups) && task != "prepare")
    .gbase_stop("Label an existing Glist with setReferenceGroups before preparing LD.")
  if (!is.null(msize) || !is.null(ldfiles)) {
    if (!task %in% c("sparseld", "ldscores"))
      .gbase_stop("`msize` and `ldfiles` require task = 'sparseld' or 'ldscores'.")
    if (!is.null(msize)) {
      if (!missing(max_distance_variants))
        .gbase_stop("Specify either `msize` or `max_distance_variants`, not both.")
      max_distance_variants <- msize
      if (missing(max_distance_bp)) max_distance_bp <- 0
      if (!threshold_supplied) r2 <- 0
    }
    if (!is.null(ldfiles)) {
      if (!is.null(out_prefix)) .gbase_stop("Specify either `ldfiles` or `out_prefix`, not both.")
      if (!is.character(ldfiles) || length(ldfiles) != 1L || is.na(ldfiles) || !nzchar(ldfiles))
        .gbase_stop("`ldfiles` must be one nonempty sparse-resource output name.")
      out_prefix <- sub("\\.ld$", "", ldfiles, ignore.case = TRUE)
    }
  }
  if (!is.character(task) || length(task) != 1L || is.na(task) ||
      !task %in% c("prepare", "subset", "sparseld", "eigen", "ldscores"))
    .gbase_stop("`task` must be `prepare`, `subset`, `sparseld`, `eigen`, or `ldscores`.")
  if (task != "ldscores") {
  if (!is.null(min_r2) && task != "sparseld")
    .gbase_stop("min_r2 requires task = 'sparseld' or 'ldscores'.")
  if (!missing(powers) || !missing(corrected) || !missing(hwe_heritability) ||
      !is.null(annotation) || !is.null(window_cm) || !missing(write_ld))
    .gbase_stop("Score settings require task = 'ldscores'.")
  }
  if (missing(companion) && is.null(mapped_dir) &&
      (task == "subset" || (task == "prepare" && is.null(ids) && is.null(rsids))))
    companion <- "binary"
  if ((!is.null(mapped_dir) || !is.null(companion)) && !task %in% c("prepare", "subset"))
    .gbase_stop("Companion preparation requires task = 'prepare' or 'subset'.")
  if (!is.null(companion)) {
    if (!is.null(mapped_dir)) .gbase_stop("Specify either `companion` or `mapped_dir`.")
    companion <- match.arg(companion, "binary")
  }
  if (task == "eigen") return(.gprep_eigen(Glist, sets, ids, rsids,
    nthreads, out_prefix, eigen_control))
  if (!is.null(sets) || length(eigen_control))
    .gbase_stop("`sets` and `eigen_control` require task = 'eigen'.")
  if (task == "subset") {
    if (!is.null(bedfiles) || !is.null(bimfiles) || !is.null(famfiles))
      .gbase_stop("Supply the input triplets in `Glist` for task = 'subset'.")
    if (.gprep_flag(overwrite, "overwrite"))
      .gbase_stop("Subset output files must be new.")
    return(.gprep_subset(Glist, rsids, ids, out_prefix, nthreads, study, mapped_dir, companion))
  }
  if (task == "ldscores") {
    if (!is.null(study) || !is.null(bedfiles) || !is.null(bimfiles) || !is.null(famfiles))
      .gbase_stop("Prepare the genotype descriptor before requesting LD scores.")
    if (!is.null(window_cm)) {
      if ((!missing(max_distance_bp) && max_distance_bp != 0) ||
          (!missing(max_distance_variants) && max_distance_variants != 0))
        .gbase_stop("Use either window_cm or physical/marker windows, not both.")
      max_distance_bp <- 0
      max_distance_variants <- 0
    } else if (missing(max_distance_variants)) max_distance_variants <- 0
    return(.gprep_ldscores(Glist, annotation, powers, ids, rsids,
      window_cm, max_distance_bp, max_distance_variants, r2, corrected,
      hwe_heritability, block_size, nthreads, write_ld, out_prefix,
      overwrite, allow_full_ld))
  }
  if (task == "sparseld") return(.gprep_sparseld(Glist, out_prefix, ids,
    rsids, max_distance_bp, max_distance_variants, r2, block_size,
    nthreads, overwrite, allow_full_ld, progress))
  if (!is.null(Glist)) .gbase_stop("`Glist` must be NULL for preparation.")
  if (!is.null(mapped_dir) || !is.null(companion)) {
    if (!is.null(ids) || !is.null(rsids))
      .gbase_stop("Mapped preparation retains all physical samples and markers.")
    nthreads <- .gprep_count(nthreads, "nthreads")
    if (is.null(companion)) {
      if (nthreads != 1L) .gbase_stop("Mapped preparation currently uses one thread.")
      prepared <- gprep_mapped(bedfiles, mapped_dir, bimfiles, famfiles, study)
    } else {
      prepared <- .gprep_ext(bedfiles, bimfiles, famfiles, study)
    }
    if (!is.null(reference_groups))
      prepared <- setReferenceGroups(prepared, reference_groups)
    return(prepared)
  }
  if (!is.null(study) && (!is.character(study) || length(study) != 1L || is.na(study)))
    .gbase_stop("`study` must be NULL or one string.")
  bedfiles <- .gprep_path(bedfiles, "bedfiles")
  if (is.null(bimfiles)) bimfiles <- .gprep_companion(bedfiles, "bim")
  if (is.null(famfiles)) famfiles <- .gprep_companion(bedfiles, "fam")
  if (length(bimfiles) != length(bedfiles) || length(famfiles) != length(bedfiles))
    .gbase_stop("PLINK path vectors must have equal lengths.")
  bimfiles <- .gprep_path(bimfiles, "bimfiles"); famfiles <- .gprep_path(famfiles, "famfiles")
  ids <- .gprep_selection(ids, "ids"); rsids <- .gprep_selection(rsids, "rsids")
  nthreads <- .gprep_count(nthreads, "nthreads")
  read_resource <- if (is.null(rsids)) cpp_gbase_full_plink_metadata else cpp_gbase_bed_resource
  resources <- lapply(seq_along(bedfiles), function(i)
    read_resource(bedfiles[i], bimfiles[i], famfiles[i]))
  canonical <- resources[[1L]]$samples
  if (anyDuplicated(canonical$individual_id)) .gbase_stop("FAM individual IDs must be globally unique.")
  rows <- if (is.null(ids)) seq_len(nrow(canonical)) else match(ids, canonical$individual_id)
  if (anyNA(rows)) .gbase_stop("Requested sample ID not found: ", ids[which(is.na(rows))[1L]])
  marker_ids <- lapply(resources, function(x) x$markers$marker_id)
  all_markers <- if (length(marker_ids) == 1L) marker_ids[[1L]] else
    unlist(marker_ids, use.names = FALSE)
  if (anyDuplicated(all_markers)) .gbase_stop("Marker IDs must be globally unique.")
  if (is.null(rsids)) {
    source <- lapply(resources, function(x) as.double(seq_len(x$marker_count)) - 1)
    metadata <- lapply(resources, `[[`, "markers")
  } else {
    if (any(!rsids %in% all_markers)) .gbase_stop("Requested marker ID not found.")
    source <- lapply(marker_ids, function(x) as.double(which(x %in% rsids) - 1L))
    metadata <- Map(function(x, i) x$markers[i + 1, , drop = FALSE], resources, source)
  }
  # The parsed resources already establish physical marker indices. Check
  # ordered sample identities without reopening the files or building a panel.
  reference_identity <- canonical[c("family_id", "individual_id")]
  for (i in seq_along(resources)[-1L]) {
    if (!identical(resources[[i]]$samples[names(reference_identity)], reference_identity))
      .gbase_stop("BedPanel components must have identical ordered FAM identities.")
  }
  sample_source <- as.double(rows - 1L)
  sample_count <- resources[[1L]]$sample_count
  marker_counts <- vapply(resources, `[[`, numeric(1), "marker_count")
  rm(resources, all_markers, marker_ids)
  counts <- cpp_gbase_bed_counts(bedfiles, sample_count, marker_counts,
    sample_source, source, nthreads)
  observed <- lapply(counts, function(x) x$n0 + x$n1 + x$n2)
  if (any(unlist(observed) == 0)) .gbase_stop("A selected marker has no observed genotypes.")
  af <- Map(function(x,n) (2*x$n2+x$n1)/(2*n), counts, observed)
  result <- list(study=study,bedfiles=bedfiles,bimfiles=bimfiles,famfiles=famfiles,
    ids=canonical$individual_id,study_ids=ids,n=sample_count,nchr=length(bedfiles),
    physical_marker_counts=marker_counts,
    rsids=lapply(metadata,`[[`,"marker_id"),mchr=vapply(metadata,nrow,integer(1)),
    chr=lapply(metadata,`[[`,"chromosome"),pos=lapply(metadata,`[[`,"base_pair_position"),
    map=lapply(metadata,`[[`,"genetic_distance_cm"),a1=lapply(metadata,`[[`,"allele1"),
    a2=lapply(metadata,`[[`,"allele2"),af=af,af1=af,af2=lapply(af,function(x)1-x),
    maf=lapply(af,function(x)pmin(x,1-x)),nmiss=lapply(counts,`[[`,"nmiss"),
    hom=Map(function(x,n)(x$n0+x$n2)/n,counts,observed),het=Map(function(x,n)x$n1/n,counts,observed),
    n0=lapply(counts,`[[`,"n0"),n1=lapply(counts,`[[`,"n1"),n2=lapply(counts,`[[`,"n2"),
    assembly=NULL,source_marker_indices_0based=source,
    sample_source_indices_0based=sample_source,
    genotype_format="PLINK BED SNP-major",marker_selection_order="canonical file/BIM order",
    provenance=list(persistent_store="existing PLINK BED files",summary_samples=if(is.null(ids))"all" else "ids subset",dosage_allele="BIM field 5 (a1)",af_policy="exact empirical; no clipping",versions=gbase_native_info()))
  result$cpra <- Map(function(chr,pos,a1,a2) paste(chr,pos,a1,a2,sep="_"),result$chr,result$pos,result$a1,result$a2)
  result$m <- sum(result$mchr); class(result) <- c("gs_genotypes","Glist")
  if (!is.null(reference_groups)) result$reference_groups <- .gbase_reference_groups(result, reference_groups)
  result
}

#' Validate a prepared Glist
#' @param Glist A prepared genotype object.
#' @return The object invisibly. Sparse-LD descriptor identity and file
#'   availability are checked without rescanning the immutable CSR payload.
#' @export
validate_Glist <- function(Glist) {
  .gprep_validate(Glist, collect_resources = FALSE)
  invisible(Glist)
}

#' Fully verify a prepared sparse-LD resource
#'
#' This is the explicit integrity check for a newly received, copied, or
#' suspected sparse-LD resource. Ordinary consumers should use
#' `validate_Glist()`, which checks the serializable descriptor without
#' hashing or rescanning the complete payload.
#' @param Glist A prepared Glist augmented by `gprep(task = "sparseld")`.
#' @return The object invisibly after native structure, metadata, checksums,
#'   and recorded ordinary LD scores have been verified.
#' @export
verify_ld <- function(Glist) {
  validate_Glist(Glist)
  if (is.null(Glist$sparseLD))
    .gbase_stop("`Glist` has no sparse LD; use gprep(Glist, task = 'sparseld').")
  .gprep_verify_sparse_ld(Glist)
  invisible(Glist)
}

.gprep_checksums <- function(paths) {
  hashes <- unname(tools::md5sum(unlist(paths, use.names = FALSE)))
  if (anyNA(hashes)) .gbase_stop("Cannot read every sparse-LD resource file.")
  stats::setNames(hashes, names(paths))
}

.gprep_validate_sparse_ld <- function(Glist) {
  saved <- Glist$sparseLD
  if (!is.list(saved)) .gbase_stop("Glist sparseLD must be a prepared resource.")
  required <- c("prefix", "format", "version", "paths", "n", "source_n", "m", "nnz", "chr", "rsids",
    "sample_ids", "sample_indices_0based", "marker_indices_0based",
    "marker_metadata", "checksums")
  if (length(missing <- setdiff(required, names(saved))))
    .gbase_stop("Glist sparseLD is missing: ", paste(missing, collapse = ", "))
  if (!is.character(saved$prefix) || length(saved$prefix) != 1L ||
      is.na(saved$prefix) || !nzchar(saved$prefix) ||
      !identical(saved$prefix, .gprep_prefix(saved$prefix)))
    .gbase_stop("Glist sparse-LD prefix must remain canonical and unchanged.")
  if (!identical(saved$format, "sparse_ld_csr") ||
      !identical(as.integer(saved$version), 1L))
    .gbase_stop("Glist sparse-LD format is unsupported.")
  path_names <- c("row_ptr", "col_idx", "values", "metadata", "markers")
  if (!is.list(saved$paths) || !identical(names(saved$paths), path_names) ||
      any(lengths(saved$paths) != 1L))
    .gbase_stop("Glist sparse-LD paths are invalid.")
  canonical_paths <- lapply(saved$paths, .gprep_path, name = "Glist sparse-LD path")
  if (!identical(saved$paths, canonical_paths))
    .gbase_stop("Glist sparse-LD paths must remain canonical and unchanged.")
  expected_paths <- stats::setNames(lapply(c(".row_ptr.u64.bin", ".col_idx.u32.0based.bin",
    ".values.f32.bin", ".meta.txt", ".markers.tsv"),
    function(suffix) paste0(saved$prefix, suffix)), path_names)
  if (!identical(saved$paths, expected_paths))
    .gbase_stop("Glist sparse-LD paths do not match its prefix.")
  if (!identical(Glist$ldfiles, saved$paths))
    .gbase_stop("Glist ldfiles do not identify its sparse-LD resource.")
  if (!identical(Glist$idsLD, saved$sample_ids))
    .gbase_stop("Glist idsLD do not identify its sparse-LD samples.")
  if (!is.numeric(saved$chr) || anyNA(saved$chr) ||
      any(saved$chr != floor(saved$chr)) || any(saved$chr < 1 | saved$chr > Glist$nchr) ||
      anyDuplicated(saved$chr) || !is.list(saved$rsids) ||
      length(saved$rsids) != length(saved$chr) || !identical(Glist$rsidsLD, {
        by_file <- vector("list", Glist$nchr)
        by_file[] <- list(character())
        by_file[saved$chr] <- saved$rsids
        by_file
      }))
    .gbase_stop("Glist rsidsLD do not identify its sparse-LD markers.")
  counts <- c(n = saved$n, source_n = saved$source_n, m = saved$m, nnz = saved$nnz)
  if (!is.numeric(counts) || anyNA(counts) || any(!is.finite(counts)) ||
      any(counts != floor(counts)) || saved$n < 2 || saved$source_n < saved$n ||
      saved$m < 1 || saved$nnz < 0 || nrow(saved$marker_metadata) != saved$m)
    .gbase_stop("Glist sparse-LD dimensions are invalid.")
  if (!is.null(saved$metadata_storage)) {
    .ld_check_metadata_storage(Glist, saved)
  } else {
    .gprep_validate_ld_markers(Glist, saved)
  }
  sample_indices <- saved$sample_indices_0based
  if (!is.numeric(sample_indices) || anyNA(sample_indices) ||
      any(!is.finite(sample_indices)) || any(sample_indices != floor(sample_indices)) ||
      any(sample_indices < 0 | sample_indices >= Glist$n) || anyDuplicated(sample_indices) ||
      length(sample_indices) != saved$n || length(saved$sample_ids) != saved$n ||
      !identical(saved$sample_ids, Glist$ids[sample_indices + 1L]))
    .gbase_stop("Glist sparse-LD sample order is inconsistent.")
  if (is.null(saved$metadata_storage)) {
    af <- saved$marker_metadata$allele_frequency
    if (!is.numeric(af) || length(af) != saved$m || anyNA(af) ||
        any(!is.finite(af)) || any(af < 0 | af > 1))
      .gbase_stop("Glist sparse-LD allele frequencies are invalid.")
  }
  recorded_scores <- unlist(Glist$ldscores, use.names = FALSE)
  if (!is.list(Glist$ldscores) || length(Glist$ldscores) != Glist$nchr ||
      !identical(lengths(Glist$ldscores), lengths(Glist$rsidsLD)) ||
      !is.numeric(recorded_scores) || length(recorded_scores) != saved$m ||
      anyNA(recorded_scores) || any(!is.finite(recorded_scores)))
    .gbase_stop("Glist sparse-LD scores are invalid.")
  if (!is.character(saved$checksums) || anyNA(saved$checksums) ||
      !identical(names(saved$checksums), names(saved$paths)) ||
      any(!nzchar(saved$checksums)))
    .gbase_stop("Glist sparse-LD checksums are invalid.")
  invisible(saved)
}

.gprep_validate_ld_markers <- function(Glist, saved) {
  if (!is.data.frame(saved$marker_metadata) ||
      !all(c("marker_id", "allele_frequency", "source_marker_index_0based") %in%
        names(saved$marker_metadata)) ||
      !identical(unlist(saved$rsids, use.names = FALSE), saved$marker_metadata$marker_id))
    .gbase_stop("Glist sparse-LD marker identity is inconsistent.")
  expected_marker_indices <- if (inherits(Glist, "gs_mapped_genotypes")) {
    .mapped_ld_marker_indices(Glist, saved)
  } else Map(function(ids, component) {
    selected <- match(ids, Glist$rsids[[component]])
    if (anyNA(selected)) return(NULL)
    Glist$source_marker_indices_0based[[component]][selected]
  }, saved$rsids, saved$chr)
  if (!is.list(saved$marker_indices_0based) ||
      length(saved$marker_indices_0based) != length(saved$chr) ||
      !identical(as.double(unlist(saved$marker_indices_0based, use.names = FALSE)),
        saved$marker_metadata$source_marker_index_0based[seq_len(saved$m)]) ||
      !identical(lapply(saved$marker_indices_0based, function(x) x[seq_along(x)]),
        unname(expected_marker_indices)))
    .gbase_stop("Glist sparse-LD marker mappings are inconsistent.")
}

.gprep_verify_sparse_ld <- function(Glist) {
  saved <- .gprep_validate_sparse_ld(Glist)
  resource <- cpp_gbase_sparse_ld_open(saved$prefix)
  marker_fields <- names(resource$markers)
  if (!identical(saved$prefix, resource$prefix) ||
      !identical(saved$format, resource$format) ||
      !identical(as.integer(saved$version), as.integer(resource$format_version)) ||
      !identical(saved$paths, resource$paths) ||
      !identical(as.double(saved$n), as.double(resource$reference_sample_count)) ||
      !identical(as.double(saved$source_n), as.double(resource$source_sample_count)) ||
      !identical(as.double(saved$m), as.double(resource$marker_count)) ||
      !identical(as.double(saved$nnz), as.double(resource$stored_entry_count)) ||
      !identical(read_ld_metadata(Glist, fields = marker_fields), resource$markers) ||
      !identical(unlist(saved$rsids, use.names = FALSE), resource$markers$marker_id) ||
      !identical(as.double(unlist(saved$marker_indices_0based, use.names = FALSE)),
        as.double(resource$markers$source_marker_index_0based)))
    .gbase_stop("Glist sparse-LD metadata does not match its native resource.")
  if (!identical(saved$checksums, .gprep_checksums(resource$paths)))
    .gbase_stop("Glist sparse-LD files changed after preparation.")
  for (file in saved$metadata_storage) {
    if (!is.null(file) && !identical(unname(tools::md5sum(file$path)), file$md5))
      .gbase_stop("Glist sparse-LD metadata files changed after preparation.")
  }
  .gprep_validate_ld_markers(Glist, saved)
  af <- saved$marker_metadata$allele_frequency[seq_len(saved$m)]
  if (anyNA(af) || any(!is.finite(af)) || any(af < 0 | af > 1))
    .gbase_stop("Glist sparse-LD allele frequencies are invalid.")
  scores <- cpp_gbase_ld_scores(saved$prefix, FALSE, NULL, character(), character())
  if (!isTRUE(all.equal(unname(unlist(Glist$ldscores, use.names = FALSE)),
        unname(scores), tolerance = 1e-12)))
    .gbase_stop("Glist sparse-LD scores do not match the native resource.")
  invisible(resource)
}

.gprep_validate_ld_blocks <- function(saved, sparse_ld) {
  if (!is.list(saved) || !identical(saved$schema_version, 1L) ||
      !is.data.frame(saved$blocks) || !is.numeric(saved$offsets_0based) ||
      !identical(saved$sparse_ld_checksums, sparse_ld$checksums))
    .gbase_stop("Glist ldBlocks is not tied to its sparse-LD identity.")
  expected <- .gbase_block_table(saved$blocks,
    sparse_ld$marker_metadata$marker_id,
    as.character(sparse_ld$marker_metadata$chromosome))
  offsets <- c(expected$begin_0based, tail(expected$end_0based, 1L))
  if (!identical(saved$blocks, expected) || !identical(saved$offsets_0based, offsets))
    .gbase_stop("Glist ldBlocks manifest is inconsistent.")
  invisible(saved)
}

.gprep_validate <- function(Glist, collect_resources=TRUE) {
  if (inherits(Glist, "gs_mapped_genotypes")) {
    .gprep_validate_mapped(Glist)
    if (!is.null(Glist$eigen)) .gprep_validate_eigen(Glist)
    if (!is.null(Glist$reference_groups)) .gbase_reference_groups(Glist)
    resources <- if (collect_resources)
      cpp_gbase_mapped_source_resources(Glist$path) else list()
    return(list(resources = resources))
  }
  if (!inherits(Glist,"gs_genotypes") || !inherits(Glist,"Glist") || !is.list(Glist))
    .gbase_stop("`Glist` must be a prepared gs_genotypes/Glist object.")
  required <- c("bedfiles","bimfiles","famfiles","ids","study_ids","n","nchr","physical_marker_counts","rsids","chr","pos","a1","a2","af","source_marker_indices_0based","sample_source_indices_0based")
  if (length(missing <- setdiff(required,names(Glist)))) .gbase_stop("Glist is missing: ",paste(missing,collapse=", "))
  nchr <- .gprep_count(Glist$nchr,"Glist$nchr")
  if(any(vapply(Glist[c("bedfiles","bimfiles","famfiles")],length,integer(1))!=nchr)) .gbase_stop("Glist file vectors do not match `nchr`.")
  bed <- .gprep_path(Glist$bedfiles,"Glist$bedfiles"); bim <- .gprep_path(Glist$bimfiles,"Glist$bimfiles"); fam <- .gprep_path(Glist$famfiles,"Glist$famfiles")
  if(!identical(unname(bed),unname(Glist$bedfiles))||!identical(unname(bim),unname(Glist$bimfiles))||!identical(unname(fam),unname(Glist$famfiles))) .gbase_stop("Glist paths must remain canonical and unchanged.")
  fields <- c("rsids","chr","pos","a1","a2","af","source_marker_indices_0based")
  if(any(vapply(Glist[fields],length,integer(1))!=nchr)) .gbase_stop("Glist marker fields do not match `nchr`.")
  if(length(Glist$physical_marker_counts)!=nchr) .gbase_stop("Glist physical marker counts no longer match BIM files.")
  resources <- if(collect_resources) vector("list",nchr) else list()
  source_ids <- vector("list",nchr)
  canonical <- reference_identity <- NULL
  # Validation retains only IDs needed for the global uniqueness check. Full
  # BIM metadata stays live for one component unless an internal caller needs it.
  for(i in seq_len(nchr)) {
    resource <- cpp_gbase_bed_resource(bed[i],bim[i],fam[i])
    if(!identical(as.double(Glist$physical_marker_counts[i]),as.double(resource$marker_count)))
      .gbase_stop("Glist physical marker counts no longer match BIM files.")
    if(i==1L) {
      canonical <- resource$samples$individual_id
      if(!identical(Glist$ids,canonical)||!identical(as.double(Glist$n),as.double(length(canonical))))
        .gbase_stop("Glist samples no longer match FAM.")
      if(anyNA(canonical)||any(!nzchar(canonical))||anyDuplicated(canonical))
        .gbase_stop("BedPanel individual IDs must be non-empty and globally unique.")
      reference_identity <- resource$samples[c("family_id","individual_id")]
    }
    if(!identical(resource$samples[c("family_id","individual_id")],reference_identity))
      .gbase_stop("BedPanel components must have identical ordered FAM identities.")
    source_ids[[i]] <- resource$markers$marker_id
    source <- Glist$source_marker_indices_0based[[i]]
    if(!is.numeric(source)||anyNA(source)||any(!is.finite(source))||any(source!=floor(source))||any(source<0)||any(source>=resource$marker_count)||anyDuplicated(source))
      .gbase_stop("Glist has invalid source marker indices for file ",i,".")
    m <- resource$markers[source+1,,drop=FALSE]
    if(!identical(Glist$rsids[[i]],m$marker_id)||!identical(Glist$chr[[i]],m$chromosome)||!identical(as.double(Glist$pos[[i]]),as.double(m$base_pair_position))||!identical(Glist$a1[[i]],m$allele1)||!identical(Glist$a2[[i]],m$allele2))
      .gbase_stop("Glist markers no longer match BIM file ",i,".")
    af <- Glist$af[[i]]
    if(!is.numeric(af)||length(af)!=length(source)||anyNA(af)||any(!is.finite(af))||any(af<0|af>1))
      .gbase_stop("Glist allele frequencies are invalid for file ",i,".")
    if(collect_resources) resources[[i]] <- resource
    else rm(resource,m)
  }
  source_ids <- unlist(source_ids,use.names=FALSE)
  if(anyNA(source_ids)||any(!nzchar(source_ids))||anyDuplicated(source_ids))
    .gbase_stop("BedPanel source marker IDs must be globally unique.")
  prepared_ids <- if(is.null(Glist$study_ids)) Glist$ids else .gprep_selection(Glist$study_ids,"Glist$study_ids")
  expected_rows <- as.double(match(prepared_ids,Glist$ids)-1L)
  if(anyNA(expected_rows)||!identical(Glist$sample_source_indices_0based,expected_rows)) .gbase_stop("Glist sample source indices are inconsistent.")
  if (!is.null(Glist$sparseLD)) {
    sparse_ld <- .gprep_validate_sparse_ld(Glist)
    if (!is.null(Glist$ldBlocks)) .gprep_validate_ld_blocks(Glist$ldBlocks, sparse_ld)
  } else if (!is.null(Glist$ldBlocks)) {
    .gbase_stop("Glist ldBlocks requires sparse LD.")
  }
  if (!is.null(Glist$eigen)) .gprep_validate_eigen(Glist)
  if (!is.null(Glist$reference_groups)) .gbase_reference_groups(Glist)
  list(resources=resources)
}

.gprep_ld_progress <- function(prefix, threads, clock = function() proc.time()[["elapsed"]]) {
  label <- paste0("[", basename(prefix), "] ")
  start <- last <- clock()
  count <- function(n) formatC(n, format = "f", digits = 0L, big.mark = ",")
  function(stage, chromosome, rows, total, entries) {
    now <- clock()
    if (stage == "writing" && now - last < 600) return(invisible(NULL))
    last <<- now
    elapsed <- sprintf(" | %.0fs elapsed", now - start)
    switch(stage,
      starting = message(label, "Computing LD for ", count(total), " markers with ",
        threads, if (threads == 1L) " thread" else " threads"),
      validating = message(label, "Validating CSR files and computing LD scores"),
      done = message(label, "Done | ", count(total), " markers | ", count(entries),
        " correlations kept", elapsed),
      message(label, "Chr ", chromosome,
        if (stage == "chromosome_complete") " complete | " else " | ",
        count(rows), " / ", count(total), " rows written (",
        sprintf("%.1f%%", 100 * rows / total), ") | ", count(entries),
        " correlations kept", elapsed)
    )
    invisible(NULL)
  }
}

.gprep_sparseld <- function(Glist,out_prefix,ids,rsids,max_bp,max_variants,r2,block_size,threads,overwrite,allow_full,
    progress = FALSE) {
  progress <- .gprep_flag(progress, "progress")
  mapped <- inherits(Glist, "gs_mapped_genotypes")
  if (!mapped) audited <- .gprep_validate(Glist)
  ids <- .gprep_selection(ids,"ids"); rsids <- .gprep_selection(rsids,"rsids")
  threads <- .gprep_count(threads,"nthreads"); max_bp <- .gprep_count(max_bp,"max_distance_bp",0L); max_variants <- .gprep_count(max_variants,"max_distance_variants",0L); block_size <- .gprep_count(block_size,"block_size"); r2 <- .gprep_number(r2,"r2")
  overwrite <- .gprep_flag(overwrite,"overwrite"); allow_full <- .gprep_flag(allow_full,"allow_full_ld")
  if(r2>1) .gbase_stop("`r2` must be at most 1."); if(max_bp==0L&&max_variants==0L&&!allow_full) .gbase_stop("Set `allow_full_ld = TRUE` when both windows are disabled.")
  reference_ids <- if(!is.null(ids)) ids else if(!is.null(Glist$study_ids)) Glist$study_ids else Glist$ids
  rows <- match(reference_ids,Glist$ids); if(anyNA(rows)||length(rows)<2L) .gbase_stop("Sparse LD requires at least two known reference samples.")
  if (is.null(out_prefix)) {
    if (length(Glist$bedfiles) != 1L)
      .gbase_stop("Sparse LD with multiple BED files requires `out_prefix` or `ldfiles`.")
    out_prefix <- tools::file_path_sans_ext(Glist$bedfiles[[1L]])
  }
  out_prefix <- .gprep_prefix(out_prefix)
  options <- list(block_size = block_size, max_distance_bp = max_bp,
    max_distance_markers = max_variants, r2_threshold = r2, threads = threads,
    overwrite = overwrite, allow_full_ld = allow_full,
    progress = if (progress) .gprep_ld_progress(out_prefix, threads) else NULL)
  if (mapped)
    return(.gprep_mapped_sparseld(Glist, out_prefix, rows, reference_ids, ids, rsids, options))
  selected <- lapply(Glist$rsids,function(x) if(is.null(rsids)) rep(TRUE,length(x)) else x%in%rsids)
  selected_ids <- Map(function(x,k)x[k],Glist$rsids,selected); source <- Map(function(x,k)x[k],Glist$source_marker_indices_0based,selected); active <- which(lengths(selected_ids)>0L)
  if(!length(active)) .gbase_stop("Sparse LD requires markers.")
  resources <- audited$resources[active]
  families <- audited$resources[[1L]]$samples$family_id[rows]
  paths <- lapply(resources,`[[`,"paths"); marker_ids <- unname(selected_ids[active])
  panel <- cpp_gbase_bed_panel(paths,families,reference_ids,marker_ids)
  if(!identical(panel$sample_source_indices_0based,as.double(rows-1L))||
      !identical(panel$component_marker_indices_0based,unname(source[active]))) .gbase_stop("Resolved sparse-LD rows or markers do not match stored BED offsets.")
  resource <- cpp_gbase_sparse_ld(paths, families, reference_ids, marker_ids,
    out_prefix, options)
  reopened <- cpp_gbase_sparse_ld_identity(resource$prefix); if(!identical(resource$markers,reopened$markers)||!identical(resource$settings,reopened$settings)) .gbase_stop("Sparse-LD identity reopen failed.")
  prepared_ids <- if(is.null(Glist$study_ids)) Glist$ids else Glist$study_ids
  if(identical(reference_ids,prepared_ids)) {
    af <- Map(function(x,k)x[k],Glist$af,selected)[active]
    af_source <- "prepared Glist allele frequencies"
  } else {
    counts <- cpp_gbase_bed_counts(Glist$bedfiles[active],Glist$n,vapply(resources,`[[`,numeric(1),"marker_count"),as.double(rows-1L),source[active],threads)
    observed<-lapply(counts,function(x)x$n0+x$n1+x$n2)
    if(any(unlist(observed)==0)) .gbase_stop("A sparse-LD marker has no observed genotypes in the reference samples.")
    af<-Map(function(x,n)(2*x$n2+x$n1)/(2*n),counts,observed)
    af_source <- "recomputed for LD reference samples with packed BED counts"
  }
  .gprep_attach_sparseld(Glist, resource, active, selected_ids, af, af_source,
    rows, reference_ids, ids, options)
}

.gprep_attach_sparseld <- function(Glist, resource, active, selected_ids, af,
    af_source, rows, reference_ids, ids, options) {
  max_bp <- options$max_distance_bp; max_variants <- options$max_distance_markers
  r2 <- options$r2_threshold; block_size <- options$block_size; threads <- options$threads
  allow_full <- options$allow_full_ld
  scores <- cpp_gbase_ld_scores(resource$prefix, FALSE, NULL, character(), character())
  rsids_ld <- rep(list(character()), Glist$nchr)
  rsids_ld[active] <- selected_ids[active]
  # Attach disk-backed metadata views after the resident scores.
  Glist$sparseLD<-list(prefix=resource$prefix,format=resource$format,version=as.integer(resource$format_version),paths=resource$paths,n=length(reference_ids),source_n=Glist$n,m=resource$marker_count,nnz=resource$stored_entry_count,chr=active,bed_files=Glist$bedfiles[active],rows=as.integer(rows),rsids=selected_ids[active],sample_ids=reference_ids,sample_indices_0based=as.double(rows-1L),r2_threshold=r2,max_distance_bp=max_bp,max_distance_variants=max_variants,block_size=block_size,nthreads=threads,checksums=.gprep_checksums(resource$paths),provenance=list(owner="gmat",storage="strict upper-triangle CSR with implicit unit diagonal",value="signed correlation r",threshold="retain when r^2 >= r2_threshold",ld_score="1 + sum of retained off-diagonal r^2",dosage_allele="BIM field 5 (a1)",missing="mean imputation after centering; standardized value zero",sample_selection=if(!is.null(ids))"explicit ids" else if(!is.null(Glist$study_ids))"Glist$study_ids" else "all Glist$ids",requested_sample_order=reference_ids,physical_marker_order="canonical file/BIM order",allele_frequency_source=af_source,allow_full_ld=allow_full,gmat_version=gbase_native_info()$gmat$runtime_version))
  Glist$ldfiles <- resource$paths
  Glist$rsidsLD <- rsids_ld
  Glist$idsLD <- reference_ids
  ends <- cumsum(lengths(rsids_ld))
  Glist$ldscores <- lapply(seq_along(ends), function(i) {
    n <- length(rsids_ld[[i]])
    if (n) scores[seq.int(ends[i] - n + 1L, ends[i])] else numeric()
  })
  Glist$ldBlocks <- NULL
  Glist$ldscore_models <- NULL
  mapped_af <- inherits(Glist, "gs_mapped_genotypes") && identical(reference_ids, Glist$ids)
  Glist <- .ld_bind_metadata(Glist, Glist$sparseLD,
    if (!mapped_af) unlist(af, use.names = FALSE), mapped_af)
  if (!is.null(options$progress))
    options$progress("done", "", resource$marker_count, resource$marker_count,
      resource$stored_entry_count)
  Glist
}

#' @export
print.gs_genotypes <- function(x, ...) {
  cat("<gs_genotypes/Glist>\n", "  Samples: ", x$n, "\n",
      "  Files: ", x$nchr, "; markers: ", sum(x$mchr), "\n", sep="")
  if(!is.null(x$sparseLD)) cat("  Sparse LD:",x$sparseLD$m,"markers\n")
  if(!is.null(x$ldBlocks)) cat("  LD blocks:",nrow(x$ldBlocks$blocks),"\n")
  invisible(x)
}
