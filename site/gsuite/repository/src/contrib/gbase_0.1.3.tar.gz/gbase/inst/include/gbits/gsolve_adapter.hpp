#ifndef GBITS_GSOLVE_ADAPTER_HPP
#define GBITS_GSOLVE_ADAPTER_HPP

#include <gbits/bed_reader.hpp>
#include <gbits/execution.hpp>
#include <gbits/gsolve_adapter_export.h>
#include <gbits/marker_solver.hpp>
#include <gbits/prepared_matrix.hpp>
#include <gbits/packed_matrix.hpp>

#include <gsolve/execution.hpp>
#include <gsolve/linear_operator.hpp>
#include <gsolve/preconditioner.hpp>
#include <gsolve/rectangular_operator.hpp>

#include <atomic>
#include <cstdint>
#include <memory>
#include <vector>

namespace gbits {

enum class GenomicCovarianceStorage : std::uint32_t {
    direct_bed = 0,
    prepared_packed = 1
};

class GenomicCovarianceOperator;

struct GenomicCovarianceCreateResult {
    gsolve::Status status{};
    std::shared_ptr<const GenomicCovarianceOperator> covariance_operator{};
};

// Cumulative operation-local work performed by one immutable covariance
// adapter.  Marker visits and packed decode passes count physical traversals,
// not processed RHS columns.  Timing excludes caller orchestration.
struct GenomicCovarianceDiagnostics {
    std::uint64_t applications{0};
    std::uint64_t processed_rhs_columns{0};
    std::uint64_t maximum_rhs_width{0};
    std::uint64_t marker_visits{0};
    std::uint64_t packed_decode_passes{0};
    std::uint32_t requested_threads{1};
    std::uint32_t resolved_threads{1};
    double decode_seconds{0.0};
    double compute_seconds{0.0};
};

struct ThreadStrategyResolution {
    gsolve::Status status{};
    std::uint32_t requested_outer_threads{1};
    std::uint32_t resolved_outer_threads{1};
    std::uint32_t requested_operator_threads{1};
    std::uint32_t resolved_operator_threads{1};
};

struct PackedGsPreconditionerDiagnostics {
    PackedMarkerStrategy strategy{PackedMarkerStrategy::fused_coordinate};
    std::uint64_t applications{0};
    std::uint64_t processed_rhs_columns{0};
    std::uint64_t symmetric_sweeps{0};
    std::uint64_t packed_block_sweeps{0};
    std::uint64_t packed_block_passes{0};
    std::uint64_t marker_visits{0};
    std::uint64_t packed_decode_passes{0};
    std::uint64_t preparation_factorizations{0};
    std::uint64_t runtime_factorizations{0};
    std::uint64_t prepared_factor_solves{0};
    std::uint64_t prepared_factor_bytes{0};
    std::uint64_t coordinate_metadata_bytes{0};
    std::uint64_t workspace_bytes{0};
    bool factor_recomputation_mode{false};
};

class PackedGsPreconditioner;
struct PackedGsPreconditionerCreateResult {
    gsolve::Status status{};
    std::shared_ptr<const PackedGsPreconditioner> preconditioner{};
};

class GBITS_GSOLVE_ADAPTER_API PackedGsPreconditioner final
    : public gsolve::Preconditioner {
public:
    ~PackedGsPreconditioner() override;
    PackedGsPreconditioner(const PackedGsPreconditioner&) = delete;
    PackedGsPreconditioner& operator=(const PackedGsPreconditioner&) = delete;

    [[nodiscard]] std::uint64_t dimension() const noexcept override;
    [[nodiscard]] bool concurrent_apply_supported() const noexcept override;
    [[nodiscard]] bool compatible_with(
        const gsolve::LinearOperator& linear_operator) const noexcept override;
    gsolve::Status prepare_workspace(std::uint64_t right_hand_side_count,
                                     gsolve::Workspace& workspace) const override;
    gsolve::Status apply(gsolve::ConstMatrixView input,
                         gsolve::MatrixView output,
                         gsolve::Workspace& workspace) const override;
    [[nodiscard]] PackedGsPreconditionerDiagnostics diagnostics() const noexcept;

private:
    struct Impl;
    explicit PackedGsPreconditioner(std::unique_ptr<Impl> implementation);
    std::unique_ptr<Impl> implementation_;
    friend PackedGsPreconditionerCreateResult create_packed_gs_preconditioner(
        std::shared_ptr<const gsolve::LinearOperator>,
        std::vector<PackedMarkerComponent>, double, std::uint64_t,
        const PackedPenaltyStateOptions&) noexcept;
};

// Constructs a fixed linear symmetric fused-coordinate operation. Every
// application starts from zero marker effects, performs exactly
// symmetric_sweeps forward/backward sweeps, and returns
// retained_residual / residual_variance. penalty_preparation is retained for
// source compatibility with the block-era constructor and is not used.
GBITS_GSOLVE_ADAPTER_API PackedGsPreconditionerCreateResult
create_packed_gs_preconditioner(
    std::shared_ptr<const gsolve::LinearOperator> covariance_operator,
    std::vector<PackedMarkerComponent> components,
    double residual_variance,
    std::uint64_t symmetric_sweeps,
    const PackedPenaltyStateOptions& penalty_preparation = {}) noexcept;

class PackedMatrixDesignOperator;

struct PackedMatrixDesignCreateResult {
    gsolve::Status status{};
    std::shared_ptr<const PackedMatrixDesignOperator> design_operator{};
};

// Source-independent binary/ternary packed rectangular design. A null
// selection selects both full axes. A null transform chooses raw values with
// MissingPolicy::error, so missing values are never imputed implicitly.
class GBITS_GSOLVE_ADAPTER_API PackedMatrixDesignOperator final
    : public gsolve::RectangularOperator {
public:
    ~PackedMatrixDesignOperator() override;
    PackedMatrixDesignOperator(const PackedMatrixDesignOperator&) = delete;
    PackedMatrixDesignOperator& operator=(const PackedMatrixDesignOperator&) =
        delete;

    [[nodiscard]] std::uint64_t row_count() const noexcept override;
    [[nodiscard]] std::uint64_t column_count() const noexcept override;
    [[nodiscard]] const gsolve::Status& status() const noexcept override;
    [[nodiscard]] bool concurrent_apply_supported() const noexcept override;
    [[nodiscard]] const ExecutionConfig& execution_config() const noexcept;

    gsolve::Status prepare_workspace(
        std::uint64_t right_hand_side_count,
        gsolve::Workspace& workspace) const override;
    gsolve::Status apply(gsolve::ConstMatrixView coefficients,
                         gsolve::MatrixView output,
                         gsolve::Workspace& workspace) const override;
    gsolve::Status apply_transpose(gsolve::ConstMatrixView values,
                                   gsolve::MatrixView output,
                                   gsolve::Workspace& workspace) const override;
    gsolve::Status materialize_columns(
        std::uint64_t first_column,
        std::uint64_t selected_column_count,
        gsolve::MatrixView output,
        gsolve::Workspace& workspace) const override;

private:
    struct Impl;
    explicit PackedMatrixDesignOperator(std::unique_ptr<Impl> implementation);
    std::unique_ptr<Impl> implementation_;

    friend PackedMatrixDesignCreateResult create_packed_matrix_design(
        std::shared_ptr<const PackedMatrix>,
        std::shared_ptr<const PackedSelection>,
        std::shared_ptr<const PackedTransform>,
        const ExecutionConfig&) noexcept;
};

GBITS_GSOLVE_ADAPTER_API PackedMatrixDesignCreateResult
create_packed_matrix_design(
    std::shared_ptr<const PackedMatrix> packed,
    std::shared_ptr<const PackedSelection> selection = nullptr,
    std::shared_ptr<const PackedTransform> transform = nullptr,
    const ExecutionConfig& execution = {}) noexcept;

// Immutable native C++ adapter for
//   K_d B = W diag(marker_weights) W' B / normalization.
// Marker weights are copied in logical marker order. The direct source retains
// shared ownership of its non-thread-safe BedReader; the prepared source owns
// shared immutable packed storage. No dense relationship matrix is formed.
class GBITS_GSOLVE_ADAPTER_API GenomicCovarianceOperator final
    : public gsolve::LinearOperator {
public:
    ~GenomicCovarianceOperator() override;

    GenomicCovarianceOperator(const GenomicCovarianceOperator&) = delete;
    GenomicCovarianceOperator& operator=(const GenomicCovarianceOperator&) =
        delete;

    [[nodiscard]] std::uint64_t rows() const noexcept override;
    [[nodiscard]] std::uint64_t columns() const noexcept override;
    [[nodiscard]] gsolve::Symmetry symmetry() const noexcept override;
    [[nodiscard]] gsolve::Definiteness definiteness() const noexcept override;

    gsolve::Status apply(gsolve::ConstMatrixView input,
                         gsolve::MatrixView output,
                         gsolve::Workspace& workspace) const override;

    [[nodiscard]] GenomicCovarianceStorage storage() const noexcept;
    [[nodiscard]] std::uint64_t marker_count() const noexcept;
    [[nodiscard]] double normalization() const noexcept;
    [[nodiscard]] const std::vector<double>& marker_weights() const noexcept;
    [[nodiscard]] const std::vector<double>& diagonal() const noexcept;
    [[nodiscard]] const ExecutionConfig& execution_config() const noexcept;
    [[nodiscard]] GenomicCovarianceDiagnostics diagnostics() const noexcept;

    // Concurrent independent apply calls are supported only for prepared
    // storage with one resolved operator thread. Direct BED owns mutable stream
    // state; an internally threaded prepared call is also exclusive so outer
    // and inner parallelism cannot be nested accidentally.
    [[nodiscard]] bool concurrent_apply_supported() const noexcept;

private:
    struct Impl;
    explicit GenomicCovarianceOperator(std::unique_ptr<Impl> implementation);
    std::unique_ptr<Impl> implementation_;

    friend GenomicCovarianceCreateResult create_direct_genomic_covariance(
        std::shared_ptr<BedReader>, const BedSelection&,
        const GenotypeTransform&, const double*, std::uint64_t, double,
        const ExecutionConfig&) noexcept;
    friend GenomicCovarianceCreateResult create_prepared_genomic_covariance(
        std::shared_ptr<const PreparedBitMatrix>, const GenotypeTransform&,
        const double*, std::uint64_t, double,
        const ExecutionConfig&) noexcept;
};

GBITS_GSOLVE_ADAPTER_API GenomicCovarianceCreateResult
create_direct_genomic_covariance(
    std::shared_ptr<BedReader> reader, const BedSelection& selection,
    const GenotypeTransform& transform, const double* marker_weights,
    std::uint64_t marker_weight_count, double normalization,
    const ExecutionConfig& execution = {}) noexcept;

GBITS_GSOLVE_ADAPTER_API GenomicCovarianceCreateResult
create_prepared_genomic_covariance(
    std::shared_ptr<const PreparedBitMatrix> prepared,
    const GenotypeTransform& transform, const double* marker_weights,
    std::uint64_t marker_weight_count, double normalization,
    const ExecutionConfig& execution = {}) noexcept;

// Resolve and validate the explicit outer-RHS versus inner-operator strategy.
// Both sides greater than one are rejected. Outer parallelism additionally
// requires concurrent independent apply support from the adapter instance.
GBITS_GSOLVE_ADAPTER_API ThreadStrategyResolution resolve_thread_strategy(
    const GenomicCovarianceOperator& covariance,
    const gsolve::ExecutionConfig& outer_execution) noexcept;

} // namespace gbits

#endif
