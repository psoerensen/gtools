#ifndef GSOLVE_PCG_HPP
#define GSOLVE_PCG_HPP

#include <cstdint>
#include <limits>
#include <vector>

#include "gsolve/execution.hpp"
#include "gsolve/preconditioner.hpp"

namespace gsolve {

struct PcgOptions {
  double relative_tolerance{1.0e-8};
  double absolute_tolerance{0.0};
  std::uint64_t maximum_iterations{1000};
  std::uint64_t residual_replacement_interval{0};
  bool retain_residual_history{false};
};

struct PcgResult {
  Status status{};
  std::uint64_t iterations{0};
  std::uint64_t operator_applications{0};
  std::uint64_t preconditioner_applications{0};
  double initial_residual_norm{0.0};
  double final_recursive_residual_norm{0.0};
  double final_true_residual_norm{0.0};
  std::vector<double> residual_history{};
};

enum class MultipleRhsKrylovStrategy { independent, block };

struct BlockPcgOptions {
  double rank_tolerance{64.0 * std::numeric_limits<double>::epsilon()};
  std::uint64_t maximum_rank_restarts{8};
};

struct BlockPcgColumnDiagnostic {
  Status status{};
  double initial_residual_norm{0.0};
  double final_recursive_residual_norm{0.0};
  double final_true_residual_norm{0.0};
  double convergence_threshold{0.0};
  std::uint64_t convergence_iteration{0};
  bool initially_converged{false};
  bool deflated{false};
};

struct BlockPcgDiagnostics {
  std::uint64_t initial_block_width{0};
  std::uint64_t initial_numerical_rank{0};
  std::uint64_t maximum_active_rank{0};
  std::uint64_t final_active_rank{0};
  std::uint64_t block_iterations{0};
  std::uint64_t rank_loss_events{0};
  std::uint64_t restart_events{0};
  std::vector<std::uint64_t> deflated_columns{};
  std::vector<std::uint64_t> converged_columns{};
  std::vector<BlockPcgColumnDiagnostic> column_diagnostics{};
};

class GSOLVE_EXPORT PcgWorkspace {
 public:
  Status prepare(std::uint64_t dimension,
                 std::uint64_t residual_history_capacity = 0);
  [[nodiscard]] std::uint64_t dimension() const noexcept { return dimension_; }

 private:
  friend PcgResult solve_pcg(const LinearOperator&, const Preconditioner&,
                             ConstMatrixView, MatrixView, const PcgOptions&,
                             PcgWorkspace&, const ConstMatrixView*);
  std::uint64_t dimension_{0};
  std::vector<double> rhs_{};
  std::vector<double> r_{};
  std::vector<double> z_{};
  std::vector<double> p_{};
  std::vector<double> ap_{};
  std::vector<double> true_residual_{};
  std::vector<double> residual_history_{};
  Workspace operator_workspace_{};
  Workspace preconditioner_workspace_{};
};

GSOLVE_EXPORT PcgResult solve_pcg(
    const LinearOperator& linear_operator,
    const Preconditioner& preconditioner, ConstMatrixView right_hand_side,
    MatrixView solution, const PcgOptions& options, PcgWorkspace& workspace,
    const ConstMatrixView* initial_guess = nullptr);

inline constexpr std::uint64_t no_failed_pcg_column =
    std::numeric_limits<std::uint64_t>::max();

struct PcgBatchResult {
  Status status{};
  std::vector<PcgResult> column_results{};
  std::uint64_t operator_applications{0};
  std::uint64_t preconditioner_applications{0};
  std::uint64_t operator_processed_columns{0};
  std::uint64_t preconditioner_processed_columns{0};
  std::uint64_t first_failed_column{no_failed_pcg_column};
  std::uint32_t requested_threads{1};
  std::uint32_t resolved_threads{1};
  MultipleRhsKrylovStrategy requested_strategy{
      MultipleRhsKrylovStrategy::independent};
  MultipleRhsKrylovStrategy resolved_strategy{
      MultipleRhsKrylovStrategy::independent};
  BlockPcgDiagnostics block{};
};

class GSOLVE_EXPORT PcgBatchWorkspace {
 public:
  Status prepare(std::uint64_t dimension, std::uint64_t right_hand_side_count,
                 std::uint32_t worker_count = 1);
  [[nodiscard]] std::uint64_t dimension() const noexcept { return dimension_; }
  [[nodiscard]] std::uint64_t right_hand_side_count() const noexcept {
    return right_hand_side_count_;
  }

 private:
  friend PcgBatchResult solve_pcg_batch(
      const LinearOperator&, const Preconditioner&, ConstMatrixView, MatrixView,
      const PcgOptions&, PcgBatchWorkspace&, const ConstMatrixView*,
      const ExecutionConfig&);
  friend PcgBatchResult solve_pcg_batch(
      const LinearOperator&, const Preconditioner&, ConstMatrixView, MatrixView,
      const PcgOptions&, PcgBatchWorkspace&, const ConstMatrixView*,
      const ExecutionConfig&, bool);
  std::uint64_t dimension_{0};
  std::uint64_t right_hand_side_count_{0};
  std::vector<double> staged_solution_{};
  std::vector<PcgWorkspace> column_workspaces_{};
};

// Solves independent RHS columns in deterministic logical order. This is
// orchestration, not block CG. Parallel execution requires immutable operators
// and preconditioners that permit concurrent apply() calls with independent
// workspaces; downstream operators must remain internally serial. Caller output
// is updated only if every column succeeds.
GSOLVE_EXPORT PcgBatchResult solve_pcg_batch(
    const LinearOperator& linear_operator,
    const Preconditioner& preconditioner, ConstMatrixView right_hand_sides,
    MatrixView solutions, const PcgOptions& options,
    PcgBatchWorkspace& workspace,
    const ConstMatrixView* initial_guesses = nullptr,
    const ExecutionConfig& execution = {});

class GSOLVE_EXPORT BlockPcgWorkspace {
 public:
  Status prepare(std::uint64_t dimension, std::uint64_t block_width);
  [[nodiscard]] std::uint64_t dimension() const noexcept { return dimension_; }
  [[nodiscard]] std::uint64_t block_width() const noexcept {
    return block_width_;
  }

 private:
  friend struct BlockPcgImplementation;
  std::uint64_t dimension_{0};
  std::uint64_t block_width_{0};
  std::vector<double> rhs_{};
  std::vector<double> solution_{};
  std::vector<double> residual_{};
  std::vector<double> product_{};
  std::vector<double> basis_{};
  std::vector<double> preconditioned_{};
  std::vector<double> direction_{};
  std::vector<double> direction_product_{};
  std::vector<double> candidate_{};
  std::vector<double> gram_{};
  std::vector<double> next_gram_{};
  std::vector<double> curvature_{};
  std::vector<double> alpha_{};
  std::vector<double> beta_{};
  std::vector<double> coefficients_{};
  std::vector<double> transformed_coefficients_{};
  std::vector<double> factor_{};
  std::vector<double> column_norms_{};
  std::vector<double> initial_norms_{};
  std::vector<double> thresholds_{};
  std::vector<double> recursive_norms_{};
  std::vector<double> true_norms_{};
  std::vector<std::uint64_t> active_columns_{};
  std::vector<std::uint64_t> pivot_columns_{};
  std::vector<unsigned char> active_{};
  std::vector<unsigned char> ever_deflated_{};
  Workspace operator_workspace_{};
  Workspace preconditioner_workspace_{};
};

struct BlockPcgResult : PcgBatchResult {};

// Uses one shared block Krylov space and dense matrix recurrence coefficients.
// The orchestration is serial; child operators may use their own internal
// execution. Caller output is committed only after every original RHS meets
// its true-residual criterion.
GSOLVE_EXPORT BlockPcgResult solve_block_pcg(
    const LinearOperator& linear_operator,
    const Preconditioner& preconditioner, ConstMatrixView right_hand_sides,
    MatrixView solutions, const PcgOptions& options,
    const BlockPcgOptions& block_options, BlockPcgWorkspace& workspace,
    const ConstMatrixView* initial_guesses = nullptr,
    const ExecutionConfig& execution = {});

class GSOLVE_EXPORT MultipleRhsPcgWorkspace {
 public:
  Status prepare(std::uint64_t dimension, std::uint64_t right_hand_side_count,
                 MultipleRhsKrylovStrategy strategy,
                 std::uint32_t independent_worker_count = 1);

 private:
  friend PcgBatchResult solve_pcg_multiple(
      const LinearOperator&, const Preconditioner&, ConstMatrixView, MatrixView,
      const PcgOptions&, MultipleRhsKrylovStrategy, const BlockPcgOptions&,
      MultipleRhsPcgWorkspace&, const ConstMatrixView*,
      const ExecutionConfig&);
  friend PcgBatchResult solve_pcg_multiple(
      const LinearOperator&, const Preconditioner&, ConstMatrixView, MatrixView,
      const PcgOptions&, MultipleRhsKrylovStrategy, const BlockPcgOptions&,
      MultipleRhsPcgWorkspace&, const ConstMatrixView*, const ExecutionConfig&, bool);
  PcgBatchWorkspace independent_{};
  BlockPcgWorkspace block_{};
};

GSOLVE_EXPORT PcgBatchResult solve_pcg_multiple(
    const LinearOperator& linear_operator,
    const Preconditioner& preconditioner, ConstMatrixView right_hand_sides,
    MatrixView solutions, const PcgOptions& options,
    MultipleRhsKrylovStrategy strategy, const BlockPcgOptions& block_options,
    MultipleRhsPcgWorkspace& workspace,
    const ConstMatrixView* initial_guesses = nullptr,
    const ExecutionConfig& execution = {});

// Additive RHS-relative independent-PCG entry points. The original APIs retain
// their initial-residual-relative contract. Block strategy retains its existing
// behavior; greml trace warm starts are restricted to independent PCG.
GSOLVE_EXPORT PcgResult solve_pcg_rhs_relative(
    const LinearOperator&, const Preconditioner&, ConstMatrixView, MatrixView,
    const PcgOptions&, PcgWorkspace&, const ConstMatrixView* initial_guess=nullptr);
GSOLVE_EXPORT PcgBatchResult solve_pcg_batch(
    const LinearOperator&, const Preconditioner&, ConstMatrixView, MatrixView,
    const PcgOptions&, PcgBatchWorkspace&, const ConstMatrixView*,
    const ExecutionConfig&, bool relative_to_rhs);
GSOLVE_EXPORT PcgBatchResult solve_pcg_multiple(
    const LinearOperator&, const Preconditioner&, ConstMatrixView, MatrixView,
    const PcgOptions&, MultipleRhsKrylovStrategy, const BlockPcgOptions&,
    MultipleRhsPcgWorkspace&, const ConstMatrixView*, const ExecutionConfig&,
    bool relative_to_rhs);

}  // namespace gsolve

#endif
