#ifndef GBITS_BED_READER_HPP
#define GBITS_BED_READER_HPP

#include <gbits/bed_selection.hpp>
#include <gbits/error.hpp>
#include <gbits/execution.hpp>
#include <gbits/genotype_transform.hpp>
#include <gbits/marker_statistics.hpp>
#include <gbits/missing_policy.hpp>
#include <gbits/prepared_matrix.hpp>

#include <cstddef>
#include <cstdint>
#include <fstream>
#include <string>
#include <vector>

namespace gbits {

constexpr std::int8_t missing_dosage = static_cast<std::int8_t>(-9);

struct VariantStatistics {
    std::uint64_t observed_count;
    std::uint64_t missing_count;
    double allele_sum;
    double mean_dosage;
    double allele_frequency;
};

constexpr std::int8_t decode_plink_code(std::uint8_t code) noexcept {
    switch (code & 0x03u) {
    case 0x00u: return 2;
    case 0x01u: return missing_dosage;
    case 0x02u: return 1;
    case 0x03u: return 0;
    default: return missing_dosage;
    }
}

class GBITS_API BedReader {
public:
    BedReader(std::string path, std::uint64_t sample_count,
              std::uint64_t variant_count);
    ~BedReader();

    BedReader(const BedReader&) = delete;
    BedReader& operator=(const BedReader&) = delete;
    BedReader(BedReader&&) = delete;
    BedReader& operator=(BedReader&&) = delete;

    std::uint64_t sample_count() const noexcept { return sample_count_; }
    std::uint64_t variant_count() const noexcept { return variant_count_; }
    std::uint64_t bytes_per_variant() const noexcept {
        return bytes_per_variant_;
    }

    void read_variant(std::uint64_t variant_index, std::int8_t* output,
                      std::uint64_t output_length);
    std::vector<std::int8_t> read_variant(std::uint64_t variant_index);
    // Read an ordered logical marker chunk into a column-major dosage matrix.
    // Values are raw allele1 dosages (0, 1, 2) or missing_dosage. Compressed
    // BED records are read in coalesced runs and each marker column is decoded
    // independently, so callers can reuse one block across several analyses.
    void read_dosage_columns(const BedSelection& selection,
        std::uint64_t begin, std::uint64_t count,
        std::int8_t* output, std::uint64_t output_length,
        std::uint64_t ldout, std::uint32_t decode_threads = 1,
        std::uint64_t max_gap_bytes = 16u * 1024u);
    // Read a logical marker chunk directly from BED into a column-major
    // numeric matrix. Centers are observed selected-sample means: missing
    // calls become zero after (dosage - center) / scale. Compressed records
    // are buffered first, coalescing short physical gaps while bounding extra
    // I/O, so no marker statistics or full decoded genotype panel is retained.
    // max_gap_bytes=0 reads only selected records. Values up to 64 MiB are
    // accepted; the default is 16 KiB. Calls are serial on this reader;
    // decoding may use decode_threads workers.
    void read_centered_scaled_columns(const BedSelection& selection,
        const double* centers, std::uint64_t center_count,
        const double* scales, std::uint64_t scale_count,
        std::uint64_t begin, std::uint64_t count,
        double* output, std::uint64_t output_length, std::uint64_t ldout,
        std::uint32_t decode_threads = 1,
        std::uint64_t max_gap_bytes = 16u * 1024u);
    VariantStatistics variant_statistics(std::uint64_t variant_index);

    void marker_statistics(MarkerStatistics* output,
                           std::uint64_t output_length);
    std::vector<MarkerStatistics> marker_statistics();
    void marker_statistics(const BedSelection& selection,
                           MarkerStatistics* output,
                           std::uint64_t output_length);
    std::vector<MarkerStatistics> marker_statistics(
        const BedSelection& selection);

    // A null pointer with count zero selects the entire corresponding axis.
    // A non-null pointer with positive count supplies an owned, ordered subset.
    BedSelection make_selection(
        const std::uint64_t* sample_indices,
        std::uint64_t sample_index_count,
        const std::uint64_t* variant_indices,
        std::uint64_t variant_index_count) const;

    // Pack the raw logical matrix directly from BED without constructing a
    // dense intermediate. The returned object owns immutable selection
    // metadata and packed storage and may outlive this reader.
    PreparedBitMatrix prepare(const BedSelection& selection);

    void xv(const double* variant_values, std::uint64_t variant_values_length,
            MissingPolicy policy, double* output,
            std::uint64_t output_length);
    void xtv(const double* sample_values, std::uint64_t sample_values_length,
             MissingPolicy policy, double* output,
             std::uint64_t output_length);
    void xv(const BedSelection& selection,
            const double* variant_values,
            std::uint64_t variant_values_length,
            MissingPolicy policy,
            double* output,
            std::uint64_t output_length);
    void xtv(const BedSelection& selection,
             const double* sample_values,
             std::uint64_t sample_values_length,
             MissingPolicy policy,
             double* output,
             std::uint64_t output_length);

    // Overwrite output with X * B. B is variant_count x right_hand_side_count
    // and output is sample_count x right_hand_side_count. Both matrices are
    // column-major; logical element (row, column) is at row + column * ld.
    // Buffer lengths count doubles and must cover (k - 1) * ld + rows.
    void xmat(const double* coefficients,
              std::uint64_t coefficients_length,
              std::uint64_t right_hand_side_count,
              std::uint64_t ldb,
              MissingPolicy policy,
              double* output,
              std::uint64_t output_length,
              std::uint64_t ldout);

    // Overwrite output with X' * Y. Y is sample_count x
    // right_hand_side_count and output is variant_count x
    // right_hand_side_count, both in column-major storage.
    void xtmat(const double* values,
               std::uint64_t values_length,
               std::uint64_t right_hand_side_count,
               std::uint64_t ldy,
               MissingPolicy policy,
               double* output,
               std::uint64_t output_length,
               std::uint64_t ldout);
    void xmat(const BedSelection& selection,
              const double* coefficients,
              std::uint64_t coefficients_length,
              std::uint64_t right_hand_side_count,
              std::uint64_t ldb,
              MissingPolicy policy,
              double* output,
              std::uint64_t output_length,
              std::uint64_t ldout);
    void xtmat(const BedSelection& selection,
               const double* values,
               std::uint64_t values_length,
               std::uint64_t right_hand_side_count,
               std::uint64_t ldy,
               MissingPolicy policy,
               double* output,
               std::uint64_t output_length,
               std::uint64_t ldout);

    // Weighted solver primitives over the logical transformed matrix Z:
    // covariance = Z diag(marker_weights) Z' values;
    // normal_equation = Z' diag(sample_weights) Z coefficients +
    //                   diag(marker_diagonal) coefficients.
    // Arrays are aligned to logical selection order and must have exact
    // lengths. Matrix storage is column-major and outputs are failure-atomic.
    void covariance(const BedSelection& selection,
                    const GenotypeTransform& transform,
                    const double* marker_weights,
                    std::uint64_t marker_weights_length,
                    const double* values, std::uint64_t values_length,
                    std::uint64_t right_hand_side_count, std::uint64_t ldy,
                    const ExecutionConfig& execution, double* output,
                    std::uint64_t output_length, std::uint64_t ldout);
    void normal_equation(const BedSelection& selection,
                         const GenotypeTransform& transform,
                         const double* sample_weights,
                         std::uint64_t sample_weights_length,
                         const double* marker_diagonal,
                         std::uint64_t marker_diagonal_length,
                         const double* coefficients,
                         std::uint64_t coefficients_length,
                         std::uint64_t right_hand_side_count,
                         std::uint64_t ldb,
                         const ExecutionConfig& execution, double* output,
                         std::uint64_t output_length, std::uint64_t ldout);
    void covariance_diagonal(const BedSelection& selection,
                             const GenotypeTransform& transform,
                             const double* marker_weights,
                             std::uint64_t marker_weights_length,
                             const ExecutionConfig& execution, double* output,
                             std::uint64_t output_length);
    double covariance_trace(const BedSelection& selection,
                            const GenotypeTransform& transform,
                            const double* marker_weights,
                            std::uint64_t marker_weights_length,
                            const ExecutionConfig& execution);
    void normal_diagonal(const BedSelection& selection,
                         const GenotypeTransform& transform,
                         const double* sample_weights,
                         std::uint64_t sample_weights_length,
                         const double* marker_diagonal,
                         std::uint64_t marker_diagonal_length,
                         const ExecutionConfig& execution, double* output,
                         std::uint64_t output_length);

    // Canonical transformed direct-BED operators. The transformation must be
    // aligned to exactly the same physical dimensions and ordered indices as
    // selection. Missing replacement is performed in raw dosage space before
    // applying (g - center[j]) / scale[j].
    void xv(const BedSelection& selection,
            const GenotypeTransform& transform,
            const double* variant_values,
            std::uint64_t variant_values_length,
            double* output,
            std::uint64_t output_length);
    void xtv(const BedSelection& selection,
             const GenotypeTransform& transform,
             const double* sample_values,
             std::uint64_t sample_values_length,
             double* output,
             std::uint64_t output_length);
    void xmat(const BedSelection& selection,
              const GenotypeTransform& transform,
              const double* coefficients,
              std::uint64_t coefficients_length,
              std::uint64_t right_hand_side_count,
              std::uint64_t ldb,
              double* output,
              std::uint64_t output_length,
              std::uint64_t ldout);
    void xmat(const BedSelection& selection,
              const GenotypeTransform& transform,
              const double* coefficients,
              std::uint64_t coefficients_length,
              std::uint64_t right_hand_side_count,
              std::uint64_t ldb,
              const ExecutionConfig& execution,
              double* output,
              std::uint64_t output_length,
              std::uint64_t ldout);
    void xtmat(const BedSelection& selection,
               const GenotypeTransform& transform,
               const double* values,
               std::uint64_t values_length,
               std::uint64_t right_hand_side_count,
               std::uint64_t ldy,
               double* output,
               std::uint64_t output_length,
               std::uint64_t ldout);
    void xtmat(const BedSelection& selection,
               const GenotypeTransform& transform,
               const double* values,
               std::uint64_t values_length,
               std::uint64_t right_hand_side_count,
               std::uint64_t ldy,
               const ExecutionConfig& execution,
               double* output,
               std::uint64_t output_length,
               std::uint64_t ldout);

private:
    std::vector<std::uint8_t> read_selected_records(
        const BedSelection& selection, std::uint64_t begin,
        std::uint64_t count, std::uint64_t max_gap_bytes);
    void read_record(std::uint64_t variant_index);
    void decode_current_record() noexcept;
    std::int8_t decoded_sample(std::uint64_t sample_index) const noexcept;
    VariantStatistics current_statistics() const;
    MarkerStatistics current_marker_statistics(
        const BedSelection& selection) const noexcept;
    void validate_selection(const BedSelection& selection) const;
    void xmat_scalar(const BedSelection& selection,
                     const GenotypeTransform& transform,
                     const double* coefficients,
                     std::uint64_t coefficients_length,
                     std::uint64_t right_hand_side_count,
                     std::uint64_t ldb,
                     double* output,
                     std::uint64_t output_length,
                     std::uint64_t ldout);
    void xtmat_scalar(const BedSelection& selection,
                      const GenotypeTransform& transform,
                      const double* values,
                      std::uint64_t values_length,
                      std::uint64_t right_hand_side_count,
                      std::uint64_t ldy,
                      double* output,
                      std::uint64_t output_length,
                      std::uint64_t ldout);
    void xmat_tiled(const BedSelection& selection,
                    const GenotypeTransform& transform,
                    const double* coefficients,
                    std::uint64_t coefficients_length,
                    std::uint64_t right_hand_side_count,
                    std::uint64_t ldb,
                    const ExecutionBackend& execution,
                    double* output,
                    std::uint64_t output_length,
                    std::uint64_t ldout);
    void xtmat_tiled(const BedSelection& selection,
                     const GenotypeTransform& transform,
                     const double* values,
                     std::uint64_t values_length,
                     std::uint64_t right_hand_side_count,
                     std::uint64_t ldy,
                     const ExecutionBackend& execution,
                     double* output,
                     std::uint64_t output_length,
                     std::uint64_t ldout);

    std::string path_;
    std::uint64_t sample_count_;
    std::uint64_t variant_count_;
    std::uint64_t bytes_per_variant_;
    std::ifstream stream_;
    std::vector<std::uint8_t> record_;
    std::vector<std::int8_t> decoded_record_;
    VariantStatistics decoded_statistics_{};
};

} // namespace gbits

#endif
