#ifndef GBITS_TRANSFORM_HPP
#define GBITS_TRANSFORM_HPP

#include <cstdint>

namespace gbits {

enum class TransformMode : std::uint32_t {
    raw = 0,
    centered = 1,
    scaled = 2,
    centered_scaled = 3
};

} // namespace gbits

#endif
