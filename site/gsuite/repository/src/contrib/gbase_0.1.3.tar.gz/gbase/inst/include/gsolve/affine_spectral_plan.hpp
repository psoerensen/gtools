#ifndef GSOLVE_AFFINE_SPECTRAL_PLAN_HPP
#define GSOLVE_AFFINE_SPECTRAL_PLAN_HPP

#include <cstdint>
#include <limits>
#include <memory>
#include <vector>

#include "gsolve/execution.hpp"
#include "gsolve/linear_operator.hpp"

namespace gsolve {

struct AffineSpectralPlanOptions {
  std::uint64_t probe_count{16};
  std::uint64_t lanczos_steps{20};
  std::uint64_t probe_batch_size{8};
  std::uint64_t seed{0x414646494e455350ULL};
  double breakdown_tolerance{1.0e-14};
  double psd_ritz_tolerance{1.0e-12};
  bool retain_per_probe_estimates{false};
};

struct AffineSpectralPlanDiagnostics {
  std::uint64_t construction_count{0};
  std::uint64_t evaluation_count{0};
  std::uint64_t extension_count{0};
  std::uint64_t depth_rebuild_count{0};
  std::uint64_t probe_count{0};
  std::uint64_t lanczos_steps{0};
  std::uint64_t operator_applications{0};
  std::uint64_t breakdown_count{0};
  std::uint64_t failure_count{0};
  std::uint64_t stored_bytes{0};
  double construction_seconds{0.0};
  double minimum_ritz{std::numeric_limits<double>::quiet_NaN()};
  double maximum_ritz{std::numeric_limits<double>::quiet_NaN()};
  std::uint32_t requested_threads{1};
  std::uint32_t resolved_threads{1};
};

struct AffineSpectralFunctionEstimate {
  double estimate{std::numeric_limits<double>::quiet_NaN()};
  double standard_error{std::numeric_limits<double>::quiet_NaN()};
  std::vector<double> per_probe_estimates{};
};

struct AffineSpectralEvaluationResult {
  Status status{};
  double covariance_coefficient{0.0};
  double identity_coefficient{0.0};
  AffineSpectralFunctionEstimate log_determinant{};
  AffineSpectralFunctionEstimate inverse_trace{};
  AffineSpectralFunctionEstimate kernel_inverse_trace{};
  AffineSpectralPlanDiagnostics diagnostics{};
};

class AffineSpectralPlan;
class AffineSpectralPlanWorkspace;
struct AffineSpectralPlanBuildResult;

class GSOLVE_EXPORT AffineSpectralPlanWorkspace {
 public:
  Status prepare(std::uint64_t dimension, std::uint64_t lanczos_steps);

 private:
  friend class AffineSpectralPlan;
  friend struct AffineSpectralPlanBuildResult;
  friend AffineSpectralPlanBuildResult create_affine_spectral_plan(
      std::shared_ptr<const LinearOperator>,
      const AffineSpectralPlanOptions&, const ExecutionConfig&,
      AffineSpectralPlanWorkspace&);
  friend AffineSpectralPlanBuildResult extend_affine_spectral_plan(
      std::shared_ptr<const AffineSpectralPlan>,
      const AffineSpectralPlanOptions&, const ExecutionConfig&,
      AffineSpectralPlanWorkspace&);
  std::uint64_t dimension_{0};
  std::uint64_t lanczos_steps_{0};
  std::vector<double> previous_{};
  std::vector<double> current_{};
  std::vector<double> product_{};
  std::vector<double> alpha_{};
  std::vector<double> beta_{};
  std::vector<double> tridiagonal_{};
  std::vector<double> eigenvectors_{};
  Workspace operator_workspace_{};
};

class GSOLVE_EXPORT AffineSpectralPlan {
 public:
  ~AffineSpectralPlan();

  [[nodiscard]] std::uint64_t dimension() const noexcept;
  [[nodiscard]] std::uint64_t probe_count() const noexcept;
  [[nodiscard]] std::uint64_t lanczos_steps() const noexcept;
  [[nodiscard]] std::uint64_t seed() const noexcept;
  [[nodiscard]] bool compatible_with(const LinearOperator& kernel,
                                     std::uint64_t seed) const noexcept;
  [[nodiscard]] AffineSpectralPlanDiagnostics diagnostics() const noexcept;
  [[nodiscard]] AffineSpectralEvaluationResult evaluate(
      double covariance_coefficient, double identity_coefficient) const;

 private:
  struct Impl;
  explicit AffineSpectralPlan(std::shared_ptr<Impl> implementation);
  friend AffineSpectralPlanBuildResult create_affine_spectral_plan(
      std::shared_ptr<const LinearOperator>,
      const AffineSpectralPlanOptions&, const ExecutionConfig&,
      AffineSpectralPlanWorkspace&);
  friend AffineSpectralPlanBuildResult extend_affine_spectral_plan(
      std::shared_ptr<const AffineSpectralPlan>,
      const AffineSpectralPlanOptions&, const ExecutionConfig&,
      AffineSpectralPlanWorkspace&);
  std::shared_ptr<Impl> implementation_{};
};

struct AffineSpectralPlanBuildResult {
  Status status{};
  std::shared_ptr<const AffineSpectralPlan> plan{};
  std::uint64_t reused_probe_count{0};
  std::uint64_t constructed_probe_count{0};
  std::uint64_t rebuilt_probe_count{0};
  std::uint64_t operator_applications{0};
};

GSOLVE_EXPORT AffineSpectralPlanBuildResult create_affine_spectral_plan(
    std::shared_ptr<const LinearOperator> kernel,
    const AffineSpectralPlanOptions& options,
    const ExecutionConfig& execution, AffineSpectralPlanWorkspace& workspace);

// Extension preserves the existing deterministic probe prefix when depth is
// unchanged. A larger depth deterministically rebuilds every requested probe.
// Probe count and depth may not decrease.
GSOLVE_EXPORT AffineSpectralPlanBuildResult extend_affine_spectral_plan(
    std::shared_ptr<const AffineSpectralPlan> existing,
    const AffineSpectralPlanOptions& options,
    const ExecutionConfig& execution, AffineSpectralPlanWorkspace& workspace);

}  // namespace gsolve

#endif
