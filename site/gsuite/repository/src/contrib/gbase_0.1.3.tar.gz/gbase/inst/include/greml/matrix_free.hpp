#ifndef GREML_MATRIX_FREE_HPP
#define GREML_MATRIX_FREE_HPP

#include <cstdint>
#include <atomic>
#include <memory>
#include <string>
#include <vector>

#include "greml/exact_dense.hpp"
#include "greml/fixed_effect_design.hpp"
#include "gsolve/dense_spd_factorization.hpp"
#include "gsolve/pcg.hpp"
#include "gsolve/probes.hpp"
#include "gsolve/slq.hpp"

namespace greml {

// The shared operator is immutable and retained by every covariance sum that
// copies this descriptor. Its apply() implementation remains responsible for
// its own numerical validity and failure-atomic output contract.
struct MatrixFreeCovarianceComponent {
  std::shared_ptr<const gsolve::LinearOperator> linear_operator{};
  double coefficient{0.0};
  // Empty asks MatrixFreeCovarianceSum to query the operator's optional exact
  // diagonal capability. If still unavailable, Jacobi construction cannot use
  // this component. A supplied vector is in logical observation order.
  std::vector<double> diagonal{};
  std::string name{};
  // Explicit structural metadata used by generic affine-plan eligibility.
  // This is set only by make_identity_covariance_component(); numerical
  // equality with an identity matrix is deliberately not inferred.
  bool identity_operator{false};
};

GREML_EXPORT MatrixFreeCovarianceComponent make_identity_covariance_component(
    std::uint64_t dimension, double coefficient,
    std::string name = "residual");

class GREML_EXPORT MatrixFreeCovarianceSum final
    : public gsolve::LinearOperator {
 public:
  explicit MatrixFreeCovarianceSum(
      std::vector<MatrixFreeCovarianceComponent> components);

  [[nodiscard]] std::uint64_t rows() const noexcept override {
    return dimension_;
  }
  [[nodiscard]] std::uint64_t columns() const noexcept override {
    return dimension_;
  }
  [[nodiscard]] gsolve::Symmetry symmetry() const noexcept override;
  [[nodiscard]] gsolve::Definiteness definiteness() const noexcept override;
  [[nodiscard]] bool concurrent_apply_supported() const noexcept override;
  [[nodiscard]] bool has_exact_diagonal() const noexcept override;
  [[nodiscard]] const Status& validation_status() const noexcept {
    return validation_status_;
  }
  [[nodiscard]] std::uint64_t component_count() const noexcept {
    return static_cast<std::uint64_t>(components_.size());
  }
  [[nodiscard]] const MatrixFreeCovarianceComponent& component(
      std::uint64_t index) const noexcept {
    return components_[static_cast<std::size_t>(index)];
  }

  gsolve::Status apply(gsolve::ConstMatrixView input, gsolve::MatrixView output,
                       gsolve::Workspace& workspace) const override;
  gsolve::Status exact_diagonal(gsolve::MatrixView output,
                                gsolve::Workspace& workspace) const override;

  // Produces diag(V) only when every active component supplies a complete,
  // finite diagonal and the assembled entries are strictly positive.
  [[nodiscard]] Status assemble_diagonal(std::vector<double>& diagonal) const;

 private:
  std::uint64_t dimension_{0};
  std::vector<MatrixFreeCovarianceComponent> components_{};
  Status validation_status_{};
};

enum class PreconditionerPolicy { automatic, identity, jacobi };
enum class ResolvedPreconditioner { identity, jacobi, supplied, two_level };
enum class TwoLevelSetupFailurePolicy { fail, use_base_preconditioner };
enum class FixedEffectProjectionStrategy { materialized, iterative };
enum class FixedEffectCovarianceAvailability { full, unavailable_iterative };

// Explicit observation-space coarse correction. The immutable vector owns a
// column-major basis with `basis_column_count` logical columns. A zero leading
// dimension means the covariance dimension. The existing base policy remains
// explicit; a supplied base wins when non-null (including route-owned hybrid
// structured preconditioners).
class TwoLevelComponentState;

struct TwoLevelPreconditionerConfiguration {
  bool enabled{false};
  PreconditionerPolicy base_policy{PreconditionerPolicy::automatic};
  std::shared_ptr<const gsolve::Preconditioner> supplied_base_preconditioner{};
  std::shared_ptr<const std::vector<double>> coarse_basis{};
  std::uint64_t basis_column_count{0};
  std::uint64_t basis_leading_dimension{0};
  gsolve::TwoLevelPreconditionerOptions setup{};
  // Opt-in bounded component-action cache. Zero preserves uncached setup.
  std::uint64_t component_cache_max_bytes{0};
  std::shared_ptr<const TwoLevelComponentState> reusable_component_state{};
  TwoLevelSetupFailurePolicy failure_policy{TwoLevelSetupFailurePolicy::fail};
};

struct IterativeFixedEffectOptions {
  gsolve::PcgOptions normal_pcg{};
  gsolve::MultipleRhsKrylovStrategy normal_solve_strategy{
      gsolve::MultipleRhsKrylovStrategy::independent};
  gsolve::BlockPcgOptions normal_block_pcg{};
  std::shared_ptr<const gsolve::Preconditioner> normal_preconditioner{};
  gsolve::ExecutionConfig solve_execution{};
  std::uint64_t determinant_seed{0x4649584544465845ULL};
  std::uint64_t determinant_probe_count{16};
  std::uint64_t determinant_probe_batch_size{8};
  std::uint64_t determinant_lanczos_steps{20};
  double determinant_breakdown_tolerance{1.0e-14};
  bool retain_determinant_probe_estimates{false};
  std::shared_ptr<const std::vector<double>> explicit_determinant_probes{};
  bool explicit_determinant_probes_are_complete{false};
};

struct PreconditionerResolution {
  Status status{};
  ResolvedPreconditioner resolved{ResolvedPreconditioner::identity};
  PreconditionerPolicy requested_base_policy{PreconditionerPolicy::automatic};
  ResolvedPreconditioner resolved_base{ResolvedPreconditioner::identity};
  bool two_level_requested{false};
  bool two_level_resolved{false};
  bool two_level_fallback_used{false};
  gsolve::TwoLevelPreconditionerDiagnostics two_level{};
  std::shared_ptr<const TwoLevelComponentState> two_level_component_state{};
  std::uint64_t cached_component_bytes{0};
  std::uint64_t cache_component_applications{0};
  bool component_cache_reused{false};
  std::shared_ptr<const gsolve::Preconditioner> preconditioner{};
  std::vector<double> diagonal{};
};

GREML_EXPORT PreconditionerResolution resolve_preconditioner(
    const MatrixFreeCovarianceSum& covariance,
    PreconditionerPolicy policy = PreconditionerPolicy::automatic);

class GREML_EXPORT MatrixFreeProjectionWorkspace {
 public:
  Status prepare(std::uint64_t observation_count,
                 std::uint64_t fixed_effect_count,
                 std::uint64_t right_hand_side_count);
  Status prepare(std::uint64_t observation_count,
                 const FixedEffectDesign& fixed_effects,
                 std::uint64_t right_hand_side_count);
  [[nodiscard]] bool compatible(std::uint64_t observation_count,
                                std::uint64_t fixed_effect_count,
                                std::uint64_t right_hand_side_count) const
      noexcept;

  // Raw inverse RHS solutions from the most recent successful projection.
  // The view is valid until this workspace is prepared or used again.
  [[nodiscard]] gsolve::ConstMatrixView inverse_solutions() const noexcept {
    return {inverse_.data(), observation_count_, right_hand_side_count_, observation_count_};
  }

 private:
  friend class MatrixFreeProjectionSystem;
  std::uint64_t observation_count_{0};
  std::uint64_t fixed_effect_count_{0};
  std::uint64_t right_hand_side_count_{0};
  std::vector<double> inverse_{};
  std::vector<double> staged_{};
  std::vector<double> correction_{};
  std::vector<double> cross_product_{};
  std::vector<double> small_solution_{};
  gsolve::MultipleRhsPcgWorkspace solve_workspace_{};
  gsolve::MultipleRhsPcgWorkspace normal_solve_workspace_{};
  gsolve::MultipleRhsPcgWorkspace correction_solve_workspace_{};
  gsolve::Workspace component_workspace_{};
  gsolve::Workspace design_workspace_{};
};

struct MatrixFreeSolveResult {
  Status status{};
  gsolve::PcgBatchResult solve_diagnostics{};
  gsolve::PcgBatchResult fixed_effect_solve_diagnostics{};
  gsolve::PcgBatchResult correction_solve_diagnostics{};
};

struct MatrixFreeResponseSummary {
  Status status{};
  std::uint64_t observation_count{0};
  std::uint64_t fixed_effect_count{0};
  std::uint64_t component_count{0};
  std::vector<double> inverse_response{};
  std::vector<double> beta{};
  std::vector<double> py{};
  double quadratic{0.0};
  gsolve::PcgBatchResult solve_diagnostics{};
  gsolve::PcgBatchResult fixed_effect_solve_diagnostics{};
  gsolve::PcgBatchResult correction_solve_diagnostics{};
  std::vector<std::vector<double>> component_predictions{};
};

struct FixedEffectNormalOperatorDiagnostics {
  std::uint64_t applications{0};
  std::uint64_t covariance_operator_applications{0};
  std::uint64_t covariance_preconditioner_applications{0};
  std::uint64_t covariance_operator_processed_columns{0};
  std::uint64_t covariance_preconditioner_processed_columns{0};
  std::uint64_t block_applications{0};
  std::uint64_t block_iterations{0};
  std::uint64_t rank_loss_events{0};
  std::uint64_t maximum_block_width{0};
  std::uint64_t maximum_block_rank{0};
};

class GREML_EXPORT FixedEffectNormalOperator final
    : public gsolve::LinearOperator {
 public:
  FixedEffectNormalOperator(
      std::shared_ptr<const MatrixFreeCovarianceSum> covariance,
      std::shared_ptr<const FixedEffectDesign> fixed_effects,
      std::shared_ptr<const gsolve::Preconditioner> covariance_preconditioner,
      gsolve::PcgOptions covariance_pcg,
      gsolve::MultipleRhsKrylovStrategy covariance_solve_strategy =
          gsolve::MultipleRhsKrylovStrategy::independent,
      gsolve::BlockPcgOptions covariance_block_pcg = {});

  [[nodiscard]] std::uint64_t rows() const noexcept override;
  [[nodiscard]] std::uint64_t columns() const noexcept override;
  [[nodiscard]] gsolve::Symmetry symmetry() const noexcept override;
  [[nodiscard]] gsolve::Definiteness definiteness() const noexcept override;
  [[nodiscard]] bool concurrent_apply_supported() const noexcept override;
  gsolve::Status apply(gsolve::ConstMatrixView input,
                       gsolve::MatrixView output,
                       gsolve::Workspace& workspace) const override;
  [[nodiscard]] FixedEffectNormalOperatorDiagnostics diagnostics() const
      noexcept;

 private:
  std::shared_ptr<const MatrixFreeCovarianceSum> covariance_{};
  std::shared_ptr<const FixedEffectDesign> fixed_effects_{};
  std::shared_ptr<const gsolve::Preconditioner> covariance_preconditioner_{};
  gsolve::PcgOptions covariance_pcg_{};
  gsolve::MultipleRhsKrylovStrategy covariance_solve_strategy_{
      gsolve::MultipleRhsKrylovStrategy::independent};
  gsolve::BlockPcgOptions covariance_block_pcg_{};
  mutable std::atomic<std::uint64_t> applications_{0};
  mutable std::atomic<std::uint64_t> covariance_operator_applications_{0};
  mutable std::atomic<std::uint64_t>
      covariance_preconditioner_applications_{0};
  mutable std::atomic<std::uint64_t>
      covariance_operator_processed_columns_{0};
  mutable std::atomic<std::uint64_t>
      covariance_preconditioner_processed_columns_{0};
  mutable std::atomic<std::uint64_t> block_applications_{0};
  mutable std::atomic<std::uint64_t> block_iterations_{0};
  mutable std::atomic<std::uint64_t> rank_loss_events_{0};
  mutable std::atomic<std::uint64_t> maximum_block_width_{0};
  mutable std::atomic<std::uint64_t> maximum_block_rank_{0};
};

// A successful object owns X, V^-1 X, the small C factorization, the resolved
// preconditioner, and shared ownership of V and its component operators. It is
// immutable after construction; concurrent calls require independent workspaces
// and output buffers. No dense n-by-n matrix is constructed.
class GREML_EXPORT MatrixFreeProjectionSystem {
 public:
  MatrixFreeProjectionSystem(
      std::shared_ptr<const MatrixFreeCovarianceSum> covariance,
      gsolve::ConstMatrixView fixed_effects,
      PreconditionerPolicy preconditioner_policy,
      const gsolve::PcgOptions& pcg_options,
      const gsolve::ConstMatrixView* initial_inverse_fixed_effects = nullptr,
      const gsolve::ExecutionConfig& execution = {},
      std::shared_ptr<const gsolve::Preconditioner>
          supplied_preconditioner = nullptr,
      FixedEffectProjectionStrategy fixed_effect_strategy =
          FixedEffectProjectionStrategy::materialized,
      const IterativeFixedEffectOptions& iterative_fixed_effects = {},
      gsolve::MultipleRhsKrylovStrategy covariance_solve_strategy =
          gsolve::MultipleRhsKrylovStrategy::independent,
      const gsolve::BlockPcgOptions& covariance_block_pcg = {},
      const TwoLevelPreconditionerConfiguration& two_level = {});
  MatrixFreeProjectionSystem(
      std::shared_ptr<const MatrixFreeCovarianceSum> covariance,
      std::shared_ptr<const FixedEffectDesign> fixed_effects,
      PreconditionerPolicy preconditioner_policy,
      const gsolve::PcgOptions& pcg_options,
      std::uint64_t fixed_effect_batch_size = 64,
      const gsolve::ConstMatrixView* initial_inverse_fixed_effects = nullptr,
      const gsolve::ExecutionConfig& execution = {},
      std::shared_ptr<const gsolve::Preconditioner>
          supplied_preconditioner = nullptr,
      FixedEffectProjectionStrategy fixed_effect_strategy =
          FixedEffectProjectionStrategy::materialized,
      const IterativeFixedEffectOptions& iterative_fixed_effects = {},
      gsolve::MultipleRhsKrylovStrategy covariance_solve_strategy =
          gsolve::MultipleRhsKrylovStrategy::independent,
      const gsolve::BlockPcgOptions& covariance_block_pcg = {},
      const TwoLevelPreconditionerConfiguration& two_level = {});

  [[nodiscard]] const Status& status() const noexcept { return status_; }
  [[nodiscard]] std::uint64_t observation_count() const noexcept {
    return observation_count_;
  }
  [[nodiscard]] std::uint64_t fixed_effect_count() const noexcept {
    return fixed_effect_count_;
  }
  [[nodiscard]] std::uint64_t component_count() const noexcept;
  [[nodiscard]] ResolvedPreconditioner resolved_preconditioner() const noexcept {
    return preconditioner_resolution_.resolved;
  }
  [[nodiscard]] const PreconditionerResolution& preconditioner_resolution()
      const noexcept {
    return preconditioner_resolution_;
  }
  [[nodiscard]] const gsolve::PcgBatchResult& preparation_diagnostics() const
      noexcept {
    return preparation_diagnostics_;
  }
  [[nodiscard]] FixedEffectProjectionStrategy fixed_effect_strategy() const
      noexcept { return fixed_effect_strategy_; }
  [[nodiscard]] FixedEffectCovarianceAvailability
  fixed_effect_covariance_availability() const noexcept {
    return fixed_effect_strategy_ == FixedEffectProjectionStrategy::materialized
               ? FixedEffectCovarianceAvailability::full
               : FixedEffectCovarianceAvailability::unavailable_iterative;
  }
  [[nodiscard]] const std::shared_ptr<const FixedEffectNormalOperator>&
  fixed_effect_normal_operator() const noexcept { return normal_operator_; }
  [[nodiscard]] gsolve::ConstMatrixView inverse_fixed_effects() const noexcept;
  [[nodiscard]] gsolve::ConstMatrixView fixed_effect_covariance() const noexcept;
  [[nodiscard]] double fixed_effect_log_determinant() const noexcept {
    return cross_factor_ ? cross_factor_->log_determinant() : 0.0;
  }
  [[nodiscard]] const std::shared_ptr<const MatrixFreeCovarianceSum>&
  covariance() const noexcept {
    return covariance_;
  }
  [[nodiscard]] const std::shared_ptr<const FixedEffectDesign>&
  fixed_effect_design() const noexcept {
    return fixed_effect_design_;
  }

  [[nodiscard]] MatrixFreeSolveResult solve(
      gsolve::ConstMatrixView right_hand_sides, gsolve::MatrixView solutions,
      MatrixFreeProjectionWorkspace& workspace,
      const gsolve::ConstMatrixView* initial_guesses = nullptr) const;

  [[nodiscard]] MatrixFreeSolveResult apply_projection(
      gsolve::ConstMatrixView right_hand_sides, gsolve::MatrixView projected,
      MatrixFreeProjectionWorkspace& workspace,
      const gsolve::ConstMatrixView* initial_guesses = nullptr) const;

  // Solves (F^T V^-1 F) X = B without materializing the normal matrix in the
  // iterative route. The materialized route reuses its existing dense factor.
  // Logical output is committed only after the complete solve succeeds.
  [[nodiscard]] MatrixFreeSolveResult solve_fixed_effect_normal(
      gsolve::ConstMatrixView right_hand_sides, gsolve::MatrixView solutions,
      MatrixFreeProjectionWorkspace& workspace) const;

  [[nodiscard]] MatrixFreeResponseSummary summarize_response(
      gsolve::ConstMatrixView response,
      MatrixFreeProjectionWorkspace& workspace,
      bool compute_component_predictions = true,
      const gsolve::ConstMatrixView* initial_guess = nullptr) const;

 private:
  Status status_{};
  std::uint64_t observation_count_{0};
  std::uint64_t fixed_effect_count_{0};
  std::shared_ptr<const MatrixFreeCovarianceSum> covariance_{};
  std::shared_ptr<const FixedEffectDesign> fixed_effect_design_{};
  PreconditionerResolution preconditioner_resolution_{};
  gsolve::PcgOptions pcg_options_{};
  gsolve::ExecutionConfig execution_{};
  FixedEffectProjectionStrategy fixed_effect_strategy_{
      FixedEffectProjectionStrategy::materialized};
  IterativeFixedEffectOptions iterative_fixed_effects_{};
  gsolve::MultipleRhsKrylovStrategy covariance_solve_strategy_{
      gsolve::MultipleRhsKrylovStrategy::independent};
  gsolve::BlockPcgOptions covariance_block_pcg_{};
  std::vector<double> inverse_fixed_effects_{};
  std::vector<double> fixed_effect_covariance_{};
  std::shared_ptr<const gsolve::DenseSpdFactorization> cross_factor_{};
  std::shared_ptr<const FixedEffectNormalOperator> normal_operator_{};
  std::shared_ptr<const gsolve::Preconditioner> normal_preconditioner_{};
  gsolve::PcgBatchResult preparation_diagnostics_{};
};

}  // namespace greml

#endif
