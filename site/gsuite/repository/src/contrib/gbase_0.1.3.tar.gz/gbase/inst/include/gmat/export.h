#ifndef GMAT_EXPORT_H
#define GMAT_EXPORT_H

#if defined(GMAT_STATIC_DEFINE)
#  define GMAT_EXPORT
#elif defined(_WIN32) || defined(__CYGWIN__)
#  if defined(GMAT_BUILDING_LIBRARY)
#    define GMAT_EXPORT __declspec(dllexport)
#  else
#    define GMAT_EXPORT __declspec(dllimport)
#  endif
#elif defined(__GNUC__) && __GNUC__ >= 4
#  define GMAT_EXPORT __attribute__((visibility("default")))
#else
#  define GMAT_EXPORT
#endif

#endif

