#ifndef GSOLVE_LINEAR_OPERATOR_HPP
#define GSOLVE_LINEAR_OPERATOR_HPP

#include <cstdint>
#include <memory>
#include <vector>

#include "gsolve/export.h"
#include "gsolve/matrix_view.hpp"

namespace gsolve {

class PcgBatchWorkspace;
class MultipleRhsPcgWorkspace;
enum class MultipleRhsKrylovStrategy;

enum class Symmetry { general, symmetric };
enum class Definiteness {
  unknown,
  positive_semidefinite,
  positive_definite,
  indefinite
};

class GSOLVE_EXPORT Workspace {
 public:
  Workspace();
  ~Workspace();
  Workspace(Workspace&&) noexcept;
  Workspace& operator=(Workspace&&) noexcept;
  Workspace(const Workspace&) = delete;
  Workspace& operator=(const Workspace&) = delete;
  Status resize(std::uint64_t element_count);
  Status prepare_children(std::uint64_t child_count);
  // Lazily owns one reusable batch-PCG workspace for operator compositions
  // that perform an inner linear solve. The slot is caller-owned through this
  // Workspace and carries no statistical or model-specific semantics.
  Status prepare_pcg_batch(std::uint64_t dimension,
                           std::uint64_t right_hand_side_count,
                           std::uint32_t worker_count = 1);
  [[nodiscard]] PcgBatchWorkspace& pcg_batch_workspace() noexcept;
  Status prepare_pcg_multiple(std::uint64_t dimension,
                              std::uint64_t right_hand_side_count,
                              MultipleRhsKrylovStrategy strategy,
                              std::uint32_t independent_worker_count = 1);
  [[nodiscard]] MultipleRhsPcgWorkspace& pcg_multiple_workspace() noexcept;
  [[nodiscard]] double* data() noexcept { return storage_.data(); }
  [[nodiscard]] const double* data() const noexcept { return storage_.data(); }
  [[nodiscard]] std::uint64_t size() const noexcept {
    return static_cast<std::uint64_t>(storage_.size());
  }
  [[nodiscard]] std::uint64_t child_count() const noexcept {
    return static_cast<std::uint64_t>(children_.size());
  }
  // Call prepare_children() before indexing. Child workspaces permit nested
  // operator composition without operator-owned mutable scratch state.
  [[nodiscard]] Workspace& child(std::uint64_t index) noexcept {
    return children_[static_cast<std::size_t>(index)];
  }

 private:
  std::vector<double> storage_{};
  std::vector<Workspace> children_{};
  std::unique_ptr<PcgBatchWorkspace> pcg_batch_workspace_{};
  std::unique_ptr<MultipleRhsPcgWorkspace> pcg_multiple_workspace_{};
};

class GSOLVE_EXPORT LinearOperator {
 public:
  virtual ~LinearOperator() = default;
  [[nodiscard]] virtual std::uint64_t rows() const noexcept = 0;
  [[nodiscard]] virtual std::uint64_t columns() const noexcept = 0;
  [[nodiscard]] virtual Symmetry symmetry() const noexcept = 0;
  [[nodiscard]] virtual Definiteness definiteness() const noexcept = 0;
  // Outer RHS/probe parallelism uses this capability to avoid concurrently
  // invoking an operator with shared mutable state. The default matches the
  // immutable algebraic operator contract; stateful backends must override it.
  [[nodiscard]] virtual bool concurrent_apply_supported() const noexcept {
    return true;
  }

  // Exact diagonal extraction is optional. Implementations advertising it
  // overwrite one logical output column and preserve any output padding.
  [[nodiscard]] virtual bool has_exact_diagonal() const noexcept {
    return false;
  }
  virtual Status exact_diagonal(MatrixView output,
                                Workspace& workspace) const {
    (void)output;
    (void)workspace;
    return {StatusCode::not_supported,
            "this operator does not provide an exact diagonal"};
  }

  // Applies the operator to every input column. Implementations overwrite the
  // logical output and retain no caller buffer after return.
  virtual Status apply(ConstMatrixView input, MatrixView output,
                       Workspace& workspace) const = 0;
};

}  // namespace gsolve

#endif
