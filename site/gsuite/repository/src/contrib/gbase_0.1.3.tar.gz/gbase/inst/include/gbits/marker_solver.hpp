#ifndef GBITS_MARKER_SOLVER_HPP
#define GBITS_MARKER_SOLVER_HPP

#include <gbits/execution.hpp>
#include <gbits/export.h>
#include <gbits/genotype_transform.hpp>
#include <gbits/packed_matrix.hpp>
#include <gbits/prepared_matrix.hpp>

#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace gbits {

namespace detail {
struct PackedMarkerCoordinateAccess;
}

enum class GramCachePolicy : std::uint32_t { disabled = 0, bounded = 1 };
enum class GramCacheResolution : std::uint32_t {
    disabled = 0,
    cached,
    disabled_by_limit
};
enum class FactorCachePolicy : std::uint32_t { disabled = 0, bounded = 1 };
enum class FactorCacheResolution : std::uint32_t {
    disabled = 0,
    cached,
    disabled_by_limit
};
enum class PackedMarkerStrategy : std::uint32_t {
    fused_coordinate = 0,
    block_cholesky = 1
};
enum class MarkerStatus : std::uint32_t {
    success = 0,
    invalid_cache,
    invalid_penalty,
    dimension_mismatch,
    rank_failure,
    maximum_sweeps,
    numerical_failure,
    not_supported
};

struct MarkerStatusDetail {
    MarkerStatus code{MarkerStatus::success};
    std::string message{};
    explicit operator bool() const noexcept {
        return code == MarkerStatus::success;
    }
};

struct PackedBlockCacheOptions {
    std::uint64_t block_size{32};
    GramCachePolicy gram_policy{GramCachePolicy::bounded};
    std::uint64_t gram_memory_limit_bytes{64u * 1024u * 1024u};
    ExecutionConfig execution{};
};

struct PackedBlockCacheMemory {
    std::uint64_t referenced_packed_storage_bytes{0};
    std::uint64_t metadata_bytes{0};
    std::uint64_t gram_cache_bytes{0};
    std::uint64_t coordinate_metadata_bytes{0};
};

struct PackedPenaltyStateOptions {
    FactorCachePolicy factor_policy{FactorCachePolicy::bounded};
    std::uint64_t factor_memory_limit_bytes{64u * 1024u * 1024u};
};

struct PackedPenaltyStateMemory {
    std::uint64_t prepared_factor_bytes{0};
};

class PackedMarkerBlockCache;
class GBITS_API PackedMarkerPenaltyState final {
public:
    static std::shared_ptr<const PackedMarkerPenaltyState> create(
        std::shared_ptr<const PackedMarkerBlockCache> cache,
        std::vector<double> penalty,
        const PackedPenaltyStateOptions& options,
        MarkerStatusDetail& status) noexcept;

    ~PackedMarkerPenaltyState();
    PackedMarkerPenaltyState(const PackedMarkerPenaltyState&) = delete;
    PackedMarkerPenaltyState& operator=(const PackedMarkerPenaltyState&) = delete;

    [[nodiscard]] const std::shared_ptr<const PackedMarkerBlockCache>&
        cache() const noexcept;
    [[nodiscard]] const std::vector<double>& penalty() const noexcept;
    [[nodiscard]] FactorCacheResolution factor_cache_resolution() const noexcept;
    [[nodiscard]] const PackedPenaltyStateMemory& memory() const noexcept;
    [[nodiscard]] std::uint64_t preparation_factorizations() const noexcept;
    [[nodiscard]] const std::vector<double>& block_factor(
        std::uint64_t block) const;

private:
    struct Impl;
    explicit PackedMarkerPenaltyState(std::unique_ptr<Impl> implementation);
    std::unique_ptr<Impl> implementation_;
};

class GBITS_API PackedMarkerBlockCache final {
public:
    static std::shared_ptr<const PackedMarkerBlockCache> create(
        std::shared_ptr<const PackedMatrix> packed,
        std::shared_ptr<const PackedSelection> selection,
        std::shared_ptr<const PackedTransform> transform,
        std::vector<double> marker_weights,
        double normalization,
        const PackedBlockCacheOptions& options,
        MarkerStatusDetail& status) noexcept;
    static std::shared_ptr<const PackedMarkerBlockCache> create_prepared(
        std::shared_ptr<const PreparedBitMatrix> prepared,
        std::shared_ptr<const GenotypeTransform> transform,
        std::vector<double> marker_weights,
        double normalization,
        const PackedBlockCacheOptions& options,
        MarkerStatusDetail& status) noexcept;

    ~PackedMarkerBlockCache();
    PackedMarkerBlockCache(const PackedMarkerBlockCache&) = delete;
    PackedMarkerBlockCache& operator=(const PackedMarkerBlockCache&) = delete;

    std::uint64_t sample_count() const noexcept;
    std::uint64_t marker_count() const noexcept;
    std::uint64_t block_count() const noexcept;
    std::uint64_t block_size() const noexcept;
    std::uint64_t block_begin(std::uint64_t block) const;
    std::uint64_t block_marker_count(std::uint64_t block) const;
    double normalization() const noexcept;
    const std::vector<double>& marker_weights() const noexcept;
    GramCacheResolution gram_cache_resolution() const noexcept;
    const PackedBlockCacheMemory& memory() const noexcept;
    const ExecutionConfig& execution_config() const noexcept;
    const std::vector<double>& cached_block_gram(
        std::uint64_t block) const;

    // Decode transformed logical columns (weights/normalization are NOT applied).
    // Output extent is checked before writing; caller owns the bounded buffer.
    MarkerStatusDetail decode_columns(std::uint64_t begin, std::uint64_t count,
        double* output, std::uint64_t length, std::uint64_t ldout) const noexcept;
    // Independent columns; no reductions or changes to arithmetic. Requests
    // above one require OpenMP. The original overload remains serial.
    MarkerStatusDetail decode_columns(std::uint64_t begin, std::uint64_t count,
        double* output, std::uint64_t length, std::uint64_t ldout,
        std::uint32_t threads) const noexcept;

    // Logical matrices are column-major. These methods overwrite logical
    // output, preserve padding, and retain no caller buffer.
    MarkerStatusDetail block_xmat(
        std::uint64_t block, const double* coefficients,
        std::uint64_t coefficients_length, std::uint64_t rhs_count,
        std::uint64_t ldb, double* output, std::uint64_t output_length,
        std::uint64_t ldout) const noexcept;
    MarkerStatusDetail block_xtmat(
        std::uint64_t block, const double* values,
        std::uint64_t values_length, std::uint64_t rhs_count,
        std::uint64_t ldy, double* output, std::uint64_t output_length,
        std::uint64_t ldout) const noexcept;

    // Selected transformed columns, without marker weights/normalization.
    // Strictly increasing indices; input/output must not alias.
    // Reuses packed multi-RHS kernels; output is unchanged on failure.
    MarkerStatusDetail product_columns(
        const std::vector<std::uint64_t>& markers, bool transpose,
        const double* input, std::uint64_t input_length,
        std::uint64_t rhs_count, std::uint64_t ldin,
        double* output, std::uint64_t output_length, std::uint64_t ldout,
        std::uint32_t threads) const noexcept;
private:
    struct Impl;
    explicit PackedMarkerBlockCache(std::unique_ptr<Impl> implementation);
    std::unique_ptr<Impl> implementation_;

    friend struct detail::PackedMarkerCoordinateAccess;

};

struct PackedMarkerComponent {
    std::shared_ptr<const PackedMarkerBlockCache> cache{};
    // Positive diagonal marker penalty, in cache logical marker order.
    std::vector<double> penalty{};
    // Optional immutable block factorization for this exact penalty state.
    // The block-Cholesky reference strategy prepares a bounded state when
    // absent; the preferred fused-coordinate strategy does not use it.
    std::shared_ptr<const PackedMarkerPenaltyState> prepared_penalty{};
};

struct PackedMarkerInitialState {
    std::vector<double> fixed_effects{}; // p by rhs, column-major
    std::vector<std::vector<double>> marker_effects{}; // component: m by rhs
};

struct PackedMarkerSolveOptions {
    std::uint64_t maximum_sweeps{100};
    double relative_tolerance{1.0e-8};
    double absolute_tolerance{0.0};
    double coefficient_tolerance{1.0e-10};
    PackedMarkerStrategy strategy{PackedMarkerStrategy::fused_coordinate};
    PackedPenaltyStateOptions penalty_preparation{};
};

struct PackedMarkerDiagnostics {
    PackedMarkerStrategy strategy{PackedMarkerStrategy::fused_coordinate};
    std::uint64_t sweeps{0};
    std::uint64_t packed_block_passes{0};
    std::uint64_t marker_visits{0};
    std::uint64_t packed_decode_passes{0};
    std::uint64_t full_convergence_audits{0};
    std::uint64_t processed_rhs_columns{0};
    double maximum_coefficient_change{0.0};
    double fixed_normal_residual{0.0};
    double marker_normal_residual{0.0};
    double observation_consistency_residual{0.0};
    double convergence_threshold{0.0};
    bool warm_start_used{false};
    std::uint64_t preparation_factorizations{0};
    std::uint64_t runtime_factorizations{0};
    std::uint64_t prepared_factor_solves{0};
    std::uint64_t prepared_factor_bytes{0};
    std::uint64_t coordinate_metadata_bytes{0};
    std::uint64_t gram_cache_bytes{0};
    std::uint64_t workspace_bytes{0};
    bool factor_recomputation_mode{false};
};

struct PackedFactorUseDiagnostics {
    PackedMarkerStrategy strategy{PackedMarkerStrategy::fused_coordinate};
    std::uint64_t marker_visits{0};
    std::uint64_t packed_decode_passes{0};
    std::uint64_t preparation_factorizations{0};
    std::uint64_t runtime_factorizations{0};
    std::uint64_t prepared_factor_solves{0};
    std::uint64_t prepared_factor_bytes{0};
    std::uint64_t workspace_bytes{0};
    bool factor_recomputation_mode{false};
};

struct PackedMarkerSolveResult {
    MarkerStatusDetail status{};
    PackedMarkerDiagnostics diagnostics{};
    std::vector<double> fixed_effects{};
    std::vector<std::vector<double>> marker_effects{};
    std::vector<double> residual{};
};

// Production multiple-system fused-coordinate execution.  A system is one
// response/probe column.  Complete columns are assigned to one worker for the
// lifetime of the call; marker blocks are decoded once and published read-only
// to those workers.  The existing solve_packed_marker_system function remains
// the deterministic serial oracle.
enum class PackedMarkerBatchStopping : std::uint32_t {
    convergence = 0,
    fixed_sweeps = 1
};

struct PackedMarkerBatchOptions {
    std::uint64_t maximum_sweeps{100};
    double relative_tolerance{1.0e-8};
    double absolute_tolerance{0.0};
    double coefficient_tolerance{1.0e-10};
    PackedMarkerBatchStopping stopping{PackedMarkerBatchStopping::convergence};
    // Zero uses the current OpenMP runtime maximum.  One is deterministic
    // serial execution.  The resolved count never exceeds system_count.
    std::uint32_t requested_threads{1};
};

struct PackedMarkerBatchSystemDiagnostics {
    MarkerStatusDetail status{};
    std::uint64_t sweeps{0};
    std::uint64_t complete_audits{0};
    double maximum_coefficient_change{0.0};
    double fixed_normal_residual{0.0};
    double marker_normal_residual{0.0};
    double observation_consistency_residual{0.0};
    double convergence_threshold{0.0};
    bool active{true};
    bool completed{false};
    bool warm_start_used{false};
};

struct PackedMarkerBatchDiagnostics {
    std::uint32_t requested_threads{1};
    std::uint32_t resolved_threads{1};
    std::uint64_t system_count{0};
    std::uint64_t block_count{0};
    std::uint64_t active_systems{0};
    std::uint64_t completed_systems{0};
    std::uint64_t marker_visits{0};
    std::uint64_t packed_block_decode_passes{0};
    std::uint64_t category_sum_passes{0};
    std::uint64_t residual_update_passes{0};
    std::uint64_t complete_audits{0};
    std::uint64_t warm_start_systems{0};
    std::uint64_t preparation_bytes{0};
    std::uint64_t workspace_bytes{0};
    double decode_seconds{0.0};
    double compute_seconds{0.0};
    std::vector<PackedMarkerBatchSystemDiagnostics> systems{};
};

struct PackedMarkerBatchResult {
    MarkerStatusDetail status{};
    PackedMarkerBatchDiagnostics diagnostics{};
    std::vector<double> fixed_effects{}; // p by systems, column-major
    std::vector<std::vector<double>> marker_effects{}; // m_c by systems
    std::vector<double> residual{}; // n by systems, packed column-major
};

struct GBITS_API PackedMarkerBatchWorkspace {
    std::vector<double> residual{};
    std::vector<double> audit_residual{};
    std::vector<std::uint8_t> decoded_block{};
};

// response is n by system_count.  The result owns packed logical outputs, so
// caller input padding is never read or written.  Any error leaves result
// output vectors empty while retaining execution and per-system diagnostics.
GBITS_API PackedMarkerBatchResult solve_packed_marker_batch(
    const double* response, std::uint64_t response_length,
    std::uint64_t sample_count, std::uint64_t system_count,
    std::uint64_t ldy, const double* fixed_design,
    std::uint64_t fixed_design_length, std::uint64_t fixed_effect_count,
    std::uint64_t ldf, const std::vector<PackedMarkerComponent>& components,
    const PackedMarkerInitialState* initial_state,
    const PackedMarkerBatchOptions& options,
    PackedMarkerBatchWorkspace& workspace) noexcept;

struct GBITS_API PackedMarkerWorkspace {
    std::vector<double> residual{};
    std::vector<double> cross{};
    std::vector<double> system{};
    std::vector<double> delta{};
    std::vector<double> fitted{};
    std::vector<double> trial{};
    std::vector<std::uint8_t> marker_codes{};
};

// fixed_design is n by p and response is n by rhs. A null fixed_design is
// valid exactly when fixed_effect_count is zero. Output is committed only on
// success; maximum_sweeps and numerical failures return diagnostics without a
// partial solution.
GBITS_API PackedMarkerSolveResult solve_packed_marker_system(
    const double* response, std::uint64_t response_length,
    std::uint64_t sample_count, std::uint64_t rhs_count,
    std::uint64_t ldy, const double* fixed_design,
    std::uint64_t fixed_design_length, std::uint64_t fixed_effect_count,
    std::uint64_t ldf, const std::vector<PackedMarkerComponent>& components,
    const PackedMarkerInitialState* initial_state,
    const PackedMarkerSolveOptions& options,
    PackedMarkerWorkspace& workspace) noexcept;

// Exactly fixed symmetric forward/backward sweeps, defaulting to fused
// coordinates with an explicit block-Cholesky reference option. The state is
// reset to zero on every call, making this a deterministic linear operation.
// No tolerance or early stopping is used.
GBITS_API MarkerStatusDetail packed_marker_symmetric_sweeps(
    const std::vector<PackedMarkerComponent>& components,
    const double* input, std::uint64_t input_length,
    std::uint64_t sample_count, std::uint64_t rhs_count,
    std::uint64_t ldin, std::uint64_t sweep_count,
    PackedMarkerWorkspace& workspace, double* residual,
    std::uint64_t residual_length, std::uint64_t ldres,
    std::vector<std::vector<double>>& marker_effects,
    std::uint64_t& packed_block_passes,
    PackedFactorUseDiagnostics* factor_diagnostics = nullptr,
    PackedMarkerStrategy strategy =
        PackedMarkerStrategy::fused_coordinate) noexcept;

} // namespace gbits

#endif
