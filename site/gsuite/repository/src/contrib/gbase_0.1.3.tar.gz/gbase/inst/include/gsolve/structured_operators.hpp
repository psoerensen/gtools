#ifndef GSOLVE_STRUCTURED_OPERATORS_HPP
#define GSOLVE_STRUCTURED_OPERATORS_HPP

#include <cstdint>
#include <memory>
#include <vector>

#include "gsolve/linear_operator.hpp"
#include "gsolve/rectangular_operator.hpp"

namespace gsolve {

// Immutable square diagonal operator. Stored values are owned by the operator.
class GSOLVE_EXPORT DiagonalOperator final : public LinearOperator {
 public:
  explicit DiagonalOperator(const std::vector<double>& diagonal);

  [[nodiscard]] std::uint64_t rows() const noexcept override;
  [[nodiscard]] std::uint64_t columns() const noexcept override;
  [[nodiscard]] Symmetry symmetry() const noexcept override;
  [[nodiscard]] Definiteness definiteness() const noexcept override;
  [[nodiscard]] bool has_exact_diagonal() const noexcept override;
  [[nodiscard]] const Status& validation_status() const noexcept {
    return validation_status_;
  }
  [[nodiscard]] const std::vector<double>& values() const noexcept {
    return diagonal_;
  }

  Status exact_diagonal(MatrixView output,
                        Workspace& workspace) const override;
  Status apply(ConstMatrixView input, MatrixView output,
               Workspace& workspace) const override;

 private:
  std::vector<double> diagonal_{};
  Status validation_status_{};
  bool positive_definite_{false};
};

// One-hot independent groups: K = Z D Z'. Empty declared groups are allowed;
// omitted group weights mean D = I.
class GSOLVE_EXPORT IndependentGroupOperator final : public LinearOperator {
 public:
  IndependentGroupOperator(const std::vector<std::uint64_t>& observation_groups,
                           std::uint64_t group_count,
                           const std::vector<double>& group_weights = {});

  [[nodiscard]] std::uint64_t rows() const noexcept override;
  [[nodiscard]] std::uint64_t columns() const noexcept override;
  [[nodiscard]] Symmetry symmetry() const noexcept override;
  [[nodiscard]] Definiteness definiteness() const noexcept override;
  [[nodiscard]] bool has_exact_diagonal() const noexcept override;
  [[nodiscard]] const Status& validation_status() const noexcept {
    return validation_status_;
  }
  [[nodiscard]] std::uint64_t group_count() const noexcept {
    return group_count_;
  }

  Status exact_diagonal(MatrixView output,
                        Workspace& workspace) const override;
  Status apply(ConstMatrixView input, MatrixView output,
               Workspace& workspace) const override;

 private:
  std::vector<std::uint64_t> observation_groups_{};
  std::vector<double> group_weights_{};
  std::uint64_t group_count_{0};
  Status validation_status_{};
};

// One-index incidence congruence Z K Z'. The inner operator is retained by
// shared ownership and each observation maps to exactly one latent level.
class GSOLVE_EXPORT IndexedIncidenceCongruenceOperator final
    : public LinearOperator {
 public:
  IndexedIncidenceCongruenceOperator(
      std::shared_ptr<const LinearOperator> inner_operator,
      const std::vector<std::uint64_t>& observation_levels);

  [[nodiscard]] std::uint64_t rows() const noexcept override;
  [[nodiscard]] std::uint64_t columns() const noexcept override;
  [[nodiscard]] Symmetry symmetry() const noexcept override;
  [[nodiscard]] Definiteness definiteness() const noexcept override;
  [[nodiscard]] bool has_exact_diagonal() const noexcept override;
  [[nodiscard]] const Status& validation_status() const noexcept {
    return validation_status_;
  }
  [[nodiscard]] const std::shared_ptr<const LinearOperator>& inner_operator()
      const noexcept {
    return inner_operator_;
  }

  Status exact_diagonal(MatrixView output,
                        Workspace& workspace) const override;
  Status apply(ConstMatrixView input, MatrixView output,
               Workspace& workspace) const override;

 private:
  std::shared_ptr<const LinearOperator> inner_operator_{};
  std::vector<std::uint64_t> observation_levels_{};
  std::vector<double> exact_diagonal_{};
  std::uint64_t level_count_{0};
  bool mapping_is_injective_{false};
  bool mapping_is_bijective_{false};
  Status validation_status_{};
};

// General rectangular congruence Z K Z'. The immutable design and inner
// covariance are retained by shared ownership. Since the rank of an abstract
// Z is not known, a valid result is conservatively reported as PSD even when K
// is positive definite.
class GSOLVE_EXPORT RectangularCongruenceOperator final
    : public LinearOperator {
 public:
  RectangularCongruenceOperator(
      std::shared_ptr<const RectangularOperator> design,
      std::shared_ptr<const LinearOperator> inner_operator);

  [[nodiscard]] std::uint64_t rows() const noexcept override;
  [[nodiscard]] std::uint64_t columns() const noexcept override;
  [[nodiscard]] Symmetry symmetry() const noexcept override;
  [[nodiscard]] Definiteness definiteness() const noexcept override;
  [[nodiscard]] bool concurrent_apply_supported() const noexcept override;
  [[nodiscard]] const Status& validation_status() const noexcept {
    return validation_status_;
  }
  [[nodiscard]] const std::shared_ptr<const RectangularOperator>& design()
      const noexcept {
    return design_;
  }
  [[nodiscard]] const std::shared_ptr<const LinearOperator>& inner_operator()
      const noexcept {
    return inner_operator_;
  }

  Status prepare_workspace(std::uint64_t right_hand_side_count,
                           Workspace& workspace) const;
  Status apply(ConstMatrixView input, MatrixView output,
               Workspace& workspace) const override;

 private:
  std::shared_ptr<const RectangularOperator> design_{};
  std::shared_ptr<const LinearOperator> inner_operator_{};
  Status validation_status_{};
};

// General symmetric congruence Z H Z'. H need only be symmetric, so the
// result deliberately makes no definiteness claim. This complements the
// covariance-specific RectangularCongruenceOperator for derivative operators.
class GSOLVE_EXPORT SymmetricRectangularCongruenceOperator final
    : public LinearOperator {
 public:
  SymmetricRectangularCongruenceOperator(
      std::shared_ptr<const RectangularOperator> design,
      std::shared_ptr<const LinearOperator> inner_operator);

  [[nodiscard]] std::uint64_t rows() const noexcept override;
  [[nodiscard]] std::uint64_t columns() const noexcept override;
  [[nodiscard]] Symmetry symmetry() const noexcept override;
  [[nodiscard]] Definiteness definiteness() const noexcept override;
  [[nodiscard]] bool concurrent_apply_supported() const noexcept override;
  [[nodiscard]] const Status& validation_status() const noexcept {
    return validation_status_;
  }
  Status prepare_workspace(std::uint64_t right_hand_side_count,
                           Workspace& workspace) const;
  Status apply(ConstMatrixView input, MatrixView output,
               Workspace& workspace) const override;

 private:
  std::shared_ptr<const RectangularOperator> design_{};
  std::shared_ptr<const LinearOperator> inner_operator_{};
  Status validation_status_{};
};

}  // namespace gsolve

#endif
