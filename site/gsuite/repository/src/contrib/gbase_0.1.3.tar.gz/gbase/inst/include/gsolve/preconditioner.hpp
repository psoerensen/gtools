#ifndef GSOLVE_PRECONDITIONER_HPP
#define GSOLVE_PRECONDITIONER_HPP

#include <atomic>
#include <cstdint>
#include <limits>
#include <memory>
#include <vector>

#include "gsolve/linear_operator.hpp"

namespace gsolve {

class GSOLVE_EXPORT Preconditioner {
 public:
  virtual ~Preconditioner() = default;
  [[nodiscard]] virtual std::uint64_t dimension() const noexcept = 0;
  // Called before an ordinary PCG iteration begins. Implementations with
  // nontrivial scratch requirements prepare all storage here; the default is
  // allocation-free and accepts every positive RHS count.
  virtual Status prepare_workspace(std::uint64_t right_hand_side_count,
                                   Workspace& workspace) const {
    (void)workspace;
    if (right_hand_side_count == 0) {
      return {StatusCode::invalid_argument,
              "preconditioner workspace requires at least one RHS"};
    }
    return Status::success();
  }
  // Batch PCG uses this metadata to reject unsafe outer parallelism. The
  // default is appropriate for immutable algebraic preconditioners.
  [[nodiscard]] virtual bool concurrent_apply_supported() const noexcept {
    return true;
  }
  // State-bound preconditioners may reject an operator with the right
  // dimension but different numerical state. Algebraic preconditioners keep
  // the default dimension-only compatibility contract.
  [[nodiscard]] virtual bool compatible_with(
      const LinearOperator& linear_operator) const noexcept {
    return dimension() == linear_operator.rows() &&
           linear_operator.rows() == linear_operator.columns();
  }
  virtual Status apply(ConstMatrixView input, MatrixView output,
                       Workspace& workspace) const = 0;
};

class GSOLVE_EXPORT IdentityPreconditioner final : public Preconditioner {
 public:
  explicit IdentityPreconditioner(std::uint64_t dimension) noexcept
      : dimension_(dimension) {}
  [[nodiscard]] std::uint64_t dimension() const noexcept override {
    return dimension_;
  }
  Status apply(ConstMatrixView input, MatrixView output,
               Workspace& workspace) const override;

 private:
  std::uint64_t dimension_;
};

class GSOLVE_EXPORT DiagonalPreconditioner final : public Preconditioner {
 public:
  explicit DiagonalPreconditioner(std::vector<double> diagonal);
  [[nodiscard]] std::uint64_t dimension() const noexcept override {
    return static_cast<std::uint64_t>(diagonal_.size());
  }
  [[nodiscard]] const Status& validation_status() const noexcept {
    return validation_status_;
  }
  Status apply(ConstMatrixView input, MatrixView output,
               Workspace& workspace) const override;

 private:
  std::vector<double> diagonal_;
  Status validation_status_{};
};

struct TwoLevelPreconditionerOptions {
  // A candidate basis direction is retained only when its twice-
  // reorthogonalized norm exceeds this fraction of its input norm.
  double rank_tolerance{64.0 * std::numeric_limits<double>::epsilon()};
};

struct TwoLevelPreconditionerDiagnostics {
  Status coarse_factorization_status{};
  std::uint64_t input_basis_width{0};
  std::uint64_t retained_rank{0};
  std::vector<std::uint64_t> retained_basis_columns{};
  std::vector<std::uint64_t> dropped_basis_columns{};
  double rank_tolerance{0.0};
  double maximum_absolute_rank_threshold{0.0};
  std::uint64_t setup_count{0};
  std::uint64_t setup_operator_applications{0};
  std::uint64_t setup_operator_processed_columns{0};
  std::uint64_t applications{0};
  std::uint64_t processed_columns{0};
  std::uint64_t base_preconditioner_applications{0};
  std::uint64_t base_preconditioner_processed_columns{0};
  std::uint64_t coarse_factor_solves{0};
};

// Balanced two-level SPD preconditioner
//   Q' M0^-1 Q + Z (Z' A Z)^-1 Z', Q = I - A Z (Z' A Z)^-1 Z'.
// The caller basis is copied, deterministically compressed in caller-column
// order, and normalized. A and the base preconditioner are retained by shared
// immutable ownership. The prepared object is bound to the exact A instance
// used during setup.
class GSOLVE_EXPORT TwoLevelPreconditioner final : public Preconditioner {
 public:
  TwoLevelPreconditioner(
      std::shared_ptr<const LinearOperator> linear_operator,
      std::shared_ptr<const Preconditioner> base_preconditioner,
      ConstMatrixView coarse_basis,
      TwoLevelPreconditionerOptions options = {});

  // Reuse a previously compressed basis with caller-computed A*Z for the
  // current operator. Products must correspond exactly to source.coarse_basis().
  // They are copied and checked for finite, symmetric positive coarse action;
  // the caller owns their algebraic provenance. No current-operator apply occurs.
  TwoLevelPreconditioner(
      std::shared_ptr<const LinearOperator> linear_operator,
      std::shared_ptr<const Preconditioner> base_preconditioner,
      const TwoLevelPreconditioner& source, ConstMatrixView operator_basis);
  [[nodiscard]] ConstMatrixView coarse_basis() const noexcept {
    return {basis_.data(), dimension_, coarse_rank_, dimension_};
  }
  [[nodiscard]] std::uint64_t dimension() const noexcept override {
    return dimension_;
  }
  [[nodiscard]] const Status& validation_status() const noexcept {
    return validation_status_;
  }
  [[nodiscard]] std::uint64_t coarse_rank() const noexcept {
    return coarse_rank_;
  }
  [[nodiscard]] const std::shared_ptr<const LinearOperator>& linear_operator()
      const noexcept {
    return linear_operator_;
  }
  [[nodiscard]] const std::shared_ptr<const Preconditioner>&
  base_preconditioner() const noexcept {
    return base_preconditioner_;
  }
  [[nodiscard]] bool concurrent_apply_supported() const noexcept override;
  [[nodiscard]] bool compatible_with(
      const LinearOperator& linear_operator) const noexcept override;
  [[nodiscard]] TwoLevelPreconditionerDiagnostics diagnostics() const;
  Status prepare_workspace(std::uint64_t right_hand_side_count,
                           Workspace& workspace) const override;
  Status apply(ConstMatrixView input, MatrixView output,
               Workspace& workspace) const override;

 private:
  TwoLevelPreconditioner(
      std::shared_ptr<const LinearOperator> linear_operator,
      std::shared_ptr<const Preconditioner> base_preconditioner,
      ConstMatrixView coarse_basis, TwoLevelPreconditionerOptions options,
      const TwoLevelPreconditioner* source,
      const ConstMatrixView* operator_basis);
  Status solve_coarse_in_place(double* values,
                               std::uint64_t columns) const noexcept;

  std::shared_ptr<const LinearOperator> linear_operator_{};
  std::shared_ptr<const Preconditioner> base_preconditioner_{};
  std::uint64_t dimension_{0};
  std::uint64_t coarse_rank_{0};
  std::vector<double> basis_{};
  std::vector<double> operator_basis_{};
  std::vector<double> coarse_lower_{};
  TwoLevelPreconditionerDiagnostics setup_diagnostics_{};
  mutable std::atomic<std::uint64_t> applications_{0};
  mutable std::atomic<std::uint64_t> processed_columns_{0};
  mutable std::atomic<std::uint64_t> base_applications_{0};
  mutable std::atomic<std::uint64_t> base_processed_columns_{0};
  mutable std::atomic<std::uint64_t> coarse_solves_{0};
  Status validation_status_{};
};

}  // namespace gsolve

#endif
