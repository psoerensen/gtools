#ifndef GSOLVE_DENSE_SPD_FACTORIZATION_HPP
#define GSOLVE_DENSE_SPD_FACTORIZATION_HPP

#include <cstdint>
#include <vector>

#include "gsolve/export.h"
#include "gsolve/matrix_view.hpp"

namespace gsolve {

// Symmetry is accepted when |a_ij - a_ji| is at most this multiplier times
// machine epsilon times max(|a_ij|, |a_ji|, sqrt(|a_ii a_jj|)). This scales
// with the corresponding matrix entries and rejects material asymmetry.
inline constexpr double dense_symmetry_tolerance_multiplier = 64.0;

// Owning exact/reference Cholesky factorization for a small dense SPD matrix.
// A successfully constructed object has no mutating operations and supports
// concurrent solves when each call has an independent output buffer.
class GSOLVE_EXPORT DenseSpdFactorization {
 public:
  explicit DenseSpdFactorization(ConstMatrixView matrix);

  [[nodiscard]] const Status& status() const noexcept { return status_; }
  [[nodiscard]] std::uint64_t dimension() const noexcept { return dimension_; }
  [[nodiscard]] double log_determinant() const noexcept {
    return log_determinant_;
  }

  // Solves one or more RHS columns. Logical output is overwritten only after
  // the complete solve succeeds; output padding is never touched.
  [[nodiscard]] Status solve(ConstMatrixView right_hand_side,
                             MatrixView solution) const;

 private:
  std::uint64_t dimension_{0};
  std::vector<double> lower_{};
  double log_determinant_{0.0};
  Status status_{};
};

}  // namespace gsolve

#endif
