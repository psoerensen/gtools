#pragma once
#include <gsolve/export.h>

#include <atomic>
#include <gsolve/matrix_view.hpp>
#include <memory>
#include <vector>
namespace gsolve {
// Immutable numeric design; implementations may decode packed or streamed
// columns. read_columns overwrites a column-major output. Calls are serial
// within a solve.
class GSOLVE_EXPORT RidgeDesignSource {
 public:
  virtual ~RidgeDesignSource() = default;
  virtual std::uint64_t rows() const noexcept = 0;
  virtual std::uint64_t columns() const noexcept = 0;
  virtual Status read_columns(std::uint64_t begin, MatrixView output) const = 0;
};
// Optional source capability: products using strictly increasing source columns.
// Applies the same numeric columns as read_columns; projection is caller-owned.
// Input/output must not alias. Overwrites logical output, preserves padding and
// leaves output unchanged on failure. No retained caller buffers/global threads.
class GSOLVE_EXPORT RidgeDesignProducts {
 public:
  virtual ~RidgeDesignProducts() = default;
  virtual Status multiply_columns(const std::vector<std::uint64_t>& columns,
      bool transpose, ConstMatrixView input, MatrixView output,
      std::uint32_t threads) const = 0;
};
struct ChunkRidgeOptions {
  // Collect ||(I-QQ')X||_F^2 during preparation, including uncached chunks.
  bool collect_projected_design_norm{false};
  std::uint64_t chunk_size{128};
  std::uint64_t gram_cache_limit_bytes{64ULL * 1024 * 1024};
  // Conservative numeric allocation budget for plan + a solve; excludes source,
  // caller inputs/previous results, allocator bookkeeping and BLAS runtime
  // pools.
  std::uint64_t numeric_memory_limit_bytes{512ULL * 1024 * 1024};
  std::uint64_t maximum_sweeps{100};
  // Coordinate fallback sweep limit. Shared-penalty multi-response cached
  // blocks may use an exact Cholesky correction when this is greater than one.
  std::uint64_t local_iterations{5};
  // Sweep interval for checking whether coefficient changes warrant a full
  // audit. A full audit is forced after eight such checks and at the last
  // sweep. Only freshly reconstructed whole-system residuals can accept a
  // solution.
  std::uint64_t audit_interval{2};
  double relative_tolerance{1e-7};
  double absolute_tolerance{1e-10};
  std::uint32_t threads{
      1};  // MKL local scope or portable OpenMP tiles; no nested teams.
  const std::atomic<bool>* cancel{
      nullptr};  // must outlive the plan; checked between chunks/sweeps
};
struct ChunkRidgeDiagnostics {
  double projected_design_squared_norm{0};
  std::uint64_t sweeps{0}, block_reads{0}, marker_columns_read{0};
  std::uint64_t matrix_products{0}, gram_builds{0}, local_sweeps{0},
      full_audits{0};
  std::uint64_t gram_cache_bytes{0}, planned_numeric_bytes{0};
  std::uint32_t resolved_threads{1};
  bool mkl{false}, warm_start_used{false};
  double read_seconds{0}, product_seconds{0}, coordinate_seconds{0},
      solve_seconds{0};
  std::vector<double> normal_residuals{}, thresholds{};
};
struct ChunkRidgeResult {
  Status status{};
  std::vector<double> coefficients{};   // m by rhs
  std::vector<double> fixed_effects{};  // p by rhs, original fixed design order
  std::vector<double> residual{};       // n by rhs
  ChunkRidgeDiagnostics diagnostics{};
};
struct ChunkRidgeBatchProblem {
  ConstMatrixView response{}, penalties{}, initial_coefficients{};
  // Strictly increasing source-column indices. Empty selects every column.
  // Penalties are source-m by one; excluded coefficients are fixed at zero.
  std::vector<std::uint64_t> active_columns{};
};
struct ChunkRidgeBatchResult {
  Status status{};
  std::vector<ChunkRidgeResult> results{};
  // Physical shared work; per-result diagnostics contain acceptance details.
  ChunkRidgeDiagnostics diagnostics{};
};
// Minimize ||Y-C A-X B||^2/2 + sum_j,r penalty(j,r)*B(j,r)^2/2.
// No implicit intercept. Positive penalties: m-by-1 shared or m-by-rhs.
// Same rows/design for all responses, but each response may have its own
// penalty. The plan retains fixed-effect QR and a bounded prefix of chunk
// Grams. Nonconvergence returns provisional outputs with maximum_iterations.
// Other failures clear outputs. The source must remain immutable and match row
// order. Source concurrency is caller-defined; the solver creates no outer
// worker team.
class GSOLVE_EXPORT ChunkRidgePlan final {
 public:
  static std::shared_ptr<const ChunkRidgePlan> create(
      std::shared_ptr<const RidgeDesignSource> source, ConstMatrixView fixed,
      const ChunkRidgeOptions& options, Status& status) noexcept;
  ~ChunkRidgePlan();
  ChunkRidgeResult solve(
      ConstMatrixView response, ConstMatrixView penalties,
      ConstMatrixView initial_coefficients = {}) const noexcept;
  // Shares chunk decoding, projection, Grams and matrix products across
  // independently penalized/selected response groups. Accepted groups retire.
  // Coefficients retain source-m rows, with zero rows for excluded columns.
  ChunkRidgeBatchResult solve_batch(
      const std::vector<ChunkRidgeBatchProblem>& problems) const noexcept;
  const ChunkRidgeDiagnostics& preparation_diagnostics() const noexcept;

 private:
  struct Impl;
  explicit ChunkRidgePlan(std::unique_ptr<Impl>);
  std::unique_ptr<Impl> impl_;
};
}  // namespace gsolve
