#ifndef GSOLVE_SOLVE_PLAN_HPP
#define GSOLVE_SOLVE_PLAN_HPP

#include <cstdint>
#include <memory>

#include "gsolve/pcg.hpp"

namespace gsolve {

class SolvePlan;

// Caller-owned mutable storage for a SolvePlan. A workspace may be reused by
// sequential calls; concurrent calls require independent workspaces.
class GSOLVE_EXPORT SolvePlanWorkspace {
 public:
  [[nodiscard]] std::uint64_t dimension() const noexcept { return dimension_; }
  [[nodiscard]] std::uint64_t right_hand_side_capacity() const noexcept {
    return right_hand_side_capacity_;
  }

 private:
  friend class SolvePlan;
  std::uint64_t dimension_{0};
  std::uint64_t right_hand_side_capacity_{0};
  MultipleRhsPcgWorkspace multiple_{};
};

// Immutable orchestration for repeated operator-based PCG solves. This class
// adds ownership and workspace coordination only; it does not change PCG's
// convergence rules or select between numerical algorithms.
class GSOLVE_EXPORT SolvePlan {
 public:
  SolvePlan(std::shared_ptr<const LinearOperator> linear_operator,
            std::shared_ptr<const Preconditioner> preconditioner,
            PcgOptions options = {}, ExecutionConfig execution = {},
            MultipleRhsKrylovStrategy multiple_rhs_strategy =
                MultipleRhsKrylovStrategy::independent,
            BlockPcgOptions block_options = {});

  [[nodiscard]] const Status& status() const noexcept { return status_; }
  [[nodiscard]] std::uint64_t dimension() const noexcept { return dimension_; }
  [[nodiscard]] const PcgOptions& options() const noexcept { return options_; }
  [[nodiscard]] const ExecutionConfig& requested_execution() const noexcept {
    return execution_;
  }
  [[nodiscard]] const ExecutionResolution& resolved_execution() const noexcept {
    return execution_resolution_;
  }
  [[nodiscard]] MultipleRhsKrylovStrategy multiple_rhs_strategy() const
      noexcept { return multiple_rhs_strategy_; }
  [[nodiscard]] const BlockPcgOptions& block_options() const noexcept {
    return block_options_;
  }
  [[nodiscard]] bool concurrent_solve_supported() const noexcept {
    return concurrent_solve_supported_;
  }
  [[nodiscard]] const std::shared_ptr<const LinearOperator>& linear_operator()
      const noexcept {
    return linear_operator_;
  }
  [[nodiscard]] const std::shared_ptr<const Preconditioner>& preconditioner()
      const noexcept {
    return preconditioner_;
  }

  [[nodiscard]] Status prepare_workspace(
      std::uint64_t right_hand_side_count,
      SolvePlanWorkspace& workspace) const;

  [[nodiscard]] PcgResult solve(
      ConstMatrixView right_hand_side, MatrixView solution,
      SolvePlanWorkspace& workspace,
      const ConstMatrixView* initial_guess = nullptr) const;

  [[nodiscard]] PcgBatchResult solve_multiple(
      ConstMatrixView right_hand_sides, MatrixView solutions,
      SolvePlanWorkspace& workspace,
      const ConstMatrixView* initial_guesses = nullptr) const;

 private:
  std::shared_ptr<const LinearOperator> linear_operator_{};
  std::shared_ptr<const Preconditioner> preconditioner_{};
  PcgOptions options_{};
  ExecutionConfig execution_{};
  ExecutionResolution execution_resolution_{};
  MultipleRhsKrylovStrategy multiple_rhs_strategy_{
      MultipleRhsKrylovStrategy::independent};
  BlockPcgOptions block_options_{};
  std::uint64_t dimension_{0};
  bool concurrent_solve_supported_{false};
  Status status_{};
};

}  // namespace gsolve

#endif
