#ifndef GSOLVE_STREAMING_RECTANGULAR_HPP
#define GSOLVE_STREAMING_RECTANGULAR_HPP
#include "gsolve/rectangular_operator.hpp"
namespace gsolve {
// Immutable row-block source. read_rows fills consecutive full-width rows in
// column-major caller storage. Storage, decoding and I/O belong to the source.
class GSOLVE_EXPORT RowBlockMatrixSource {
 public:
  virtual ~RowBlockMatrixSource()=default;
  virtual std::uint64_t rows()const noexcept=0;
  virtual std::uint64_t columns()const noexcept=0;
  virtual bool concurrent_read_supported()const noexcept{return false;}
  virtual Status read_rows(std::uint64_t first_row,MatrixView output)const=0;
};
struct StreamingRectangularOptions {
  std::uint64_t block_rows{1024};
  std::uint64_t maximum_block_bytes{256ULL*1024*1024};
  std::uint32_t product_threads{1};
};
// Fixed-size row tiles plus input/output vectors. Never retains the complete
// source matrix. Child failures preserve all caller output and padding.
class GSOLVE_EXPORT StreamingRectangularOperator final:public RectangularOperator {
 public:
  StreamingRectangularOperator(std::shared_ptr<const RowBlockMatrixSource>,StreamingRectangularOptions={});
  std::uint64_t row_count()const noexcept override;
  std::uint64_t column_count()const noexcept override;
  const Status& status()const noexcept override{return status_;}
  bool concurrent_apply_supported()const noexcept override;
  Status prepare_workspace(std::uint64_t,Workspace&)const override;
  Status apply(ConstMatrixView,MatrixView,Workspace&)const override;
  Status apply_transpose(ConstMatrixView,MatrixView,Workspace&)const override;
  Status materialize_columns(std::uint64_t,std::uint64_t,MatrixView,Workspace&)const override;
 private:
  Status product(bool,ConstMatrixView,MatrixView,Workspace&)const;
  std::shared_ptr<const RowBlockMatrixSource> source_;
  StreamingRectangularOptions control_;std::uint64_t tile_rows_{0};Status status_{};
};
}
#endif
