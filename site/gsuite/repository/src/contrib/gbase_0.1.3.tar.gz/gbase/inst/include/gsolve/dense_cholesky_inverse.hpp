#ifndef GSOLVE_DENSE_CHOLESKY_INVERSE_HPP
#define GSOLVE_DENSE_CHOLESKY_INVERSE_HPP
#include "gsolve/linear_operator.hpp"
namespace gsolve {
struct DenseCholeskyOptions {
  std::uint32_t threads{1};
  // Conservative allowance for factor plus fallback setup scratch.
  std::uint64_t maximum_factor_bytes{512ULL * 1024 * 1024};
};
// Immutable SPD inverse operator. Blocked LAPACK/BLAS with MKL when available;
// portable serial Eigen fallback. Owns O(k^2) factor, never an explicit
// inverse.
class GSOLVE_EXPORT DenseCholeskyInverse final : public LinearOperator {
public:
  DenseCholeskyInverse(ConstMatrixView, DenseCholeskyOptions = {});
  const Status &validation_status() const noexcept { return status_; }
  bool uses_mkl() const noexcept { return mkl_; }
  std::uint64_t rows() const noexcept override { return n_; }
  std::uint64_t columns() const noexcept override { return n_; }
  Symmetry symmetry() const noexcept override { return Symmetry::symmetric; }
  Definiteness definiteness() const noexcept override {
    return status_ ? Definiteness::positive_definite : Definiteness::unknown;
  }
  Status apply(ConstMatrixView, MatrixView, Workspace &) const override;

private:
  std::uint64_t n_{0};
  std::vector<double> lower_;
  DenseCholeskyOptions options_;
  bool mkl_{false};
  Status status_{};
};
} // namespace gsolve
#endif
