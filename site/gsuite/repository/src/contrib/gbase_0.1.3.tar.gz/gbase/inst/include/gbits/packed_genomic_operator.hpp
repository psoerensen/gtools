#pragma once
#include <gbits/gsolve_adapter.hpp>
#include <atomic>
namespace gbits {
// Selected Z Z'/normalization over shared packed storage. Excluded columns are
// absent from the design: products never traverse them. Scratch is caller-owned.
class GBITS_GSOLVE_ADAPTER_API PackedGenomicOperator final : public gsolve::LinearOperator {
public:
    PackedGenomicOperator(std::shared_ptr<const PackedMatrix> packed,
        std::shared_ptr<const PackedSelection> selection,
        std::shared_ptr<const PackedTransform> transform, double normalization,
        const ExecutionConfig& execution = {});
    std::uint64_t rows() const noexcept override;
    std::uint64_t columns() const noexcept override { return rows(); }
    gsolve::Symmetry symmetry() const noexcept override { return gsolve::Symmetry::symmetric; }
    gsolve::Definiteness definiteness() const noexcept override { return gsolve::Definiteness::positive_semidefinite; }
    bool concurrent_apply_supported() const noexcept override;
    bool has_exact_diagonal() const noexcept override { return true; }
    gsolve::Status exact_diagonal(gsolve::MatrixView, gsolve::Workspace&) const override;
    gsolve::Status apply(gsolve::ConstMatrixView, gsolve::MatrixView, gsolve::Workspace&) const override;
    const std::vector<double>& diagonal() const noexcept { return diagonal_; }
    std::uint64_t marker_count() const noexcept;
    std::uint64_t applications() const noexcept { return applications_.load(); }
    std::uint64_t processed_columns() const noexcept { return processed_columns_.load(); }
private:
    std::shared_ptr<const PackedMatrixDesignOperator> design_;
    std::vector<double> diagonal_;
    double normalization_;
    mutable std::atomic<std::uint64_t> applications_{0}, processed_columns_{0};
};
}
