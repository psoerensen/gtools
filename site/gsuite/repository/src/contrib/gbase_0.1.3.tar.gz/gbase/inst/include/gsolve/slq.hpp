#ifndef GSOLVE_SLQ_HPP
#define GSOLVE_SLQ_HPP

#include <cstdint>
#include <limits>
#include <vector>

#include "gsolve/execution.hpp"
#include "gsolve/linear_operator.hpp"
#include "gsolve/probes.hpp"

namespace gsolve {

struct SlqOptions {
  std::uint64_t lanczos_steps{20};
  std::uint64_t probe_batch_size{8};
  double breakdown_tolerance{1.0e-14};
  bool retain_per_probe_estimates{false};
};

struct SlqProbeDiagnostic {
  Status status{};
  double estimate{std::numeric_limits<double>::quiet_NaN()};
  std::uint64_t completed_steps{0};
  std::uint64_t operator_applications{0};
  bool terminated_by_breakdown{false};
};

struct SlqResult {
  Status status{};
  double log_determinant{std::numeric_limits<double>::quiet_NaN()};
  double standard_error{std::numeric_limits<double>::quiet_NaN()};
  std::uint64_t probe_count{0};
  std::uint64_t lanczos_steps{0};
  std::uint64_t operator_applications{0};
  std::uint64_t first_failed_probe{std::numeric_limits<std::uint64_t>::max()};
  std::uint32_t requested_threads{1};
  std::uint32_t resolved_threads{1};
  std::vector<double> per_probe_estimates{};
  std::vector<SlqProbeDiagnostic> probe_diagnostics{};
};

class GSOLVE_EXPORT SlqWorkspace {
 public:
  Status prepare(std::uint64_t dimension, std::uint64_t lanczos_steps,
                 std::uint32_t worker_count);

 private:
  struct Worker {
    std::vector<double> previous{};
    std::vector<double> current{};
    std::vector<double> product{};
    std::vector<double> alpha{};
    std::vector<double> beta{};
    std::vector<double> tridiagonal{};
    std::vector<double> eigenvectors{};
    Workspace operator_workspace{};
  };
  friend SlqResult estimate_log_determinant_slq(
      const LinearOperator&, const RademacherProbePlan&, const SlqOptions&,
      const ExecutionConfig&, SlqWorkspace&, const ConstMatrixView*);
  std::uint64_t dimension_{0};
  std::uint64_t lanczos_steps_{0};
  std::vector<Worker> workers_{};
};

// Uses the unreorthogonalized three-term symmetric Lanczos recurrence. An
// invariant-subspace breakdown is a successful early termination; nonpositive
// Ritz values and operator failures are reported. Optional explicit probes are
// intended for small deterministic validation and must match the probe plan.
GSOLVE_EXPORT SlqResult estimate_log_determinant_slq(
    const LinearOperator& linear_operator,
    const RademacherProbePlan& probe_plan, const SlqOptions& options,
    const ExecutionConfig& execution, SlqWorkspace& workspace,
    const ConstMatrixView* explicit_probes = nullptr);

}  // namespace gsolve

#endif
