#ifndef GREML_OPTIMIZER_HPP
#define GREML_OPTIMIZER_HPP

#include <cstdint>
#include <limits>
#include <vector>

#include "greml/export.h"

namespace greml {

// The legacy strategy preserves the pre-0.25 AI/damping/backtracking path.
// The safeguarded strategy adds scale-aware KKT handling, trust scaling, and
// a projected-gradient fallback without changing the evaluated model.
enum class OptimizationStrategy { legacy_ai = 0, safeguarded };

// The established default compares common-precision likelihoods at every
// trial.  The experimental policy instead accepts score/AI states and defers
// all likelihood/determinant work until convergence has been independently
// verified.
enum class MatrixFreeAcceptancePolicy {
  likelihood_monotone = 0,
  determinant_deferred
};

enum class OptimizationStepType {
  initial = 0,
  undamped_ai,
  damped_ai,
  projected_gradient,
  em_fallback
};

enum class OptimizationConvergenceReason {
  none = 0,
  converged_interior,
  converged_boundary,
  maximum_iterations,
  insufficient_stochastic_precision,
  insufficient_linear_solve_precision,
  ai_system_unusable,
  no_valid_ascent_direction,
  line_search_exhaustion,
  restart_exhaustion,
  active_set_cycling,
  covariance_or_preconditioner_failure,
  structurally_nonidentifiable,
  numerical_failure,
  score_stationary,
  stationary_within_stochastic_precision,
  stationary_within_step_resolution,
  likelihood_finalization_failure
};

struct SafeguardedOptimizerOptions {
  OptimizationStrategy strategy{OptimizationStrategy::legacy_ai};
  double kkt_relative_tolerance{1.0e-10};
  double maximum_scaled_step{2.0};
  double diagonal_scale_floor{1.0e-8};
  double initial_damping{1.0e-8};
  double damping_growth_factor{10.0};
  std::uint64_t maximum_damping_attempts{8};
  std::uint64_t maximum_restarts{2};
  std::uint64_t ai_rejections_before_fallback{1};
  double restart_step_contraction{0.5};
  double armijo_coefficient{1.0e-4};
  double relative_likelihood_tolerance{1.0e-10};
  bool use_armijo_for_exact_likelihood{true};
};

struct SafeguardedIterationDiagnostics {
  OptimizationStepType step_type{OptimizationStepType::initial};
  OptimizationConvergenceReason convergence_reason{
      OptimizationConvergenceReason::none};
  double raw_score_norm{std::numeric_limits<double>::quiet_NaN()};
  double projected_score_norm{std::numeric_limits<double>::quiet_NaN()};
  double curvature_scaled_score_norm{
      std::numeric_limits<double>::quiet_NaN()};
  double newton_decrement{std::numeric_limits<double>::quiet_NaN()};
  double score_merit{std::numeric_limits<double>::quiet_NaN()};
  double scaled_step_norm{0.0};
  double likelihood_change{std::numeric_limits<double>::quiet_NaN()};
  double damping{0.0};
  double trust_radius{0.0};
  double directional_derivative{0.0};
  std::uint64_t damping_attempts{0};
  std::uint64_t backtracking_reductions{0};
  std::uint64_t restart_count{0};
  std::vector<std::uint64_t> active_components{};
  std::vector<std::uint64_t> released_components{};
};

struct UnifiedOptimizerDiagnostics {
  OptimizationStrategy requested_strategy{OptimizationStrategy::legacy_ai};
  OptimizationStrategy resolved_strategy{OptimizationStrategy::legacy_ai};
  OptimizationConvergenceReason final_reason{
      OptimizationConvergenceReason::none};
  bool boundary_convergence{false};
  bool kkt_satisfied{false};
  bool active_set_stabilized{true};
  bool unresolved_common_precision_comparison{false};
  bool determinant_deferred{false};
  bool optimizer_converged{false};
  bool stochastic_precision_adequate{false};
  bool provisional_convergence_verified{false};
  bool independent_probe_verification_performed{false};
  bool independent_probe_verification_bypassed{false};
  double final_raw_score_norm{std::numeric_limits<double>::quiet_NaN()};
  double final_projected_score_norm{std::numeric_limits<double>::quiet_NaN()};
  double final_curvature_scaled_score_norm{
      std::numeric_limits<double>::quiet_NaN()};
  double final_newton_decrement{std::numeric_limits<double>::quiet_NaN()};
  double final_relative_parameter_change{
      std::numeric_limits<double>::quiet_NaN()};
  double final_last_accepted_relative_change{
      std::numeric_limits<double>::quiet_NaN()};
  double final_proposed_relative_change{
      std::numeric_limits<double>::quiet_NaN()};
  std::uint64_t iterative_likelihood_evaluations{0};
  std::uint64_t final_likelihood_evaluations{0};
  std::vector<double> final_projected_score{};
  std::vector<std::uint64_t> final_active_components{};
  std::vector<std::uint64_t> final_free_components{};
  std::vector<std::uint64_t> released_components{};
  std::uint64_t total_evaluations{0};
  std::uint64_t accepted_candidate_count{0};
  std::uint64_t full_step_acceptance_count{0};
  std::uint64_t reduced_step_acceptance_count{0};
  std::uint64_t rejected_candidate_count{0};
  std::uint64_t undamped_ai_step_count{0};
  std::uint64_t damped_ai_step_count{0};
  std::uint64_t projected_gradient_step_count{0};
  std::uint64_t em_fallback_step_count{0};
  std::uint64_t active_set_change_count{0};
  std::uint64_t restart_count{0};
  std::uint64_t preconditioner_rebuild_count{0};
  std::uint64_t operator_applications{0};
  std::uint64_t preconditioner_applications{0};
  std::uint64_t operator_processed_columns{0};
  std::uint64_t preconditioner_processed_columns{0};
};

GREML_EXPORT bool valid_safeguarded_optimizer_options(
    const SafeguardedOptimizerOptions& options) noexcept;

}  // namespace greml

#endif
