#ifndef GMAT_C_API_H
#define GMAT_C_API_H

#include <gmat/export.h>

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum gmat_status {
  GMAT_STATUS_SUCCESS = 0,
  GMAT_STATUS_INVALID_ARGUMENT = 1,
  GMAT_STATUS_IO_ERROR = 2,
  GMAT_STATUS_INTERNAL_ERROR = 3
} gmat_status;

typedef struct gmat_variant_metadata_handle gmat_variant_metadata_handle;
typedef struct gmat_sample_metadata_handle gmat_sample_metadata_handle;
typedef struct gmat_phased_vcf_reader_handle gmat_phased_vcf_reader_handle;

typedef struct gmat_metadata_write_info {
  uint64_t record_count;
  uint64_t bytes_written;
  uint64_t maximum_record_bytes;
} gmat_metadata_write_info;

GMAT_EXPORT uint32_t gmat_abi_version(void);
GMAT_EXPORT const char* gmat_library_version(void);
GMAT_EXPORT const char* gmat_last_error(void);

GMAT_EXPORT gmat_status gmat_variant_metadata_create(
    const char* const* chromosome,
    const char* const* variant_id,
    const double* genetic_position_cm,
    const uint64_t* base_pair_position,
    const char* const* alternate_allele,
    const char* const* reference_allele,
    uint64_t count,
    gmat_variant_metadata_handle** output_handle);
GMAT_EXPORT gmat_status gmat_variant_metadata_read_bim(
    const char* source_utf8,
    gmat_variant_metadata_handle** output_handle);
GMAT_EXPORT gmat_status gmat_variant_metadata_count(
    const gmat_variant_metadata_handle* handle, uint64_t* output_count);
GMAT_EXPORT gmat_status gmat_variant_metadata_get(
    const gmat_variant_metadata_handle* handle, uint64_t index,
    const char** chromosome, const char** variant_id,
    double* genetic_position_cm, uint64_t* base_pair_position,
    const char** alternate_allele, const char** reference_allele);
GMAT_EXPORT gmat_status gmat_variant_metadata_close(
    gmat_variant_metadata_handle* handle);
GMAT_EXPORT gmat_status gmat_variant_metadata_write_bim(
    const gmat_variant_metadata_handle* handle,
    const char* destination_utf8,
    uint32_t overwrite,
    gmat_metadata_write_info* output_info);

GMAT_EXPORT gmat_status gmat_sample_metadata_create(
    const char* const* family_id,
    const char* const* individual_id,
    const char* const* paternal_id,
    const char* const* maternal_id,
    const uint32_t* sex,
    uint64_t count,
    gmat_sample_metadata_handle** output_handle);
GMAT_EXPORT gmat_status gmat_sample_metadata_read_fam(
    const char* source_utf8,
    gmat_sample_metadata_handle** output_handle);
GMAT_EXPORT gmat_status gmat_sample_metadata_count(
    const gmat_sample_metadata_handle* handle, uint64_t* output_count);
GMAT_EXPORT gmat_status gmat_sample_metadata_get(
    const gmat_sample_metadata_handle* handle, uint64_t index,
    const char** family_id, const char** individual_id,
    const char** paternal_id, const char** maternal_id, uint32_t* sex);
GMAT_EXPORT gmat_status gmat_sample_metadata_close(
    gmat_sample_metadata_handle* handle);
GMAT_EXPORT gmat_status gmat_sample_metadata_write_fam(
    const gmat_sample_metadata_handle* handle,
    const char* destination_utf8,
    uint32_t overwrite,
    gmat_metadata_write_info* output_info);

GMAT_EXPORT gmat_status gmat_phased_vcf_reader_open(
    const char* source_utf8, gmat_phased_vcf_reader_handle** output_handle);
GMAT_EXPORT gmat_status gmat_phased_vcf_reader_close(
    gmat_phased_vcf_reader_handle* handle);
GMAT_EXPORT gmat_status gmat_phased_vcf_reader_dimensions(
    const gmat_phased_vcf_reader_handle* handle, uint64_t* sample_count,
    uint64_t* variant_count, uint64_t* chromosome_count);
GMAT_EXPORT gmat_status gmat_phased_vcf_reader_sample(
    const gmat_phased_vcf_reader_handle* handle, uint64_t index,
    const char** sample_id);
GMAT_EXPORT gmat_status gmat_phased_vcf_reader_variant(
    const gmat_phased_vcf_reader_handle* handle, uint64_t index,
    const char** chromosome, const char** variant_id,
    uint64_t* base_pair_position, const char** reference_allele,
    const char** alternate_allele, uint32_t* generated_id);
GMAT_EXPORT gmat_status gmat_phased_vcf_reader_chromosome(
    const gmat_phased_vcf_reader_handle* handle, uint64_t index,
    const char** chromosome, uint64_t* first_variant,
    uint64_t* variant_count);
GMAT_EXPORT gmat_status gmat_phased_vcf_reader_start_chromosome(
    gmat_phased_vcf_reader_handle* handle, uint64_t chromosome_index);
GMAT_EXPORT gmat_status gmat_phased_vcf_reader_next(
    gmat_phased_vcf_reader_handle* handle, uint8_t* h1, uint8_t* h2,
    uint64_t allele_capacity, uint64_t* variant_index, uint32_t* has_record);

#ifdef __cplusplus
}
#endif

#endif
