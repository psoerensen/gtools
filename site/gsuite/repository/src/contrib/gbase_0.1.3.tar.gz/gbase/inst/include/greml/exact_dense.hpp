#ifndef GREML_EXACT_DENSE_HPP
#define GREML_EXACT_DENSE_HPP

#include <cstdint>
#include <limits>
#include <vector>

#include "greml/export.h"
#include "greml/status.hpp"
#include "gsolve/matrix_view.hpp"

namespace greml {

enum class LikelihoodMode { maximum_likelihood, restricted_maximum_likelihood };

struct ExactDenseResult {
  Status status{};
  LikelihoodMode mode{LikelihoodMode::restricted_maximum_likelihood};
  std::uint64_t observation_count{0};
  std::uint64_t fixed_effect_count{0};
  std::uint64_t component_count{0};
  double log_likelihood{std::numeric_limits<double>::quiet_NaN()};
  double log_determinant{std::numeric_limits<double>::quiet_NaN()};
  double fixed_effect_log_determinant{0.0};
  double quadratic{std::numeric_limits<double>::quiet_NaN()};
  std::vector<double> beta{};
  // Column-major fixed_effect_count x fixed_effect_count covariance of beta,
  // conditional on the supplied covariance parameters.
  std::vector<double> fixed_effect_covariance{};
  std::vector<double> py{};
  // Column-major observation_count x observation_count projection matrix.
  // Retained only by this explicitly dense reference route.
  std::vector<double> projection_matrix{};
  std::vector<double> score{};
  // Column-major component_count x component_count matrix. Corresponding
  // off-diagonal entries are reconciled and stored identically.
  std::vector<double> average_information{};
  // Empty when predictions are not requested; otherwise one length-n vector
  // per component, with prediction[c] = theta[c] * K[c] * Py.
  std::vector<std::vector<double>> component_predictions{};
};

// Evaluates V = sum_c parameters[c] * components[c]. Parameters are variances,
// not standard deviations. Inputs are column-major and are never modified.
GREML_EXPORT ExactDenseResult evaluate_exact_dense_covariance_components(
    gsolve::ConstMatrixView response, gsolve::ConstMatrixView fixed_effects,
    const std::vector<gsolve::ConstMatrixView>& components,
    const std::vector<double>& parameters, LikelihoodMode mode,
    bool compute_component_predictions = true);

// Convenience route for V = genetic_variance * kernel +
// residual_variance * I. Residual variance must be strictly positive.
GREML_EXPORT ExactDenseResult evaluate_exact_dense_single_trait(
    gsolve::ConstMatrixView response, gsolve::ConstMatrixView fixed_effects,
    gsolve::ConstMatrixView kernel, double genetic_variance,
    double residual_variance, LikelihoodMode mode,
    bool compute_component_predictions = true);

}  // namespace greml

#endif
