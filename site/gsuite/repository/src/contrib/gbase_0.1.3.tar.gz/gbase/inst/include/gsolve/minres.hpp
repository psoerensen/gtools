#ifndef GSOLVE_MINRES_HPP
#define GSOLVE_MINRES_HPP
#include "gsolve/preconditioner.hpp"
#include <atomic>
#include <limits>
namespace gsolve {
struct MinresOptions {
  double relative_tolerance{1e-8};
  double absolute_tolerance{0};
  std::uint64_t maximum_iterations{2000};
  std::uint64_t true_residual_interval{10};
  std::uint64_t maximum_workspace_bytes{std::numeric_limits<std::uint64_t>::max()};
  const std::atomic<bool>* cancellation{nullptr};
};
struct MinresResult {
  Status status{};
  std::uint64_t iterations{0}, operator_applications{0}, preconditioner_applications{0};
  std::uint64_t vector_workspace_bytes{0};
  double initial_residual_norm{0}, final_true_residual_norm{0}, convergence_threshold{0};
};
// Real symmetric systems, including indefinite systems. M must be fixed SPD.
// Convergence requires the unpreconditioned true residual. Output (including
// padding) is unchanged on failure; a consistent singular system may succeed.
// Uses a fixed number of O(n) vectors, never a retained Krylov basis or factor.
// Workspace limit covers solver vectors, excluding child operator/preconditioner
// scratch. Cancellation is checked between applications and before publication.
GSOLVE_EXPORT MinresResult solve_minres(const LinearOperator&, const Preconditioner&,
    ConstMatrixView rhs, MatrixView solution, const MinresOptions& = {},
    const ConstMatrixView* initial_guess = nullptr);
}
#endif
