#ifndef GSOLVE_VERSION_HPP
#define GSOLVE_VERSION_HPP

#include <cstdint>

#include "gsolve/export.h"

namespace gsolve {

inline constexpr std::uint32_t version_major = 0;
inline constexpr std::uint32_t version_minor = 27;
inline constexpr std::uint32_t version_patch = 0;
inline constexpr std::uint32_t experimental_abi = 4;

GSOLVE_EXPORT const char* version_string() noexcept;
GSOLVE_EXPORT std::uint32_t abi_version() noexcept;

}  // namespace gsolve

#endif
