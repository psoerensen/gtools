#ifndef GBITS_MARKER_STATISTICS_HPP
#define GBITS_MARKER_STATISTICS_HPP

#include <gbits/export.h>

#include <cstdint>

namespace gbits {

// Statistics over the logical selected samples for one logical marker. M2 is
// the unnormalised second central moment over observed raw dosages.
struct GBITS_API MarkerStatistics {
    std::uint64_t observed_count;
    std::uint64_t missing_count;
    double dosage_sum;
    double mean_dosage;
    double m2;
};

} // namespace gbits

#endif
