#ifndef GMAT_LD_SCORE_HPP
#define GMAT_LD_SCORE_HPP

#include <cstdint>
#include <string>
#include <vector>

#include "gmat/export.h"
#include "gmat/sparse_ld_csr.hpp"

namespace gmat {

// Marker-major annotation values: values[marker * annotation_count + column].
// Marker IDs and annotation names are non-empty and unique; values are finite.
class GMAT_EXPORT AnnotationMatrix final {
 public:
  AnnotationMatrix(std::vector<std::string> marker_ids,
                   std::vector<std::string> annotation_names,
                   std::vector<double> values);

  [[nodiscard]] std::uint64_t marker_count() const noexcept;
  [[nodiscard]] std::uint64_t annotation_count() const noexcept;
  [[nodiscard]] const std::vector<std::string>& marker_ids() const noexcept;
  [[nodiscard]] const std::vector<std::string>& annotation_names() const
      noexcept;
  [[nodiscard]] const std::vector<double>& values() const noexcept;
  [[nodiscard]] double value(std::uint64_t marker,
                             std::uint64_t annotation) const;

 private:
  std::vector<std::string> marker_ids_;
  std::vector<std::string> annotation_names_;
  std::vector<double> values_;
};

// A marker-major matrix of annotation-specific LD scores. Disk-backed results
// preserve sparse-LD marker-sidecar order and computation metadata.
class GMAT_EXPORT LdScoreMatrix final {
 public:
  // Import named marker-major scores without constructing LD. Correction status
  // is caller-declared; reference_sample_count=0 means unknown for imports.
  // Sparse window/threshold metadata is absent. Values are not recomputed.
  static LdScoreMatrix from_precomputed(
      std::vector<std::string> marker_ids,
      std::vector<std::string> annotation_names, std::vector<double> values,
      bool finite_sample_corrected, std::uint64_t reference_sample_count = 0);

  [[nodiscard]] std::uint64_t marker_count() const noexcept;
  [[nodiscard]] std::uint64_t annotation_count() const noexcept;
  [[nodiscard]] const std::vector<std::string>& marker_ids() const noexcept;
  [[nodiscard]] const std::vector<std::string>& annotation_names() const
      noexcept;
  [[nodiscard]] const std::vector<double>& values() const noexcept;
  [[nodiscard]] double value(std::uint64_t marker,
                             std::uint64_t annotation) const;
  [[nodiscard]] bool finite_sample_corrected() const noexcept;
  [[nodiscard]] std::uint64_t reference_sample_count() const noexcept;
  [[nodiscard]] bool has_sparse_ld_metadata() const noexcept;
  [[nodiscard]] double r2_threshold() const noexcept;
  [[nodiscard]] std::uint64_t max_distance_bp() const noexcept;
  [[nodiscard]] std::uint64_t max_distance_markers() const noexcept;

 private:
  LdScoreMatrix(std::vector<std::string> marker_ids,
                std::vector<std::string> annotation_names,
                std::vector<double> values, bool corrected,
                std::uint64_t reference_sample_count,
                bool has_sparse_ld_metadata, double r2_threshold,
                std::uint64_t max_distance_bp,
                std::uint64_t max_distance_markers);

  std::vector<std::string> marker_ids_;
  std::vector<std::string> annotation_names_;
  std::vector<double> values_;
  bool corrected_;
  std::uint64_t reference_sample_count_;
  bool has_sparse_ld_metadata_;
  double r2_threshold_;
  std::uint64_t max_distance_bp_;
  std::uint64_t max_distance_markers_;

  friend LdScoreMatrix partitioned_ld_scores(
      const SparseLdCsr&, const AnnotationMatrix&);
  friend LdScoreMatrix corrected_partitioned_ld_scores(
      const SparseLdCsr&, const AnnotationMatrix&, std::uint64_t);
  friend LdScoreMatrix partitioned_ld_scores_from_disk(
      const std::string&, const AnnotationMatrix&);
  friend LdScoreMatrix corrected_partitioned_ld_scores_from_disk(
      const std::string&, const AnnotationMatrix&);
};

// Apply r^2 - (1-r^2)/(N-2) to each retained off-diagonal pair. The implicit
// diagonal remains exactly one. N must exceed two.
GMAT_EXPORT std::vector<double> corrected_ld_scores(
    const SparseLdCsr& ld, std::uint64_t reference_sample_count);

// The annotation rows must already follow the in-memory CSR marker order.
GMAT_EXPORT LdScoreMatrix partitioned_ld_scores(
    const SparseLdCsr& ld, const AnnotationMatrix& annotations);
GMAT_EXPORT LdScoreMatrix corrected_partitioned_ld_scores(
    const SparseLdCsr& ld, const AnnotationMatrix& annotations,
    std::uint64_t reference_sample_count);

// Disk annotations are realigned by exact marker ID to marker-sidecar order.
// Corrected disk functions use the validated n_samples_used metadata value.
GMAT_EXPORT std::vector<double> corrected_sparse_ld_scores_from_disk(
    const std::string& prefix);
GMAT_EXPORT LdScoreMatrix partitioned_ld_scores_from_disk(
    const std::string& prefix, const AnnotationMatrix& annotations);
GMAT_EXPORT LdScoreMatrix corrected_partitioned_ld_scores_from_disk(
    const std::string& prefix, const AnnotationMatrix& annotations);

}  // namespace gmat

#endif
