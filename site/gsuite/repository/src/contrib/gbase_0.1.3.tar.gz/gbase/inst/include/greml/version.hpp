#ifndef GREML_VERSION_HPP
#define GREML_VERSION_HPP

#include <cstdint>

#include "greml/export.h"

namespace greml {

inline constexpr std::uint32_t version_major = 0;
inline constexpr std::uint32_t version_minor = 89;
inline constexpr std::uint32_t version_patch = 0;
inline constexpr std::uint32_t experimental_abi = 46;

GREML_EXPORT const char* version_string() noexcept;
GREML_EXPORT std::uint32_t abi_version() noexcept;
GREML_EXPORT const char* linked_gsolve_version() noexcept;
GREML_EXPORT std::uint32_t linked_gsolve_abi() noexcept;

}  // namespace greml

#endif
