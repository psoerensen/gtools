#ifndef GMAT_BED_PANEL_HPP
#define GMAT_BED_PANEL_HPP

#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "gmat/bed_matrix.hpp"
#include "gmat/export.h"

namespace gmat {

struct SampleIdentity {
  std::string family_id;
  std::string individual_id;
};

// Empty samples select every FAM row. An empty markers_by_component selects
// every BIM row in every component; an empty per-component entry selects every
// BIM row in that component.
struct BedPanelSelection {
  std::vector<SampleIdentity> samples;
  std::vector<std::vector<std::string>> markers_by_component;
};

struct PanelMarker {
  MarkerMetadata metadata;
  std::uint64_t component_index;
  std::uint64_t source_marker_index;
};

// Immutable identity and source mapping for an ordered collection of PLINK
// triplets. Components are retained by shared ownership; genotype access and
// BED decoding remain responsibilities of BedMatrix and gbits.
class GMAT_EXPORT BedPanel final {
 public:
  explicit BedPanel(
      std::vector<std::shared_ptr<const BedMatrix>> components,
      BedPanelSelection selection = {});
  ~BedPanel();

  BedPanel(const BedPanel&) = delete;
  BedPanel& operator=(const BedPanel&) = delete;
  BedPanel(BedPanel&&) = delete;
  BedPanel& operator=(BedPanel&&) = delete;

  [[nodiscard]] std::uint64_t component_count() const noexcept;
  [[nodiscard]] std::uint64_t sample_count() const noexcept;
  [[nodiscard]] std::uint64_t marker_count() const noexcept;

  [[nodiscard]] const BedMatrix& component(std::uint64_t index) const;
  [[nodiscard]] const std::vector<SampleMetadata>& samples() const noexcept;
  [[nodiscard]] const SampleMetadata& sample(std::uint64_t index) const;
  [[nodiscard]] const std::vector<std::uint64_t>& sample_source_indices()
      const noexcept;
  [[nodiscard]] std::uint64_t sample_source_index(
      std::uint64_t index) const;

  [[nodiscard]] const std::vector<PanelMarker>& markers() const noexcept;
  [[nodiscard]] const PanelMarker& marker(std::uint64_t index) const;
  [[nodiscard]] const std::vector<std::uint64_t>&
  component_marker_indices(std::uint64_t component_index) const;

 private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};

}  // namespace gmat

#endif
