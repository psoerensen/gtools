#ifndef GBITS_ERROR_HPP
#define GBITS_ERROR_HPP

#include <gbits/export.h>
#include <gbits/status.h>

#include <stdexcept>
#include <string>

namespace gbits {

class GBITS_API Error : public std::runtime_error {
public:
    Error(gbits_status status, const std::string& message)
        : std::runtime_error(message), status_(status) {}

    gbits_status status() const noexcept { return status_; }

private:
    gbits_status status_;
};

} // namespace gbits

#endif
