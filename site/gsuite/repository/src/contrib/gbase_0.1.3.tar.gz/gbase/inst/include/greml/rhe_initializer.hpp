#ifndef GREML_RHE_INITIALIZER_HPP
#define GREML_RHE_INITIALIZER_HPP

#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "greml/exact_dense_optimizer.hpp"
#include "greml/fixed_effect_design.hpp"
#include "gsolve/linear_operator.hpp"
#include "gsolve/moment_system.hpp"

namespace greml {

enum class RheStatusCode {
  success = 0,
  invalid_argument,
  rank_deficient,
  numerical_failure
};

struct RheStatus {
  RheStatusCode code{RheStatusCode::success};
  std::string message{};
  explicit operator bool() const noexcept {
    return code == RheStatusCode::success;
  }
};

struct RheOptions {
  std::uint64_t probe_count{32};
  std::uint64_t probe_batch_size{8};
  std::uint64_t seed{UINT64_C(0x6a09e667f3bcc909)};
  double strictly_positive_floor{1.0e-8};
  double relative_rank_tolerance{256.0};
};

struct RheBoundaryAdjustment {
  std::uint64_t component{0};
  double raw_value{0.0};
  double constrained_value{0.0};
  ComponentConstraint constraint{ComponentConstraint::may_be_zero};
  std::string reason{};
};

struct RheDiagnostics {
  std::uint64_t probe_count{0};
  std::uint64_t probe_batch_size{0};
  std::uint64_t seed{0};
  std::uint64_t covariance_applications{0};
  std::uint64_t covariance_processed_columns{0};
  gsolve::MomentSystemDiagnostics moment_system{};
  // Column-major component_count by component_count.
  std::vector<double> moment_matrix{};
  std::vector<double> moment_matrix_standard_error{};
  std::vector<double> parameter_standard_error{};
};

struct RheInitializationResult {
  RheStatus status{};
  std::vector<std::string> component_names{};
  std::vector<double> raw_estimates{};
  std::vector<double> constrained_start{};
  std::vector<RheBoundaryAdjustment> boundary_adjustments{};
  RheDiagnostics diagnostics{};
};

// components excludes the residual identity, which is appended last and named
// by residual_name. The fixed projection is ordinary P_F. RHE produces an
// initializer only; it evaluates no ML/REML likelihood and reports none.
GREML_EXPORT RheInitializationResult randomized_haseman_elston_initialize(
    gsolve::ConstMatrixView response,
    std::shared_ptr<const FixedEffectDesign> fixed_effects,
    const std::vector<std::shared_ptr<const gsolve::LinearOperator>>& components,
    const std::vector<std::string>& component_names,
    const std::string& residual_name,
    const std::vector<ComponentConstraint>& constraints,
    const std::vector<double>& provided_parameters,
    const RheOptions& options,
    gsolve::Workspace& workspace) noexcept;

}  // namespace greml

#endif
