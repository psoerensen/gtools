#ifndef GSOLVE_MATRIX_VIEW_HPP
#define GSOLVE_MATRIX_VIEW_HPP

#include <cstddef>
#include <cstdint>
#include <limits>

#include "gsolve/status.hpp"

namespace gsolve {
namespace detail {

inline Status validate_matrix_extent(const double* data, std::uint64_t rows,
                                     std::uint64_t columns,
                                     std::uint64_t leading_dimension) {
  if (leading_dimension < rows) {
    return {StatusCode::invalid_extent,
            "leading dimension is smaller than the logical row count"};
  }
  if (rows == 0 || columns == 0) {
    return Status::success();
  }
  if (data == nullptr) {
    return {StatusCode::invalid_argument,
            "a non-empty matrix view requires a non-null pointer"};
  }
  const auto column = columns - 1;
  if (column != 0 &&
      leading_dimension >
          (std::numeric_limits<std::uint64_t>::max() - (rows - 1)) / column) {
    return {StatusCode::invalid_extent, "matrix element offset overflows"};
  }
  const auto last = column * leading_dimension + (rows - 1);
  if (last > static_cast<std::uint64_t>(
                 std::numeric_limits<std::size_t>::max() / sizeof(double))) {
    return {StatusCode::invalid_extent, "matrix byte offset is not addressable"};
  }
  return Status::success();
}

}  // namespace detail

class ConstMatrixView {
 public:
  constexpr ConstMatrixView() noexcept = default;
  constexpr ConstMatrixView(const double* data, std::uint64_t rows,
                            std::uint64_t columns,
                            std::uint64_t leading_dimension) noexcept
      : data_(data),
        rows_(rows),
        columns_(columns),
        leading_dimension_(leading_dimension) {}

  [[nodiscard]] Status validate() const {
    return detail::validate_matrix_extent(data_, rows_, columns_,
                                          leading_dimension_);
  }
  [[nodiscard]] const double* data() const noexcept { return data_; }
  [[nodiscard]] std::uint64_t rows() const noexcept { return rows_; }
  [[nodiscard]] std::uint64_t columns() const noexcept { return columns_; }
  [[nodiscard]] std::uint64_t leading_dimension() const noexcept {
    return leading_dimension_;
  }
  [[nodiscard]] const double& operator()(std::uint64_t row,
                                         std::uint64_t column) const noexcept {
    return data_[column * leading_dimension_ + row];
  }

 private:
  const double* data_{nullptr};
  std::uint64_t rows_{0};
  std::uint64_t columns_{0};
  std::uint64_t leading_dimension_{0};
};

class MatrixView {
 public:
  constexpr MatrixView() noexcept = default;
  constexpr MatrixView(double* data, std::uint64_t rows, std::uint64_t columns,
                       std::uint64_t leading_dimension) noexcept
      : data_(data),
        rows_(rows),
        columns_(columns),
        leading_dimension_(leading_dimension) {}

  [[nodiscard]] Status validate() const {
    return detail::validate_matrix_extent(data_, rows_, columns_,
                                          leading_dimension_);
  }
  [[nodiscard]] double* data() const noexcept { return data_; }
  [[nodiscard]] std::uint64_t rows() const noexcept { return rows_; }
  [[nodiscard]] std::uint64_t columns() const noexcept { return columns_; }
  [[nodiscard]] std::uint64_t leading_dimension() const noexcept {
    return leading_dimension_;
  }
  [[nodiscard]] double& operator()(std::uint64_t row,
                                   std::uint64_t column) const noexcept {
    return data_[column * leading_dimension_ + row];
  }
  [[nodiscard]] operator ConstMatrixView() const noexcept {
    return {data_, rows_, columns_, leading_dimension_};
  }

 private:
  double* data_{nullptr};
  std::uint64_t rows_{0};
  std::uint64_t columns_{0};
  std::uint64_t leading_dimension_{0};
};

}  // namespace gsolve

#endif

