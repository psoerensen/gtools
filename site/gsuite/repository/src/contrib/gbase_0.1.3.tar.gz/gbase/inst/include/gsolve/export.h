#ifndef GSOLVE_EXPORT_H
#define GSOLVE_EXPORT_H

#if defined(GSOLVE_STATIC_DEFINE)
#  define GSOLVE_EXPORT
#elif defined(_WIN32) || defined(__CYGWIN__)
#  if defined(GSOLVE_BUILDING_LIBRARY)
#    define GSOLVE_EXPORT __declspec(dllexport)
#  else
#    define GSOLVE_EXPORT __declspec(dllimport)
#  endif
#elif defined(__GNUC__) && __GNUC__ >= 4
#  define GSOLVE_EXPORT __attribute__((visibility("default")))
#else
#  define GSOLVE_EXPORT
#endif

#endif
