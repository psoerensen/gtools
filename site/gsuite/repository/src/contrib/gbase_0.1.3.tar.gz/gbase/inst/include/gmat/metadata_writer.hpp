#ifndef GMAT_METADATA_WRITER_HPP
#define GMAT_METADATA_WRITER_HPP

#include <cstdint>
#include <string>
#include <vector>

#include "gmat/bed_matrix.hpp"
#include "gmat/export.h"

namespace gmat {

struct SimulationSampleMetadata {
  std::string family_id;
  std::string individual_id;
  std::string paternal_id;
  std::string maternal_id;
  std::uint32_t sex;
};

struct MetadataWriteResult {
  std::uint64_t record_count;
  std::uint64_t bytes_written;
  std::uint64_t maximum_record_bytes;
};

class GMAT_EXPORT ValidatedVariantMetadata final {
 public:
  explicit ValidatedVariantMetadata(std::vector<MarkerMetadata> records);
  [[nodiscard]] static ValidatedVariantMetadata read_bim(
      const std::string& path);

  [[nodiscard]] std::uint64_t size() const noexcept;
  [[nodiscard]] const std::vector<MarkerMetadata>& records() const noexcept;
  [[nodiscard]] MetadataWriteResult write_bim(const std::string& path,
                                               bool overwrite) const;

 private:
  std::vector<MarkerMetadata> records_;
};

class GMAT_EXPORT ValidatedSampleMetadata final {
 public:
  explicit ValidatedSampleMetadata(
      std::vector<SimulationSampleMetadata> records);
  [[nodiscard]] static ValidatedSampleMetadata read_fam(
      const std::string& path);

  [[nodiscard]] std::uint64_t size() const noexcept;
  [[nodiscard]] const std::vector<SimulationSampleMetadata>& records()
      const noexcept;
  [[nodiscard]] MetadataWriteResult write_fam(const std::string& path,
                                               bool overwrite) const;

 private:
  std::vector<SimulationSampleMetadata> records_;
};

}  // namespace gmat

#endif
