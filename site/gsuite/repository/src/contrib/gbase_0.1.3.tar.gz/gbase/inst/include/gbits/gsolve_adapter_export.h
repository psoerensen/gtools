#ifndef GBITS_GSOLVE_ADAPTER_EXPORT_H
#define GBITS_GSOLVE_ADAPTER_EXPORT_H

#if defined(GBITS_GSOLVE_ADAPTER_STATIC_DEFINE)
#  define GBITS_GSOLVE_ADAPTER_API
#elif defined(_WIN32) || defined(__CYGWIN__)
#  if defined(GBITS_BUILDING_GSOLVE_ADAPTER)
#    define GBITS_GSOLVE_ADAPTER_API __declspec(dllexport)
#  else
#    define GBITS_GSOLVE_ADAPTER_API __declspec(dllimport)
#  endif
#elif defined(__GNUC__) || defined(__clang__)
#  define GBITS_GSOLVE_ADAPTER_API __attribute__((visibility("default")))
#else
#  define GBITS_GSOLVE_ADAPTER_API
#endif

#endif
