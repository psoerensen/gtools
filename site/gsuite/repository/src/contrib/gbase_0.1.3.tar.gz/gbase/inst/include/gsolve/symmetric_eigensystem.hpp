#ifndef GSOLVE_SYMMETRIC_EIGENSYSTEM_HPP
#define GSOLVE_SYMMETRIC_EIGENSYSTEM_HPP

#include <cstdint>
#include <functional>
#include <limits>
#include <string>
#include <vector>

#include "gsolve/export.h"
#include "gsolve/matrix_view.hpp"

namespace gsolve {

struct SymmetricEigensystemOptions {
  std::uint64_t maximum_dimension{2048};
  // max_ij |a_ij-a_ji| / max_ij |a_ij|; zero matrices have zero error.
  double symmetry_tolerance{64.0 * std::numeric_limits<double>::epsilon()};
  // Bounds each normalized residual, reconstruction and orthogonality error.
  double verification_tolerance{1.e-10};
  // Optional cooperative cancellation before/after the backend and before
  // publication. The dense backend call itself is not interruptible.
  std::function<bool()> cancel_requested{};
};

struct SymmetricEigensystemDiagnostics {
  std::uint64_t dimension{0};
  std::string backend{};
  double input_max_abs{0.0};
  // NaN means the corresponding check was not reached.
  double relative_symmetry_error{std::numeric_limits<double>::quiet_NaN()};
  double relative_residual{std::numeric_limits<double>::quiet_NaN()};
  double relative_reconstruction_error{std::numeric_limits<double>::quiet_NaN()};
  double orthogonality_error{std::numeric_limits<double>::quiet_NaN()};
};

struct SymmetricEigensystemResult {
  Status status{};
  SymmetricEigensystemDiagnostics diagnostics{};
  // Descending eigenvalues; paired eigenvectors are columns in n-by-n storage.
  // Both vectors are empty on every failure, including cancellation.
  std::vector<double> eigenvalues{};
  std::vector<double> eigenvectors{};
};

// Ordered eigenvalues of a real symmetric matrix. Uses the same finite-input,
// extent, symmetry, scaling, cancellation and failure-atomicity contract as the
// complete eigensystem, but does not compute or return eigenvectors. Residual,
// reconstruction and orthogonality diagnostics are therefore not applicable.
GSOLVE_EXPORT SymmetricEigensystemResult compute_symmetric_spectrum(
    ConstMatrixView matrix, const SymmetricEigensystemOptions& options = {}) noexcept;

// Complete real symmetric decomposition A = U diag(lambda) U'.
// Copies logical input entries; ignores padding and never modifies the caller.
// Accepted rounding-level asymmetry is explicitly averaged. No PSD repair,
// truncation, rank selection or eigenvalue clipping is performed.
// Results own their storage. Separate calls share no mutable solver state.
GSOLVE_EXPORT SymmetricEigensystemResult compute_symmetric_eigensystem(
    ConstMatrixView matrix, const SymmetricEigensystemOptions& options = {}) noexcept;

// Validate supplied full descending eigenvalues and column-major eigenvectors
// against the matrix using the same residual/reconstruction/orthogonality checks.
// Does not invoke an eigensolver. Verification itself uses dense matrix products.
// Returns owning buffers only on success; no repair, truncation or clipping.
GSOLVE_EXPORT SymmetricEigensystemResult import_symmetric_eigensystem(
    ConstMatrixView matrix, const std::vector<double>& eigenvalues,
    const std::vector<double>& eigenvectors,
    const SymmetricEigensystemOptions& options = {}) noexcept;

}  // namespace gsolve
#endif
