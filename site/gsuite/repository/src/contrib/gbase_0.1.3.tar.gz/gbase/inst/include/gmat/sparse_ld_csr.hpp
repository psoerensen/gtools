#ifndef GMAT_SPARSE_LD_CSR_HPP
#define GMAT_SPARSE_LD_CSR_HPP

#include <cstdint>
#include <memory>
#include <vector>

#include "gmat/export.h"
#include "gmat/status.hpp"

namespace gmat {

inline constexpr float sparse_ld_correlation_tolerance = 1.0e-4F;

GMAT_EXPORT Status validate_sparse_ld_csr(
    std::uint64_t marker_count,
    const std::vector<std::uint64_t>& row_ptr,
    const std::vector<std::uint32_t>& col_idx,
    const std::vector<float>& correlations);

class GMAT_EXPORT SparseLdCsr {
 public:
  SparseLdCsr(std::uint64_t marker_count,
              std::vector<std::uint64_t> row_ptr,
              std::vector<std::uint32_t> col_idx,
              std::vector<float> correlations);

  [[nodiscard]] std::uint64_t marker_count() const noexcept {
    return marker_count_;
  }
  [[nodiscard]] std::uint64_t stored_entry_count() const noexcept {
    return static_cast<std::uint64_t>(correlations_.size());
  }
  [[nodiscard]] const std::vector<std::uint64_t>& row_ptr() const noexcept {
    return row_ptr_;
  }
  [[nodiscard]] const std::vector<std::uint32_t>& col_idx() const noexcept {
    return col_idx_;
  }
  [[nodiscard]] const std::vector<float>& correlations() const noexcept {
    return correlations_;
  }

  [[nodiscard]] std::vector<double> matvec(
      const std::vector<double>& input) const;
  [[nodiscard]] std::vector<double> ld_scores() const;

  [[nodiscard]] std::vector<double> cross_product_matvec(
      const std::vector<double>& marker_ss,
      const std::vector<double>& input) const;
  void add_cross_product_column(
      std::uint64_t marker, double scale,
      const std::vector<double>& marker_ss,
      std::vector<double>& target) const;

 private:
  friend class PreparedSparseLdCrossProducts;
  void build_reverse_index();
  std::vector<double> cross_product_matvec_prepared(
      const std::vector<double>& marker_ss, const std::vector<double>& roots,
      const std::vector<double>& input) const;
  void add_cross_product_column_prepared(
      std::uint64_t marker, double scale,
      const std::vector<double>& marker_ss, const std::vector<double>& roots,
      std::vector<double>& target) const;

  std::uint64_t marker_count_;
  std::vector<std::uint64_t> row_ptr_;
  std::vector<std::uint32_t> col_idx_;
  std::vector<float> correlations_;

  std::vector<std::uint64_t> reverse_ptr_;
  std::vector<std::uint32_t> reverse_row_idx_;
  std::vector<std::uint64_t> reverse_value_pos_;
};

// Fixed scaling for repeated sparse updates. Owns the scaling and shares the
// immutable LD resource; callers must not mutate that resource through aliases.
// Construction is O(markers). A column update is O(1 + retained neighbours),
// with no allocation or panel-wide validation. Concurrent reads are supported
// when each caller supplies its own target vector.
class GMAT_EXPORT PreparedSparseLdCrossProducts {
 public:
  PreparedSparseLdCrossProducts(std::shared_ptr<const SparseLdCsr> ld,
                               std::vector<double> marker_ss);
  [[nodiscard]] const std::vector<double>& marker_ss() const noexcept {
    return marker_ss_;
  }
  [[nodiscard]] std::vector<double> multiply(
      const std::vector<double>& input) const;
  void add_column(std::uint64_t marker, double scale,
                  std::vector<double>& target) const;

 private:
  std::shared_ptr<const SparseLdCsr> ld_;
  std::vector<double> marker_ss_;
  std::vector<double> roots_;
};

}  // namespace gmat

#endif

