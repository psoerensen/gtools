#pragma once
#include <greml/export.h>

#include <functional>
#include <greml/status.hpp>
#include <gsolve/chunk_ridge.hpp>
#include <limits>
namespace greml {

struct PredictionHeritabilityGridResult {
  double heritability{0};
  bool used_initial{true};
  std::vector<double> equations{};
};
// Approximate MC REML ratio on a supplied grid of ridge smoothers. Inputs must
// already be projected against the same fixed design. data_residuals is N by H;
// probes is N by Q; probe_residuals is N by (H*Q), grid-major. Each residual
// equals response minus its ridge prediction. Linear interpolation of an
// adjacent sign-changing equation is bounded to the supplied grid. Without a
// bracket, explicitly retain initial_h; this is not converged scalar REML.
// Throws on invalid/nonfinite inputs. Does not perform or schedule solves.
GREML_EXPORT PredictionHeritabilityGridResult prediction_heritability_grid(
    gsolve::ConstMatrixView phenotype, gsolve::ConstMatrixView data_residuals,
    gsolve::ConstMatrixView probes, gsolve::ConstMatrixView probe_residuals,
    const std::vector<double>& grid, double initial_h);
enum class AssociationRatioCode {
  converged,
  boundary,
  maximum_evaluations,
  invalid_input,
  solver_failure,
  cancelled,
  numerical_failure
};
struct AssociationRatioEvaluation;
struct AssociationRatioOptions {
  gsolve::ChunkRidgeOptions ridge{};
  double minimum_log_delta{-10}, maximum_log_delta{10};
  double equation_tolerance{1e-4}, log_delta_tolerance{0.005};
  std::uint64_t maximum_evaluations{20};
  // Synchronous observation of completed candidates; the reference is valid
  // only during the call. Exceptions fail the fit; callbacks must not mutate
  // source/inputs. Empty by default, with no numerical or stopping changes.
  std::function<void(const AssociationRatioEvaluation&)> evaluation_observer{};
};
struct AssociationRatioEvaluation {
  double log_delta{0}, equation{0}, equation_mc_standard_error{0};
  double genetic_variance{0}, residual_variance{0};
  // First entry is data; remaining entries are simulations. B=sum beta^2,
  // E=sum residual^2; common normalization factors cancel in the ratio.
  std::vector<double> coefficient_norms{}, residual_norms{},
      delete_one_equations{};
  gsolve::ChunkRidgeDiagnostics ridge{};
};
struct AssociationRatioResult {
  Status status{StatusCode::invalid_argument, "fit not performed"};
  AssociationRatioCode code{AssociationRatioCode::invalid_input};
  gsolve::Status solver_status{};
  std::uint64_t sample_count{0}, marker_count{0}, fixed_effect_count{0},
      simulation_count{0};
  double initial_log_delta{0};
  double log_delta{std::numeric_limits<double>::quiet_NaN()};
  double genetic_variance{std::numeric_limits<double>::quiet_NaN()};
  double residual_variance{std::numeric_limits<double>::quiet_NaN()};
  // Conditional MC SE of the scalar equation, NOT a statistical parameter SE.
  double equation{std::numeric_limits<double>::quiet_NaN()};
  double equation_mc_standard_error{std::numeric_limits<double>::quiet_NaN()};
  bool initial_value_clipped{false};
  std::vector<double> coefficients{}, fixed_effects{}, residual{},
      projected_response{};
  std::vector<AssociationRatioEvaluation> evaluations{};
  std::shared_ptr<const gsolve::ChunkRidgePlan> plan{};
  std::uint64_t controller_numeric_bytes{0}, planned_numeric_bytes{0};
  double plan_seconds{0}, total_seconds{0};
};
// One continuous phenotype, K = X X'/normalization, V=sg*K+se*I.
// Simulation columns are independent G~(0,K), E~(0,I) pairs supplied once;
// use the same pairs at every candidate: G+sqrt(delta)*E. Their distribution
// and alignment are caller contracts. Fixed effects are projected by the plan.
// The input source, fixed design and simulation arrays must share row order.
// Scalar convergence is conditional on supplied MC pairs; no likelihood or
// independent stochastic-precision gate is claimed. Boundary/max-evaluation
// results retain PROVISIONAL best outputs with a non-success status.
// ridge.numeric_memory_limit_bytes includes conservative controller storage,
// including simulation inputs, but excludes source, caller y/C, and runtime
// pools.
GREML_EXPORT AssociationRatioResult fit_association_variance_ratio(
    std::shared_ptr<const gsolve::RidgeDesignSource> source,
    gsolve::ConstMatrixView fixed, gsolve::ConstMatrixView phenotype,
    gsolve::ConstMatrixView genetic_simulations,
    gsolve::ConstMatrixView environmental_simulations, double normalization,
    double initial_log_delta,
    const AssociationRatioOptions& options = {}) noexcept;
struct AssociationRatioBatchInput {
  gsolve::ConstMatrixView phenotype{}, genetic_simulations{},
      environmental_simulations{};
  double normalization{1}, initial_log_delta{0};
  // Ordered source-column selection; empty means the whole source. Returned
  // coefficient arrays keep full source order, with excluded rows zero.
  std::vector<std::uint64_t> active_columns{};
  // Optional model-specific notification, before the common options observer.
  std::function<void(const AssociationRatioEvaluation&)> evaluation_observer{};
};
// Independent scalar controllers advance together through shared numerical
// solves. Only pending models enter each batch; scalar stopping is unchanged.
// Physical shared-work counters are charged to the first pending model's
// evaluation, avoiding double counting when evaluation histories are summed.
GREML_EXPORT std::vector<AssociationRatioResult>
fit_association_variance_ratio_batch(
    std::shared_ptr<const gsolve::RidgeDesignSource> source,
    gsolve::ConstMatrixView fixed,
    const std::vector<AssociationRatioBatchInput>& inputs,
    const AssociationRatioOptions& options = {}) noexcept;
}  // namespace greml
