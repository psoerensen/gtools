#ifndef GREML_EXPORT_H
#define GREML_EXPORT_H

#if defined(GREML_STATIC_DEFINE)
#  define GREML_EXPORT
#elif defined(_WIN32) || defined(__CYGWIN__)
#  if defined(GREML_BUILDING_LIBRARY)
#    define GREML_EXPORT __declspec(dllexport)
#  else
#    define GREML_EXPORT __declspec(dllimport)
#  endif
#elif defined(__GNUC__) && __GNUC__ >= 4
#  define GREML_EXPORT __attribute__((visibility("default")))
#else
#  define GREML_EXPORT
#endif

#endif
