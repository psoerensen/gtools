#ifndef GSOLVE_EXECUTION_HPP
#define GSOLVE_EXECUTION_HPP

#include <cstdint>

#include "gsolve/export.h"
#include "gsolve/status.hpp"

namespace gsolve {

struct ExecutionConfig {
  std::uint32_t requested_threads{1};
};

struct ExecutionResolution {
  Status status{};
  std::uint32_t requested_threads{1};
  std::uint32_t resolved_threads{1};
  bool openmp_enabled{false};
};

// These queries do not mutate process-global OpenMP state. Parallel operations
// use operation-local num_threads clauses and deterministic logical ordering.
GSOLVE_EXPORT bool openmp_available() noexcept;
GSOLVE_EXPORT ExecutionResolution resolve_execution(
    const ExecutionConfig& execution);

}  // namespace gsolve

#endif
