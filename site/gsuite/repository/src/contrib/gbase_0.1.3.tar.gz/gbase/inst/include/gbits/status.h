#ifndef GBITS_STATUS_H
#define GBITS_STATUS_H

#ifdef __cplusplus
extern "C" {
#endif

typedef enum gbits_status {
    GBITS_STATUS_SUCCESS = 0,
    GBITS_STATUS_INVALID_ARGUMENT = 1,
    GBITS_STATUS_IO_ERROR = 2,
    GBITS_STATUS_BED_FORMAT_ERROR = 3,
    GBITS_STATUS_OUT_OF_RANGE = 4,
    GBITS_STATUS_MISSING_DATA = 5,
    GBITS_STATUS_INTERNAL_ERROR = 6,
    GBITS_STATUS_NOT_SUPPORTED = 7
} gbits_status;

#ifdef __cplusplus
}
#endif

#endif
