#ifndef GBITS_BED_SELECTION_HPP
#define GBITS_BED_SELECTION_HPP

#include <gbits/export.h>

#include <cstdint>
#include <memory>

namespace gbits {

class BedReader;
class GenotypeTransform;
class PreparedBitMatrix;

// Immutable, owned sample/variant selection metadata. A selection is compatible
// with any BedReader having the same physical dimensions as the reader used to
// create it. It owns no reader, stream, or mutable operator scratch.
class GBITS_API BedSelection final {
public:
    // Source-independent identity axes for an already prepared matrix.
    static BedSelection full(std::uint64_t sample_count,
                             std::uint64_t variant_count);
    BedSelection(const BedSelection& other);
    BedSelection(BedSelection&& other) noexcept;
    ~BedSelection();

    BedSelection& operator=(const BedSelection&) = delete;
    BedSelection& operator=(BedSelection&&) = delete;

    std::uint64_t sample_count() const noexcept;
    std::uint64_t variant_count() const noexcept;
    bool selects_all_samples() const noexcept;
    bool selects_all_variants() const noexcept;

private:
    struct Impl;

    explicit BedSelection(std::shared_ptr<const Impl> implementation);

    std::uint64_t physical_sample_count() const noexcept;
    std::uint64_t physical_variant_count() const noexcept;
    std::uint64_t sample_index(std::uint64_t logical_index) const noexcept;
    std::uint64_t variant_index(std::uint64_t logical_index) const noexcept;
    bool has_same_identity(const BedSelection& other) const noexcept;

    std::shared_ptr<const Impl> implementation_;

    friend class BedReader;
    friend class GenotypeTransform;
    friend class PreparedBitMatrix;
};

} // namespace gbits

#endif
