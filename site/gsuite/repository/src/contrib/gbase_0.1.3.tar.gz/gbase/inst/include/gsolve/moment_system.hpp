#ifndef GSOLVE_MOMENT_SYSTEM_HPP
#define GSOLVE_MOMENT_SYSTEM_HPP

#include <cstdint>
#include <vector>

#include "gsolve/export.h"
#include "gsolve/matrix_view.hpp"

namespace gsolve {

struct MomentSystemDiagnostics {
  std::uint64_t dimension{0};
  std::uint64_t numerical_rank{0};
  double largest_eigenvalue{0.0};
  double smallest_retained_eigenvalue{0.0};
  double condition_estimate{0.0};
  double rank_threshold{0.0};
};

struct MomentSystemResult {
  Status status{};
  MomentSystemDiagnostics diagnostics{};
  std::vector<double> solution{};  // dimension by RHS, column-major
};

// Checked solution of a small symmetric positive-definite moment system.
// Rank is diagnosed from a deterministic symmetric Jacobi eigensolve. No
// ridge, pseudoinverse, column dropping, or hidden repair is performed.
GSOLVE_EXPORT MomentSystemResult solve_moment_system(
    ConstMatrixView system, ConstMatrixView right_hand_sides,
    double relative_rank_tolerance = 256.0) noexcept;

}  // namespace gsolve

#endif
