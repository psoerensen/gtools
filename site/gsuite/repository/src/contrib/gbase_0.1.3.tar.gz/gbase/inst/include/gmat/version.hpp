#ifndef GMAT_VERSION_HPP
#define GMAT_VERSION_HPP

#include <cstdint>

#include "gmat/export.h"

namespace gmat {

inline constexpr std::uint32_t version_major = 0;
inline constexpr std::uint32_t version_minor = 6;
inline constexpr std::uint32_t version_patch = 0;
inline constexpr std::uint32_t experimental_abi = 0;

GMAT_EXPORT const char* version_string() noexcept;
GMAT_EXPORT std::uint32_t abi_version() noexcept;

}  // namespace gmat

#endif
