#ifndef GBITS_MISSING_POLICY_HPP
#define GBITS_MISSING_POLICY_HPP

#include <cstdint>

namespace gbits {

enum class MissingPolicy : std::uint32_t {
    error = 0,
    zero = 1,
    mean = 2
};

} // namespace gbits

#endif
