#pragma once
#include <gbits/gsolve_adapter_export.h>

#include <gbits/marker_solver.hpp>
#include <gsolve/chunk_ridge.hpp>
namespace gbits {
// Shares packed cache ownership for decoding and products; no ridge algebra.
class GBITS_GSOLVE_ADAPTER_API PackedRidgeDesign final
    : public gsolve::RidgeDesignSource, public gsolve::RidgeDesignProducts {
 public:
  explicit PackedRidgeDesign(
      std::shared_ptr<const PackedMarkerBlockCache> cache);
  PackedRidgeDesign(std::shared_ptr<const PackedMarkerBlockCache> cache,
                    std::uint32_t decode_threads);
  std::uint64_t rows() const noexcept override;
  std::uint64_t columns() const noexcept override;
  gsolve::Status read_columns(std::uint64_t begin,
                              gsolve::MatrixView output) const override;

  gsolve::Status multiply_columns(const std::vector<std::uint64_t>& columns,
      bool transpose, gsolve::ConstMatrixView input, gsolve::MatrixView output,
      std::uint32_t threads) const override;
 private:
  std::shared_ptr<const PackedMarkerBlockCache> cache_;
  std::uint32_t decode_threads_{1};
};
}  // namespace gbits
