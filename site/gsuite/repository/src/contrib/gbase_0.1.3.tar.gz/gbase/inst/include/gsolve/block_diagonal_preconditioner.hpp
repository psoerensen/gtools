#ifndef GSOLVE_BLOCK_DIAGONAL_PRECONDITIONER_HPP
#define GSOLVE_BLOCK_DIAGONAL_PRECONDITIONER_HPP
#include "gsolve/dense_spd_factorization.hpp"
#include "gsolve/preconditioner.hpp"
namespace gsolve {
// Contiguous, disjoint blocks covering every coefficient. Matrices represent
// M, not M^-1. All blocks must be SPD even when the solved system is
// indefinite.
struct DensePreconditionerBlock {
  std::uint64_t offset{0};
  std::vector<double> matrix;
};
class GSOLVE_EXPORT BlockDiagonalPreconditioner final : public Preconditioner {
public:
  BlockDiagonalPreconditioner(std::uint64_t dimension,
                              std::vector<DensePreconditionerBlock> blocks,
                              std::uint64_t maximum_block_dimension = 64,
                              std::uint64_t maximum_factor_bytes = 512ULL *
                                                                   1024 * 1024);
  std::uint64_t dimension() const noexcept override { return dimension_; }
  const Status &validation_status() const noexcept { return status_; }
  Status apply(ConstMatrixView, MatrixView, Workspace &) const override;

private:
  std::uint64_t dimension_{0};
  std::vector<std::uint64_t> offsets_;
  std::vector<DenseSpdFactorization> factors_;
  Status status_{};
};
} // namespace gsolve
#endif
