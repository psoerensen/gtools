#ifndef GSOLVE_DIAGONAL_ESTIMATION_HPP
#define GSOLVE_DIAGONAL_ESTIMATION_HPP
#include "gsolve/linear_operator.hpp"
#include <functional>
namespace gsolve {
struct DiagonalEstimationOptions {
  std::uint64_t probe_count{32}, deflation_rank{0}, seed{20261003};
  std::uint64_t maximum_storage_bytes{512ULL * 1024 * 1024};
  double relative_rank_tolerance{1e-10};
  std::function<bool()> cancel_requested{};
};
struct DiagonalEstimationResult {
  Status status{};
  std::vector<double> diagonal, mcse;
  std::uint64_t completed_probes{0}, sketch_applications{0}, retained_rank{0};
};
// diag(BB') + mean[z .* (A-BB')z], with independent sketch/residual streams.
// B is a bounded Nystrom factor for a certified symmetric PSD operator.
// MCSE is conditional finite-probe error, not numerical-solve or model error.
// No clipping; every failure clears estimates. Rank zero is ordinary
// Hutchinson.
GSOLVE_EXPORT DiagonalEstimationResult estimate_operator_diagonal(
    const LinearOperator &, const DiagonalEstimationOptions & = {});
} // namespace gsolve
#endif
