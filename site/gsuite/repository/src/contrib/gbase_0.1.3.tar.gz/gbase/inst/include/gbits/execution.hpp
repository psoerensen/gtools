#ifndef GBITS_EXECUTION_HPP
#define GBITS_EXECUTION_HPP

#include <gbits/export.h>

#include <cstdint>

namespace gbits {

enum class KernelMode : std::uint32_t {
    // Select conservatively from dimensions, storage, selection, RHS count,
    // OpenMP capability, and the requested thread count.
    automatic = 0,
    // Always use the deterministic scalar correctness implementation.
    scalar_reference = 1,
    // Force the tiled implementation. IsaMode independently selects its
    // portable or AVX2 inner loops; OpenMP remains operation-local.
    tiled = 2
};

enum class IsaMode : std::uint32_t {
    // Select a supported ISA conservatively for the resolved operator.
    automatic = 0,
    // Use only the portable scalar inner loops.
    portable = 1,
    // Require the separately compiled AVX2 inner loops.
    avx2 = 2
};

enum class OperatorKind : std::uint32_t {
    direct_xb = 0,
    direct_xty = 1,
    prepared_xb = 2,
    prepared_xty = 3,
    direct_covariance = 4,
    prepared_covariance = 5,
    direct_normal = 6,
    prepared_normal = 7,
    direct_covariance_diagonal = 8,
    prepared_covariance_diagonal = 9,
    direct_covariance_trace = 10,
    prepared_covariance_trace = 11,
    direct_normal_diagonal = 12,
    prepared_normal_diagonal = 13
};

struct ExecutionConfig {
    KernelMode kernel_mode = KernelMode::automatic;
    IsaMode isa_mode = IsaMode::automatic;
    // Zero uses the current OpenMP runtime default when OpenMP is compiled in.
    // One forces serial execution. Larger values request that local team size.
    std::uint32_t requested_threads = 0;
};

// Concrete, validated operation-local choice. Values are never automatic.
struct ExecutionBackend {
    KernelMode kernel_mode;
    IsaMode isa_mode;
    std::uint32_t thread_count;
};

// True exactly when this library build contains OpenMP execution support.
GBITS_API bool openmp_enabled() noexcept;
// Build and runtime capability queries. avx2_supported() includes the x86 CPU
// feature bits and the operating-system YMM extended-state requirement.
GBITS_API bool simd_compiled() noexcept;
GBITS_API bool avx2_compiled() noexcept;
GBITS_API bool avx2_supported() noexcept;
GBITS_API IsaMode automatic_isa() noexcept;

// Resolve the backend without executing an operator. This is primarily useful
// for diagnostics and reproducible benchmarks; normal callers may use the
// automatic execution configuration directly.
GBITS_API ExecutionBackend resolve_execution(
    OperatorKind operation, std::uint64_t sample_count,
    std::uint64_t variant_count, std::uint64_t right_hand_side_count,
    bool full_axes, const ExecutionConfig& execution);

} // namespace gbits

#endif
