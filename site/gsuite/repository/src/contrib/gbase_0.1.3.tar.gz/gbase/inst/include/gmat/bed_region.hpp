#ifndef GMAT_BED_REGION_HPP
#define GMAT_BED_REGION_HPP

#include <cstdint>
#include <vector>
#include "gmat/bed_panel.hpp"
#include "gmat/export.h"

namespace gmat {
struct StandardizedBedRegion {
  std::uint64_t sample_count{0};
  std::uint64_t marker_count{0};
  // Column-major observed-mean-centred, unit-norm dosage columns.
  // Missing calls are zero after centring (mean imputation).
  std::vector<double> values;
};

// Nonempty, unique, increasing logical panel indices from one chromosome.
// At least two samples and nonzero observed variation are required.
// Decoding is delegated to gbits; no persistent genotype or LD files are made.
GMAT_EXPORT StandardizedBedRegion read_standardized_bed_region(
    const BedPanel& panel, const std::vector<std::uint64_t>& marker_indices,
    std::uint32_t decode_threads = 1);

// Physical BED rows from an already validated BIM/FAM descriptor. The caller
// checks marker identities, allele orientation and chromosome membership.
// BED header/length, row bounds/uniqueness and observed variation are checked
// here. No BIM/FAM metadata or marker-name lookup is allocated.
GMAT_EXPORT StandardizedBedRegion read_standardized_bed_region(
    const std::string& bed_path, std::uint64_t source_sample_count,
    std::uint64_t source_marker_count,
    const std::vector<std::uint64_t>& sample_indices,
    const std::vector<std::uint64_t>& marker_indices,
    std::uint32_t decode_threads = 1);
}  // namespace gmat
#endif
