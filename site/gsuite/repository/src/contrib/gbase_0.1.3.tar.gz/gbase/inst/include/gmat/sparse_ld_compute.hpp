#ifndef GMAT_SPARSE_LD_COMPUTE_HPP
#define GMAT_SPARSE_LD_COMPUTE_HPP

#include <cstdint>
#include <vector>

#include "gmat/bed_matrix.hpp"
#include "gmat/export.h"
#include "gmat/sparse_ld_csr.hpp"

namespace gmat {

struct SparseLdOptions {
  std::uint64_t block_size{1024};
  std::uint64_t max_distance_bp{1000000};
  std::uint64_t max_distance_markers{1000};
  double r2_threshold{0.01};
  std::uint32_t requested_threads{0};
  bool allow_full_ld{false};
};

struct SparseLdResult {
  SparseLdCsr ld;
  std::vector<double> marker_ss;
};

// Compute strict-upper-triangle sparse correlations in BedMatrix marker order.
// requested_threads values 0 and 1 select scalar execution. Values above one
// request an explicit local OpenMP team and require OpenMP-enabled gmat.
GMAT_EXPORT SparseLdResult compute_sparse_ld_csr(
    const BedMatrix& bed, const SparseLdOptions& options);

}  // namespace gmat

#endif
