#ifndef GBITS_PACKED_MATRIX_HPP
#define GBITS_PACKED_MATRIX_HPP

#include <gbits/execution.hpp>
#include <gbits/export.h>
#include <gbits/missing_policy.hpp>
#include <gbits/transform.hpp>

#include <cstdint>
#include <memory>

namespace gbits {

namespace detail {
struct PackedStorage;
struct PackedMarkerKernelAccess;
}

class BedReader;
class PreparedBitMatrix;

enum class PackedEncoding : std::uint32_t {
    binary = 0,
    ternary = 1
};

enum class PackedWordPlane : std::uint32_t {
    value_a = 0,
    value_b = 1,
    observed = 2
};

// Immutable ordered selection over a PackedMatrix. For either axis, nullptr
// with count zero selects the full axis; a non-null pointer with positive count
// supplies an ordered subset. Indices are copied and must be unique and in
// range.
class GBITS_API PackedSelection final {
public:
    static PackedSelection create(
        std::uint64_t physical_row_count,
        std::uint64_t physical_column_count,
        const std::uint64_t* row_indices,
        std::uint64_t row_index_count,
        const std::uint64_t* column_indices,
        std::uint64_t column_index_count);

    PackedSelection(const PackedSelection& other);
    PackedSelection(PackedSelection&& other) noexcept;
    ~PackedSelection();

    PackedSelection& operator=(const PackedSelection&) = delete;
    PackedSelection& operator=(PackedSelection&&) = delete;

    std::uint64_t row_count() const noexcept;
    std::uint64_t column_count() const noexcept;
    bool selects_all_rows() const noexcept;
    bool selects_all_columns() const noexcept;
    std::uint64_t physical_row_count() const noexcept;
    std::uint64_t physical_column_count() const noexcept;
    std::uint64_t row_index(std::uint64_t logical_row) const;
    std::uint64_t column_index(std::uint64_t logical_column) const;

private:
    struct Impl;
    explicit PackedSelection(std::shared_ptr<const Impl> implementation);

    std::shared_ptr<const Impl> implementation_;

    friend class PackedMatrix;
    friend class PackedTransform;
    friend struct detail::PackedMarkerKernelAccess;
};

// Immutable affine metadata aligned to the exact ordered axes of a
// PackedSelection. Required arrays are copied in logical column order.
class GBITS_API PackedTransform final {
public:
    static PackedTransform create(
        const PackedSelection& selection,
        TransformMode mode,
        MissingPolicy missing_policy,
        const double* centers,
        std::uint64_t center_count,
        const double* scales,
        std::uint64_t scale_count);

    PackedTransform(const PackedTransform& other);
    PackedTransform(PackedTransform&& other) noexcept;
    ~PackedTransform();

    PackedTransform& operator=(const PackedTransform&) = delete;
    PackedTransform& operator=(PackedTransform&&) = delete;

    std::uint64_t row_count() const noexcept;
    std::uint64_t column_count() const noexcept;
    TransformMode mode() const noexcept;
    MissingPolicy missing_policy() const noexcept;
    bool compatible_with(const PackedSelection& selection) const noexcept;
    double center(std::uint64_t logical_column) const;
    double scale(std::uint64_t logical_column) const;

private:
    struct Impl;
    explicit PackedTransform(std::shared_ptr<const Impl> implementation);

    std::shared_ptr<const Impl> implementation_;

    friend class PackedMatrix;
    friend struct detail::PackedMarkerKernelAccess;
};

// Immutable source-independent packed logical matrix. Storage is column-major
// over rows and owns every copied input. Binary matrices use one value plane;
// ternary matrices use canonical A/B planes. The observed plane is optional.
class GBITS_API PackedMatrix final {
public:
    // values and optional observed bytes share the checked column-major
    // leading dimension. Logical positions are copied; padding is not read.
    static PackedMatrix from_values(
        PackedEncoding encoding,
        std::uint64_t row_count,
        std::uint64_t column_count,
        const std::uint8_t* values,
        std::uint64_t values_length,
        std::uint64_t leading_dimension,
        const std::uint8_t* observed,
        std::uint64_t observed_length);

    // Plane counts must exactly equal columns * ceil(rows / 64). The value-B
    // plane is required only for ternary encoding; an absent observed plane
    // means all logical entries are observed.
    static PackedMatrix from_packed_words(
        PackedEncoding encoding,
        std::uint64_t row_count,
        std::uint64_t column_count,
        const std::uint64_t* value_a,
        std::uint64_t value_a_count,
        const std::uint64_t* value_b,
        std::uint64_t value_b_count,
        const std::uint64_t* observed,
        std::uint64_t observed_count);

    PackedMatrix(const PackedMatrix& other);
    PackedMatrix(PackedMatrix&& other) noexcept;
    ~PackedMatrix();

    PackedMatrix& operator=(const PackedMatrix&) = delete;
    PackedMatrix& operator=(PackedMatrix&&) = delete;

    std::uint64_t row_count() const noexcept;
    std::uint64_t column_count() const noexcept;
    PackedEncoding encoding() const noexcept;
    std::uint64_t words_per_column() const noexcept;
    std::uint64_t packed_storage_bytes() const noexcept;
    std::uint64_t word(PackedWordPlane plane, std::uint64_t logical_column,
                       std::uint64_t word_index) const;

    PackedSelection make_selection(
        const std::uint64_t* row_indices,
        std::uint64_t row_index_count,
        const std::uint64_t* column_indices,
        std::uint64_t column_index_count) const;

    void xmat(const PackedSelection& selection,
              const PackedTransform& transform,
              const double* coefficients,
              std::uint64_t coefficients_length,
              std::uint64_t right_hand_side_count,
              std::uint64_t ldb,
              const ExecutionConfig& execution,
              double* output,
              std::uint64_t output_length,
              std::uint64_t ldout) const;
    void xtmat(const PackedSelection& selection,
               const PackedTransform& transform,
               const double* values,
               std::uint64_t values_length,
               std::uint64_t right_hand_side_count,
               std::uint64_t ldy,
               const ExecutionConfig& execution,
               double* output,
               std::uint64_t output_length,
               std::uint64_t ldout) const;

private:
    explicit PackedMatrix(
        std::shared_ptr<const detail::PackedStorage> implementation);

    std::shared_ptr<const detail::PackedStorage> implementation_;

    friend class BedReader;
    friend class PreparedBitMatrix;
    friend struct detail::PackedMarkerKernelAccess;
};

} // namespace gbits

#endif
