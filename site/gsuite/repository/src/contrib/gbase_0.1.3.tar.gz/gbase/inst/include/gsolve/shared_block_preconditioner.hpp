#ifndef GSOLVE_SHARED_BLOCK_PRECONDITIONER_HPP
#define GSOLVE_SHARED_BLOCK_PRECONDITIONER_HPP
#include "gsolve/preconditioner.hpp"
#include "gsolve/dense_spd_factorization.hpp"
namespace gsolve {
// M has scalar diagonal gaps and disjoint scaled copies s_i B of ONE SPD
// block B. Stored metadata is O(dimension+block_count+B_dimension^2), not
// O(block_count*B_dimension^2). Offsets must be ordered and non-overlapping.
class GSOLVE_EXPORT SharedBlockDiagonalPreconditioner final : public Preconditioner {
public:
  SharedBlockDiagonalPreconditioner(
      std::vector<double> scalar_diagonal, std::vector<std::uint64_t> offsets,
      std::vector<double> scales, ConstMatrixView shared_block,
      std::uint64_t maximum_workspace_bytes = 512ULL*1024*1024,
      std::uint64_t tile_columns = 256);
  const Status& validation_status() const noexcept { return status_; }
  std::uint64_t dimension() const noexcept override { return diagonal_.size(); }
  std::uint64_t block_count() const noexcept { return offsets_.size(); }
  std::uint64_t block_dimension() const noexcept { return factor_.dimension(); }
  bool concurrent_apply_supported() const noexcept override { return true; }
  // Staged output, independent workspaces, aliased/padded multiple RHS.
  Status apply(ConstMatrixView, MatrixView, Workspace&) const override;
private:
  std::vector<double> diagonal_, scales_;
  std::vector<std::uint64_t> offsets_;
  DenseSpdFactorization factor_;
  std::uint64_t budget_, tile_;
  Status status_{};
};
}
#endif
