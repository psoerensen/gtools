#ifndef GSOLVE_STATUS_HPP
#define GSOLVE_STATUS_HPP

#include <string>
#include <utility>

namespace gsolve {

enum class StatusCode {
  success = 0,
  invalid_argument,
  dimension_mismatch,
  invalid_extent,
  not_supported,
  maximum_iterations,
  cancelled,
  non_positive_curvature,
  singular_preconditioner,
  non_finite_arithmetic,
  stagnation,
  not_positive_definite,
  lanczos_breakdown,
  internal_error,
  invalid_sparse_structure,
  pattern_mismatch,
  factorization_failure,
  nested_solve_failure,
  block_rank_failure
};

class Status {
 public:
  Status() = default;
  Status(StatusCode code, std::string message)
      : code_(code), message_(std::move(message)) {}

  static Status success() { return {}; }

  [[nodiscard]] bool is_ok() const noexcept {
    return code_ == StatusCode::success;
  }
  explicit operator bool() const noexcept { return is_ok(); }
  [[nodiscard]] StatusCode code() const noexcept { return code_; }
  [[nodiscard]] const std::string& message() const noexcept { return message_; }

 private:
  StatusCode code_{StatusCode::success};
  std::string message_{};
};

}  // namespace gsolve

#endif
