#pragma once
#include <string>
#include <vector>
#include "gsolve/export.h"
namespace gsolve {
struct QuadraticTailResult {
  bool available{false}, moment_fallback{false};
  std::string unavailable_reason;
  double p_value{};
};
// Positive weighted chi-square_1 upper tail. Saddlepoint approximation with
// moment matching near the mean; explicitly unavailable outside supported range.
// Numerical extraction of gcorr's existing calculation; no changed tolerances.
GSOLVE_EXPORT QuadraticTailResult weighted_chisquare_tail(double statistic,
    const std::vector<double>& weights);
struct PositiveChiSquareOptions {
  double absolute_tolerance{1e-10}, relative_tolerance{1e-5};
  std::size_t maximum_terms{4096};
};
struct PositiveChiSquareResult {
  bool available{false};
  double p_value{}, absolute_error_bound{};
  std::size_t terms{};
  std::string reason;
};
// Positive gamma-mixture expansion. No saddlepoint or simulation fallback.
// Bound covers unaccumulated mixture mass plus a floating-point allowance;
// it is not an interval-arithmetic guarantee. Ill-conditioned spectra may fail.
GSOLVE_EXPORT PositiveChiSquareResult positive_chisquare_series(double statistic,
    const std::vector<double>& weights, const PositiveChiSquareOptions& = {});
}
