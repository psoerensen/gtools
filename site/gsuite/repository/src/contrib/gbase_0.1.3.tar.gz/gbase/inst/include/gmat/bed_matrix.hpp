#ifndef GMAT_BED_MATRIX_HPP
#define GMAT_BED_MATRIX_HPP

#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "gmat/export.h"

namespace gmat {

struct MarkerMetadata {
  std::string chromosome;
  std::string marker_id;
  double genetic_distance_cm;
  std::uint64_t base_pair_position;
  std::string allele1;
  std::string allele2;
};

struct SampleMetadata {
  std::string family_id;
  std::string individual_id;
  std::string paternal_id;
  std::string maternal_id;
  std::string sex;
  std::string phenotype;
};

// Immutable metadata and BED access for one explicit PLINK BED/BIM/FAM
// triplet. PLINK raw code 00 is dosage 2, so raw dosage counts BIM allele 1.
// Alleles are preserved as written and are never reordered or reinterpreted.
class GMAT_EXPORT BedMatrix final {
 public:
  BedMatrix(std::string bed_path, std::string bim_path,
            std::string fam_path);
  ~BedMatrix();

  BedMatrix(const BedMatrix&) = delete;
  BedMatrix& operator=(const BedMatrix&) = delete;
  BedMatrix(BedMatrix&&) = delete;
  BedMatrix& operator=(BedMatrix&&) = delete;

  [[nodiscard]] const std::string& bed_path() const noexcept;
  [[nodiscard]] const std::string& bim_path() const noexcept;
  [[nodiscard]] const std::string& fam_path() const noexcept;

  [[nodiscard]] std::uint64_t sample_count() const noexcept;
  [[nodiscard]] std::uint64_t marker_count() const noexcept;

  [[nodiscard]] const std::vector<MarkerMetadata>& markers() const noexcept;
  [[nodiscard]] const std::vector<SampleMetadata>& samples() const noexcept;
  [[nodiscard]] const MarkerMetadata& marker(std::uint64_t index) const;
  [[nodiscard]] const SampleMetadata& sample(std::uint64_t index) const;

 private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};

}  // namespace gmat

#endif
