#ifndef GBITS_BED_SUMMARY_HPP
#define GBITS_BED_SUMMARY_HPP

#include <gbits/export.h>

#include <cstdint>
#include <string>
#include <vector>

namespace gbits {

// Exact PLINK allele-1 genotype counts over a selected sample set.
struct GenotypeCounts {
    std::uint64_t n0;
    std::uint64_t n1;
    std::uint64_t n2;
    std::uint64_t nmiss;
};

// Scan selected physical BED marker records directly from SNP-major packed
// storage. Both index vectors are zero-based, non-empty, unique, and retained
// in caller order. Worker storage is bounded by one packed marker record per
// requested thread; no decoded sample-by-marker matrix is constructed.
GBITS_API std::vector<GenotypeCounts> bed_genotype_counts(
    const std::string& path,
    std::uint64_t sample_count,
    std::uint64_t marker_count,
    const std::vector<std::uint64_t>& sample_indices,
    const std::vector<std::uint64_t>& marker_indices,
    std::uint32_t requested_threads = 1u);

} // namespace gbits

#endif
