#ifndef GMAT_ERROR_HPP
#define GMAT_ERROR_HPP

#include <stdexcept>
#include <string>

#include "gmat/export.h"
#include "gmat/status.hpp"

namespace gmat {

class GMAT_EXPORT Error : public std::runtime_error {
 public:
  Error(StatusCode code, const std::string& message)
      : std::runtime_error(message), code_(code) {}

  [[nodiscard]] StatusCode code() const noexcept { return code_; }

 private:
  StatusCode code_;
};

}  // namespace gmat

#endif
