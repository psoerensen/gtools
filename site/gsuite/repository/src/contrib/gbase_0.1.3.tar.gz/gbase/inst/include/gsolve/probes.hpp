#ifndef GSOLVE_PROBES_HPP
#define GSOLVE_PROBES_HPP

#include <cstdint>

#include "gsolve/export.h"
#include "gsolve/matrix_view.hpp"
#include "gsolve/linear_operator.hpp"
#include <vector>

namespace gsolve {

// Copied caller-supplied orthonormal columns, validated once. The caller owns
// basis provenance (in particular independence from trace estimation probes).
class GSOLVE_EXPORT OrthonormalProjector {
 public:
  explicit OrthonormalProjector(ConstMatrixView basis, double tolerance=1e-10);
  const Status& status() const noexcept {return status_;}
  ConstMatrixView basis() const noexcept {return {basis_.data(),dimension_,rank_,dimension_};}
  // Replaces logical columns by (I-Q Q') times those columns. Failure leaves
  // vectors unchanged; padding is preserved. Workspace is caller-owned.
  Status apply_complement(MatrixView vectors,Workspace& workspace) const;
 private:
  std::uint64_t dimension_{0},rank_{0};
  std::vector<double> basis_;
  Status status_;
};

// Counter-based deterministic Rademacher plan. Each value is obtained by a
// documented SplitMix64 finalizer applied to (seed, probe index, row index),
// so generation is independent of batching, scheduling, and thread count.
class GSOLVE_EXPORT RademacherProbePlan {
 public:
  RademacherProbePlan(std::uint64_t dimension, std::uint64_t probe_count,
                      std::uint64_t seed) noexcept;

  [[nodiscard]] const Status& status() const noexcept { return status_; }
  [[nodiscard]] std::uint64_t dimension() const noexcept { return dimension_; }
  [[nodiscard]] std::uint64_t probe_count() const noexcept {
    return probe_count_;
  }
  [[nodiscard]] std::uint64_t seed() const noexcept { return seed_; }

  // Writes probes [first_probe, first_probe + output.columns()) in packed
  // logical order while preserving output padding. Failure leaves output
  // unchanged.
  [[nodiscard]] Status generate(std::uint64_t first_probe,
                                MatrixView output) const;

  [[nodiscard]] double value(std::uint64_t row,
                             std::uint64_t probe) const noexcept;

 private:
  std::uint64_t dimension_{0};
  std::uint64_t probe_count_{0};
  std::uint64_t seed_{0};
  Status status_{};
};

}  // namespace gsolve

#endif
