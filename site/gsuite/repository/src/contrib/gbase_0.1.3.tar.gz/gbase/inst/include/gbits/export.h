#ifndef GBITS_EXPORT_H
#define GBITS_EXPORT_H

#if defined(GBITS_STATIC_DEFINE)
#  define GBITS_API
#elif defined(_WIN32) || defined(__CYGWIN__)
#  if defined(GBITS_BUILDING_LIBRARY)
#    define GBITS_API __declspec(dllexport)
#  else
#    define GBITS_API __declspec(dllimport)
#  endif
#elif defined(__GNUC__) || defined(__clang__)
#  define GBITS_API __attribute__((visibility("default")))
#else
#  define GBITS_API
#endif

#endif
