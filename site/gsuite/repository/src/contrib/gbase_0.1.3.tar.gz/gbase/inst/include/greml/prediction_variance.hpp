#pragma once
#include <greml/status.hpp>
#include <greml/export.h>
#include <gsolve/chunk_ridge.hpp>
#include <limits>
#include <functional>
namespace greml {
struct PredictionVarianceOptions {
  gsolve::ChunkRidgeOptions ridge{};
  std::uint64_t seed{16092026}, initial_probes{32}, maximum_probes{256};
  std::uint64_t probe_batch_size{32}, maximum_evaluations{40};
  double minimum_ratio{.001}, maximum_ratio{.99};
  double ratio_tolerance{.0005}, maximum_ratio_mc_se{.005};
  // Completed score evaluations: probe count, ratio, score, score MC SE.
  std::function<void(std::uint64_t,double,double,double)> evaluation_observer{};
  PredictionVarianceOptions() { ridge.maximum_sweeps = 1000; }
};
struct PredictionVarianceResult {
  Status status{StatusCode::invalid_argument, "fit not performed"};
  double component_ratio{0}, genetic_variance{0}, residual_variance{0};
  // tr(P XX'/normalization)/(n-rank(C)); P removes the fixed design.
  double mean_projected_covariance{0}, genetic_variance_fraction{0};
  // Conditional Monte Carlo uncertainty, not a statistical parameter SE.
  double ratio_mc_se{std::numeric_limits<double>::infinity()};
  bool at_boundary{false};
  std::uint64_t probe_count{0}, evaluations{0}, block_reads{0};
};
// Profile REML for V=sg*XX'/normalization+se*I. Uses common Rademacher
// probes, audited ridge solves, a bracketed scalar root and adaptive probe
// precision. No dense covariance is formed. Boundary results are explicitly
// labelled; exhausted precision/solve budgets return failure, never a fallback.
// ridge.numeric_memory_limit_bytes includes controller storage, excluding
// source and caller-owned inputs. Input source and row order stay immutable.
GREML_EXPORT PredictionVarianceResult fit_prediction_variance(
    std::shared_ptr<const gsolve::RidgeDesignSource> source,
    gsolve::ConstMatrixView fixed, gsolve::ConstMatrixView phenotype,
    double normalization, double initial_ratio,
    const PredictionVarianceOptions& options = {}) noexcept;
}
