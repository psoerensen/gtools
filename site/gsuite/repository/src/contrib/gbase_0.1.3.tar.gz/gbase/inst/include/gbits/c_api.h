#ifndef GBITS_C_API_H
#define GBITS_C_API_H

#include <gbits/export.h>
#include <gbits/status.h>
#include <gbits/version.h>

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct gbits_bed_handle gbits_bed_handle;
typedef struct gbits_bed_selection_handle gbits_bed_selection_handle;
typedef struct gbits_genotype_transform_handle gbits_genotype_transform_handle;
typedef struct gbits_prepared_matrix_handle gbits_prepared_matrix_handle;
typedef struct gbits_packed_matrix_handle gbits_packed_matrix_handle;
typedef struct gbits_phased_haplotype_handle gbits_phased_haplotype_handle;
typedef struct gbits_bed_sink_handle gbits_bed_sink_handle;
typedef struct gbits_hap_sink_handle gbits_hap_sink_handle;
typedef struct gbits_hap_reader_handle gbits_hap_reader_handle;

typedef enum gbits_missing_policy {
    GBITS_MISSING_ERROR = 0,
    GBITS_MISSING_ZERO = 1,
    GBITS_MISSING_MEAN = 2
} gbits_missing_policy;

typedef enum gbits_transform_mode {
    GBITS_TRANSFORM_RAW = 0,
    GBITS_TRANSFORM_CENTERED = 1,
    GBITS_TRANSFORM_SCALED = 2,
    GBITS_TRANSFORM_CENTERED_SCALED = 3
} gbits_transform_mode;

typedef enum gbits_packed_plane {
    GBITS_PACKED_DOSAGE_A = 0,
    GBITS_PACKED_DOSAGE_B = 1,
    GBITS_PACKED_OBSERVED = 2
} gbits_packed_plane;

typedef enum gbits_packed_encoding {
    GBITS_PACKED_BINARY = 0,
    GBITS_PACKED_TERNARY = 1
} gbits_packed_encoding;

typedef enum gbits_packed_word_plane {
    GBITS_PACKED_VALUE_A = 0,
    GBITS_PACKED_VALUE_B = 1,
    GBITS_PACKED_VALIDITY = 2
} gbits_packed_word_plane;

typedef enum gbits_kernel_mode {
    GBITS_KERNEL_AUTOMATIC = 0,
    GBITS_KERNEL_SCALAR_REFERENCE = 1,
    GBITS_KERNEL_TILED = 2
} gbits_kernel_mode;

typedef enum gbits_isa_mode {
    GBITS_ISA_AUTOMATIC = 0,
    GBITS_ISA_PORTABLE = 1,
    GBITS_ISA_AVX2 = 2
} gbits_isa_mode;

typedef enum gbits_operator_kind {
    GBITS_OPERATOR_DIRECT_XB = 0,
    GBITS_OPERATOR_DIRECT_XTY = 1,
    GBITS_OPERATOR_PREPARED_XB = 2,
    GBITS_OPERATOR_PREPARED_XTY = 3,
    GBITS_OPERATOR_DIRECT_COVARIANCE = 4,
    GBITS_OPERATOR_PREPARED_COVARIANCE = 5,
    GBITS_OPERATOR_DIRECT_NORMAL = 6,
    GBITS_OPERATOR_PREPARED_NORMAL = 7,
    GBITS_OPERATOR_DIRECT_COVARIANCE_DIAGONAL = 8,
    GBITS_OPERATOR_PREPARED_COVARIANCE_DIAGONAL = 9,
    GBITS_OPERATOR_DIRECT_COVARIANCE_TRACE = 10,
    GBITS_OPERATOR_PREPARED_COVARIANCE_TRACE = 11,
    GBITS_OPERATOR_DIRECT_NORMAL_DIAGONAL = 12,
    GBITS_OPERATOR_PREPARED_NORMAL_DIAGONAL = 13
} gbits_operator_kind;

/* Execution is local to one operation. Algorithm and ISA are independent.
 * requested_threads=0 uses the current OpenMP runtime default, 1 is serial,
 * and >1 requests that local team size. The library never changes
 * process-global OpenMP settings. Forced unavailable AVX2 or threading returns
 * GBITS_STATUS_NOT_SUPPORTED before output is modified. */
typedef struct gbits_execution_config {
    gbits_kernel_mode kernel_mode;
    gbits_isa_mode isa_mode;
    uint32_t requested_threads;
} gbits_execution_config;

typedef struct gbits_execution_backend {
    gbits_kernel_mode kernel_mode;
    gbits_isa_mode isa_mode;
    uint32_t thread_count;
} gbits_execution_backend;

/* Compact full-axis affine descriptor for generic packed operations. Required
 * arrays must have column_count entries; unused arrays are NULL/count zero.
 * The arrays are read only during the call. */
typedef struct gbits_packed_transform {
    gbits_transform_mode mode;
    gbits_missing_policy missing_policy;
    const double* centers;
    uint64_t center_count;
    const double* scales;
    uint64_t scale_count;
} gbits_packed_transform;

typedef struct gbits_variant_statistics {
    uint64_t observed_count;
    uint64_t missing_count;
    double allele_sum;
    double mean_dosage;
    double allele_frequency;
} gbits_variant_statistics;

typedef struct gbits_marker_statistics {
    uint64_t observed_count;
    uint64_t missing_count;
    double dosage_sum;
    double mean_dosage;
    double m2;
} gbits_marker_statistics;

typedef enum gbits_bed_sink_state {
    GBITS_BED_SINK_OPEN = 0,
    GBITS_BED_SINK_FINALIZED = 1,
    GBITS_BED_SINK_FAILED = 2
} gbits_bed_sink_state;

typedef struct gbits_bed_sink_info {
    uint64_t individual_count;
    uint64_t variant_count;
    uint64_t bytes_written;
    uint64_t conversion_buffer_bytes;
    uint64_t lifecycle_object_bytes;
    gbits_bed_sink_state state;
} gbits_bed_sink_info;

typedef enum gbits_hap_sink_state {
    GBITS_HAP_SINK_OPEN = 0,
    GBITS_HAP_SINK_FINALIZED = 1,
    GBITS_HAP_SINK_FAILED = 2
} gbits_hap_sink_state;

typedef struct gbits_hap_sink_info {
    uint64_t individual_count;
    uint64_t marker_count;
    uint64_t chromosome_count;
    uint64_t bytes_written;
    gbits_hap_sink_state state;
} gbits_hap_sink_info;

typedef struct gbits_hap_chromosome_info {
    uint64_t global_start_marker;
    uint64_t marker_count;
    uint64_t h1_offset;
    uint64_t h2_offset;
    uint64_t bytes_per_phase;
} gbits_hap_chromosome_info;

GBITS_API uint32_t gbits_abi_version(void);
GBITS_API const char* gbits_library_version(void);
GBITS_API const char* gbits_last_error(void);
/* Returns 1 if this build includes OpenMP support, otherwise 0. */
GBITS_API uint32_t gbits_openmp_enabled(void);
/* Compiled capability and runtime CPU/OS capability are intentionally
 * separate. All queries clear the calling thread's last-error diagnostic. */
GBITS_API uint32_t gbits_simd_compiled(void);
GBITS_API uint32_t gbits_avx2_compiled(void);
GBITS_API uint32_t gbits_avx2_supported(void);
GBITS_API gbits_isa_mode gbits_automatic_isa(void);
GBITS_API gbits_status gbits_resolve_execution(
    gbits_operator_kind operation,
    uint64_t sample_count,
    uint64_t variant_count,
    uint64_t right_hand_side_count,
    uint32_t full_axes,
    const gbits_execution_config* execution,
    gbits_execution_backend* output_backend);

GBITS_API gbits_status gbits_bed_open(const char* path, uint64_t sample_count,
                                      uint64_t variant_count,
                                      gbits_bed_handle** output_handle);
GBITS_API gbits_status gbits_bed_close(gbits_bed_handle* handle);

/* Create immutable, owned selection metadata. Independently for each axis,
 * NULL with count 0 selects all entries; non-NULL with positive count supplies
 * an ordered, zero-based subset. Every other pointer/count combination is
 * invalid. Duplicate and out-of-range indices are rejected. The result owns no
 * BED handle and is compatible with readers having the same physical
 * dimensions. */
GBITS_API gbits_status gbits_bed_selection_create(
    gbits_bed_handle* handle,
    const uint64_t* sample_indices,
    uint64_t sample_index_count,
    const uint64_t* variant_indices,
    uint64_t variant_index_count,
    gbits_bed_selection_handle** output_selection);
GBITS_API gbits_status gbits_bed_selection_close(
    gbits_bed_selection_handle* selection);
GBITS_API gbits_status gbits_bed_selection_sample_count(
    const gbits_bed_selection_handle* selection,
    uint64_t* output_count);
GBITS_API gbits_status gbits_bed_selection_variant_count(
    const gbits_bed_selection_handle* selection,
    uint64_t* output_count);

/* Calculate one result per logical marker in selection order, using only
 * selected samples. All-missing markers return NaN mean and M2. */
GBITS_API gbits_status gbits_bed_marker_statistics(
    gbits_bed_handle* handle,
    const gbits_bed_selection_handle* selection,
    gbits_marker_statistics* output,
    uint64_t output_length);

/* Create immutable transformation metadata aligned to the exact selection.
 * Arrays required by mode must have selection variant count elements; unused
 * arrays must be NULL with count zero. Values are copied. */
GBITS_API gbits_status gbits_genotype_transform_create(
    const gbits_bed_selection_handle* selection,
    gbits_transform_mode mode,
    gbits_missing_policy missing_policy,
    const double* centers,
    uint64_t center_count,
    const double* scales,
    uint64_t scale_count,
    gbits_genotype_transform_handle** output_transform);
GBITS_API gbits_status gbits_genotype_transform_close(
    gbits_genotype_transform_handle* transform);
GBITS_API gbits_status gbits_genotype_transform_sample_count(
    const gbits_genotype_transform_handle* transform,
    uint64_t* output_count);
GBITS_API gbits_status gbits_genotype_transform_variant_count(
    const gbits_genotype_transform_handle* transform,
    uint64_t* output_count);
GBITS_API gbits_status gbits_bed_read_variant(gbits_bed_handle* handle,
                                              uint64_t variant_index,
                                              int8_t* output,
                                              uint64_t output_length);
GBITS_API gbits_status gbits_bed_variant_statistics(
    gbits_bed_handle* handle, uint64_t variant_index,
    gbits_variant_statistics* output);
GBITS_API gbits_status gbits_bed_xv(gbits_bed_handle* handle,
                                    const double* variant_values,
                                    uint64_t variant_values_length,
                                    gbits_missing_policy policy,
                                    double* output, uint64_t output_length);
GBITS_API gbits_status gbits_bed_xtv(gbits_bed_handle* handle,
                                     const double* sample_values,
                                     uint64_t sample_values_length,
                                     gbits_missing_policy policy,
                                     double* output, uint64_t output_length);

/* Overwrite output with X * B. B is variant_count by right_hand_side_count;
 * output is sample_count by right_hand_side_count. Matrices are column-major:
 * element (row, column) is buffer[row + column * leading_dimension]. Lengths
 * count double elements and must cover (k - 1) * ld + logical_rows. Padding is
 * neither read nor written. */
GBITS_API gbits_status gbits_bed_xmat(
    gbits_bed_handle* handle,
    const double* coefficients,
    uint64_t coefficients_length,
    uint64_t right_hand_side_count,
    uint64_t ldb,
    gbits_missing_policy policy,
    double* output,
    uint64_t output_length,
    uint64_t ldout);

/* Overwrite output with X' * Y. Y is sample_count by right_hand_side_count;
 * output is variant_count by right_hand_side_count. Storage and buffer-extent
 * rules are the same as gbits_bed_xmat. */
GBITS_API gbits_status gbits_bed_xtmat(
    gbits_bed_handle* handle,
    const double* values,
    uint64_t values_length,
    uint64_t right_hand_side_count,
    uint64_t ldy,
    gbits_missing_policy policy,
    double* output,
    uint64_t output_length,
    uint64_t ldout);

/* Selected vector products. Logical vector lengths are the selected variant
 * and sample counts. Outputs follow caller-specified selection ordering and are
 * unchanged on error. */
GBITS_API gbits_status gbits_bed_xv_selected(
    gbits_bed_handle* handle,
    const gbits_bed_selection_handle* selection,
    const double* variant_values,
    uint64_t variant_values_length,
    gbits_missing_policy policy,
    double* output,
    uint64_t output_length);
GBITS_API gbits_status gbits_bed_xtv_selected(
    gbits_bed_handle* handle,
    const gbits_bed_selection_handle* selection,
    const double* sample_values,
    uint64_t sample_values_length,
    gbits_missing_policy policy,
    double* output,
    uint64_t output_length);

/* Selected column-major products. For XB, B rows are selected-marker
 * positions and output rows are selected-sample positions. For X'Y, input rows
 * are selected-sample positions and output rows are selected-marker positions.
 * The Phase 2A leading-dimension, extent, overwrite, and padding rules apply. */
GBITS_API gbits_status gbits_bed_xmat_selected(
    gbits_bed_handle* handle,
    const gbits_bed_selection_handle* selection,
    const double* coefficients,
    uint64_t coefficients_length,
    uint64_t right_hand_side_count,
    uint64_t ldb,
    gbits_missing_policy policy,
    double* output,
    uint64_t output_length,
    uint64_t ldout);
GBITS_API gbits_status gbits_bed_xtmat_selected(
    gbits_bed_handle* handle,
    const gbits_bed_selection_handle* selection,
    const double* values,
    uint64_t values_length,
    uint64_t right_hand_side_count,
    uint64_t ldy,
    gbits_missing_policy policy,
    double* output,
    uint64_t output_length,
    uint64_t ldout);

/* Canonical transformed direct-BED operations. The selection and transform
 * must have identical physical dimensions and ordered logical index sequences.
 * Missing replacement precedes the affine transform. */
GBITS_API gbits_status gbits_bed_xv_transformed(
    gbits_bed_handle* handle,
    const gbits_bed_selection_handle* selection,
    const gbits_genotype_transform_handle* transform,
    const double* variant_values,
    uint64_t variant_values_length,
    double* output,
    uint64_t output_length);
GBITS_API gbits_status gbits_bed_xtv_transformed(
    gbits_bed_handle* handle,
    const gbits_bed_selection_handle* selection,
    const gbits_genotype_transform_handle* transform,
    const double* sample_values,
    uint64_t sample_values_length,
    double* output,
    uint64_t output_length);
GBITS_API gbits_status gbits_bed_xmat_transformed(
    gbits_bed_handle* handle,
    const gbits_bed_selection_handle* selection,
    const gbits_genotype_transform_handle* transform,
    const double* coefficients,
    uint64_t coefficients_length,
    uint64_t right_hand_side_count,
    uint64_t ldb,
    double* output,
    uint64_t output_length,
    uint64_t ldout);
GBITS_API gbits_status gbits_bed_xtmat_transformed(
    gbits_bed_handle* handle,
    const gbits_bed_selection_handle* selection,
    const gbits_genotype_transform_handle* transform,
    const double* values,
    uint64_t values_length,
    uint64_t right_hand_side_count,
    uint64_t ldy,
    double* output,
    uint64_t output_length,
    uint64_t ldout);

/* Execution-controlled transformed direct-BED products. A NULL execution
 * pointer is invalid. Existing transformed functions use automatic mode. */
GBITS_API gbits_status gbits_bed_xmat_execute(
    gbits_bed_handle* handle,
    const gbits_bed_selection_handle* selection,
    const gbits_genotype_transform_handle* transform,
    const double* coefficients,
    uint64_t coefficients_length,
    uint64_t right_hand_side_count,
    uint64_t ldb,
    const gbits_execution_config* execution,
    double* output,
    uint64_t output_length,
    uint64_t ldout);
GBITS_API gbits_status gbits_bed_xtmat_execute(
    gbits_bed_handle* handle,
    const gbits_bed_selection_handle* selection,
    const gbits_genotype_transform_handle* transform,
    const double* values,
    uint64_t values_length,
    uint64_t right_hand_side_count,
    uint64_t ldy,
    const gbits_execution_config* execution,
    double* output,
    uint64_t output_length,
    uint64_t ldout);

/* Immutable marker-major packed raw matrix lifecycle and queries. Dosage is
 * bit(A) + bit(B); dosage one is canonically A=1,B=0. Tail bits are zero. */
GBITS_API gbits_status gbits_prepared_matrix_create(
    gbits_bed_handle* handle,
    const gbits_bed_selection_handle* selection,
    gbits_prepared_matrix_handle** output_prepared);
GBITS_API gbits_status gbits_prepared_matrix_close(
    gbits_prepared_matrix_handle* prepared);
GBITS_API gbits_status gbits_prepared_matrix_sample_count(
    const gbits_prepared_matrix_handle* prepared,
    uint64_t* output_count);
GBITS_API gbits_status gbits_prepared_matrix_variant_count(
    const gbits_prepared_matrix_handle* prepared,
    uint64_t* output_count);
GBITS_API gbits_status gbits_prepared_matrix_words_per_marker(
    const gbits_prepared_matrix_handle* prepared,
    uint64_t* output_count);
GBITS_API gbits_status gbits_prepared_matrix_word(
    const gbits_prepared_matrix_handle* prepared,
    gbits_packed_plane plane,
    uint64_t logical_marker,
    uint64_t word_index,
    uint64_t* output_word);
GBITS_API gbits_status gbits_prepared_matrix_marker_statistics(
    const gbits_prepared_matrix_handle* prepared,
    gbits_marker_statistics* output,
    uint64_t output_length);
GBITS_API gbits_status gbits_prepared_matrix_xv(
    const gbits_prepared_matrix_handle* prepared,
    const gbits_genotype_transform_handle* transform,
    const double* variant_values,
    uint64_t variant_values_length,
    double* output,
    uint64_t output_length);
GBITS_API gbits_status gbits_prepared_matrix_xtv(
    const gbits_prepared_matrix_handle* prepared,
    const gbits_genotype_transform_handle* transform,
    const double* sample_values,
    uint64_t sample_values_length,
    double* output,
    uint64_t output_length);
GBITS_API gbits_status gbits_prepared_matrix_xmat(
    const gbits_prepared_matrix_handle* prepared,
    const gbits_genotype_transform_handle* transform,
    const double* coefficients,
    uint64_t coefficients_length,
    uint64_t right_hand_side_count,
    uint64_t ldb,
    double* output,
    uint64_t output_length,
    uint64_t ldout);
GBITS_API gbits_status gbits_prepared_matrix_xtmat(
    const gbits_prepared_matrix_handle* prepared,
    const gbits_genotype_transform_handle* transform,
    const double* values,
    uint64_t values_length,
    uint64_t right_hand_side_count,
    uint64_t ldy,
    double* output,
    uint64_t output_length,
    uint64_t ldout);
GBITS_API gbits_status gbits_prepared_matrix_xmat_execute(
    const gbits_prepared_matrix_handle* prepared,
    const gbits_genotype_transform_handle* transform,
    const double* coefficients,
    uint64_t coefficients_length,
    uint64_t right_hand_side_count,
    uint64_t ldb,
    const gbits_execution_config* execution,
    double* output,
    uint64_t output_length,
    uint64_t ldout);
GBITS_API gbits_status gbits_prepared_matrix_xtmat_execute(
    const gbits_prepared_matrix_handle* prepared,
    const gbits_genotype_transform_handle* transform,
    const double* values,
    uint64_t values_length,
    uint64_t right_hand_side_count,
    uint64_t ldy,
    const gbits_execution_config* execution,
    double* output,
    uint64_t output_length,
    uint64_t ldout);

/* Source-independent immutable packed matrix. Ordinary byte values and an
 * optional canonical zero/one validity array use the same checked
 * column-major leading dimension. Packed planes are feature-major and copied;
 * their lengths must exactly equal columns * ceil(rows / 64). */
GBITS_API gbits_status gbits_packed_matrix_create_from_values(
    gbits_packed_encoding encoding,
    uint64_t row_count,
    uint64_t column_count,
    const uint8_t* values,
    uint64_t values_length,
    uint64_t leading_dimension,
    const uint8_t* validity,
    uint64_t validity_length,
    gbits_packed_matrix_handle** output_matrix);
GBITS_API gbits_status gbits_packed_matrix_create_from_words(
    gbits_packed_encoding encoding,
    uint64_t row_count,
    uint64_t column_count,
    const uint64_t* value_a,
    uint64_t value_a_count,
    const uint64_t* value_b,
    uint64_t value_b_count,
    const uint64_t* validity,
    uint64_t validity_count,
    gbits_packed_matrix_handle** output_matrix);
GBITS_API gbits_status gbits_packed_matrix_close(
    gbits_packed_matrix_handle* matrix);
GBITS_API gbits_status gbits_packed_matrix_row_count(
    const gbits_packed_matrix_handle* matrix, uint64_t* output_count);
GBITS_API gbits_status gbits_packed_matrix_column_count(
    const gbits_packed_matrix_handle* matrix, uint64_t* output_count);
GBITS_API gbits_status gbits_packed_matrix_encoding(
    const gbits_packed_matrix_handle* matrix,
    gbits_packed_encoding* output_encoding);
GBITS_API gbits_status gbits_packed_matrix_words_per_column(
    const gbits_packed_matrix_handle* matrix, uint64_t* output_count);
GBITS_API gbits_status gbits_packed_matrix_word(
    const gbits_packed_matrix_handle* matrix,
    gbits_packed_word_plane plane,
    uint64_t logical_column,
    uint64_t word_index,
    uint64_t* output_word);

/* Initial generic C operations cover full axes. They retain checked
 * column-major extents, output-padding preservation, overwrite semantics,
 * explicit execution, and unchanged output on failure. */
GBITS_API gbits_status gbits_packed_matrix_xmat_execute(
    const gbits_packed_matrix_handle* matrix,
    const gbits_packed_transform* transform,
    const double* coefficients,
    uint64_t coefficients_length,
    uint64_t right_hand_side_count,
    uint64_t ldb,
    const gbits_execution_config* execution,
    double* output,
    uint64_t output_length,
    uint64_t ldout);
GBITS_API gbits_status gbits_packed_matrix_xtmat_execute(
    const gbits_packed_matrix_handle* matrix,
    const gbits_packed_transform* transform,
    const double* values,
    uint64_t values_length,
    uint64_t right_hand_side_count,
    uint64_t ldy,
    const gbits_execution_config* execution,
    double* output,
    uint64_t output_length,
    uint64_t ldout);

/* Mutable chromosome-local one-bit phased haplotypes. Storage is
 * marker-major: marker * words_per_marker + individual / 64, with individual
 * i in bit i % 64 (least-significant bit first). Tail bits are canonical zero.
 * Handles own their storage and use zero-based indices. */
GBITS_API gbits_status gbits_phased_haplotype_create_zero(
    uint64_t individual_count,
    uint64_t marker_count,
    gbits_phased_haplotype_handle** output_haplotypes);
GBITS_API gbits_status gbits_phased_haplotype_create_from_values(
    uint64_t individual_count,
    uint64_t marker_count,
    const uint8_t* values,
    uint64_t values_length,
    uint64_t leading_dimension,
    gbits_phased_haplotype_handle** output_haplotypes);
GBITS_API gbits_status gbits_phased_haplotype_close(
    gbits_phased_haplotype_handle* haplotypes);
GBITS_API gbits_status gbits_phased_haplotype_individual_count(
    const gbits_phased_haplotype_handle* haplotypes,
    uint64_t* output_count);
GBITS_API gbits_status gbits_phased_haplotype_marker_count(
    const gbits_phased_haplotype_handle* haplotypes,
    uint64_t* output_count);
GBITS_API gbits_status gbits_phased_haplotype_words_per_marker(
    const gbits_phased_haplotype_handle* haplotypes,
    uint64_t* output_count);
GBITS_API gbits_status gbits_phased_haplotype_storage_bytes(
    const gbits_phased_haplotype_handle* haplotypes,
    uint64_t* output_bytes);
GBITS_API gbits_status gbits_phased_haplotype_word(
    const gbits_phased_haplotype_handle* haplotypes,
    uint64_t marker,
    uint64_t word_index,
    uint64_t* output_word);
GBITS_API gbits_status gbits_phased_haplotype_allele(
    const gbits_phased_haplotype_handle* haplotypes,
    uint64_t individual,
    uint64_t marker,
    uint8_t* output_allele);
GBITS_API gbits_status gbits_phased_haplotype_set_allele(
    gbits_phased_haplotype_handle* haplotypes,
    uint64_t individual,
    uint64_t marker,
    uint8_t allele);
GBITS_API gbits_status gbits_phased_haplotype_unpack(
    const gbits_phased_haplotype_handle* haplotypes,
    uint8_t* output,
    uint64_t output_length,
    uint64_t leading_dimension);
GBITS_API gbits_status gbits_phased_haplotype_copy_interval(
    gbits_phased_haplotype_handle* destination,
    uint64_t destination_individual,
    const gbits_phased_haplotype_handle* source,
    uint64_t source_individual,
    uint64_t first_marker,
    uint64_t last_marker);
GBITS_API gbits_status gbits_phased_haplotype_copy_filtered_segment(
    gbits_phased_haplotype_handle* destination,
    uint64_t destination_individual,
    const gbits_phased_haplotype_handle* source,
    uint64_t source_individual,
    uint64_t first_marker,
    uint64_t last_marker,
    double coalescent_age,
    const double* mutation_age,
    uint64_t mutation_age_count);
/* Boundary b switches parental source before marker b. Boundaries must be
 * sorted, may repeat, and lie in [0, marker_count]. */
GBITS_API gbits_status gbits_phased_haplotype_make_gamete(
    gbits_phased_haplotype_handle* destination,
    uint64_t destination_individual,
    const gbits_phased_haplotype_handle* parent_h1,
    const gbits_phased_haplotype_handle* parent_h2,
    uint64_t parent_individual,
    uint32_t starting_haplotype,
    const uint64_t* crossover_boundaries,
    uint64_t crossover_count);
GBITS_API gbits_status gbits_phased_haplotype_decode_genotypes(
    const gbits_phased_haplotype_handle* h1,
    const gbits_phased_haplotype_handle* h2,
    uint8_t* output,
    uint64_t output_length,
    uint64_t leading_dimension);

/* Transactional SNP-major BED sink for two compatible chromosome-local
 * phased handles. destination_utf8 is interpreted as exact UTF-8. Creation
 * writes only to an exclusively owned sibling temporary file. Finalization
 * publishes the complete file; close before finalization cancels it. Buffer
 * capacity is measured in variant records and must be in [1, 4096]. */
GBITS_API gbits_status gbits_bed_sink_create(
    const char* destination_utf8,
    uint64_t individual_count,
    uint32_t overwrite,
    uint64_t buffer_variant_capacity,
    gbits_bed_sink_handle** output_sink);
GBITS_API gbits_status gbits_bed_sink_append_phased(
    gbits_bed_sink_handle* sink,
    const gbits_phased_haplotype_handle* h1,
    const gbits_phased_haplotype_handle* h2);
GBITS_API gbits_status gbits_bed_sink_finalize(gbits_bed_sink_handle* sink);
GBITS_API gbits_status gbits_bed_sink_get_info(
    const gbits_bed_sink_handle* sink,
    gbits_bed_sink_info* output_info);
GBITS_API gbits_status gbits_bed_sink_close(gbits_bed_sink_handle* sink);

/* HAP v1 stores the existing marker-major one-bit H1/H2 planes directly.
 * The single-file sink is transactional; closing before finalization cancels.
 * Reader-loaded chromosome handles own their packed storage independently. */
GBITS_API gbits_status gbits_hap_sink_create(
    const char* destination_utf8, uint64_t individual_count,
    uint32_t overwrite, gbits_hap_sink_handle** output_sink);
GBITS_API gbits_status gbits_hap_sink_append_phased(
    gbits_hap_sink_handle* sink,
    const gbits_phased_haplotype_handle* h1,
    const gbits_phased_haplotype_handle* h2);
GBITS_API gbits_status gbits_hap_sink_finalize(gbits_hap_sink_handle* sink);
GBITS_API gbits_status gbits_hap_sink_get_info(
    const gbits_hap_sink_handle* sink, gbits_hap_sink_info* output_info);
GBITS_API gbits_status gbits_hap_sink_close(gbits_hap_sink_handle* sink);
GBITS_API gbits_status gbits_hap_reader_open(
    const char* path_utf8, gbits_hap_reader_handle** output_reader);
GBITS_API gbits_status gbits_hap_reader_close(gbits_hap_reader_handle* reader);
GBITS_API gbits_status gbits_hap_reader_dimensions(
    const gbits_hap_reader_handle* reader,
    uint64_t* output_individual_count, uint64_t* output_marker_count,
    uint64_t* output_chromosome_count);
GBITS_API gbits_status gbits_hap_reader_chromosome_info(
    const gbits_hap_reader_handle* reader, uint64_t chromosome_index,
    gbits_hap_chromosome_info* output_info);
GBITS_API gbits_status gbits_hap_reader_load_chromosome(
    const gbits_hap_reader_handle* reader, uint64_t chromosome_index,
    gbits_phased_haplotype_handle** output_h1,
    gbits_phased_haplotype_handle** output_h2);

/* Weighted solver primitives over the selected, transformed logical matrix Z.
 * Weight arrays have exact logical lengths, are ordered with the selection,
 * and contain finite nonnegative values. Matrix buffers are column-major and
 * follow the same checked-extent, untouched-padding, overwrite, and
 * failure-atomic contracts as Xmat/X'mat. */
GBITS_API gbits_status gbits_bed_covariance_execute(
    gbits_bed_handle* handle,
    const gbits_bed_selection_handle* selection,
    const gbits_genotype_transform_handle* transform,
    const double* marker_weights, uint64_t marker_weights_length,
    const double* values, uint64_t values_length,
    uint64_t right_hand_side_count, uint64_t ldy,
    const gbits_execution_config* execution,
    double* output, uint64_t output_length, uint64_t ldout);
GBITS_API gbits_status gbits_prepared_matrix_covariance_execute(
    const gbits_prepared_matrix_handle* prepared,
    const gbits_genotype_transform_handle* transform,
    const double* marker_weights, uint64_t marker_weights_length,
    const double* values, uint64_t values_length,
    uint64_t right_hand_side_count, uint64_t ldy,
    const gbits_execution_config* execution,
    double* output, uint64_t output_length, uint64_t ldout);
GBITS_API gbits_status gbits_bed_normal_equation_execute(
    gbits_bed_handle* handle,
    const gbits_bed_selection_handle* selection,
    const gbits_genotype_transform_handle* transform,
    const double* sample_weights, uint64_t sample_weights_length,
    const double* marker_diagonal, uint64_t marker_diagonal_length,
    const double* coefficients, uint64_t coefficients_length,
    uint64_t right_hand_side_count, uint64_t ldb,
    const gbits_execution_config* execution,
    double* output, uint64_t output_length, uint64_t ldout);
GBITS_API gbits_status gbits_prepared_matrix_normal_equation_execute(
    const gbits_prepared_matrix_handle* prepared,
    const gbits_genotype_transform_handle* transform,
    const double* sample_weights, uint64_t sample_weights_length,
    const double* marker_diagonal, uint64_t marker_diagonal_length,
    const double* coefficients, uint64_t coefficients_length,
    uint64_t right_hand_side_count, uint64_t ldb,
    const gbits_execution_config* execution,
    double* output, uint64_t output_length, uint64_t ldout);
GBITS_API gbits_status gbits_bed_covariance_diagonal_execute(
    gbits_bed_handle* handle,
    const gbits_bed_selection_handle* selection,
    const gbits_genotype_transform_handle* transform,
    const double* marker_weights, uint64_t marker_weights_length,
    const gbits_execution_config* execution,
    double* output, uint64_t output_length);
GBITS_API gbits_status gbits_prepared_matrix_covariance_diagonal_execute(
    const gbits_prepared_matrix_handle* prepared,
    const gbits_genotype_transform_handle* transform,
    const double* marker_weights, uint64_t marker_weights_length,
    const gbits_execution_config* execution,
    double* output, uint64_t output_length);
GBITS_API gbits_status gbits_bed_covariance_trace_execute(
    gbits_bed_handle* handle,
    const gbits_bed_selection_handle* selection,
    const gbits_genotype_transform_handle* transform,
    const double* marker_weights, uint64_t marker_weights_length,
    const gbits_execution_config* execution, double* output_trace);
GBITS_API gbits_status gbits_prepared_matrix_covariance_trace_execute(
    const gbits_prepared_matrix_handle* prepared,
    const gbits_genotype_transform_handle* transform,
    const double* marker_weights, uint64_t marker_weights_length,
    const gbits_execution_config* execution, double* output_trace);
GBITS_API gbits_status gbits_bed_normal_diagonal_execute(
    gbits_bed_handle* handle,
    const gbits_bed_selection_handle* selection,
    const gbits_genotype_transform_handle* transform,
    const double* sample_weights, uint64_t sample_weights_length,
    const double* marker_diagonal, uint64_t marker_diagonal_length,
    const gbits_execution_config* execution,
    double* output, uint64_t output_length);
GBITS_API gbits_status gbits_prepared_matrix_normal_diagonal_execute(
    const gbits_prepared_matrix_handle* prepared,
    const gbits_genotype_transform_handle* transform,
    const double* sample_weights, uint64_t sample_weights_length,
    const double* marker_diagonal, uint64_t marker_diagonal_length,
    const gbits_execution_config* execution,
    double* output, uint64_t output_length);

#ifdef __cplusplus
}
#endif

#endif
