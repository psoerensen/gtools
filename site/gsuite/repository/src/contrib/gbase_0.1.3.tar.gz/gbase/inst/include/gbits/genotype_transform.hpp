#ifndef GBITS_GENOTYPE_TRANSFORM_HPP
#define GBITS_GENOTYPE_TRANSFORM_HPP

#include <gbits/bed_selection.hpp>
#include <gbits/export.h>
#include <gbits/missing_policy.hpp>
#include <gbits/transform.hpp>

#include <cstdint>
#include <memory>

namespace gbits {

class BedReader;
class PreparedBitMatrix;
class PackedMarkerBlockCache;

// Immutable affine transformation metadata aligned to the exact logical
// marker order of an immutable BedSelection.
class GBITS_API GenotypeTransform final {
public:
    static GenotypeTransform create(
        const BedSelection& selection,
        TransformMode mode,
        MissingPolicy missing_policy,
        const double* centers,
        std::uint64_t center_count,
        const double* scales,
        std::uint64_t scale_count);

    GenotypeTransform(const GenotypeTransform& other);
    GenotypeTransform(GenotypeTransform&& other) noexcept;
    ~GenotypeTransform();

    GenotypeTransform& operator=(const GenotypeTransform&) = delete;
    GenotypeTransform& operator=(GenotypeTransform&&) = delete;

    std::uint64_t sample_count() const noexcept;
    std::uint64_t variant_count() const noexcept;
    TransformMode mode() const noexcept;
    MissingPolicy missing_policy() const noexcept;

private:
    struct Impl;
    explicit GenotypeTransform(std::shared_ptr<const Impl> implementation);

    const BedSelection& selection() const noexcept;
    double center(std::uint64_t logical_marker) const noexcept;
    double scale(std::uint64_t logical_marker) const noexcept;
    const double* center_data() const noexcept;
    const double* scale_data() const noexcept;

    std::shared_ptr<const Impl> implementation_;

    friend class BedReader;
    friend class PreparedBitMatrix;
    friend class PackedMarkerBlockCache;
};

} // namespace gbits

#endif
