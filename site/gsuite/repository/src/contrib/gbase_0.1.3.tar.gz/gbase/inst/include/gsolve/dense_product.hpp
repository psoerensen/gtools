#pragma once
#include <gsolve/export.h>

#include <gsolve/matrix_view.hpp>
namespace gsolve {
// C = alpha * op(A) * B + beta * C. Column-major, non-overlapping storage.
// Caller owns all buffers. No retained state; MKL uses a restored thread-local
// scope. Portable OpenMP builds use local teams for large Eigen products;
// other Eigen fallbacks support one thread. Invalid dimensions leave C intact;
// arithmetic failure may leave partial/nonfinite output. Padding is untouched.
GSOLVE_EXPORT Status dense_product(ConstMatrixView a, bool transpose_a,
                                   ConstMatrixView b, MatrixView c,
                                   double alpha = 1, double beta = 0,
                                   std::uint32_t threads = 1) noexcept;
}  // namespace gsolve
