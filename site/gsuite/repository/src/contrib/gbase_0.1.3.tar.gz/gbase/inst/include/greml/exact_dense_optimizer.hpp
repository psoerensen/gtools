#ifndef GREML_EXACT_DENSE_OPTIMIZER_HPP
#define GREML_EXACT_DENSE_OPTIMIZER_HPP

#include <cstdint>
#include <limits>
#include <string>
#include <utility>
#include <vector>

#include "greml/exact_dense.hpp"
#include "greml/optimizer.hpp"

namespace greml {

enum class ComponentConstraint { may_be_zero, strictly_positive, fixed };

enum class OptimizationStatusCode {
  converged = 0,
  maximum_iterations,
  invalid_initial_values,
  singular_ai_system,
  failed_line_search,
  no_valid_ascent_direction,
  restart_exhaustion,
  active_set_cycling,
  structurally_nonidentifiable,
  numerical_failure
};

class OptimizationStatus {
 public:
  OptimizationStatus() = default;
  OptimizationStatus(OptimizationStatusCode code, std::string message)
      : code_(code), message_(std::move(message)) {}

  [[nodiscard]] bool is_converged() const noexcept {
    return code_ == OptimizationStatusCode::converged;
  }
  [[nodiscard]] OptimizationStatusCode code() const noexcept { return code_; }
  [[nodiscard]] const std::string& message() const noexcept { return message_; }

 private:
  OptimizationStatusCode code_{OptimizationStatusCode::numerical_failure};
  std::string message_{"optimizer did not run"};
};

struct ExactDenseOptimizerOptions {
  LikelihoodMode mode{LikelihoodMode::restricted_maximum_likelihood};
  std::uint64_t maximum_iterations{50};
  double score_tolerance{1.0e-6};
  double relative_parameter_tolerance{1.0e-8};
  // Lower bound for strictly-positive components and numerical snap-to-zero
  // threshold for components that may be zero.
  double minimum_positive_value{1.0e-8};
  std::uint64_t maximum_line_search_reductions{20};
  SafeguardedOptimizerOptions safeguard{};
  bool retain_history{false};
};

struct ExactDenseIterationRecord {
  std::uint64_t iteration{0};
  std::uint64_t evaluation_count{0};
  double log_likelihood{std::numeric_limits<double>::quiet_NaN()};
  double projected_score_norm{std::numeric_limits<double>::quiet_NaN()};
  double relative_parameter_change{std::numeric_limits<double>::quiet_NaN()};
  double accepted_step_scale{0.0};
  double ai_diagonal_damping{0.0};
  std::vector<double> parameters{};
  SafeguardedIterationDiagnostics safeguard{};
};

struct ExactDenseOptimizationResult {
  OptimizationStatus status{};
  std::vector<double> parameters{};
  std::vector<double> projected_score{};
  ExactDenseResult evaluation{};
  std::uint64_t iterations{0};
  std::uint64_t evaluation_count{0};
  UnifiedOptimizerDiagnostics optimizer_diagnostics{};
  std::vector<ExactDenseIterationRecord> history{};
};

// Maximizes the selected exact ML/REML likelihood. A boundary component has
// projected score zero when it is at its lower bound and its ordinary score is
// nonpositive. The legacy strategy retains the historical score-or-small-step
// rule. The safeguarded strategy requires projected-score, accepted-step, and
// accepted-likelihood stabilization, with a stable active set.
GREML_EXPORT ExactDenseOptimizationResult
optimize_exact_dense_covariance_components(
    gsolve::ConstMatrixView response, gsolve::ConstMatrixView fixed_effects,
    const std::vector<gsolve::ConstMatrixView>& components,
    const std::vector<double>& initial_parameters,
    const std::vector<ComponentConstraint>& constraints,
    const ExactDenseOptimizerOptions& options = {});

// Convenience route for genetic kernel plus identity residual. The residual
// component is strictly positive; the genetic component may optionally be zero.
GREML_EXPORT ExactDenseOptimizationResult optimize_exact_dense_single_trait(
    gsolve::ConstMatrixView response, gsolve::ConstMatrixView fixed_effects,
    gsolve::ConstMatrixView kernel, double initial_genetic_variance,
    double initial_residual_variance,
    const ExactDenseOptimizerOptions& options = {},
    bool genetic_component_may_be_zero = true);

}  // namespace greml

#endif
