#ifndef GREML_FIXED_EFFECT_DESIGN_HPP
#define GREML_FIXED_EFFECT_DESIGN_HPP

#include <cstdint>
#include <memory>
#include <vector>

#include "greml/exact_dense.hpp"
#include "gsolve/rectangular_operator.hpp"

namespace greml {

// Exact caller-defined fixed-effect columns. This class performs no formula
// parsing, contrast choice, intercept insertion, scaling, imputation, column
// reordering, or rank repair. Estimability remains a downstream factorization
// contract.
class GREML_EXPORT FixedEffectDesign {
 public:
  explicit FixedEffectDesign(gsolve::ConstMatrixView dense_fixed_effects);
  explicit FixedEffectDesign(
      std::vector<std::shared_ptr<const gsolve::RectangularOperator>> blocks);

  [[nodiscard]] const Status& status() const noexcept { return status_; }
  [[nodiscard]] std::uint64_t observation_count() const noexcept;
  [[nodiscard]] std::uint64_t column_count() const noexcept;
  [[nodiscard]] std::uint64_t block_count() const noexcept;
  [[nodiscard]] const std::vector<std::uint64_t>& column_offsets()
      const noexcept {
    return column_offsets_;
  }
  [[nodiscard]] const std::shared_ptr<const gsolve::RectangularOperator>&
  rectangular_operator() const noexcept {
    return operator_;
  }
  [[nodiscard]] bool concurrent_apply_supported() const noexcept;

  [[nodiscard]] Status prepare_workspace(std::uint64_t right_hand_side_count,
                                         gsolve::Workspace& workspace) const;
  [[nodiscard]] Status apply(gsolve::ConstMatrixView coefficients,
                             gsolve::MatrixView output,
                             gsolve::Workspace& workspace) const;
  [[nodiscard]] Status apply_transpose(gsolve::ConstMatrixView values,
                                       gsolve::MatrixView output,
                                       gsolve::Workspace& workspace) const;
  [[nodiscard]] Status materialize_columns(
      std::uint64_t first_column, std::uint64_t selected_column_count,
      gsolve::MatrixView output, gsolve::Workspace& workspace) const;

 private:
  std::shared_ptr<const gsolve::RectangularOperator> operator_{};
  std::vector<std::shared_ptr<const gsolve::RectangularOperator>> blocks_{};
  std::vector<std::uint64_t> column_offsets_{};
  Status status_{};
};

}  // namespace greml

#endif
