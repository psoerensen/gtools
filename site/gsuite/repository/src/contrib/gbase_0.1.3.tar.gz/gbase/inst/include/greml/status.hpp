#ifndef GREML_STATUS_HPP
#define GREML_STATUS_HPP

#include <string>
#include <utility>

namespace greml {

enum class StatusCode {
  success = 0,
  invalid_argument,
  dimension_mismatch,
  invalid_extent,
  non_finite_input,
  nonsymmetric_component,
  covariance_not_positive_definite,
  rank_deficient_fixed_effects,
  invalid_component,
  definiteness_not_established,
  invalid_diagonal,
  pcg_failure,
  slq_failure,
  incompatible_workspace,
  non_finite_arithmetic,
  internal_error,
  invalid_model_structure,
  sparse_factorization_failure,
  not_factorized,
  not_supported,
  insufficient_stochastic_precision,
  invalid_precision_configuration,
  insufficient_linear_solve_precision,
  sparse_symbolic_analysis_failure,
  sparse_numerical_factorization_failure,
  covariance_construction_failure,
  preconditioner_construction_failure,
  invalid_parameter_constraints,
  active_set_incompatibility,
  fixed_effect_pcg_failure,
  fixed_effect_slq_failure,
  block_rank_failure,
  optimizer_ai_unusable,
  optimizer_no_valid_ascent_direction,
  optimizer_line_search_exhaustion,
  optimizer_restart_exhaustion,
  optimizer_active_set_cycling,
  optimizer_maximum_iterations,
  unsupported_covariance_boundary,
  structurally_nonidentifiable,
  likelihood_precision_insufficient
};

class Status {
 public:
  Status() = default;
  Status(StatusCode code, std::string message)
      : code_(code), message_(std::move(message)) {}

  static Status ok() { return {}; }
  [[nodiscard]] bool is_ok() const noexcept {
    return code_ == StatusCode::success;
  }
  explicit operator bool() const noexcept { return is_ok(); }
  [[nodiscard]] StatusCode code() const noexcept { return code_; }
  [[nodiscard]] const std::string& message() const noexcept { return message_; }

 private:
  StatusCode code_{StatusCode::success};
  std::string message_{};
};

}  // namespace greml

#endif
