#ifndef GMAT_SPARSE_LD_DISK_HPP
#define GMAT_SPARSE_LD_DISK_HPP

#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <string>
#include <vector>

#include "gmat/bed_panel.hpp"
#include "gmat/export.h"
#include "gmat/sparse_ld_compute.hpp"
#include "gmat/sparse_ld_csr.hpp"

namespace gmat {

struct SparseLdDiskMarker {
  std::string marker_id;
  std::string chromosome;
  std::uint64_t base_pair_position;
  std::string allele1;
  std::string allele2;
  std::uint64_t component_index;
  std::uint64_t source_marker_index;
};

struct SparseLdDiskResource {
  std::string prefix;
  std::string row_ptr_path;
  std::string col_idx_path;
  std::string values_path;
  std::string metadata_path;
  std::string markers_path;
  std::uint64_t marker_count;
  std::uint64_t stored_entry_count;
  std::uint64_t reference_sample_count;
  std::uint64_t source_sample_count;
  std::uint64_t component_count;
  std::uint32_t format_version;
  SparseLdOptions options;
  std::vector<SparseLdDiskMarker> markers;
};

// Stream strict-upper-triangle correlations in global BedPanel marker order.
// BED decoding is delegated to gbits and only active marker blocks plus their
// retained row entries are held in memory.
GMAT_EXPORT SparseLdDiskResource compute_sparse_ld_csr_to_disk(
    const BedPanel& panel, const std::string& output_prefix,
    const SparseLdOptions& options, bool overwrite = false);

// Parse metadata and validate the sidecar and every CSR payload entry without
// materializing the complete CSR.
GMAT_EXPORT SparseLdDiskResource inspect_sparse_ld_csr_disk(
    const std::string& prefix);

// Parse and validate the manifest, marker sidecar, paths and exact file sizes
// without traversing CSR entries. The resource must remain immutable while in
// use; call inspect_sparse_ld_csr_disk() at explicit trust boundaries.
GMAT_EXPORT SparseLdDiskResource open_sparse_ld_csr_disk(
    const std::string& prefix);

// Dense column-major selected-marker matrix, with implicit unit diagonal and
// omitted sparse pairs equal to zero. No PSD repair or correlation reconstruction.
struct SparseLdRegion {
  std::vector<SparseLdDiskMarker> markers;
  std::uint64_t reference_sample_count;
  std::vector<double> matrix;
};

// Indices are zero-based, nonempty, strictly increasing in reference order.
// Uses a resource-bound reader and checks entries encountered during indexed
// extraction; only the regional matrix is materialized. Full verification is
// the separate inspect_sparse_ld_csr_disk() operation.
GMAT_EXPORT SparseLdRegion sparse_ld_region_from_disk(
    const std::string& prefix, const std::vector<std::uint64_t>& marker_indices,
    std::uint64_t maximum_dimension = 2048);

// Validate and stream a block-diagonal sparse resource in one payload pass.
// Offsets begin at zero, end at marker_count, and are strictly increasing.
// Retained cross-block edges are rejected. Only one block CSR is live in the
// visitor; callers must not retain its reference.
using SparseLdBlockVisitor = std::function<void(
    std::uint64_t begin, std::uint64_t end, const SparseLdCsr& block)>;
// Descriptor metadata is available before the validated payload traversal;
// the callback may reject marker/coding mismatches before any block fit.
using SparseLdDescriptorVisitor = std::function<void(
    const SparseLdDiskResource& descriptor)>;
GMAT_EXPORT SparseLdDiskResource visit_sparse_ld_blocks_from_disk(
    const std::string& prefix, const std::vector<std::uint64_t>& offsets,
    const SparseLdBlockVisitor& visitor,
    const SparseLdDescriptorVisitor& descriptor_visitor = {});

// Bounded symmetric columns, with global row indices and implicit unit diagonal.
struct SparseLdDiskColumns {
  std::uint64_t begin{}, end{};
  std::vector<std::uint64_t> column_ptr;
  std::vector<std::uint32_t> row_indices;
  std::vector<float> values;
};
struct SparseLdDiskReadOptions {
  std::uint64_t maximum_columns{2048};
  std::uint64_t maximum_entries{4 * 1024 * 1024};
};
struct SparseLdDiskReadDiagnostics {
  std::uint64_t column_loads{}, entries_scanned{}, matvec_passes{};
  std::uint64_t peak_column_entries{}, index_builds{}, index_entries_scanned{};
};

struct SparseLdBlockProviderDiagnostics {
  std::uint64_t block_loads{}, cache_hits{}, peak_block_markers{};
};
// Opens the descriptor and row pointers without a full payload scan. Regional
// reads seek directly to selected rows. The first column request builds
// O(markers) reverse indices in one column-index pass; later column requests
// reuse them. Correlation values are checked as read.
// Reads an active range plus all incident edges, including both sides outside
// the range. Long-distance edges can increase I/O, but are never dropped.
// Files must remain immutable. Size/time changes are rejected; this is not a
// cryptographic identity guarantee. Separate readers are required concurrently.
class GMAT_EXPORT SparseLdDiskReader {
 public:
  explicit SparseLdDiskReader(const std::string& prefix,
                              const SparseLdDiskReadOptions& = {});
  ~SparseLdDiskReader();
  SparseLdDiskReader(const SparseLdDiskReader&) = delete;
  SparseLdDiskReader& operator=(const SparseLdDiskReader&) = delete;
  const SparseLdDiskResource& resource() const noexcept;
  const SparseLdDiskReadOptions& options() const noexcept;
  SparseLdDiskReadDiagnostics diagnostics() const noexcept;
  void check_unchanged() const;
  SparseLdDiskColumns read_columns(std::uint64_t begin, std::uint64_t end) const;
  SparseLdRegion read_region(
      const std::vector<std::uint64_t>& marker_indices,
      std::uint64_t maximum_dimension = 2048) const;
  std::vector<double> matvec(const std::vector<double>& x) const;
 private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};

// Session-bound access to an exhaustive, contiguous partition of one sparse
// LD resource. Establish the partition once with
// visit_sparse_ld_blocks_from_disk(), which rejects retained cross-block
// edges. The provider then owns one lightweight reader and retains at most the
// most recently requested dense block. It does not choose ranks or perform an
// eigendecomposition; those are consumer/model responsibilities.
class GMAT_EXPORT SparseLdBlockProvider {
 public:
  SparseLdBlockProvider(const std::string& prefix,
                        std::vector<std::uint64_t> offsets,
                        const SparseLdDiskReadOptions& = {});
  ~SparseLdBlockProvider();
  SparseLdBlockProvider(const SparseLdBlockProvider&) = delete;
  SparseLdBlockProvider& operator=(const SparseLdBlockProvider&) = delete;
  const SparseLdDiskResource& resource() const noexcept;
  const std::vector<std::uint64_t>& offsets() const noexcept;
  std::size_t block_count() const noexcept;
  SparseLdBlockProviderDiagnostics diagnostics() const noexcept;
  std::shared_ptr<const SparseLdRegion> block(std::size_t block_index) const;
 private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};

// Validate and materialize the disk resource as the existing in-memory type.
GMAT_EXPORT SparseLdCsr load_sparse_ld_csr_from_disk(
    const std::string& prefix);

// Load validated CSR and its checked marker/construction descriptor together,
// without a separate full-resource inspect pass.
struct LoadedSparseLdCsr {
  SparseLdDiskResource resource;
  SparseLdCsr ld;
};
GMAT_EXPORT LoadedSparseLdCsr load_sparse_ld_csr_with_resource_from_disk(
    const std::string& prefix);

// Validate while streaming each upper-triangle entry once. The result follows
// marker sidecar order and needs only an O(marker_count) score vector plus
// bounded input buffers.
GMAT_EXPORT std::vector<double> sparse_ld_scores_from_disk(
    const std::string& prefix);

}  // namespace gmat

#endif
