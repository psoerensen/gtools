#ifndef GSOLVE_RECTANGULAR_OPERATOR_HPP
#define GSOLVE_RECTANGULAR_OPERATOR_HPP

#include <cstdint>
#include <limits>
#include <memory>
#include <vector>

#include "gsolve/linear_operator.hpp"

namespace gsolve {

inline constexpr std::uint64_t omitted_design_column =
    std::numeric_limits<std::uint64_t>::max();

// Immutable rectangular numerical map F. apply() computes F B and
// apply_transpose() computes F' Y for column-major multiple-RHS views.
class GSOLVE_EXPORT RectangularOperator {
 public:
  virtual ~RectangularOperator() = default;
  [[nodiscard]] virtual std::uint64_t row_count() const noexcept = 0;
  [[nodiscard]] virtual std::uint64_t column_count() const noexcept = 0;
  [[nodiscard]] virtual const Status& status() const noexcept = 0;
  [[nodiscard]] virtual bool concurrent_apply_supported() const noexcept {
    return true;
  }
  virtual Status prepare_workspace(std::uint64_t right_hand_side_count,
                                   Workspace& workspace) const = 0;
  virtual Status apply(ConstMatrixView coefficients, MatrixView output,
                       Workspace& workspace) const = 0;
  virtual Status apply_transpose(ConstMatrixView values, MatrixView output,
                                 Workspace& workspace) const = 0;
  // Materializes only the requested consecutive column range into caller
  // storage; it never allocates the complete design implicitly.
  virtual Status materialize_columns(std::uint64_t first_column,
                                     std::uint64_t selected_column_count,
                                     MatrixView output,
                                     Workspace& workspace) const = 0;
};

class GSOLVE_EXPORT DenseRectangularOperator final
    : public RectangularOperator {
 public:
  explicit DenseRectangularOperator(ConstMatrixView values);
  [[nodiscard]] std::uint64_t row_count() const noexcept override {
    return row_count_;
  }
  [[nodiscard]] std::uint64_t column_count() const noexcept override {
    return column_count_;
  }
  [[nodiscard]] const Status& status() const noexcept override {
    return status_;
  }
  Status prepare_workspace(std::uint64_t, Workspace&) const override;
  Status apply(ConstMatrixView, MatrixView, Workspace&) const override;
  Status apply_transpose(ConstMatrixView, MatrixView,
                         Workspace&) const override;
  Status materialize_columns(std::uint64_t, std::uint64_t, MatrixView,
                             Workspace&) const override;

 private:
  std::uint64_t row_count_{0};
  std::uint64_t column_count_{0};
  std::vector<double> values_{};
  Status status_{};
};

// Unit-indicator factor block. observation_levels indexes level_to_column;
// omitted_design_column means that a level contributes no design column.
class GSOLVE_EXPORT FactorRectangularOperator final
    : public RectangularOperator {
 public:
  FactorRectangularOperator(
      const std::vector<std::uint64_t>& observation_levels,
      const std::vector<std::uint64_t>& level_to_column,
      std::uint64_t column_count);
  [[nodiscard]] std::uint64_t row_count() const noexcept override;
  [[nodiscard]] std::uint64_t column_count() const noexcept override {
    return column_count_;
  }
  [[nodiscard]] const Status& status() const noexcept override {
    return status_;
  }
  Status prepare_workspace(std::uint64_t, Workspace&) const override;
  Status apply(ConstMatrixView, MatrixView, Workspace&) const override;
  Status apply_transpose(ConstMatrixView, MatrixView,
                         Workspace&) const override;
  Status materialize_columns(std::uint64_t, std::uint64_t, MatrixView,
                             Workspace&) const override;

 private:
  std::vector<std::uint64_t> observation_levels_{};
  std::vector<std::uint64_t> level_to_column_{};
  std::uint64_t column_count_{0};
  Status status_{};
};

// Immutable zero-based rectangular CSC matrix. Rows within each column are
// strictly increasing and duplicate structural entries are rejected.
class GSOLVE_EXPORT SparseCscRectangularOperator final
    : public RectangularOperator {
 public:
  SparseCscRectangularOperator(
      std::uint64_t row_count, std::uint64_t column_count,
      const std::vector<std::uint64_t>& column_offsets,
      const std::vector<std::uint64_t>& row_indices,
      const std::vector<double>& values);
  [[nodiscard]] std::uint64_t row_count() const noexcept override {
    return row_count_;
  }
  [[nodiscard]] std::uint64_t column_count() const noexcept override {
    return column_count_;
  }
  [[nodiscard]] std::uint64_t nonzero_count() const noexcept {
    return static_cast<std::uint64_t>(values_.size());
  }
  [[nodiscard]] const Status& status() const noexcept override {
    return status_;
  }
  Status prepare_workspace(std::uint64_t, Workspace&) const override;
  Status apply(ConstMatrixView, MatrixView, Workspace&) const override;
  Status apply_transpose(ConstMatrixView, MatrixView,
                         Workspace&) const override;
  Status materialize_columns(std::uint64_t, std::uint64_t, MatrixView,
                             Workspace&) const override;

 private:
  std::uint64_t row_count_{0};
  std::uint64_t column_count_{0};
  std::vector<std::uint64_t> column_offsets_{};
  std::vector<std::uint64_t> row_indices_{};
  std::vector<double> values_{};
  Status status_{};
};

// Column-wise concatenation [F1 F2 ...]. Child execution is sequential and
// deterministic; shared immutable ownership preserves child lifetimes.
class GSOLVE_EXPORT CompositeRectangularOperator final
    : public RectangularOperator {
 public:
  explicit CompositeRectangularOperator(
      std::vector<std::shared_ptr<const RectangularOperator>> blocks);
  [[nodiscard]] std::uint64_t row_count() const noexcept override {
    return row_count_;
  }
  [[nodiscard]] std::uint64_t column_count() const noexcept override {
    return column_count_;
  }
  [[nodiscard]] std::uint64_t block_count() const noexcept {
    return static_cast<std::uint64_t>(blocks_.size());
  }
  [[nodiscard]] const std::vector<std::uint64_t>& column_offsets()
      const noexcept {
    return column_offsets_;
  }
  [[nodiscard]] const Status& status() const noexcept override {
    return status_;
  }
  [[nodiscard]] bool concurrent_apply_supported() const noexcept override;
  Status prepare_workspace(std::uint64_t, Workspace&) const override;
  Status apply(ConstMatrixView, MatrixView, Workspace&) const override;
  Status apply_transpose(ConstMatrixView, MatrixView,
                         Workspace&) const override;
  Status materialize_columns(std::uint64_t, std::uint64_t, MatrixView,
                             Workspace&) const override;

 private:
  std::vector<std::shared_ptr<const RectangularOperator>> blocks_{};
  std::vector<std::uint64_t> column_offsets_{};
  std::uint64_t row_count_{0};
  std::uint64_t column_count_{0};
  Status status_{};
};

}  // namespace gsolve

#endif
