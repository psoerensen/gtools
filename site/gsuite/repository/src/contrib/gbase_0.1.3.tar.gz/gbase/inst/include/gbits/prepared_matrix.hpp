#ifndef GBITS_PREPARED_MATRIX_HPP
#define GBITS_PREPARED_MATRIX_HPP

#include <gbits/export.h>
#include <gbits/execution.hpp>
#include <gbits/genotype_transform.hpp>
#include <gbits/marker_statistics.hpp>

#include <cstdint>
#include <memory>
#include <vector>

namespace gbits {

class BedReader;
class PackedMatrix;

enum class PackedPlane : std::uint32_t {
    dosage_a = 0,
    dosage_b = 1,
    observed = 2
};

enum class PreparedCovarianceStrategy : std::uint32_t {
    scalar_reference = 0,
    fused_one_rhs = 1,
    batched_tiled = 2
};

// Borrowed immutable words for one prepared marker. The pointers remain valid
// while the owning PreparedBitMatrix lives. An absent observed plane means that
// every logical sample is observed; mask the unused bits in the final word.
struct PackedMarkerWords {
    const std::uint64_t* dosage_a{nullptr};
    const std::uint64_t* dosage_b{nullptr};
    const std::uint64_t* observed{nullptr};
    std::uint64_t word_count{0};
};

struct PreparedCovarianceDiagnostics {
    PreparedCovarianceStrategy strategy{
        PreparedCovarianceStrategy::scalar_reference};
    std::uint64_t marker_visits{0};
    std::uint64_t packed_decode_passes{0};
    std::uint64_t workspace_bytes{0};
    std::uint64_t right_hand_side_count{0};
    std::uint32_t requested_threads{1};
    std::uint32_t resolved_threads{1};
    double decode_seconds{0.0};
    double compute_seconds{0.0};
};

// Work for one shared-source multi-component packed traversal. Marker visits
// and decode passes count physical source traversals and therefore do not
// scale with component_count or right_hand_side_count.
struct PreparedMultiCovarianceDiagnostics {
    std::uint64_t marker_visits{0};
    std::uint64_t packed_decode_passes{0};
    std::uint64_t workspace_bytes{0};
    std::uint64_t right_hand_side_count{0};
    std::uint64_t component_count{0};
    std::uint32_t requested_threads{1};
    std::uint32_t resolved_threads{1};
    double decode_seconds{0.0};
    double compute_seconds{0.0};
};

// Immutable marker-major packed raw genotype matrix. Logical sample bit i is
// stored in word i / 64 at bit i % 64. Dosage is A + B for observed calls;
// dosage one canonically uses A=1, B=0.
class GBITS_API PreparedBitMatrix final {
public:
    struct ColumnRef {
        std::uint64_t source_index;
        std::uint64_t marker_index;
    };
    // Combine selected columns from prepared sources with the same ordered
    // samples. The returned matrix owns one packed copy in the requested order.
    static PreparedBitMatrix combine_columns(
        const std::vector<std::shared_ptr<const PreparedBitMatrix>>& sources,
        const std::vector<ColumnRef>& columns);
    PreparedBitMatrix(const PreparedBitMatrix& other);
    PreparedBitMatrix(PreparedBitMatrix&& other) noexcept;
    ~PreparedBitMatrix();

    PreparedBitMatrix& operator=(const PreparedBitMatrix&) = delete;
    PreparedBitMatrix& operator=(PreparedBitMatrix&&) = delete;

    std::uint64_t sample_count() const noexcept;
    std::uint64_t variant_count() const noexcept;
    std::uint64_t words_per_marker() const noexcept;

    // Return one immutable packed word. Both indices are zero-based.
    std::uint64_t word(PackedPlane plane, std::uint64_t logical_marker,
                       std::uint64_t word_index) const;

    // Borrow all word planes without per-word calls across the library boundary.
    // This is for marker-wise algorithms such as individual-level BLR.
    PackedMarkerWords marker_words(std::uint64_t logical_marker) const;

    // Return a source-independent facade sharing the same immutable storage.
    PackedMatrix packed_matrix() const;

    void marker_statistics(MarkerStatistics* output,
                           std::uint64_t output_length) const;
    std::vector<MarkerStatistics> marker_statistics() const;

    void xv(const GenotypeTransform& transform,
            const double* variant_values,
            std::uint64_t variant_values_length,
            double* output,
            std::uint64_t output_length) const;
    void xtv(const GenotypeTransform& transform,
             const double* sample_values,
             std::uint64_t sample_values_length,
             double* output,
             std::uint64_t output_length) const;
    void xmat(const GenotypeTransform& transform,
              const double* coefficients,
              std::uint64_t coefficients_length,
              std::uint64_t right_hand_side_count,
              std::uint64_t ldb,
              double* output,
              std::uint64_t output_length,
              std::uint64_t ldout) const;
    void xmat(const GenotypeTransform& transform,
              const double* coefficients,
              std::uint64_t coefficients_length,
              std::uint64_t right_hand_side_count,
              std::uint64_t ldb,
              const ExecutionConfig& execution,
              double* output,
              std::uint64_t output_length,
              std::uint64_t ldout) const;
    void xtmat(const GenotypeTransform& transform,
               const double* values,
               std::uint64_t values_length,
               std::uint64_t right_hand_side_count,
               std::uint64_t ldy,
               double* output,
               std::uint64_t output_length,
               std::uint64_t ldout) const;

    // Prepared weighted operations have the same formulas, logical ordering,
    // exact weight lengths, column-major layout, and failure atomicity as the
    // BedReader functions, but are safe for concurrent calls with independent
    // outputs because packed storage is immutable.
    void covariance(const GenotypeTransform& transform,
                    const double* marker_weights,
                    std::uint64_t marker_weights_length,
                    const double* values, std::uint64_t values_length,
                    std::uint64_t right_hand_side_count, std::uint64_t ldy,
                    const ExecutionConfig& execution, double* output,
                    std::uint64_t output_length, std::uint64_t ldout) const;
    void covariance(const GenotypeTransform& transform,
                    const double* marker_weights,
                    std::uint64_t marker_weights_length,
                    const double* values, std::uint64_t values_length,
                    std::uint64_t right_hand_side_count, std::uint64_t ldy,
                    const ExecutionConfig& execution, double* output,
                    std::uint64_t output_length, std::uint64_t ldout,
                    PreparedCovarianceDiagnostics& diagnostics) const;

    // Applies every K_c = W diag(weights_c) W' / normalization_c to one
    // common n-by-r input. component_weights is marker_count-by-component_count
    // column-major. Output component c begins at c * component_stride and is
    // n-by-r column-major with leading dimension ldout.
    void covariance_components(
        const GenotypeTransform& transform, const double* component_weights,
        std::uint64_t component_weights_length,
        std::uint64_t component_count, std::uint64_t weight_leading_dimension,
        const double* normalizations, std::uint64_t normalization_count,
        const double* values, std::uint64_t values_length,
        std::uint64_t right_hand_side_count, std::uint64_t ldy,
        const ExecutionConfig& execution, double* output,
        std::uint64_t output_length, std::uint64_t ldout,
        std::uint64_t component_stride,
        PreparedMultiCovarianceDiagnostics& diagnostics) const;

    // Applies component c to its own n-by-r input and directly accumulates
    // sum_c K_c B_c. Input component c begins at c * component_stride.
    void covariance_component_sum(
        const GenotypeTransform& transform, const double* component_weights,
        std::uint64_t component_weights_length,
        std::uint64_t component_count, std::uint64_t weight_leading_dimension,
        const double* normalizations, std::uint64_t normalization_count,
        const double* component_values, std::uint64_t component_values_length,
        std::uint64_t right_hand_side_count, std::uint64_t ldy,
        std::uint64_t component_stride, const ExecutionConfig& execution,
        double* output, std::uint64_t output_length, std::uint64_t ldout,
        PreparedMultiCovarianceDiagnostics& diagnostics) const;

    // Applies K_c to a distinct n-by-r input B_c and returns every K_c B_c.
    // Inputs and outputs use component-major blocks. Shared packed sources are
    // decoded once across all components and RHS columns.
    void covariance_component_outputs(
        const GenotypeTransform& transform, const double* component_weights,
        std::uint64_t component_weights_length,
        std::uint64_t component_count, std::uint64_t weight_leading_dimension,
        const double* normalizations, std::uint64_t normalization_count,
        const double* component_values,
        std::uint64_t component_values_length,
        std::uint64_t right_hand_side_count, std::uint64_t ldy,
        std::uint64_t input_component_stride,
        const ExecutionConfig& execution, double* output,
        std::uint64_t output_length, std::uint64_t ldout,
        std::uint64_t output_component_stride,
        PreparedMultiCovarianceDiagnostics& diagnostics) const;

    // Computes all exact K_c diagonals in one packed traversal. Output is
    // sample_count-by-component_count column-major with leading dimension
    // ldout.
    void covariance_component_diagonals(
        const GenotypeTransform& transform, const double* component_weights,
        std::uint64_t component_weights_length,
        std::uint64_t component_count, std::uint64_t weight_leading_dimension,
        const double* normalizations, std::uint64_t normalization_count,
        const ExecutionConfig& execution, double* output,
        std::uint64_t output_length, std::uint64_t ldout,
        PreparedMultiCovarianceDiagnostics& diagnostics) const;

    // Computes Y' K_c Y and diag(K_c) for all components in one prepared
    // packed traversal. The implementation uses the marker-wise off-diagonal
    // HE identity and adds the retained diagonal contribution, so the returned
    // component moments are the full symmetric trait moments required by
    // projected matrix-free RHE. moments is component_count blocks of
    // trait_count-by-trait_count column-major matrices.
    void rhe_phenotype_moments(
        const GenotypeTransform& transform, const double* component_weights,
        std::uint64_t component_weights_length,
        std::uint64_t component_count, std::uint64_t weight_leading_dimension,
        const double* normalizations, std::uint64_t normalization_count,
        const double* residualized_phenotypes,
        std::uint64_t phenotype_length, std::uint64_t trait_count,
        std::uint64_t ldy, const ExecutionConfig& execution,
        double* moments, std::uint64_t moments_length,
        double* diagonals, std::uint64_t diagonals_length,
        std::uint64_t diagonal_leading_dimension,
        PreparedMultiCovarianceDiagnostics& diagnostics) const;
    void normal_equation(const GenotypeTransform& transform,
                         const double* sample_weights,
                         std::uint64_t sample_weights_length,
                         const double* marker_diagonal,
                         std::uint64_t marker_diagonal_length,
                         const double* coefficients,
                         std::uint64_t coefficients_length,
                         std::uint64_t right_hand_side_count,
                         std::uint64_t ldb,
                         const ExecutionConfig& execution, double* output,
                         std::uint64_t output_length,
                         std::uint64_t ldout) const;
    void covariance_diagonal(const GenotypeTransform& transform,
                             const double* marker_weights,
                             std::uint64_t marker_weights_length,
                             const ExecutionConfig& execution, double* output,
                             std::uint64_t output_length) const;
    double covariance_trace(const GenotypeTransform& transform,
                            const double* marker_weights,
                            std::uint64_t marker_weights_length,
                            const ExecutionConfig& execution) const;
    void normal_diagonal(const GenotypeTransform& transform,
                         const double* sample_weights,
                         std::uint64_t sample_weights_length,
                         const double* marker_diagonal,
                         std::uint64_t marker_diagonal_length,
                         const ExecutionConfig& execution, double* output,
                         std::uint64_t output_length) const;
    void xtmat(const GenotypeTransform& transform,
               const double* values,
               std::uint64_t values_length,
               std::uint64_t right_hand_side_count,
               std::uint64_t ldy,
               const ExecutionConfig& execution,
               double* output,
               std::uint64_t output_length,
               std::uint64_t ldout) const;

private:
    struct Impl;
    explicit PreparedBitMatrix(std::shared_ptr<const Impl> implementation);

    std::shared_ptr<const Impl> implementation_;

    friend class BedReader;
};

} // namespace gbits

#endif
