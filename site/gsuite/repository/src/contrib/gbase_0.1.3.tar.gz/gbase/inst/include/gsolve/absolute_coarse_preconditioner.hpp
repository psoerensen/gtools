#ifndef GSOLVE_ABSOLUTE_COARSE_PRECONDITIONER_HPP
#define GSOLVE_ABSOLUTE_COARSE_PRECONDITIONER_HPP
#include "gsolve/preconditioner.hpp"
namespace gsolve {
struct AbsoluteCoarseOptions {
  std::uint64_t maximum_storage_bytes{512ULL * 1024 * 1024};
  double rank_tolerance{1e-12}, minimum_relative_eigenvalue{1e-12};
};
// For symmetric, possibly indefinite A. E=Z'AZ must be nonsingular.
// B=(I-Z E^-1 Z'A) B0 (I-AZ E^-1 Z') + Z |E|^-1 Z'.
// B remains SPD for an SPD B0. No operator regularization; near-zero E fails.
class GSOLVE_EXPORT AbsoluteCoarsePreconditioner final : public Preconditioner {
public:
  AbsoluteCoarsePreconditioner(std::shared_ptr<const LinearOperator>,
                               std::shared_ptr<const Preconditioner>,
                               ConstMatrixView, AbsoluteCoarseOptions = {});
  const Status &validation_status() const noexcept { return status_; }
  std::uint64_t dimension() const noexcept override { return n_; }
  std::uint64_t coarse_rank() const noexcept { return rank_; }
  bool concurrent_apply_supported() const noexcept override;
  bool compatible_with(const LinearOperator &) const noexcept override;
  Status prepare_workspace(std::uint64_t, Workspace &) const override;
  Status apply(ConstMatrixView, MatrixView, Workspace &) const override;

private:
  std::shared_ptr<const LinearOperator> a_;
  std::shared_ptr<const Preconditioner> base_;
  std::uint64_t n_{0}, rank_{0}, budget_{0};
  std::vector<double> z_, az_, signed_inverse_, absolute_inverse_;
  Status status_{};
};
// Disjoint normalized indicator basis encoded by one label per coefficient.
// Retains O(N+r^2), not N*r. Empty labels are dropped. In balanced mode AZ is
// recomputed in two operator applications per apply; additive mode uses
// B0 + Z|E|^-1Z' without extra operator passes. Both are SPD.
class GSOLVE_EXPORT PartitionAbsoluteCoarsePreconditioner final
    : public Preconditioner {
public:
  PartitionAbsoluteCoarsePreconditioner(std::shared_ptr<const LinearOperator>,
                                        std::shared_ptr<const Preconditioner>,
                                        std::vector<std::uint64_t> labels,
                                        std::uint64_t input_rank,
                                        bool balanced = false,
                                        AbsoluteCoarseOptions = {});
  const Status &validation_status() const noexcept { return status_; }
  std::uint64_t dimension() const noexcept override { return labels_.size(); }
  std::uint64_t coarse_rank() const noexcept { return rank_; }
  bool concurrent_apply_supported() const noexcept override;
  bool compatible_with(const LinearOperator &) const noexcept override;
  Status prepare_workspace(std::uint64_t, Workspace &) const override;
  Status apply(ConstMatrixView, MatrixView, Workspace &) const override;

private:
  std::shared_ptr<const LinearOperator> a_;
  std::shared_ptr<const Preconditioner> base_;
  std::vector<std::uint64_t> labels_;
  std::vector<double> normalization_, signed_, absolute_;
  std::uint64_t rank_{0}, budget_{0};
  bool balanced_;
  Status status_{};
};
} // namespace gsolve
#endif
