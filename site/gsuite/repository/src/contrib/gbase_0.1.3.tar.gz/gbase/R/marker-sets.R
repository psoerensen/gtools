#' Extract chromosome marker sets from a reference
#'
#' Groups marker names by their chromosome labels using existing metadata only,
#' without opening genotype or LD files.
#' @param Glist Reference containing aligned file-wise rsids and chr vectors.
#' @return A named list of disjoint marker-ID vectors covering the reference.
#'   Chromosomes and markers retain their first-occurrence/reference order.
#' @export
getChromosomeSets <- function(Glist) {
  fields <- c("rsids","chr")
  if (!is.list(Glist) || !all(fields %in% names(Glist)) ||
      !all(vapply(Glist[fields],is.list,logical(1))) ||
      !identical(unname(lengths(Glist$rsids)),unname(lengths(Glist$chr))))
    .gbase_stop("Glist must contain aligned file-wise rsids and chr.")
  markers <- unlist(Glist$rsids,use.names=FALSE)
  chromosome <- as.character(unlist(Glist$chr,use.names=FALSE))
  if (!is.character(markers) || !length(markers) || anyNA(markers) ||
      any(!nzchar(markers)) || anyDuplicated(markers) || anyNA(chromosome) ||
      any(!nzchar(chromosome)))
    .gbase_stop("Glist marker IDs must be unique and chromosome labels nonempty.")
  split(markers,factor(chromosome,levels=unique(chromosome)))
}
