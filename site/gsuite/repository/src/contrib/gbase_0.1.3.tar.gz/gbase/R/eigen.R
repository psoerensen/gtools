.gprep_eigen_sets <- function(Glist, sets) {
  if (!is.list(sets) || !length(sets) || is.null(names(sets)) ||
      anyNA(names(sets)) || any(!nzchar(names(sets))) || anyDuplicated(names(sets)))
    .gbase_stop("`sets` must be a nonempty uniquely named list of marker vectors.")
  markers <- unlist(Glist$rsids, use.names = FALSE)
  chromosomes <- unlist(Glist$chr, use.names = FALSE)
  members <- lapply(seq_along(sets), function(i) {
    members <- .gprep_selection(sets[[i]], paste0("sets$", names(sets)[i]))
    if (is.null(members)) .gbase_stop("An eigen region must contain markers: ", names(sets)[i])
    members
  })
  # Hash the reference once for the whole batch rather than once per gene.
  matched <- match(unlist(members, use.names = FALSE), markers)
  offsets <- c(0, cumsum(as.double(lengths(members))))
  locations <- lapply(seq_along(sets), function(i) {
    index <- matched[seq.int(offsets[i] + 1, offsets[i + 1L])]
    if (anyNA(index)) .gbase_stop("Unknown marker in region ", names(sets)[i], ": ", members[[i]][which(is.na(index))[1L]])
    index <- sort(index)
    if (length(unique(chromosomes[index])) != 1L)
      .gbase_stop("An eigen region must belong to one chromosome: ", names(sets)[i])
    as.double(index - 1L)
  })
  names(locations) <- names(sets)
  list(indices = locations, sets = lapply(locations, function(i) markers[i + 1L]))
}

.gprep_eigen <- function(Glist, sets, ids, rsids, threads, out_prefix, control) {
  validation_start <- proc.time()[[3L]]
  audited <- .gprep_validate(Glist)
  validation_seconds <- unname(proc.time()[[3L]] - validation_start)
  if (!is.null(rsids)) .gbase_stop("Use `sets`, rather than `rsids`, for task = 'eigen'.")
  if (!is.null(out_prefix)) .gbase_stop("task = 'eigen' stores spectra in Glist; save it with saveRDS().")
  threads <- .gprep_count(threads, "nthreads")
  control <- .gbase_eigen_control(control)
  matching_start <- proc.time()[[3L]]
  region <- .gprep_eigen_sets(Glist, sets)
  matching_seconds <- unname(proc.time()[[3L]] - matching_start)
  ids <- .gprep_selection(ids, "ids")
  reference_ids <- if (!is.null(ids)) ids else if (!is.null(Glist$study_ids)) Glist$study_ids else Glist$ids
  rows <- match(reference_ids, Glist$ids)
  if (anyNA(rows) || length(rows) < 2L)
    .gbase_stop("Eigen preparation requires at least two known reference samples.")
  dimensions <- pmin(length(reference_ids), lengths(region$sets))
  if (any(dimensions > control$maximum_dimension))
    .gbase_stop("Region eigensystem exceeds maximum_dimension: ", names(sets)[which(dimensions > control$maximum_dimension)[1L]])
  active <- which(lengths(Glist$rsids) > 0L)
  families <- audited$resources[[1L]]$samples$family_id[rows]
  native <- cpp_gbase_bed_spectra(.gprep_paths(audited$resources[active]),
    families, reference_ids, unname(Glist$rsids[active]), unname(region$indices),
    threads, control$maximum_dimension, control$symmetry_tolerance,
    control$verification_tolerance)
  names(native) <- names(region$sets)
  Glist$eigen <- list(version = 1L, sets = region$sets,
    values = lapply(native, `[[`, "values"),
    diagnostics = lapply(native, `[[`, "diagnostics"),
    timings_seconds = list(validation = validation_seconds, matching = matching_seconds,
      panel_setup = attr(native, "panel_setup_seconds")),
    sample_ids = reference_ids, sample_indices_0based = as.double(rows - 1L),
    n = length(reference_ids), nthreads = threads,
    eigen_control = control,
    provenance = list(source = "BED", correlation = "full within-region signed correlation",
      missing = "observed-mean imputation", normalization = "centred unit-norm columns",
      windows = "none", r2_threshold = 0, eigenvalues_only = TRUE,
      ordering = "descending; regions and markers retain their stored identities",
      clipping = "none; sample-space null eigenvalues are padded with exact zeros",
      threads = "local BED decoding; regions are processed sequentially",
      native_versions = gbase_native_info()))
  Glist
}

.gprep_validate_eigen <- function(Glist) {
  saved <- Glist$eigen
  required <- c("version", "sets", "values", "diagnostics", "sample_ids", "sample_indices_0based",
    "n", "nthreads", "eigen_control", "provenance")
  if (!is.list(saved) || length(setdiff(required, names(saved))) || !identical(saved$version, 1L))
    .gbase_stop("Glist eigen preparation is missing or has an unsupported version.")
  region <- .gprep_eigen_sets(Glist, saved$sets)
  ids <- .gprep_selection(saved$sample_ids, "eigen$sample_ids")
  if (is.null(ids) || length(ids) < 2L || !identical(as.double(saved$n), as.double(length(ids))) ||
      !identical(saved$sample_indices_0based, as.double(match(ids, Glist$ids) - 1L)) ||
      anyNA(saved$sample_indices_0based))
    .gbase_stop("Glist eigen sample identity is inconsistent.")
  .gprep_count(saved$nthreads, "eigen$nthreads")
  .gbase_eigen_control(saved$eigen_control)
  if (!identical(saved$sets, region$sets) || !is.list(saved$values) ||
      !identical(names(saved$values), names(saved$sets)) ||
      !is.list(saved$diagnostics) || !identical(names(saved$diagnostics), names(saved$sets)))
    .gbase_stop("Glist eigen region identity is inconsistent.")
  for (name in names(saved$sets)) {
    values <- saved$values[[name]]
    if (!is.numeric(values) || length(values) != length(saved$sets[[name]]) ||
        anyNA(values) || any(!is.finite(values)) || is.unsorted(-values))
      .gbase_stop("Glist eigen spectrum is invalid for region: ", name)
  }
  invisible(saved)
}
