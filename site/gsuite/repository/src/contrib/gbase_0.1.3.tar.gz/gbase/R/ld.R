.gbase_ld <- function(Glist) {
  validate_Glist(Glist)
  if (is.null(Glist$sparseLD))
    .gbase_stop("`Glist` has no sparse LD; use gprep(Glist, task = 'sparseld').")
  Glist$sparseLD
}

.gbase_block_table <- function(blocks, marker_ids, chromosomes) {
  required <- c("block_id", "first_marker", "last_marker")
  if (!is.data.frame(blocks) || !all(required %in% names(blocks)) || !nrow(blocks))
    .gbase_stop("`blocks` must contain block_id, first_marker, and last_marker columns.")
  id <- as.character(blocks$block_id)
  first <- as.character(blocks$first_marker)
  last <- as.character(blocks$last_marker)
  if (anyNA(id) || any(!nzchar(id)) || anyDuplicated(id) || anyNA(first) ||
      anyNA(last) || any(!nzchar(first)) || any(!nzchar(last)))
    .gbase_stop("Block and boundary marker IDs must be unique and nonempty.")
  begin <- match(first, marker_ids)
  end <- match(last, marker_ids)
  if (anyNA(begin) || anyNA(end) || any(begin > end))
    .gbase_stop("Every block boundary must identify an ordered sparse-LD marker.")
  if (begin[1L] != 1L || end[length(end)] != length(marker_ids) ||
      (length(begin) > 1L && any(begin[-1L] != end[-length(end)] + 1L)))
    .gbase_stop("LD blocks must be an ordered, non-overlapping, exhaustive partition.")
  chr <- vapply(seq_along(begin), function(i) {
    values <- unique(chromosomes[begin[i]:end[i]])
    if (length(values) != 1L) .gbase_stop("An LD block cannot cross chromosomes.")
    values
  }, character(1))
  data.frame(block_id = id, chromosome = chr, first_marker = first,
    last_marker = last, marker_count = as.integer(end - begin + 1L),
    begin_0based = as.double(begin - 1L), end_0based = as.double(end),
    stringsAsFactors = FALSE)
}

#' Define verified independent LD blocks
#' @param Glist A prepared Glist augmented by `gprep(task = "sparseld")`.
#' @param blocks A data frame with unique `block_id`, `first_marker`, and
#'   `last_marker` columns in sparse-LD reference order. Blocks must form an
#'   exhaustive contiguous partition and cannot cross chromosomes.
#' @return `Glist` with a serializable `ldBlocks` manifest. The sparse payload
#'   is scanned once to reject retained cross-block correlations.
#' @export
define_ld_blocks <- function(Glist, blocks) {
  resource <- .gbase_ld(Glist)
  table <- .gbase_block_table(blocks, resource$marker_metadata$marker_id,
    as.character(resource$marker_metadata$chromosome))
  offsets <- c(table$begin_0based, tail(table$end_0based, 1L))
  cpp_gbase_verify_ld_blocks(resource$prefix, offsets)
  Glist$ldBlocks <- list(schema_version = 1L, blocks = table,
    offsets_0based = offsets, sparse_ld_checksums = resource$checksums)
  validate_Glist(Glist)
  Glist
}

.gbase_annotations <- function(annotation, marker_ids) {
  if (is.data.frame(annotation)) {
    if (.row_names_info(annotation, type = 1L) < 0L)
      .gbase_stop("`annotation` must have explicit marker IDs as row names.")
    valid <- vapply(annotation, function(x)
      (is.numeric(x) || is.integer(x) || is.logical(x)) && !is.factor(x), logical(1))
    if (!all(valid)) .gbase_stop("Every annotation column must be numeric, integer, or logical.")
    values <- as.matrix(annotation)
  } else if (is.matrix(annotation) && (is.numeric(annotation) || is.logical(annotation))) {
    values <- annotation
  } else .gbase_stop("`annotation` must be a numeric matrix or data frame.")
  storage.mode(values) <- "double"
  ids <- rownames(values); labels <- colnames(values)
  if (!nrow(values) || !ncol(values)) .gbase_stop("`annotation` must have at least one marker and one column.")
  if (is.null(ids) || anyNA(ids) || any(!nzchar(ids)) || anyDuplicated(ids))
    .gbase_stop("Annotation marker IDs must be explicit, unique, and nonempty.")
  if (is.null(labels) || anyNA(labels) || any(!nzchar(labels)) || anyDuplicated(labels))
    .gbase_stop("Annotation names must be unique and nonempty.")
  if (any(!is.finite(values))) .gbase_stop("Annotation values must be finite.")
  missing <- setdiff(marker_ids, ids); extra <- setdiff(ids, marker_ids)
  if (length(missing) || length(extra) || length(ids) != length(marker_ids))
    .gbase_stop("Annotation marker IDs must exactly match the sparse-LD markers.")
  list(values = values, marker_ids = ids, annotation_names = labels)
}

#' Compute ordinary, corrected, or annotation-specific LD scores
#' @param Glist A prepared Glist augmented by `gprep(task = "sparseld")`.
#' @param annotation Optional marker-named numeric matrix or data frame.
#' @param corrected Apply the finite-reference-sample correction.
#' @return A named vector, or a marker-by-annotation matrix.
#' @export
ld_scores <- function(Glist, annotation = NULL, corrected = FALSE) {
  resource <- .gbase_ld(Glist)
  corrected <- .gprep_flag(corrected, "corrected")
  if (is.null(annotation) && !corrected) {
    scores <- unlist(Glist$ldscores, use.names = FALSE)
    names(scores) <- unlist(Glist$rsidsLD, use.names = FALSE)
    return(scores)
  }
  if (is.null(annotation))
    return(cpp_gbase_ld_scores(resource$prefix, corrected, NULL, character(), character()))
  parsed <- .gbase_annotations(annotation, resource$marker_metadata$marker_id)
  cpp_gbase_ld_scores(resource$prefix, corrected, parsed$values,
    parsed$marker_ids, parsed$annotation_names)
}

.gbase_region <- function(Glist, markers) {
  resource <- .gbase_ld(Glist)
  if (!is.character(markers) || !length(markers) || anyNA(markers) ||
      any(!nzchar(markers)) || anyDuplicated(markers))
    .gbase_stop("`markers` must be nonempty unique marker IDs in reference order.")
  indices <- match(markers, resource$marker_metadata$marker_id)
  if (anyNA(indices) || is.unsorted(indices, strictly = TRUE))
    .gbase_stop("Region markers must exist and follow reference order.")
  list(resource = resource, indices = as.double(indices - 1L))
}

.gbase_eigen_control <- function(control) {
  defaults <- list(maximum_dimension = 2048, symmetry_tolerance = 64 * .Machine$double.eps,
    verification_tolerance = 1e-10)
  if (!is.list(control) || (length(control) && (is.null(names(control)) ||
      anyDuplicated(names(control)) || any(!names(control) %in% names(defaults)))))
    .gbase_stop("Unknown or unnamed eigen_control setting.")
  defaults[names(control)] <- control
  for (name in names(defaults)) {
    value <- defaults[[name]]
    if (!is.numeric(value) || length(value) != 1L || !is.finite(value) || value <= 0)
      .gbase_stop("Eigensystem controls must be positive finite numbers.")
    defaults[[name]] <- as.double(value)
  }
  if (defaults$maximum_dimension != floor(defaults$maximum_dimension) ||
      defaults$maximum_dimension > .Machine$integer.max)
    .gbase_stop("maximum_dimension must be a positive integer within R matrix limits.")
  defaults
}

#' Extract a regional LD matrix in sparse-LD reference order
#' @param Glist A prepared Glist augmented by `gprep(task = "sparseld")`.
#' @param markers Unique marker IDs in reference order.
#' @param maximum_dimension Maximum number of selected markers.
#' @return A named dense LD matrix. Omitted sparse entries are zero.
#' @export
ld_region <- function(Glist, markers, maximum_dimension = 2048) {
  region <- .gbase_region(Glist, markers)
  control <- .gbase_eigen_control(list(maximum_dimension = maximum_dimension))
  cpp_gbase_ld_region(region$resource$prefix, region$indices,
    control$maximum_dimension, FALSE, control$symmetry_tolerance,
    control$verification_tolerance)$matrix
}

#' Compute a complete verified regional LD eigensystem
#' @inheritParams ld_region
#' @param eigen_control Named maximum-dimension and numerical verification settings.
#' @return Descending eigenvalues, column eigenvectors, and native diagnostics.
#' @export
ld_eigen <- function(Glist, markers, eigen_control = list()) {
  region <- .gbase_region(Glist, markers)
  control <- .gbase_eigen_control(eigen_control)
  cpp_gbase_ld_region(region$resource$prefix, region$indices,
    control$maximum_dimension, TRUE, control$symmetry_tolerance,
    control$verification_tolerance)
}
