#' Impute missing marker-by-trait Z-scores onto a reference backbone
#' @param Glist Prepared BED reference, with optional ancestry reference_groups.
#' @param stat Summary data frame, numeric marker-by-trait matrix, or gact z/n list.
#' @param columns Data-frame Z-score columns; defaults to z/stat, or derives z from b/seb.
#' @param ancestry Ancestry per trait; defaults to the ancestry attribute of stat.
#' @param ancestry_weights Named nonnegative weights summing to one, or a group-by-trait matrix.
#'   Weights are squared standardized meta-analysis coefficients, constant across markers.
#' @param lambda Positive ridge adjustment to reference LD.
#' @param r2 Minimum predicted imputation quality.
#' @param window,buffer Core window and flanking context in base pairs.
#' @param max_markers Bound on decoded markers; dense windows have shorter buffers.
#' @param nthreads Local genotype-decoding threads.
#' @return Input format in eligible Glist order, with an imputation attribute
#'   containing quality, imputed indicators and settings. Auxiliary fields are not invented.
#' @details Uses full local BED correlation. Missing scores are W z / sqrt(q),
#'   W = R_mt (R_tt + lambda I)^-1, q = diag(W (R_tt + lambda I) W').
#'   Ancestry mixtures use sum(w_a R_a) for independent, standardized meta-analysis
#'   scores with constant coefficients; local admixture and changing study overlap are not modeled.
#' @references Pasaniuc et al. (2014), doi:10.1093/bioinformatics/btu416.
#' @export
impute <- function(Glist, stat, columns = NULL, ancestry = NULL, ancestry_weights = NULL,
    lambda = .1, r2 = .6, window = 1000000, buffer = 250000, max_markers = 2048L, nthreads = 1L) {
  validate_Glist(Glist)
  input <- .gbase_summary_input(Glist, stat, columns, harmonize = FALSE)
  .gbase_summary_run(Glist, input, ancestry, ancestry_weights, FALSE, TRUE,
    rep(TRUE, nrow(input$z)), NULL, list(), list(lambda = lambda, r2 = r2,
      window = window, buffer = buffer, max_markers = max_markers), nthreads)
}

.gbase_summary_input <- function(Glist, stat, columns = NULL, harmonize = TRUE) {
  marker <- unlist(Glist$rsids, use.names = FALSE)
  metadata <- attr(stat, "marker_alleles", exact = TRUE)
  frame <- is.data.frame(stat); container <- is.list(stat) && !frame
  ancestry <- attr(stat, "ancestry", exact = TRUE)
  weights <- attr(stat, "ancestry_weights", exact = TRUE)
  study <- attr(stat, "study_id", exact = TRUE)
  if (frame) {
    original_names <- names(stat); stat <- .check_stat_names(stat)
    if (!is.null(columns)) columns <- unname(stats::setNames(names(stat), original_names)[columns])
    if (is.null(columns)) columns <- intersect("stat", names(stat))
    if (!length(columns) && all(c("b", "seb") %in% names(stat))) {
      stat$stat <- stat$b / stat$seb; columns <- "stat"
    }
    if (!is.character(stat$rsids) || !is.character(columns) || !length(columns) ||
        anyNA(columns) || anyDuplicated(columns) || any(!columns %in% names(stat)) ||
        any(!vapply(stat[columns], is.numeric, logical(1))))
      .gbase_stop("Data-frame statistics require rsids and numeric Z-score columns.")
    ids <- stat$rsids; z <- as.matrix(stat[columns])
    metadata <- stat[intersect(c("rsids", "chr", "pos", "ea", "nea"), names(stat))]
    if (length(columns) == 1L && length(study) == 1L) colnames(z) <- study
  } else {
    if (!is.null(columns)) .gbase_stop("`columns` applies only to a data frame.")
    z <- if (container) stat$z else stat
    if (!is.matrix(z) || !is.numeric(z) || !ncol(z))
      .gbase_stop("Supply a numeric Z-score matrix, summary data frame or list containing z.")
    ids <- rownames(z)
  }
  if (is.null(ids) || anyNA(ids) || any(!nzchar(ids))) .gbase_stop("Statistic marker IDs must be nonempty.")
  if (any(!is.finite(z) & !is.na(z))) .gbase_stop("Z-scores contain an infinite value.")
  if (is.null(colnames(z))) colnames(z) <- paste0("Trait", seq_len(ncol(z)))
  if (anyNA(colnames(z)) || any(!nzchar(colnames(z))) || anyDuplicated(colnames(z)))
    .gbase_stop("Trait column names must be unique and nonempty.")
  at <- match(ids, marker)
  if (!is.null(metadata) && all(c("rsids", "chr", "pos", "ea", "nea") %in% names(metadata))) {
    md <- match(ids, metadata$rsids); unknown <- is.na(at) & !is.na(md)
    if (any(unknown)) {
      refkey <- paste(unlist(Glist$chr, use.names = FALSE), unlist(Glist$pos, use.names = FALSE),
        unlist(Glist$a1, use.names = FALSE), unlist(Glist$a2, use.names = FALSE), sep = "_")
      key <- function(swap) paste(metadata$chr[md[unknown]], metadata$pos[md[unknown]],
        toupper(metadata[[if (swap) "nea" else "ea"]][md[unknown]]),
        toupper(metadata[[if (swap) "ea" else "nea"]][md[unknown]]), sep = "_")
      exact <- match(key(FALSE), refkey); reversed <- match(key(TRUE), refkey)
      exact[is.na(exact)] <- reversed[is.na(exact)]; at[unknown] <- exact
    }
  }
  known <- !is.na(at)
  if (!any(known)) .gbase_stop("No statistic markers map to Glist.")
  ids <- ids[known]; at <- at[known]; z <- z[known, , drop = FALSE]
  if (frame) stat <- stat[known, , drop = FALSE]
  if (anyDuplicated(at)) .gbase_stop("Mapped statistic marker IDs are duplicated.")
  swapped <- rep(FALSE, length(at)); allele_checked <- FALSE
  if (!is.null(metadata) && any(c("ea", "nea") %in% names(metadata))) {
    if (!all(c("rsids", "ea", "nea") %in% names(metadata))) .gbase_stop("Allele metadata requires rsids, ea and nea.")
    allele_checked <- TRUE
    md <- match(ids, metadata$rsids)
    a1 <- toupper(unlist(Glist$a1, use.names = FALSE)[at]); a2 <- toupper(unlist(Glist$a2, use.names = FALSE)[at])
    ea <- toupper(metadata$ea[md]); nea <- toupper(metadata$nea[md])
    exact <- !is.na(ea) & !is.na(nea) & ea == a1 & nea == a2
    swapped <- !is.na(ea) & !is.na(nea) & ea == a2 & nea == a1
    observed <- rowSums(!is.na(z)) > 0L
    if (any(observed & !exact & !swapped)) .gbase_stop("Summary and reference alleles disagree.")
    if (!harmonize && any(observed & swapped)) .gbase_stop("Observed scores must use Glist a1; harmonize with checkStat first.")
    if (all(c("chr", "pos") %in% names(metadata))) {
      ok <- as.character(metadata$chr[md]) == as.character(unlist(Glist$chr, use.names = FALSE)[at]) &
        metadata$pos[md] == unlist(Glist$pos, use.names = FALSE)[at]
      if (any(observed & (is.na(ok) | !ok))) .gbase_stop("Summary and reference coordinates disagree.")
    }
    if (harmonize) z[swapped, ] <- -z[swapped, , drop = FALSE]
  }
  if (frame && harmonize) {
    for (name in intersect(c("b", "score"), names(stat))) stat[[name]][swapped] <- -stat[[name]][swapped]
    if ("eaf" %in% names(stat)) stat$eaf[swapped] <- 1 - stat$eaf[swapped]
  }
  aligned <- matrix(NA_real_, length(marker), ncol(z), dimnames = list(marker, colnames(z)))
  aligned[at, ] <- z
  if (frame) {
    out <- stat[match(seq_along(marker), at), , drop = FALSE]; rownames(out) <- marker
    ref <- list(rsids = marker, chr = unlist(Glist$chr, use.names = FALSE), pos = unlist(Glist$pos, use.names = FALSE),
      ea = unlist(Glist$a1, use.names = FALSE), nea = unlist(Glist$a2, use.names = FALSE))
    for (name in names(ref)) out[[name]] <- ref[[name]]
  } else if (container) {
    out <- stat
    for (name in setdiff(names(out), "z")) if (is.matrix(out[[name]])) {
      value <- out[[name]]; rows <- rownames(value)
      if (is.null(rows) || anyNA(rows) || anyDuplicated(rows)) .gbase_stop("Auxiliary matrices need unique marker row names.")
      mapped <- match(rows, ids)
      rows[!is.na(mapped)] <- marker[at[mapped[!is.na(mapped)]]]
      if (anyDuplicated(rows)) .gbase_stop("Mapped auxiliary marker IDs are duplicated.")
      if (name %in% c("b", "seb", "p", "n", "eaf", "info")) {
        if (!is.numeric(value) || any(!is.finite(value) & !is.na(value)))
          .gbase_stop("Invalid auxiliary matrix: ", name)
        if (name %in% c("seb", "n") && any(value <= 0, na.rm = TRUE))
          .gbase_stop(name, " must be positive.")
        if (name %in% c("p", "eaf", "info") && any(value < 0 | value > 1, na.rm = TRUE))
          .gbase_stop(name, " must lie in [0, 1].")
        if (is.null(colnames(value)) || anyDuplicated(colnames(value)) ||
            !setequal(colnames(value), colnames(z))) .gbase_stop("Auxiliary trait columns disagree with z.")
        value <- value[, colnames(z), drop = FALSE]
      }
      out[[name]] <- value[match(marker, rows), , drop = FALSE]; rownames(out[[name]]) <- marker
      if (harmonize && name == "b") out[[name]][at[swapped], ] <- -out[[name]][at[swapped], , drop = FALSE]
    }
    out$z <- aligned
  } else out <- aligned
  list(z = aligned, template = out, frame = frame, container = container, columns = columns,
    ancestry = ancestry, weights = weights, study = study, present = seq_along(marker) %in% at,
    allele_alignment = if (allele_checked) "checked" else "assumed reference coding")
}

.gbase_summary_run <- function(Glist, input, ancestry, ancestry_weights, ldcheck,
    do_impute, eligible, reference_qc, ld_control, impute_control, nthreads) {
  groups <- .gbase_reference_groups(Glist)
  if (is.null(ancestry_weights) && is.null(ancestry)) ancestry_weights <- input$weights
  if (is.null(ancestry) && is.null(ancestry_weights)) ancestry <- input$ancestry
  weights <- .gbase_ancestry_weights(groups, colnames(input$z), ancestry, ancestry_weights)
  # Z-score covariance weights do not determine a meta-analysis allele frequency.
  if (!is.null(input$eaf)) input$eaf[, colSums(weights > 0) > 1L] <- NA_real_
  allowed <- c("iterations", "p_threshold", "rank_fraction", "seed", "max_pair_r2", "min_variance")
  if (!is.list(ld_control) || any(!names(ld_control) %in% allowed) ||
      length(ld_control) && (is.null(names(ld_control)) || anyDuplicated(names(ld_control)))) .gbase_stop("Unknown or unnamed ld_control setting.")
  qc <- utils::modifyList(list(iterations = 10L, p_threshold = 5e-8, rank_fraction = .5,
    seed = 1L, max_pair_r2 = .95, min_variance = 1e-6), ld_control)
  qc$iterations <- .gprep_count(qc$iterations, "iterations"); qc$seed <- .gprep_count(qc$seed, "seed", minimum = 0L)
  for (name in c("p_threshold", "rank_fraction", "max_pair_r2", "min_variance")) {
    qc[[name]] <- .gprep_number(qc[[name]], name)
    if (qc[[name]] <= 0 || qc[[name]] >= 1) .gbase_stop(name, " must be between zero and one.")
  }
  allowed <- c("lambda", "r2", "window", "buffer", "max_markers")
  if (!is.list(impute_control) || any(!names(impute_control) %in% allowed) ||
      length(impute_control) && (is.null(names(impute_control)) || anyDuplicated(names(impute_control)))) .gbase_stop("Unknown or unnamed impute_control setting.")
  controls <- utils::modifyList(list(lambda = .1, r2 = .6, window = 1000000, buffer = 250000, max_markers = 2048L), impute_control)
  for (name in c("lambda", "r2", "window", "buffer")) controls[[name]] <- .gprep_number(controls[[name]], name)
  if (!controls$lambda || !controls$window || controls$r2 > 1) .gbase_stop("Invalid imputation controls.")
  controls$max_markers <- .gprep_count(controls$max_markers, "max_markers", minimum = 2L); nthreads <- .gprep_count(nthreads, "nthreads")
  plans <- .gbase_imputation_windows(unlist(Glist$chr, use.names = FALSE), unlist(Glist$pos, use.names = FALSE),
    eligible, controls$window, controls$buffer, controls$max_markers)
  if (is.null(reference_qc)) reference_qc <- function(counts) rep(TRUE, length(counts$n0))
  fit <- cpp_gbase_summary_prepare(Glist$bedfiles, as.double(Glist$n), as.double(Glist$physical_marker_counts),
    lapply(groups, function(x) as.double(x - 1L)), as.integer(rep(seq_along(Glist$rsids) - 1L, lengths(Glist$rsids))),
    as.double(unlist(Glist$source_marker_indices_0based, use.names = FALSE)), input$z, plans, weights,
    reference_qc, if (is.null(input$eaf)) matrix(numeric(), 0L, 0L) else input$eaf,
    if (is.null(input$study_eligible)) matrix(logical(), 0L, 0L) else input$study_eligible,
    if (is.null(input$max_afdiff)) NA_real_ else input$max_afdiff,
    ldcheck, do_impute, controls$lambda, controls$r2, controls$max_markers, nthreads, qc)
  for (name in c("z", "r2", "imputed", "eligible", "p", "rejected")) dimnames(fit[[name]]) <- dimnames(input$z)
  rows <- eligible & rowSums(fit$eligible) > 0L; out <- input$template
  if (input$frame) {
    for (j in seq_along(input$columns)) out[[input$columns[j]]] <- fit$z[, j]
    changed <- rowSums(fit$imputed | fit$rejected) > 0L
    for (name in intersect(c("b", "seb", "p"), names(out))) out[[name]][changed] <- NA_real_
    out <- out[rows, , drop = FALSE]
  } else if (input$container) {
    for (name in names(out)) if (is.matrix(out[[name]]) && nrow(out[[name]]) == nrow(input$z)) {
      if (name %in% c("b", "seb", "p")) {
        at <- match(colnames(out[[name]]), colnames(input$z))
        if (anyNA(at)) .gbase_stop("Auxiliary trait columns disagree with z.")
        out[[name]][fit$imputed[, at, drop = FALSE] | fit$rejected[, at, drop = FALSE]] <- NA_real_
      }
      out[[name]] <- out[[name]][rows, , drop = FALSE]
    }
    out$z <- fit$z[rows, , drop = FALSE]
  } else out <- fit$z[rows, , drop = FALSE]
  settings <- c(controls, list(nthreads = nthreads, ancestry_weights = weights, reference_samples = lengths(groups),
    ld = "complete regional BED correlation", allele_alignment = input$allele_alignment))
  if (do_impute) attr(out, "imputation") <- list(r2 = fit$r2[rows, , drop = FALSE], imputed = fit$imputed[rows, , drop = FALSE],
    factorizations = fit$factorizations, settings = settings)
  if (ldcheck) {
    rejected_at <- which(fit$rejected, arr.ind = TRUE)
    original <- data.frame(rsids = rownames(input$z)[rejected_at[, 1L]], trait = colnames(input$z)[rejected_at[, 2L]],
      z = input$z[rejected_at], stringsAsFactors = FALSE)
    if (input$frame) for (name in intersect(c("b", "seb", "p", "n"), names(input$template)))
      original[[name]] <- input$template[[name]][rejected_at[, 1L]]
    attr(out, "ldcheck") <- list(p = fit$p[rows, , drop = FALSE], rejected = fit$rejected[rows, , drop = FALSE],
      original = original, settings = c(qc, settings), decompositions = fit$decompositions)
  }
  labels <- rownames(weights)[max.col(t(weights), ties.method = "first")]
  labels[colSums(weights > 0) > 1L] <- "Mixed"
  if (!is.null(ancestry)) labels <- if (!is.null(names(ancestry))) ancestry[colnames(input$z)] else rep(ancestry, length.out = ncol(input$z))
  attr(out, "ancestry") <- stats::setNames(labels, colnames(input$z))
  attr(out, "ancestry_weights") <- weights
  attr(out, "marker_alleles") <- NULL
  if (!is.null(input$study)) attr(out, "study_id") <- input$study
  out
}

.gbase_imputation_windows <- function(chr, pos, eligible, window, buffer, max_markers) {
  plans <- list()
  for (indices in split(which(eligible), chr[eligible])) {
    indices <- indices[order(pos[indices], indices)]; positions <- pos[indices]
    for (core in split(seq_along(indices), floor(positions / window))) {
      for (target in split(core, (seq_along(core) - 1L) %/% (max_markers %/% 2L))) {
        first <- findInterval(positions[target[1L]] - buffer, positions, left.open = TRUE) + 1L
        last <- findInterval(positions[tail(target, 1L)] + buffer, positions); spare <- max_markers - length(target)
        left <- min(target[1L] - first, spare %/% 2L); right <- min(last - tail(target, 1L), spare - left)
        left <- min(target[1L] - first, spare - right)
        context <- indices[seq.int(target[1L] - left, tail(target, 1L) + right)]
        plans[[length(plans) + 1L]] <- list(indices = as.integer(context - 1L), targets = as.integer(indices[target] - 1L))
      }
    }
  }
  plans
}
