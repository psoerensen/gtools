.gfilter_threshold <- function(value, name) {
  if (is.null(value)) return(NULL)
  if (!is.numeric(value) || length(value) != 1L || is.na(value) ||
      !is.finite(value) || value < 0 || value > 1)
    .gbase_stop("`", name, "` must be NULL or one finite number in [0, 1].")
  as.double(value)
}

.gfilter_logical <- function(value, name) {
  if (!is.logical(value) || length(value) != 1L || is.na(value))
    .gbase_stop("`", name, "` must be TRUE or FALSE.")
  value
}

.gfilter_exact_hwe_one <- function(n0, n1, n2) {
  total <- n0 + n1 + n2
  rare_copies <- 2 * min(n0, n2) + n1
  if (rare_copies == 0 || rare_copies == 2 * total) return(1)
  midpoint <- floor(rare_copies * (2 * total - rare_copies) / (2 * total))
  if ((rare_copies - midpoint) %% 2 != 0) midpoint <- midpoint + 1
  probabilities <- numeric(rare_copies + 1); probabilities[midpoint + 1] <- 1
  het <- midpoint; hom_rare <- (rare_copies - het) / 2
  hom_common <- total - het - hom_rare
  while (het >= 2) {
    probabilities[het - 1] <- probabilities[het + 1] * het * (het - 1) /
      (4 * (hom_rare + 1) * (hom_common + 1))
    het <- het - 2; hom_rare <- hom_rare + 1; hom_common <- hom_common + 1
  }
  het <- midpoint; hom_rare <- (rare_copies - het) / 2
  hom_common <- total - het - hom_rare
  while (het <= rare_copies - 2) {
    probabilities[het + 3] <- probabilities[het + 1] * 4 * hom_rare * hom_common /
      ((het + 2) * (het + 1))
    het <- het + 2; hom_rare <- hom_rare - 1; hom_common <- hom_common - 1
  }
  probabilities <- probabilities / sum(probabilities)
  observed <- probabilities[n1 + 1]
  min(1, sum(probabilities[probabilities <= observed * (1 + 1e-12)]))
}

.gfilter_info <- function(info, marker_ids) {
  if (is.numeric(info) && !is.list(info)) values <- info
  else if (is.list(info) && length(info) && all(vapply(info, is.numeric, logical(1))))
    values <- do.call(c, unname(info))
  else .gbase_stop("`Glist$info` must be a named numeric vector or list.")
  ids <- names(values)
  if (is.null(ids) || length(ids) != length(values) || anyNA(ids) ||
      any(!nzchar(ids)) || anyDuplicated(ids))
    .gbase_stop("`Glist$info` must have complete, unique marker-ID names.")
  if (length(values) != length(marker_ids) || length(setdiff(marker_ids, ids)) ||
      length(setdiff(ids, marker_ids)))
    .gbase_stop("`Glist$info` marker IDs do not match `Glist$rsids`.")
  values <- as.double(values[marker_ids])
  if (anyNA(values) || any(!is.finite(values)) || any(values < 0 | values > 1))
    .gbase_stop("`Glist$info` values must be finite numbers in [0, 1].")
  values
}

.gfilter_assembly <- function(assembly) {
  if (!is.character(assembly) || length(assembly) != 1L || is.na(assembly) || !nzchar(assembly))
    .gbase_stop("MHC filtering requires one supported nonempty assembly.")
  key <- toupper(assembly)
  if (!key %in% c("GRCH37", "GRCH38"))
    .gbase_stop("Unsupported assembly; MHC filtering supports GRCh37 and GRCh38.")
  if (key == "GRCH37") "GRCh37" else "GRCh38"
}

.gfilter_audit <- function(Glist, maf = 0.01, missing = 0.05, hwe = 1e-12,
    info = NULL, ambiguous = TRUE, indels = TRUE, mhc = FALSE, assembly = NULL) {
  maf <- .gfilter_threshold(maf, "maf"); missing <- .gfilter_threshold(missing, "missing")
  hwe <- .gfilter_threshold(hwe, "hwe"); info <- .gfilter_threshold(info, "info")
  ambiguous <- .gfilter_logical(ambiguous, "ambiguous")
  indels <- .gfilter_logical(indels, "indels"); mhc <- .gfilter_logical(mhc, "mhc")
  validate_Glist(Glist)
  required <- c("rsids", "maf", "nmiss", "n0", "n1", "n2", "a1", "a2", "chr", "pos")
  if (length(absent <- setdiff(required, names(Glist))))
    .gbase_stop("Prepared `Glist` is missing marker-summary fields: ", paste(absent, collapse = ", "), ".")
  provenance <- Glist$provenance$summary_samples
  if (!is.character(provenance) || length(provenance) != 1L || is.na(provenance) ||
      !provenance %in% c("all", "ids subset"))
    .gbase_stop("Prepared `Glist` lacks valid summary-sample provenance.")
  expected <- if (is.null(Glist$study_ids)) "all" else "ids subset"
  if (!identical(provenance, expected))
    .gbase_stop("Prepared `Glist` summary-sample provenance is inconsistent.")
  nchr <- length(Glist$rsids); marker_counts <- lengths(Glist$rsids)
  if (any(vapply(Glist[required], length, integer(1)) != nchr) ||
      any(vapply(Glist[required], function(x) !is.list(x) ||
        !identical(lengths(x), marker_counts), logical(1))))
    .gbase_stop("Prepared `Glist` marker-summary fields must match chromosome-wise marker counts.")
  if (!length(marker_counts) || sum(marker_counts) == 0L)
    .gbase_stop("Prepared `Glist` must contain at least one marker.")
  marker_id <- unlist(Glist$rsids, use.names = FALSE)
  chromosome <- unlist(Glist$chr, use.names = FALSE)
  position <- unlist(Glist$pos, use.names = FALSE)
  allele1 <- unlist(Glist$a1, use.names = FALSE); allele2 <- unlist(Glist$a2, use.names = FALSE)
  marker_maf <- unlist(Glist$maf, use.names = FALSE)
  counts <- lapply(c("n0", "n1", "n2", "nmiss"), function(x)
    unlist(Glist[[x]], use.names = FALSE)); names(counts) <- c("n0", "n1", "n2", "nmiss")
  if (!is.character(marker_id) || anyNA(marker_id) || any(!nzchar(marker_id)) || anyDuplicated(marker_id))
    .gbase_stop("Prepared `Glist` marker IDs must be complete and globally unique.")
  if (!is.character(chromosome) || anyNA(chromosome) || any(!nzchar(chromosome)))
    .gbase_stop("Prepared `Glist` chromosome labels must be complete and nonempty.")
  if (!is.numeric(position) || anyNA(position) || any(!is.finite(position)) ||
      any(position <= 0) || any(position != floor(position)))
    .gbase_stop("Prepared `Glist` positions must be finite positive integers.")
  if (!is.character(allele1) || !is.character(allele2) || anyNA(allele1) || anyNA(allele2) ||
      any(!nzchar(allele1)) || any(!nzchar(allele2)) || any(allele1 == allele2))
    .gbase_stop("Prepared `Glist` alleles must be complete, nonempty, and distinct.")
  if (!is.numeric(marker_maf) || anyNA(marker_maf) || any(!is.finite(marker_maf)) ||
      any(marker_maf < 0 | marker_maf > 0.5))
    .gbase_stop("Prepared `Glist` MAF values must be finite numbers in [0, 0.5].")
  for (field in names(counts)) if (!is.numeric(counts[[field]]) || anyNA(counts[[field]]) ||
      any(!is.finite(counts[[field]])) || any(counts[[field]] < 0) ||
      any(counts[[field]] != floor(counts[[field]])))
    .gbase_stop("`Glist$", field, "` must contain nonnegative integer counts.")
  summary_n <- length(Glist$sample_source_indices_0based)
  totals <- counts$n0 + counts$n1 + counts$n2 + counts$nmiss
  if (summary_n < 1L || any(totals != summary_n))
    .gbase_stop("Genotype counts do not equal the recorded summary-sample count.")
  observed <- counts$n0 + counts$n1 + counts$n2
  if (any(observed == 0)) .gbase_stop("A marker has no observed summary genotypes.")
  derived_maf <- pmin((2 * counts$n2 + counts$n1) / (2 * observed),
    1 - (2 * counts$n2 + counts$n1) / (2 * observed))
  if (any(abs(marker_maf - derived_maf) > 64 * .Machine$double.eps))
    .gbase_stop("Prepared `Glist` MAF values are inconsistent with genotype counts.")
  hwe_p <- vapply(seq_along(marker_id), function(i)
    .gfilter_exact_hwe_one(counts$n0[[i]], counts$n1[[i]], counts$n2[[i]]), numeric(1))
  info_value <- if (is.null(info)) rep(NA_real_, length(marker_id)) else {
    if (!"info" %in% names(Glist))
      .gbase_stop("`info` filtering requires a marker-aligned `Glist$info` field.")
    .gfilter_info(Glist$info, marker_id)
  }
  snp <- allele1 %in% c("A", "C", "G", "T") & allele2 %in% c("A", "C", "G", "T") &
    nchar(allele1) == 1L & nchar(allele2) == 1L
  exclude_mhc <- rep(FALSE, length(marker_id))
  if (mhc) {
    build <- .gfilter_assembly(if (is.null(assembly)) Glist$assembly else assembly)
    interval <- if (build == "GRCh37") c(28477797, 33448397) else c(28510120, 33480577)
    exclude_mhc <- chromosome %in% c("6", "chr6") & position >= interval[1] & position <= interval[2]
  }
  result <- data.frame(marker_id, chromosome, position = as.double(position), a1 = allele1,
    a2 = allele2, maf = as.double(marker_maf), missing_rate = as.double(counts$nmiss / totals),
    hwe_p = as.double(hwe_p), info = info_value, stringsAsFactors = FALSE, check.names = FALSE)
  result$exclude_maf <- if (is.null(maf)) FALSE else marker_maf <= maf
  result$exclude_missing <- if (is.null(missing)) FALSE else result$missing_rate > missing
  result$exclude_hwe <- if (is.null(hwe)) FALSE else !is.finite(hwe_p) | hwe_p < hwe
  result$exclude_info <- if (is.null(info)) FALSE else info_value < info
  result$exclude_ambiguous <- if (ambiguous) paste0(allele1, "/", allele2) %in%
    c("A/T", "T/A", "C/G", "G/C") else FALSE
  result$exclude_indel <- if (indels) !snp else FALSE
  result$exclude_mhc <- exclude_mhc
  result$excluded <- Reduce(`|`, result[paste0("exclude_", c("maf", "missing", "hwe", "info", "ambiguous", "indel", "mhc"))])
  result
}

#' Select markers using prepared genotype quality-control summaries
#' @param Glist A prepared Glist.
#' @param maf,missing,hwe,info Optional thresholds in `[0,1]`.
#' @param ambiguous,indels,mhc Logical exclusion controls.
#' @param assembly Optional `GRCh37` or `GRCh38` assembly for MHC filtering.
#' @param verbose Report overlapping and total exclusion counts.
#' @param excludeMAF,excludeMISS,excludeHWE,excludeINFO,excludeCGAT,excludeINDEL,excludeMHC
#'   Familiar aliases for maf, missing, hwe, info, ambiguous, indels and mhc.
#' @param excludeDUPS Familiar duplicate-exclusion flag. Prepared Glist marker
#'   IDs are already unique; TRUE adds no work and FALSE cannot restore duplicates.
#' @return Retained marker IDs in canonical file/BIM order.
#' @export
gfilter <- function(Glist, maf = 0.01, missing = 0.05, hwe = 1e-12,
    info = NULL, ambiguous = TRUE, indels = TRUE, mhc = FALSE,
    assembly = NULL, verbose = TRUE, excludeMAF = NULL, excludeMISS = NULL,
    excludeHWE = NULL, excludeINFO = NULL, excludeCGAT = NULL,
    excludeINDEL = NULL, excludeMHC = NULL, excludeDUPS = TRUE) {
  supplied <- names(match.call())[-1L]
  resolve <- function(value, alias, modern, familiar) {
    if (!familiar %in% supplied) return(value)
    if (modern %in% supplied)
      .gbase_stop("Specify either `", modern, "` or `", familiar, "`, not both.")
    alias
  }
  maf <- resolve(maf, excludeMAF, "maf", "excludeMAF")
  missing <- resolve(missing, excludeMISS, "missing", "excludeMISS")
  hwe <- resolve(hwe, excludeHWE, "hwe", "excludeHWE")
  info <- resolve(info, excludeINFO, "info", "excludeINFO")
  ambiguous <- resolve(ambiguous, excludeCGAT, "ambiguous", "excludeCGAT")
  indels <- resolve(indels, excludeINDEL, "indels", "excludeINDEL")
  mhc <- resolve(mhc, excludeMHC, "mhc", "excludeMHC")
  .gfilter_logical(excludeDUPS, "excludeDUPS")
  verbose <- .gfilter_logical(verbose, "verbose")
  audit <- .gfilter_audit(Glist, maf, missing, hwe, info, ambiguous, indels, mhc, assembly)
  if (verbose) {
    message(sprintf("Markers evaluated: %d", nrow(audit)))
    enabled <- c(maf = !is.null(maf), missing = !is.null(missing), hwe = !is.null(hwe),
      info = !is.null(info), ambiguous = ambiguous, indels = indels, mhc = mhc)
    columns <- c(maf = "exclude_maf", missing = "exclude_missing", hwe = "exclude_hwe",
      info = "exclude_info", ambiguous = "exclude_ambiguous", indels = "exclude_indel", mhc = "exclude_mhc")
    labels <- c(maf = "MAF", missing = "missingness", hwe = "HWE", info = "INFO",
      ambiguous = "ambiguity", indels = "indel/non-SNP", mhc = "MHC")
    for (criterion in names(enabled)[enabled])
      message(sprintf("Flagged by %s: %d", labels[[criterion]], sum(audit[[columns[[criterion]]]])))
    message(sprintf("Unique markers excluded: %d", sum(audit$excluded)))
    message(sprintf("Markers retained: %d", sum(!audit$excluded)))
    message("Per-criterion counts can overlap and need not sum to total excluded.")
  }
  audit$marker_id[!audit$excluded]
}
