#' Label ancestry reference samples without copying genotypes
#' @param Glist Prepared genotype reference.
#' @param groups Named list of sample-ID vectors or one-based integer indices
#'   into Glist$ids. Groups must be disjoint subsets of the prepared samples.
#' @return Glist with compact integer reference_groups. BED files are unchanged.
#' @export
setReferenceGroups <- function(Glist, groups) {
  validate_Glist(Glist)
  Glist$reference_groups <- .gbase_reference_groups(Glist, groups)
  Glist
}

.gbase_reference_groups <- function(Glist, groups = Glist$reference_groups) {
  prepared <- as.integer(Glist$sample_source_indices_0based + 1L)
  if (is.null(groups)) return(list(reference = prepared))
  if (!is.list(groups) || !length(groups) || is.null(names(groups)) ||
      anyNA(names(groups)) || any(!nzchar(names(groups))) || anyDuplicated(names(groups)))
    .gbase_stop("`reference_groups` must be a named list of sample selections.")
  groups <- lapply(groups, function(x) {
    if (is.character(x)) x <- match(x, Glist$ids)
    if (!is.numeric(x) || length(x) < 2L || anyNA(x) || any(!is.finite(x)) ||
        any(x != floor(x)) || any(!x %in% prepared) || anyDuplicated(x))
      .gbase_stop("Each reference group needs at least two unique prepared samples.")
    as.integer(x)
  })
  if (anyDuplicated(unlist(groups, use.names = FALSE)))
    .gbase_stop("Ancestry reference groups must be disjoint.")
  groups
}

.gbase_ancestry_weights <- function(groups, traits, ancestry, weights) {
  if (!is.null(weights) && !is.null(ancestry))
    .gbase_stop("Specify ancestry or ancestry_weights, not both.")
  if (!is.null(weights)) {
    if (is.numeric(weights) && is.null(dim(weights))) {
      if (is.null(names(weights))) .gbase_stop("Ancestry weights need group names.")
      weights <- matrix(weights, ncol = 1L, dimnames = list(names(weights), NULL))
      weights <- weights[, rep(1L, length(traits)), drop = FALSE]
      colnames(weights) <- traits
    }
    if (!is.matrix(weights) || !is.numeric(weights) || is.null(rownames(weights)) ||
        anyNA(weights) || any(!is.finite(weights)) || any(weights < 0) ||
        anyDuplicated(rownames(weights)) || any(!rownames(weights) %in% names(groups)) ||
        is.null(colnames(weights)) || anyDuplicated(colnames(weights)) ||
        !setequal(colnames(weights), traits))
      .gbase_stop("ancestry_weights must name reference groups and trait columns.")
    out <- matrix(0, length(groups), length(traits), dimnames = list(names(groups), traits))
    out[rownames(weights), ] <- weights[, traits, drop = FALSE]
    if (any(abs(colSums(out) - 1) > 1e-8)) .gbase_stop("Ancestry weights must sum to one per trait.")
    return(out)
  }
  if (is.null(ancestry)) {
    if (length(groups) != 1L) .gbase_stop("Choose an ancestry for every trait column.")
    ancestry <- rep(names(groups), length(traits))
  }
  if (!is.character(ancestry) || anyNA(ancestry) || any(!nzchar(ancestry)))
    .gbase_stop("Ancestry labels must be nonempty strings.")
  if (!is.null(names(ancestry))) {
    if (anyDuplicated(names(ancestry)) || any(!traits %in% names(ancestry)))
      .gbase_stop("Ancestry labels must name every trait column.")
    ancestry <- ancestry[traits]
  } else if (length(ancestry) == 1L) ancestry <- rep(ancestry, length(traits))
  if (length(ancestry) != length(traits)) .gbase_stop("Supply one ancestry per trait.")
  # A preselected, unlabelled single reference remains a supported old Glist.
  # It cannot serve columns declaring different ancestries.
  if (identical(names(groups), "reference") && length(unique(ancestry)) == 1L &&
      !toupper(ancestry[1L]) %in% c("MIXED", "ADMIXED", "UNKNOWN")) ancestry[] <- "reference"
  at <- match(ancestry, names(groups))
  if (anyNA(at)) .gbase_stop("Ancestry has no matching reference group; supply explicit mixture weights when needed.")
  out <- matrix(0, length(groups), length(traits), dimnames = list(names(groups), traits))
  out[cbind(at, seq_along(traits))] <- 1
  out
}
