#' Match named marker sets to a reference
#' @param sets List of marker-ID vectors; unnamed sets receive Set1, Set2, ... names.
#' @param rsids Reference marker IDs, in the desired order.
#' @param Glist Optional prepared reference overriding rsids.
#' @param index Return one-based indices rather than marker IDs.
#' @return Named list retaining each set's supplied member order and repetitions. Unknown members
#'   are dropped, as in qgg; empty sets remain visible.
#' @export
mapSets <- function(sets, rsids = NULL, Glist = NULL, index = TRUE) {
  if (!is.list(sets)) .gbase_stop("`sets` must be a list of marker vectors.")
  if (!is.null(Glist)) rsids <- unlist(Glist$rsids, use.names = FALSE)
  if (!is.character(rsids) || anyNA(rsids) || anyDuplicated(rsids) || any(!nzchar(rsids)))
    .gbase_stop("`rsids` must contain unique nonempty marker IDs.")
  index <- .gfilter_logical(index, "index")
  if (is.null(names(sets))) names(sets) <- paste0("Set", seq_along(sets))
  if (anyNA(names(sets)) || any(!nzchar(names(sets))) || anyDuplicated(names(sets)))
    .gbase_stop("Set names must be unique and nonempty.")
  lapply(sets, function(x) {
    if (!is.character(x) || anyNA(x) || any(!nzchar(x)))
      .gbase_stop("Set members must be nonempty marker IDs.")
    at <- match(x, rsids); at <- at[!is.na(at)]
    if (index) at else rsids[at]
  })
}

#' Read complete regional LD from BED
#' @param Glist Prepared BED reference.
#' @param rsids Nonempty marker IDs from one chromosome.
#' @param ids Reference sample IDs; defaults to the prepared study selection.
#' @param nthreads Local genotype-decoding threads. BLAS threading is unchanged.
#' @param maximum_dimension Bound on the returned square LD matrix.
#' @return Named signed correlation matrix in requested marker order. Missing
#'   genotypes are mean-imputed. Phase timings and reference sample count are
#'   attributes. No sparse threshold, window or persistent file is used.
#' @export
getLD <- function(Glist, rsids, ids = NULL, nthreads = 1L, maximum_dimension = 2048L) {
  started <- proc.time()[[3L]]
  validate_Glist(Glist)
  rsids <- .gprep_selection(rsids, "rsids")
  if (is.null(rsids)) .gbase_stop("`rsids` must select a nonempty region.")
  nthreads <- .gprep_count(nthreads, "nthreads")
  maximum_dimension <- .gprep_count(maximum_dimension, "maximum_dimension")
  if (length(rsids) > maximum_dimension) .gbase_stop("Region exceeds maximum_dimension.")
  markers <- unlist(Glist$rsids, use.names = FALSE)
  selected <- match(rsids, markers)
  if (anyNA(selected)) .gbase_stop("Unknown regional marker.")
  chromosomes <- unlist(Glist$chr, use.names = FALSE)
  if (length(unique(chromosomes[selected])) != 1L) .gbase_stop("Region must belong to one chromosome.")
  ids <- .gprep_selection(ids, "ids")
  if (is.null(ids)) ids <- if (is.null(Glist$study_ids)) Glist$ids else Glist$study_ids
  samples <- Glist$ids[match(ids, Glist$ids)]
  if (anyNA(samples) || length(samples) < 2L) .gbase_stop("At least two known reference samples are required.")
  # Existing native BedPanel owns sample/marker selection and allele1 dosage.
  paths <- Map(function(bed, bim, fam) list(bed=bed, bim=bim, fam=fam),
    Glist$bedfiles, Glist$bimfiles, Glist$famfiles)
  families <- Glist$sample_metadata$family_id
  if (is.null(families)) {
    first <- cpp_gbase_bed_resource(Glist$bedfiles[1L], Glist$bimfiles[1L], Glist$famfiles[1L])
    families <- first$samples$family_id
  }
  rows <- match(ids, Glist$ids)
  ordering <- order(selected)
  validation <- unname(proc.time()[[3L]] - started)
  begin <- proc.time()[[3L]]
  W <- cpp_gbase_standardized_region(paths, families[rows], ids, Glist$rsids,
    as.double(selected[ordering] - 1L), nthreads)
  decode <- unname(proc.time()[[3L]] - begin)
  begin <- proc.time()[[3L]]
  LD <- crossprod(W)
  bound <- 8*.Machine$double.eps*nrow(W)
  if(any(!is.finite(LD)) || any(abs(LD)>1+bound)) .gbase_stop("Invalid regional correlation product.")
  LD[LD>1] <- 1;LD[LD< -1] <- -1
  # Unit-norm native columns define correlations. Retain one product triangle;
  # Only rounding-level excursions outside [-1,1] are clamped above. No
  # thresholding, jitter or PSD repair is performed.
  LD[upper.tri(LD)] <- t(LD)[upper.tri(LD)]
  diag(LD) <- 1
  LD <- LD[order(ordering), order(ordering), drop = FALSE]
  dimnames(LD) <- list(rsids, rsids)
  attr(LD, "reference_sample_count") <- nrow(W)
  attr(LD, "timings_seconds") <- c(validation=validation, decode=decode,
    product=unname(proc.time()[[3L]] - begin), total=unname(proc.time()[[3L]] - started))
  LD
}
