#' Construct marker-count windows around selected markers
#' @param Glist Prepared reference with aligned marker IDs and chromosomes.
#' @param rsids Index marker IDs. Unknown IDs are warned about and skipped.
#' @param upstream,downstream Nonnegative marker counts, using the established
#'   qgg convention: downstream precedes the index and upstream follows it.
#' @return Named marker-ID lists, bounded by chromosome and reference order.
#' @export
createMarkerSets <- function(Glist, rsids, upstream = 1000L, downstream = 1000L) {
  markers <- unlist(Glist$rsids, use.names = FALSE)
  chr <- as.character(unlist(Glist$chr, use.names = FALSE))
  if (!is.character(markers) || !length(markers) || anyNA(markers) ||
      any(!nzchar(markers)) || anyDuplicated(markers) || length(chr) != length(markers) ||
      anyNA(chr) || any(!nzchar(chr)))
    .gbase_stop("Glist marker IDs and chromosomes must be aligned and valid.")
  if (!is.character(rsids) || anyNA(rsids) || any(!nzchar(rsids)) || anyDuplicated(rsids))
    .gbase_stop("`rsids` must contain unique nonempty marker IDs.")
  count <- function(x, name) {
    if (!is.numeric(x) || length(x) != 1L || !is.finite(x) ||
        x < 0 || x != floor(x) || x > .Machine$integer.max)
      .gbase_stop("`", name, "` must be a nonnegative integer.")
    as.double(x)
  }
  upstream <- count(upstream, "upstream")
  downstream <- count(downstream, "downstream")
  at <- match(rsids, markers)
  if (anyNA(at)) warning("Unknown index markers were skipped: ",
    paste(rsids[is.na(at)], collapse = ", "), call. = FALSE)
  at <- at[!is.na(at)]
  stats::setNames(lapply(at, function(i) {
    take <- seq.int(max(1, i - downstream), min(length(markers), i + upstream))
    markers[take[chr[take] == chr[i]]]
  }), markers[at])
}

#' Retrieve stored LD scores in marker order
#' @param Glist Prepared reference with stored LD scores.
#' @param chr Optional chromosome labels.
#' @return Marker-named numeric scores; no LD files are opened.
#' @export
getLDscores <- function(Glist, chr = NULL) {
  scores <- unlist(Glist$ldscores, use.names = FALSE)
  markers <- unlist(if (is.null(Glist$rsidsLD)) Glist$rsids else Glist$rsidsLD,
    use.names = FALSE)
  if (!is.numeric(scores) || !length(scores) || length(scores) != length(markers) ||
      any(!is.finite(scores)) || anyDuplicated(markers))
    .gbase_stop("Glist must contain finite LD scores aligned to unique marker IDs.")
  if (!is.null(chr)) {
    reference <- unlist(Glist$rsids, use.names = FALSE)
    chromosome <- unlist(Glist$chr, use.names = FALSE)[match(markers, reference)]
    if (anyNA(chromosome)) .gbase_stop("LD-score chromosomes must resolve in Glist.")
    take <- as.character(chromosome) %in% as.character(chr)
    scores <- scores[take]; markers <- markers[take]
  }
  stats::setNames(scores, markers)
}

#' Split marker sets at low rolling LD-score boundaries
#' @param ldscores Finite nonnegative marker-named LD scores from one chromosome.
#' @param msize Rolling mean width in markers.
#' @param maxsize Minimum spacing around a selected boundary, in markers.
#' @param nsplit Maximum number of boundaries.
#' @param verbose Report the resulting number of sets.
#' @return Disjoint exhaustive marker-ID sets in input order. These score-based
#'   candidates are not verified independent LD blocks.
#' @export
createLDsets <- function(ldscores, msize = 200L, maxsize = 2000L,
                         nsplit = 200L, verbose = FALSE) {
  if (!is.numeric(ldscores) || !length(ldscores) || any(!is.finite(ldscores)) ||
      any(ldscores < 0) || is.null(names(ldscores)) || anyNA(names(ldscores)) ||
      any(!nzchar(names(ldscores))) || anyDuplicated(names(ldscores)))
    .gbase_stop("Supply finite nonnegative marker-named LD scores from one chromosome.")
  msize <- .gprep_count(msize, "msize")
  maxsize <- .gprep_count(maxsize, "maxsize")
  nsplit <- .gprep_count(nsplit, "nsplit")
  verbose <- .gfilter_logical(verbose, "verbose")
  n <- length(ldscores); boundaries <- integer()
  if (n > msize && n > 2 * maxsize) {
    ends <- seq.int(msize + 1L, n)
    sums <- cumsum(ldscores)
    means <- (sums[ends] - sums[ends - msize]) / msize
    means[ends <= maxsize | ends >= n - maxsize] <- Inf
    for (i in seq_len(nsplit)) {
      selected <- which.min(means)
      if (!length(selected) || !is.finite(means[selected])) break
      boundary <- ends[selected]
      boundaries <- c(boundaries, boundary)
      means[abs(ends - boundary) <= maxsize] <- Inf
    }
  }
  group <- cumsum(seq_len(n) %in% sort(boundaries))
  result <- unname(split(names(ldscores), group))
  names(result) <- paste0("Set", seq_along(result))
  if (verbose) message(length(result), " LD-score candidate sets")
  result
}
