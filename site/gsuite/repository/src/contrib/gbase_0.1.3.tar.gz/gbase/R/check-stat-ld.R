#' Align, check and optionally impute summary statistics
#' @inheritParams .check_stat_frame
#' @param ldcheck Enable iterative DENTIST-style LD consistency checks.
#' @param impute Impute missing and LD-rejected Z-scores onto the eligible reference backbone.
#' @param columns,ancestry,ancestry_weights As in impute.
#' @param nthreads Local genotype-decoding threads.
#' @param ld_control Named overrides: iterations, p_threshold, rank_fraction,
#'   seed, max_pair_r2 and min_variance.
#' @param impute_control Named overrides: lambda, r2, window, buffer and max_markers.
#' @return An ordinary data frame, matrix or gact list, with compact ldcheck and
#'   imputation attributes when requested. Original LD-rejected scores are retained.
#' @export
checkStat <- function(Glist = NULL, stat = NULL, excludeMAF = .01,
    excludeMAFDIFF = .05, excludeINFO = .8, excludeCGAT = TRUE,
    excludeINDEL = TRUE, excludeDUPS = TRUE, excludeMHC = FALSE,
    excludeMISS = .05, excludeHWE = 1e-12, ldcheck = FALSE, impute = FALSE,
    columns = NULL, ancestry = NULL, ancestry_weights = NULL, nthreads = 1L,
    ld_control = list(), impute_control = list()) {
  ldcheck <- .check_stat_flag(ldcheck, "ldcheck"); impute <- .check_stat_flag(impute, "impute")
  if (is.data.frame(stat) && !ldcheck && !impute && is.null(columns) &&
      is.null(ancestry) && is.null(ancestry_weights))
    return(.check_stat_frame(Glist, stat, excludeMAF, excludeMAFDIFF, excludeINFO,
      excludeCGAT, excludeINDEL, excludeDUPS, excludeMHC, excludeMISS, excludeHWE))
  validate_Glist(Glist)
  for (name in c("excludeMAF", "excludeMAFDIFF", "excludeINFO", "excludeMISS", "excludeHWE"))
    .check_stat_threshold(get(name), name)
  for (name in c("excludeCGAT", "excludeINDEL", "excludeDUPS", "excludeMHC")) .check_stat_flag(get(name), name)
  if (is.data.frame(stat) && anyDuplicated(stat$rsids)) {
    if (!excludeDUPS) .gbase_stop("Mapped statistic marker IDs are duplicated.")
    metadata <- attributes(stat)[c("ancestry", "ancestry_weights", "study_id")]
    stat <- stat[!duplicated(stat$rsids), , drop = FALSE]
    for (name in names(metadata)) attr(stat, name) <- metadata[[name]]
  }
  input <- .gbase_summary_input(Glist, stat, columns, harmonize = TRUE)
  a1 <- toupper(unlist(Glist$a1, use.names = FALSE)); a2 <- toupper(unlist(Glist$a2, use.names = FALSE))
  eligible <- rep(TRUE, nrow(input$z))
  if (excludeCGAT) eligible <- eligible & !paste0(a1, a2) %in% c("AT", "TA", "CG", "GC")
  if (excludeINDEL) eligible <- eligible & nchar(a1) == 1L & nchar(a2) == 1L
  if (excludeMHC) {
    chr <- unlist(Glist$chr, use.names = FALSE); pos <- unlist(Glist$pos, use.names = FALSE)
    eligible <- eligible & !(chr %in% c("6", "chr6", "CHR6") & pos >= 25000000 & pos <= 34000000)
  }
  if (input$frame) {
    out <- input$template
    for (name in intersect(c("eaf", "b", "seb", "p", "n", "info"), names(out))) {
      x <- out[[name]]
      if (!is.numeric(x) || any(!is.finite(x) & !is.na(x))) .gbase_stop("Invalid numerical column: ", name)
      if (name %in% c("seb", "n") && any(x <= 0, na.rm = TRUE)) .gbase_stop(name, " must be positive.")
      if (name %in% c("eaf", "p", "info") && any(x < 0 | x > 1, na.rm = TRUE)) .gbase_stop(name, " must lie in [0, 1].")
    }
    if (!is.null(excludeINFO) && "info" %in% names(out))
      eligible <- eligible & (!input$present | is.na(out$info) & rowSums(!is.na(input$z)) == 0L |
        !is.na(out$info) & out$info >= excludeINFO)
    if (!is.null(excludeMAF) && "eaf" %in% names(out))
      eligible <- eligible & (is.na(out$eaf) | pmin(out$eaf, 1 - out$eaf) > excludeMAF)
    if ("eaf" %in% names(out)) input$eaf <- matrix(out$eaf, nrow(input$z), ncol(input$z))
  } else if (input$container) {
    out <- input$template
    study_eligible <- matrix(TRUE, nrow(input$z), ncol(input$z))
    if (!is.null(excludeINFO) && is.matrix(out$info))
      study_eligible <- study_eligible & (is.na(out$info) & is.na(input$z) |
        !is.na(out$info) & out$info >= excludeINFO)
    if (is.matrix(out$eaf)) {
      input$eaf <- out$eaf
      if (!is.null(excludeMAF)) study_eligible <- study_eligible &
        (is.na(out$eaf) | pmin(out$eaf, 1 - out$eaf) > excludeMAF)
    }
    input$study_eligible <- study_eligible
  }
  input$max_afdiff <- if (is.null(excludeMAFDIFF)) NA_real_ else excludeMAFDIFF
  if (!any(eligible)) .gbase_stop("No reference markers remain after QC.")
  reference_qc <- function(counts) {
    observed <- counts$n0 + counts$n1 + counts$n2
    af <- (2 * counts$n2 + counts$n1) / (2 * observed)
    keep <- observed > 0
    if (!is.null(excludeMAF)) keep <- keep & pmin(af, 1 - af) > excludeMAF
    if (!is.null(excludeMISS)) keep <- keep & counts$nmiss / (observed + counts$nmiss) <= excludeMISS
    if (!is.null(excludeHWE)) {
      p <- vapply(seq_along(observed), function(i)
        if (!observed[i]) 0 else .gfilter_exact_hwe_one(counts$n0[i], counts$n1[i], counts$n2[i]), numeric(1))
      keep <- keep & p >= excludeHWE
    }
    keep[is.na(keep)] <- FALSE
    keep
  }
  .gbase_summary_run(Glist, input, ancestry, ancestry_weights, ldcheck, impute,
    eligible, reference_qc, ld_control, impute_control, nthreads)
}
