# gbase

`gbase` contains small, task-neutral R data contracts shared by the gsuite
ecosystem. It performs no statistical fitting. Its genotype preparation contract
uses the installed public `gmat`, `gbits`, and `gsolve` interfaces, with a
qualified native prefix checked during compilation and native versions and ABIs
checked again when the package loads. `gsolve` supplies dense products and
regional eigensystems or eigenvalues; the portable binary disables CHOLMOD, MKL and PARDISO
while retaining OpenMP support.

Summary statistics use the established qgg workflow: `checkStat()` maps and
aligns an ordinary data frame to Glist, applies explicit QC, and returns an
ordinary data frame with familiar short column names:

```r
library(gbase)

stat <- checkStat(Glist = Glist, stat = raw_stat)
```

The result has no special summary-statistics class, constructor or accessor.
Each task function validates the columns it uses, and statistical work belongs
to the task package.

PLINK genotype resources are prepared once and remain serializable:

```r
Glist <- gprep(bedfiles = c("chr1.bed", "chr2.bed"))
Glist <- gprep(
  Glist = Glist,
  task = "sparseld",
  out_prefix = "reference",
  max_distance_bp = 1000000,
  max_distance_variants = 1000,
  r2 = 0.01
)
```

The second call returns the same `Glist` contract augmented with its sparse-LD
descriptor; it does not introduce a separate genotype or LD owner.

`validate_Glist()` checks BED/BIM/FAM identity one file component at a time,
retaining only marker IDs for the global uniqueness check. It does not keep
every chromosome's full BIM metadata in memory together.

The same Glist is the input to task-neutral marker and LD utilities:

```r
markers <- gfilter(Glist)
scores <- ld_scores(Glist)
region <- ld_region(Glist, markers = markers[1:100])
spectrum <- ld_eigen(Glist, markers = markers[1:100])

blocks <- data.frame(block_id = "chr1", first_marker = markers[1],
  last_marker = markers[length(markers)])
Glist <- define_ld_blocks(Glist, blocks)
```

Sparse-LD construction and metadata stay on the Glist returned by
`gprep(task = "sparseld")`.

Chromosomes can be extracted as marker sets from the existing metadata:

```r
sets <- getChromosomeSets(Glist)
```

This gives one named, disjoint set per chromosome, preserving reference marker
order. Grouping uses chromosome labels, including when one BED file contains
several chromosomes. The helper reads no genotype or LD files.

Full regional LD eigenvalues can also be prepared directly from BED without
first making sparse LD:

```r
regionSets <- list(region1 = Glist$rsids[[1]][1:100])
Glist <- gprep(Glist, task = "eigen", sets = regionSets, nthreads = 4)
values <- Glist$eigen$values$region1
saveRDS(Glist, "Glist-with-regional-eigenvalues.rds")
```

Each region is a named marker set from one chromosome. Membership is retained
in reference order, and the prepared sample IDs are stored with the spectra.
Missing genotypes are mean-imputed; constant markers are rejected by ID.
Only eigenvalues are computed, with no clipping or truncation. When markers
outnumber samples, the smaller sample-space Gram matrix is used and the full
marker spectrum is recovered by padding its null eigenvalues with zeros.
Regions are processed sequentially; `nthreads` controls local BED decoding.
The existing gsolve Eigen backend performs dense products and decomposition
without a mandatory OpenBLAS dependency. Sparse-LD cutoffs and windows do not
apply. `glma::prepare_vegas(Glist)` reuses these stored spectra for VEGAS without
repeating LD computation or decomposition. It returns a serializable prepared
object with the required marker and allele order for subsequent traits.
Constant positive weights within each gene are supported; nonuniform weights
continue to use the sparse-LD route. Statistical evaluation remains owned by glma.

`mapSets(sets, Glist)` resolves named marker memberships to prepared marker IDs
or indices. Unknown members are dropped; empty sets remain visible.
`getLD(Glist, rsids=region)` computes full regional BED correlation in requested
marker order using the selected people, installed gmat decoding and R's
configured BLAS. Missing genotypes are mean-imputed and constant markers are
rejected. It writes no files and applies no sparse-LD windows or cutoffs.
The returned matrix records sample count and decoding/product timings.
Statistical priors, sampler controls and posterior sets remain with task packages.
