test_that("regional LD preserves requested order, selection and imputation", {
  genotype <- matrix(c(0,1,2,1,NA,2, 0,0,1,2,2,1, 2,1,0,1,2,0),nrow=6)
  fixture <- write_tiny_plink(genotype,paste0("m",1:3))
  on.exit(unlink_tiny_plink(fixture))
  G <- gprep(bedfiles=fixture$paths['bed'])
  ids <- G$ids[c(1,2,4,5,6)]
  members <- c('m3','m1','m2')
  selected <- genotype[c(1,2,4,5,6),c(3,1,2)]
  for(j in seq_len(ncol(selected))) selected[is.na(selected[,j]),j] <- mean(selected[,j],na.rm=TRUE)
  expected <- cor(selected);dimnames(expected) <- list(members,members)
  LD <- getLD(G,members,ids=ids)
  expect_equal(as.vector(LD),as.vector(expected),tolerance=1e-12)
  expect_identical(dimnames(LD),list(members,members))
  expect_equal(attr(LD,'reference_sample_count'),5)
  expect_true(all(attr(LD,'timings_seconds')>=0))
  expect_error(getLD(G,c('m1','unknown')),'Unknown')
  expect_error(getLD(G,c('m1','m1')),'unique')
  expect_identical(mapSets(list(A=c('m2','absent','m1'),B='absent'),Glist=G),
    list(A=c(2L,1L),B=integer()))
  expect_identical(mapSets(list(c('m2','m1')),Glist=G,index=FALSE),list(Set1=c('m2','m1')))
})
