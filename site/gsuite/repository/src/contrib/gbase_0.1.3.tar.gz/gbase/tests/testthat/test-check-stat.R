test_that("checkStat returns an ordinary aligned qgg-style data frame", {
  fixture <- write_tiny_plink(matrix(c(
    0, 1, 2,
    1, 2, 0,
    2, 0, 1,
    0, 1, 2,
    1, 2, 0,
    2, 0, 1
  ), nrow = 6L, byrow = TRUE), c("rs1", "rs2", "rs3"))
  on.exit(unlink_tiny_plink(fixture), add = TRUE)
  Glist <- gprep(bedfiles = fixture$paths[["bed"]])
  raw <- data.frame(marker = c("rs3", "rs1", "absent", "rs2"),
    chromosome = "1", position = c(300, 100, 999, 200),
    effect_allele = c("G", "A", "A", "A"),
    other_allele = c("A", "G", "G", "G"),
    allele_frequency = c(0.5, 0.5, 0.2, 0.5),
    effect = c(0.3, 0.1, 9, 0.2), standard_error = 0.1,
    z = c(3, 1, 90, 2),
    p_value = c(.03, .01, .9, .02), sample_size = 100,
    info = .95, stringsAsFactors = FALSE)
  stat <- suppressMessages(checkStat(Glist, raw, excludeMAF = NULL,
    excludeMAFDIFF = NULL, excludeMISS = NULL, excludeHWE = NULL))
  expect_identical(class(stat), "data.frame")
  expect_identical(stat$rsids, c("rs1", "rs2", "rs3"))
  expect_identical(stat$ea, rep("A", 3))
  expect_identical(stat$nea, rep("G", 3))
  expect_equal(stat$b, c(.1, .2, -.3))
  expect_equal(stat$stat, c(1, 2, -3))
  expect_equal(stat$eaf, c(.5, .5, .5))
  expect_identical(rownames(stat), stat$rsids)
  expect_identical(variant_key(stat), c("1:100:A:G", "1:200:A:G", "1:300:A:G"))
})

test_that("checkStat applies explicit filters without inventing columns", {
  fixture <- write_tiny_plink(matrix(c(
    0, 0, 1,
    1, 1, 1,
    2, 2, 1,
    0, 0, 1,
    1, 1, 1,
    2, 2, 1
  ), nrow = 6L, byrow = TRUE), c("a", "b", "c"))
  on.exit(unlink_tiny_plink(fixture), add = TRUE)
  Glist <- gprep(bedfiles = fixture$paths[["bed"]])
  stat <- data.frame(rsids = c("a", "b", "b", "c"), chr = "1",
    pos = c(100, 200, 200, 300), ea = "A", nea = "G",
    b = 1:4, seb = .1, p = .01, n = 100,
    info = c(.9, .7, .7, .95), stringsAsFactors = FALSE)
  checked <- suppressMessages(checkStat(Glist, stat, excludeMAF = NULL,
    excludeMAFDIFF = NULL, excludeINFO = .8, excludeMISS = NULL,
    excludeHWE = NULL))
  expect_identical(checked$rsids, c("a", "c"))
  expect_false("eaf" %in% names(checked))
  expect_error(suppressMessages(checkStat(Glist, stat,
    excludeDUPS = FALSE, excludeMAF = NULL, excludeMAFDIFF = NULL,
    excludeMISS = NULL, excludeHWE = NULL)), "duplicated")
})

test_that("checkStat rejects identity and numeric ambiguity", {
  fixture <- write_tiny_plink(matrix(c(0, 1, 2, 2, 1, 0), ncol = 2L),
    c("a", "b"))
  on.exit(unlink_tiny_plink(fixture), add = TRUE)
  Glist <- gprep(bedfiles = fixture$paths[["bed"]])
  stat <- data.frame(rsids = "a", chr = "1", pos = 999,
    ea = "A", nea = "G", b = .1, seb = .1)
  expect_error(suppressMessages(checkStat(Glist, stat,
    excludeMAF = NULL, excludeMISS = NULL, excludeHWE = NULL)), "coordinates")
  stat$pos <- 100; stat$seb <- 0
  expect_error(suppressMessages(checkStat(Glist, stat,
    excludeMAF = NULL, excludeMISS = NULL, excludeHWE = NULL)), "positive")
})
