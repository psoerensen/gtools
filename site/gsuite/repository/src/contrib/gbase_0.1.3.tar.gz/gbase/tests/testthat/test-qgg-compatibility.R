test_that("familiar QC and LD arguments preserve the existing numerical route", {
  x <- cbind(a=c(0,0,1,1,2,2), b=c(0,1,0,2,1,2), c=c(2,2,1,1,0,0))
  f <- write_tiny_plink(x, colnames(x))
  a <- tempfile("familiar-ld-"); b <- tempfile("modern-ld-")
  on.exit({ unlink_tiny_plink(f); unlink_sparse_ld(a); unlink_sparse_ld(b) })
  G <- gprep(bedfiles=f$paths['bed'])
  expect_identical(gfilter(G, excludeMAF=.05, excludeMISS=.05,
    excludeHWE=NULL, excludeCGAT=TRUE, excludeDUPS=TRUE, verbose=FALSE),
    gfilter(G, maf=.05, missing=.05, hwe=NULL, ambiguous=TRUE, verbose=FALSE))
  expect_error(gfilter(G, maf=.05, excludeMAF=.05), "either")
  old <- gprep(G, task="sparseld", msize=2, ldfiles=paste0(a,'.ld'))
  new <- gprep(G, task="sparseld", max_distance_bp=0,
    max_distance_variants=2, r2=0, out_prefix=b)
  expect_equal(ld_region(old, colnames(x)), ld_region(new, colnames(x)), tolerance=0)
  expect_equal(getLDscores(old), ld_scores(new), tolerance=0)
})

test_that("familiar helpers keep marker order, repetitions and chromosome bounds", {
  G <- list(rsids=list(c('a','b','c','d','e')), chr=list(c('1','1','1','2','2')),
    ldscores=list(c(2,3,4,5,6)))
  expect_identical(createMarkerSets(G, c('a','c','d'), upstream=1, downstream=1),
    list(a=c('a','b'), c=c('b','c'), d=c('d','e')))
  expect_identical(mapSets(list(A=c('b','b','absent','a')), rsids=unlist(G$rsids)),
    list(A=c(2L,2L,1L)))
  expect_equal(getLDscores(G, chr='2'), c(d=5,e=6))
  scores <- setNames(c(rep(3,12), rep(1,6), rep(3,12)), paste0('m',1:30))
  sets <- createLDsets(scores, msize=2, maxsize=5, nsplit=2)
  expect_identical(unlist(sets, use.names=FALSE), names(scores))
  expect_false(anyDuplicated(unlist(sets, use.names=FALSE)) > 0)
})
