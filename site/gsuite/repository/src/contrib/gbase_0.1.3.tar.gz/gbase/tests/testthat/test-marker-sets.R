test_that("chromosome sets group labels across files and retain order", {
  # A file can contain several chromosomes, and a chromosome can span files.
  g <- list(rsids=list(c("a","b","c"),c("d","e","f")),
    chr=list(c("2","10","2"),c("1","10","2")))
  expect_identical(getChromosomeSets(g),
    list(`2`=c("a","c","f"),`10`=c("b","e"),`1`="d"))
  g <- list(rsids=list(c("a","b"),character()),chr=list(c("X","MT"),character()))
  expect_identical(getChromosomeSets(g),list(X="a",MT="b"))
})

test_that("chromosome sets reject inconsistent identities", {
  expect_error(getChromosomeSets(list(rsids=list("a"),chr=list(c("1","2")))),
    "aligned file-wise")
  expect_error(getChromosomeSets(list(rsids=list(c("a","a")),chr=list(c("1","2")))),
    "unique")
  expect_error(getChromosomeSets(list(rsids=list("a"),chr=list(NA_character_))),
    "nonempty")
  expect_error(getChromosomeSets(list(rsids=list(character()),chr=list(character()))),
    "unique")
})
