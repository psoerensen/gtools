test_that("regional eigen preparation agrees with full dense LD", {
  genotype <- cbind(a=c(0,1,2,0,1,2), b=c(0,2,1,2,0,1),
    c=c(2,1,0,2,1,0), d=c(0,NA,2,1,0,2),
    e=c(1,2,0,1,2,0), f=c(2,0,1,1,2,0), g=c(0,2,1,0,2,1))
  fixture <- write_tiny_plink(genotype, colnames(genotype))
  on.exit(unlink_tiny_plink(fixture), add=TRUE)
  G <- gprep(bedfiles=fixture$paths[["bed"]])
  original <- serialize(G, NULL)
  sets <- list(small=c("d","a","b"), large=rev(colnames(genotype)), single="a")
  B <- gprep(G, task="eigen", sets=sets, nthreads=1)
  imputed <- genotype
  for (j in seq_len(ncol(imputed))) imputed[is.na(imputed[,j]),j] <- mean(imputed[,j],na.rm=TRUE)
  for (name in names(B$eigen$sets)) {
    members <- B$eigen$sets[[name]]
    expected <- if(length(members)==1) 1 else eigen(cor(imputed[,members,drop=FALSE]),
      symmetric=TRUE, only.values=TRUE)$values
    expect_equal(B$eigen$values[[name]], expected, tolerance=1e-11)
    expect_length(B$eigen$values[[name]], length(members))
  }
  expect_identical(B$eigen$sets$small, c("a","b","d"))
  expect_identical(B$eigen$diagnostics$small$matrix_space, "markers")
  expect_identical(B$eigen$diagnostics$large$matrix_space, "samples")
  expect_equal(B$eigen$diagnostics$large$solver_dimension, 6)
  expect_identical(B$eigen$provenance$source, "BED")
  expect_null(B$sparseLD)
  expect_identical(serialize(G,NULL), original)
  expect_invisible(validate_Glist(unserialize(serialize(B,NULL))))
  threaded <- gprep(G, task="eigen", sets=sets, nthreads=4)
  expect_identical(threaded$eigen$values, B$eigen$values)
  selected <- gprep(G, task="eigen", sets=list(region=c("a","b")), ids=c("I5","I1","I3"))
  expect_identical(selected$eigen$sample_ids, c("I5","I1","I3"))
  expect_equal(selected$eigen$values$region,
    eigen(cor(genotype[c(6,2,4),c("a","b")]), symmetric=TRUE,only.values=TRUE)$values,
    tolerance=1e-11)
  bad <- B; bad$eigen$values$small <- rev(bad$eigen$values$small)
  expect_error(validate_Glist(bad), "spectrum")
  bad <- B; bad$eigen$sets$small <- rev(bad$eigen$sets$small)
  expect_error(validate_Glist(bad), "region identity")
})

test_that("large regional Gram matrices preserve symmetry under rounding", {
  genotype <- outer(seq_len(503),seq_len(1152),
    function(i,j) ((i*((j%%100)+1)+j*11)%%101)%%3)
  markers <- paste0("dense",seq_len(ncol(genotype)))
  fixture <- write_tiny_plink(genotype,markers)
  on.exit(unlink_tiny_plink(fixture),add=TRUE)
  G <- gprep(bedfiles=fixture$paths[["bed"]])
  B <- gprep(G,task="eigen",sets=list(region=markers),
    eigen_control=list(symmetry_tolerance=1e-18))
  expected <- eigen(cor(genotype),symmetric=TRUE,only.values=TRUE)$values
  expect_equal(B$eigen$values$region,expected,tolerance=1e-9)
  expect_identical(B$eigen$diagnostics$region$relative_symmetry_error,0)
})

test_that("eigen preparation validates membership and numerical limits", {
  fixture <- write_tiny_plink(cbind(a=c(0,1,2), b=c(0,2,1), constant=c(0,0,0)),
    c("a","b","constant"), chromosome=c("1","2","1"))
  on.exit(unlink_tiny_plink(fixture), add=TRUE)
  G <- gprep(bedfiles=fixture$paths[["bed"]])
  expect_error(gprep(G, task="eigen"), "sets")
  expect_error(gprep(G, task="eigen", sets=list(c("a"))), "named")
  expect_error(gprep(G, task="eigen", sets=list(x=character())), "nonempty")
  expect_error(gprep(G, task="eigen", sets=list(x=c("a","a"))), "unique")
  expect_error(gprep(G, task="eigen", sets=list(x="absent")), "Unknown marker")
  expect_error(gprep(G, task="eigen", sets=list(first="a", second="absent")),
    "Unknown marker in region second: absent")
  expect_error(gprep(G, task="eigen", sets=list(x=c("a","b"))), "one chromosome")
  expect_error(gprep(G, task="eigen", sets=list(x="constant")), "variable observed")
  expect_error(gprep(G, task="eigen", sets=list(x="a"), ids="I0"), "two known")
  expect_error(gprep(G, task="eigen", sets=list(x="a"), ids=c("I0","absent")), "two known")
  expect_error(gprep(G, task="eigen", sets=list(x="a"), rsids="a"), "rather than")
  expect_error(gprep(G, task="eigen", sets=list(x="a"), out_prefix="unused"), "saveRDS")
  expect_error(gprep(G, task="eigen", sets=list(x=c("a","constant")),
    eigen_control=list(maximum_dimension=1)), "maximum_dimension")
  expect_error(gprep(G, task="sparseld", sets=list(x="a")), "require task")
})
