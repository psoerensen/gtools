write_tiny_bed <- function(genotypes, path = tempfile(fileext = ".bed")) {
  encode <- function(x) {
    if (is.na(x)) return(1L)
    switch(as.character(x), "2" = 0L, "1" = 2L, "0" = 3L)
  }
  body <- raw()
  for (marker in seq_len(ncol(genotypes))) {
    codes <- vapply(genotypes[, marker], encode, integer(1))
    bytes <- raw(ceiling(nrow(genotypes) / 4))
    for (byte in seq_along(bytes)) {
      value <- 0L
      for (offset in 0:3) {
        sample <- (byte - 1L) * 4L + offset + 1L
        if (sample <= length(codes))
          value <- bitwOr(value, bitwShiftL(codes[[sample]], 2L * offset))
      }
      bytes[[byte]] <- as.raw(value)
    }
    body <- c(body, bytes)
  }
  writeBin(c(as.raw(c(0x6c, 0x1b, 0x01)), body), path)
  path
}

write_tiny_plink <- function(genotypes, marker_ids, chromosome = "1") {
  prefix <- tempfile("gbase-plink-")
  paths <- setNames(paste0(prefix, c(".bed", ".bim", ".fam")),
    c("bed", "bim", "fam"))
  write_tiny_bed(genotypes, paths[["bed"]])
  markers <- data.frame(chromosome = rep_len(chromosome, ncol(genotypes)),
    marker_id = marker_ids, genetic_distance_cm = 0,
    base_pair_position = seq_len(ncol(genotypes)) * 100L,
    allele1 = "A", allele2 = "G")
  samples <- data.frame(family_id = paste0("F", seq_len(nrow(genotypes)) - 1L),
    individual_id = paste0("I", seq_len(nrow(genotypes)) - 1L),
    paternal_id = "0", maternal_id = "0", sex = "0", phenotype = "-9")
  write.table(markers, paths[["bim"]], quote = FALSE, row.names = FALSE,
    col.names = FALSE)
  write.table(samples, paths[["fam"]], quote = FALSE, row.names = FALSE,
    col.names = FALSE)
  list(paths = paths, genotypes = genotypes)
}

unlink_tiny_plink <- function(x) unlink(unname(x$paths))

unlink_sparse_ld <- function(prefix) unlink(paste0(prefix, c(
  ".row_ptr.u64.bin", ".col_idx.u32.0based.bin", ".values.f32.bin",
  ".meta.txt", ".markers.tsv")))
