library(testthat)
library(gbase)

test_check("gbase")
