#include <Rcpp.h>
#include <gbits/bed_summary.hpp>
#include <gmat/bed_region.hpp>
#include <gsolve/dense_product.hpp>
#include <gsolve/dense_cholesky_inverse.hpp>
#include <gsolve/symmetric_eigensystem.hpp>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <map>
#include <numeric>
#include <vector>

namespace {
using Index = std::uint64_t;
Index integer(double x) {
  if (!std::isfinite(x) || x < 0 || x != std::floor(x) || x > 9007199254740992.0)
    Rcpp::stop("Invalid physical BED index.");
  return static_cast<Index>(x);
}
std::uint64_t hash(std::uint64_t x) {
  x += 0x9e3779b97f4a7c15ULL; x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ULL;
  x = (x ^ (x >> 27)) * 0x94d049bb133111ebULL; return x ^ (x >> 31);
}
struct Reference {
  std::vector<double> ld, af;
  std::vector<bool> valid;
};
Reference read_reference(Rcpp::CharacterVector bed, double source_samples,
    Rcpp::NumericVector counts, const std::vector<Index>& samples,
    Rcpp::IntegerVector components, Rcpp::NumericVector sources,
    const Rcpp::IntegerVector& context, int threads, Rcpp::Function qc) {
  const Index n = samples.size(), k = context.size();
  Reference out; out.valid.assign(k, false); out.af.assign(k, NA_REAL);
  std::vector<double> x(n * k, 0.0);
  std::map<int, std::vector<int>> files;
  for (Index j = 0; j < k; ++j) {
    int file = components[context[j]];
    if (file < 0 || file >= bed.size()) Rcpp::stop("Invalid BED component index.");
    files[file].push_back(static_cast<int>(j));
  }
  for (auto& piece : files) {
    auto& locations = piece.second;
    std::sort(locations.begin(), locations.end(), [&](int a, int b) { return sources[context[a]] < sources[context[b]]; });
    std::vector<Index> markers;
    for (int j : locations) markers.push_back(integer(sources[context[j]]));
    auto summary = gbits::bed_genotype_counts(Rcpp::as<std::string>(bed[piece.first]),
        integer(source_samples), integer(counts[piece.first]), samples, markers, threads);
    Rcpp::NumericVector n0(summary.size()), n1(summary.size()), n2(summary.size()), miss(summary.size());
    for (std::size_t j = 0; j < summary.size(); ++j) {
      n0[j] = summary[j].n0; n1[j] = summary[j].n1; n2[j] = summary[j].n2; miss[j] = summary[j].nmiss;
    }
    Rcpp::LogicalVector keep = qc(Rcpp::List::create(Rcpp::_["n0"] = n0,
        Rcpp::_["n1"] = n1, Rcpp::_["n2"] = n2, Rcpp::_["nmiss"] = miss));
    if (keep.size() != static_cast<R_xlen_t>(summary.size())) Rcpp::stop("Reference QC dimension mismatch.");
    std::vector<Index> variable; std::vector<int> destination;
    for (std::size_t j = 0; j < summary.size(); ++j) {
      const double observed = n0[j] + n1[j] + n2[j], dosage = n1[j] + 2 * n2[j];
      out.af[locations[j]] = observed ? dosage / (2 * observed) : NA_REAL;
      const double variation = observed ? n1[j] + 4 * n2[j] - dosage * dosage / observed : 0;
      if (keep[j] == TRUE && variation > 1e-12) {
        variable.push_back(markers[j]); destination.push_back(locations[j]); out.valid[locations[j]] = true;
      }
    }
    if (!variable.empty()) {
      auto region = gmat::read_standardized_bed_region(Rcpp::as<std::string>(bed[piece.first]),
          integer(source_samples), integer(counts[piece.first]), samples, variable, threads);
      for (std::size_t j = 0; j < variable.size(); ++j)
        std::copy_n(region.values.data() + j * n, n, x.data() + destination[j] * n);
    }
  }
  out.ld.resize(k * k);
  const auto status = gsolve::dense_product({x.data(), n, k, n}, true,
      {x.data(), n, k, n}, {out.ld.data(), k, k, k});
  if (!status) Rcpp::stop(status.message());
  for (Index j = 0; j < k; ++j) {
    out.ld[j + j * k] = out.valid[j] ? 1.0 : 0.0;
    for (Index i = j + 1; i < k; ++i) out.ld[j + i * k] = out.ld[i + j * k];
  }
  return out;
}

// Cluster near-perfect-LD variants into the same held-out partition: they
// cannot predict one another. Hash ordering is reproducible and leaves R RNG alone.
std::vector<int> partition(const std::vector<double>& r, int k, double max_r2,
    std::uint64_t seed) {
  std::vector<int> root(k); std::iota(root.begin(), root.end(), 0);
  const auto find = [&](int a) { while (root[a] != a) a = root[a]; return a; };
  for (int j = 0; j < k; ++j) for (int i = 0; i < j; ++i)
    if (r[i + j * k] * r[i + j * k] > max_r2) root[find(j)] = find(i);
  std::map<int, std::vector<int>> clusters;
  for (int i = 0; i < k; ++i) clusters[find(i)].push_back(i);
  std::vector<int> order; for (const auto& group : clusters) order.push_back(group.first);
  std::sort(order.begin(), order.end(), [&](int a, int b) {
    auto ha = hash(seed + a), hb = hash(seed + b); return ha == hb ? a < b : ha < hb;
  });
  std::vector<int> side(k); int sizes[2] = {0, 0};
  for (int id : order) {
    const int which = sizes[0] <= sizes[1] ? 0 : 1;
    for (int i : clusters[id]) side[i] = which;
    sizes[which] += static_cast<int>(clusters[id].size());
  }
  return side;
}

void check_window(const std::vector<double>& r, const std::vector<bool>& valid,
    Rcpp::NumericMatrix z, const Rcpp::IntegerVector& context, const std::vector<int>& core,
    const std::vector<int>& columns, Rcpp::NumericMatrix p, Rcpp::LogicalMatrix rejected,
    Rcpp::List control, int maximum, int& decompositions) {
  const int k = context.size(), c = columns.size();
  const int iterations = Rcpp::as<int>(control["iterations"]), seed = Rcpp::as<int>(control["seed"]);
  const double fraction = Rcpp::as<double>(control["rank_fraction"]), threshold = Rcpp::as<double>(control["p_threshold"]),
    pair_r2 = Rcpp::as<double>(control["max_pair_r2"]), min_variance = Rcpp::as<double>(control["min_variance"]);
  std::vector<std::vector<bool>> active(c, std::vector<bool>(k));
  std::vector<std::vector<double>> probability(c, std::vector<double>(k, NA_REAL));
  for (int j = 0; j < c; ++j) for (int i = 0; i < k; ++i)
    active[j][i] = valid[i] && std::isfinite(z(context[i], columns[j]));
  for (int iteration = 0; iteration < iterations; ++iteration) {
    Rcpp::checkUserInterrupt();
    for (auto& values : probability) std::fill(values.begin(), values.end(), NA_REAL);
    auto side = partition(r, k, pair_r2, hash(seed + static_cast<Index>(context[0])) + iteration);
    for (int fold = 0; fold < 2; ++fold) {
      std::map<std::vector<int>, std::vector<int>> batches;
      for (int j = 0; j < c; ++j) {
        std::vector<int> observed;
        for (int i = 0; i < k; ++i) if (side[i] != fold && active[j][i]) observed.push_back(i);
        if (!observed.empty()) batches[observed].push_back(j);
      }
      for (const auto& batch : batches) {
        const auto& observed = batch.first; const Index t = observed.size();
        std::vector<double> gram(t * t);
        for (Index j = 0; j < t; ++j) for (Index i = 0; i < t; ++i) gram[i + j * t] = r[observed[i] + observed[j] * k];
        gsolve::SymmetricEigensystemOptions options; options.maximum_dimension = maximum;
        auto eig = gsolve::compute_symmetric_eigensystem({gram.data(), t, t, t}, options);
        if (!eig.status) Rcpp::stop("LD-check eigensystem: " + eig.status.message());
        ++decompositions;
        Index rank = 0; const double cutoff = eig.eigenvalues[0] * 1e-8;
        while (rank < t && eig.eigenvalues[rank] > cutoff) ++rank;
        const Index retained = rank ? std::max<Index>(1, static_cast<Index>(std::floor(rank * fraction))) : 0;
        if (!retained) continue;
        std::vector<double> score(retained * batch.second.size(), 0.0);
        for (std::size_t j = 0; j < batch.second.size(); ++j)
          for (Index a = 0; a < retained; ++a) for (Index i = 0; i < t; ++i)
            score[a + j * retained] += eig.eigenvectors[i + a * t] * z(context[observed[i]], columns[batch.second[j]]);
        for (int target = 0; target < k; ++target) if (valid[target] && side[target] == fold) {
          double q = 0; std::vector<double> projection(retained, 0.0);
          for (Index a = 0; a < retained; ++a) {
            for (Index i = 0; i < t; ++i) projection[a] += r[target + observed[i] * k] * eig.eigenvectors[i + a * t];
            q += projection[a] * projection[a] / eig.eigenvalues[a];
          }
          if (!std::isfinite(q) || q < -1e-8 || q > 1 + 1e-8) Rcpp::stop("Invalid LD-check conditional variance.");
          const double variance = 1 - std::max(0.0, std::min(1.0, q));
          if (variance < min_variance) continue;
          for (std::size_t j = 0; j < batch.second.size(); ++j) {
            const int column = batch.second[j]; const double value = z(context[target], columns[column]);
            if (!std::isfinite(value)) continue;
            double prediction = 0;
            for (Index a = 0; a < retained; ++a) prediction += projection[a] * score[a + j * retained] / eig.eigenvalues[a];
            probability[column][target] = R::pchisq((value - prediction) * (value - prediction) / variance, 1, false, false);
          }
        }
      }
    }
    if (iteration + 1 == iterations) break;
    for (int j = 0; j < c; ++j) {
      std::vector<int> weak, strong; int weak_count = 0, strong_count = 0;
      for (int i = 0; i < k; ++i) if (active[j][i]) {
        bool associated = std::abs(z(context[i], columns[j])) >= 2.5758293035489004;
        if (associated) ++strong_count; else ++weak_count;
        if (std::isfinite(probability[j][i]) && probability[j][i] < threshold)
          (associated ? strong : weak).push_back(i);
      }
      const auto by_p = [&](int a, int b) { return probability[j][a] == probability[j][b] ? a < b : probability[j][a] < probability[j][b]; };
      std::sort(weak.begin(), weak.end(), by_p); std::sort(strong.begin(), strong.end(), by_p);
      const int nw = std::min<int>(weak.size(), static_cast<int>(std::floor(.005 * weak_count)));
      const double rate = weak_count ? static_cast<double>(nw) / weak_count : 0;
      const int ns = std::min<int>(strong.size(), static_cast<int>(std::floor(rate * strong_count)));
      for (int a = 0; a < nw; ++a) active[j][weak[a]] = false;
      for (int a = 0; a < ns; ++a) active[j][strong[a]] = false;
    }
  }
  for (int j = 0; j < c; ++j) for (int i : core) if (valid[i] && std::isfinite(z(context[i], columns[j]))) {
    p(context[i], columns[j]) = probability[j][i];
    rejected(context[i], columns[j]) = !active[j][i] ||
      (std::isfinite(probability[j][i]) && probability[j][i] < threshold);
  }
}

void impute_window(const std::vector<double>& r, const std::vector<bool>& valid,
    Rcpp::NumericMatrix accepted, const Rcpp::IntegerVector& context, const std::vector<int>& core,
    const std::vector<int>& columns, Rcpp::NumericMatrix out, Rcpp::NumericMatrix quality,
    Rcpp::LogicalMatrix imputed, double lambda, double minimum_r2, int& factorizations) {
  const int k = context.size();
  std::map<std::vector<int>, std::vector<int>> batches;
  for (int j : columns) {
    bool needed = false; for (int i : core) needed |= valid[i] && !std::isfinite(accepted(context[i], j));
    if (!needed) continue;
    std::vector<int> observed;
    for (int i = 0; i < k; ++i) if (valid[i] && std::isfinite(accepted(context[i], j))) observed.push_back(i);
    if (observed.empty()) {
      for (int i : core) if (valid[i] && !std::isfinite(accepted(context[i], j))) quality(context[i], j) = 0;
    } else batches[observed].push_back(j);
  }
  for (const auto& batch : batches) {
    Rcpp::checkUserInterrupt(); const auto& observed = batch.first; const auto& traits = batch.second;
    const Index t = observed.size(); std::vector<int> missing;
    for (int i : core) if (valid[i] && !std::isfinite(accepted(context[i], traits[0]))) missing.push_back(i);
    const Index u = missing.size(); std::vector<double> gram(t * t), rhs(t * u), solved(t * u);
    for (Index j = 0; j < t; ++j) for (Index i = 0; i < t; ++i) gram[i + j * t] = r[observed[i] + observed[j] * k];
    for (Index i = 0; i < t; ++i) gram[i + i * t] += lambda;
    gsolve::DenseCholeskyInverse factor({gram.data(), t, t, t});
    if (!factor.validation_status()) Rcpp::stop("Imputation factorization: " + factor.validation_status().message());
    ++factorizations; std::vector<double>().swap(gram);
    for (Index j = 0; j < u; ++j) for (Index i = 0; i < t; ++i) rhs[i + j * t] = r[observed[i] + missing[j] * k];
    gsolve::Workspace workspace;
    auto status = factor.apply({rhs.data(), t, u, t}, {solved.data(), t, u, t}, workspace);
    if (!status) Rcpp::stop(status.message());
    for (Index a = 0; a < u; ++a) {
      double q = 0; for (Index i = 0; i < t; ++i) q += rhs[i + a * t] * solved[i + a * t];
      if (!std::isfinite(q) || q < -1e-8 || q > 1 + 1e-8) Rcpp::stop("Invalid imputation quality.");
      q = std::max(0.0, std::min(1.0, q));
      for (int j : traits) {
        quality(context[missing[a]], j) = q;
        if (q < minimum_r2 || q <= 1e-12) continue;
        double prediction = 0;
        for (Index i = 0; i < t; ++i) prediction += solved[i + a * t] * accepted(context[observed[i]], j);
        prediction /= std::sqrt(q);
        if (!std::isfinite(prediction)) Rcpp::stop("Non-finite imputed score.");
        out(context[missing[a]], j) = prediction; imputed(context[missing[a]], j) = true;
      }
    }
  }
}
}

// [[Rcpp::export]]
Rcpp::List cpp_gbase_summary_prepare(Rcpp::CharacterVector bed, double source_samples,
    Rcpp::NumericVector marker_counts, Rcpp::List sample_groups,
    Rcpp::IntegerVector component_indices, Rcpp::NumericVector source_indices,
    Rcpp::NumericMatrix z, Rcpp::List windows, Rcpp::NumericMatrix weights,
    Rcpp::Function reference_qc, Rcpp::NumericMatrix eaf, Rcpp::LogicalMatrix study_eligible, double max_afdiff,
    bool ldcheck, bool do_impute, double lambda, double minimum_r2,
    int max_markers, int threads, Rcpp::List control) {
  const int m = z.nrow(), traits = z.ncol(), g = sample_groups.size();
  if (!traits || !g || component_indices.size() != m || source_indices.size() != m ||
      weights.nrow() != g || weights.ncol() != traits || bed.size() != marker_counts.size() ||
      max_markers < 2 || threads < 1 || !(lambda > 0)) Rcpp::stop("Invalid summary preparation dimensions.");
  if (eaf.size() && (eaf.nrow() != m || eaf.ncol() != traits)) Rcpp::stop("Frequency dimensions disagree with scores.");
  if (study_eligible.size() && (study_eligible.nrow() != m || study_eligible.ncol() != traits))
    Rcpp::stop("Study QC dimensions disagree with scores.");
  std::vector<std::vector<Index>> samples(g);
  for (int a = 0; a < g; ++a) {
    for (double x : Rcpp::NumericVector(sample_groups[a])) samples[a].push_back(integer(x));
    if (samples[a].size() < 2) Rcpp::stop("Reference group requires at least two samples.");
  }
  std::map<std::vector<double>, std::vector<int>> ancestry_batches;
  for (int j = 0; j < traits; ++j) {
    std::vector<double> w(g); for (int a = 0; a < g; ++a) w[a] = weights(a, j);
    ancestry_batches[w].push_back(j);
  }
  Rcpp::NumericMatrix accepted = Rcpp::clone(z), out, quality(m, traits), p(m, traits);
  Rcpp::LogicalMatrix eligible(m, traits), rejected(m, traits), imputed(m, traits);
  std::fill(quality.begin(), quality.end(), NA_REAL); std::fill(p.begin(), p.end(), NA_REAL);
  int factorizations = 0, decompositions = 0;
  if (do_impute && !ldcheck) out = Rcpp::clone(z);
  // Complete LD QC before any imputation: rejected scores in a neighbouring
  // window cannot contaminate predictions, and predictions never feed QC.
  for (int pass = 0; pass < (do_impute && ldcheck ? 2 : 1); ++pass) {
    if (pass == 1) {
      for (int j = 0; j < traits; ++j) for (int i = 0; i < m; ++i) {
        if (rejected(i, j) || !eligible(i, j)) accepted(i, j) = NA_REAL;
        if (std::isfinite(accepted(i, j))) quality(i, j) = 1;
      }
      out = Rcpp::clone(accepted);
    }
    for (R_xlen_t w = 0; w < windows.size(); ++w) {
      Rcpp::checkUserInterrupt(); Rcpp::List plan(windows[w]);
      Rcpp::IntegerVector context(plan["indices"]), target(plan["targets"]); const Index k = context.size();
      if (!k || k > static_cast<Index>(max_markers)) Rcpp::stop("Invalid summary preparation window.");
      for (int id : context) if (id == NA_INTEGER || id < 0 || id >= m) Rcpp::stop("Window index out of bounds.");
      std::vector<int> core;
      for (int id : target) {
        auto at = std::find(context.begin(), context.end(), id);
        if (at == context.end()) Rcpp::stop("Target absent from its window."); core.push_back(at - context.begin());
      }
      if (pass == 1) {
        bool needed = false;
        for (int j = 0; j < traits; ++j) for (int i : core) needed |= eligible(context[i], j) && !std::isfinite(accepted(context[i], j));
        if (!needed) continue;
      }
      std::vector<Reference> references(g);
      for (int a = 0; a < g; ++a) {
        bool used = false; for (int j = 0; j < traits; ++j) used |= weights(a, j) > 0;
        if (used) references[a] = read_reference(bed, source_samples, marker_counts, samples[a], component_indices,
            source_indices, context, threads, reference_qc);
      }
      for (const auto& batch : ancestry_batches) {
        std::vector<double> r(k * k, 0), af(k, 0); std::vector<bool> valid(k, true);
        for (int a = 0; a < g; ++a) if (batch.first[a] > 0) {
          for (Index i = 0; i < k; ++i) { valid[i] = valid[i] && references[a].valid[i]; af[i] += batch.first[a] * references[a].af[i]; }
          for (Index i = 0; i < k * k; ++i) r[i] += batch.first[a] * references[a].ld[i];
        }
        // Frequency filtering can differ per trait even when ancestry weights agree.
        std::map<std::vector<bool>, std::vector<int>> validity_batches;
        for (int j : batch.second) {
          auto v = valid;
          if (study_eligible.size()) for (Index i = 0; i < k; ++i)
            v[i] = v[i] && study_eligible(context[i], j) == TRUE;
          if (eaf.size() && std::isfinite(max_afdiff)) for (Index i = 0; i < k; ++i)
            if (std::isfinite(eaf(context[i], j)) && std::abs(eaf(context[i], j) - af[i]) > max_afdiff) v[i] = false;
          if (pass == 1) for (Index i = 0; i < k; ++i) v[i] = v[i] && eligible(context[i], j);
          else for (int i : core) eligible(context[i], j) = v[i];
          validity_batches[v].push_back(j);
        }
        for (const auto& selection : validity_batches) {
          if (pass == 0 && ldcheck) check_window(r, selection.first, z, context, core,
              selection.second, p, rejected, control, max_markers, decompositions);
          if (do_impute && (pass == 1 || !ldcheck)) impute_window(r, selection.first, accepted, context, core,
              selection.second, out, quality, imputed, lambda, minimum_r2, factorizations);
        }
      }
    }
  }
  if (!do_impute) {
    out = Rcpp::clone(z);
    for (int j = 0; j < traits; ++j) for (int i = 0; i < m; ++i)
      if (rejected(i, j) || !eligible(i, j)) out(i, j) = NA_REAL;
  }
  if (do_impute) for (int j = 0; j < traits; ++j) for (int i = 0; i < m; ++i) {
    if (!eligible(i, j)) { out(i, j) = NA_REAL; quality(i, j) = NA_REAL; }
    else if (!rejected(i, j) && std::isfinite(z(i, j))) quality(i, j) = 1;
  }
  return Rcpp::List::create(Rcpp::_["z"] = out, Rcpp::_["r2"] = quality,
      Rcpp::_["imputed"] = imputed, Rcpp::_["eligible"] = eligible, Rcpp::_["p"] = p,
      Rcpp::_["rejected"] = rejected, Rcpp::_["factorizations"] = factorizations,
      Rcpp::_["decompositions"] = decompositions);
}
