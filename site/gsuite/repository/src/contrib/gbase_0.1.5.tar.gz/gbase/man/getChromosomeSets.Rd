\name{getChromosomeSets}
\alias{getChromosomeSets}
\title{Extract chromosome marker sets from a reference}
\usage{getChromosomeSets(Glist)}
\arguments{
\item{Glist}{Reference containing aligned file-wise rsids and chr vectors.}
}
\value{A named list of disjoint marker-ID vectors covering the reference.
Chromosomes and markers retain their first-occurrence/reference order.}
\description{Groups marker names by their chromosome labels using existing
metadata only, without opening genotype or LD files.}
\examples{
Glist <- list(rsids = list(c("a", "b", "c")), chr = list(c("1", "2", "1")))
getChromosomeSets(Glist)
}
