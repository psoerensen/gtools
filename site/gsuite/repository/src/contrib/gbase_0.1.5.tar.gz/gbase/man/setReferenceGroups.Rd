\name{setReferenceGroups}
\alias{setReferenceGroups}
\title{Label ancestry reference samples without copying genotypes}
\usage{setReferenceGroups(Glist, groups)}
\arguments{
\item{Glist}{Prepared genotype reference.}
\item{groups}{Named list of sample-ID vectors or one-based indices into Glist$ids.
Groups must be disjoint subsets of the prepared reference selection, each with at least two samples.}
}
\value{Glist with compact integer reference_groups, serializable using ordinary RDS.}
\description{Attaches ancestry sample selections used by summary checking and imputation.
It does not rebuild genotype descriptors, copy BED files or change existing LD resources.}
