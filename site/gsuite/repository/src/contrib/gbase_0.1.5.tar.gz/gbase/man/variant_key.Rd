\name{variant_key}
\alias{variant_key}
\title{Construct explicit variant keys}
\usage{
variant_key(x)
}
\arguments{
\item{x}{An ordinary data frame with qgg-style or descriptive identity columns.}
}
\value{
A character vector of chromosome, position, effect-allele, and other-allele keys.
}
\description{
Construct explicit variant keys while preserving the supplied allele orientation.
}
