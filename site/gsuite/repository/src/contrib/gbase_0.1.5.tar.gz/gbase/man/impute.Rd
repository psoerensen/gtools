\name{impute}
\alias{impute}
\title{Impute missing summary Z-scores onto the reference backbone}
\usage{
impute(Glist, stat, columns = NULL, ancestry = NULL, ancestry_weights = NULL,
  lambda = 0.1, r2 = 0.6, window = 1000000, buffer = 250000,
  max_markers = 2048L, nthreads = 1L)
}
\arguments{
\item{Glist}{Prepared BED reference with optional ancestry sample groups.}
\item{stat}{Summary data frame, numeric marker-by-trait matrix, or gact list containing z.}
\item{columns}{Data-frame Z-score columns. Defaults to z/stat, or derives Z from b/seb.}
\item{ancestry}{One ancestry per trait, optionally named. Defaults to the ancestry attribute.}
\item{ancestry_weights}{Named vector or group-by-trait matrix of nonnegative weights summing to one.
These are squared standardized meta-analysis coefficients, constant across markers.}
\item{lambda}{Positive ridge adjustment.}
\item{r2}{Minimum prediction quality in [0,1].}
\item{window, buffer}{Core and flanking widths in base pairs.}
\item{max_markers}{Maximum local markers; dense cores split and buffers shorten to respect the bound.}
\item{nthreads}{Local decoding thread count; global BLAS settings are unchanged.}
}
\value{Input format in Glist marker order, with an imputation attribute containing
r2, imputed indicators, factorization count and settings. Matrix/list columns are traits.
Data-frame z aliases normalize to stat, consistently with checkStat.}
\description{Predicts missing Z-scores using complete local BED correlation and existing gsolve factors.}
\details{Observed scores must be coded to Glist a1. Supplied allele metadata is checked;
use checkStat for harmonization. Reference variation is required in every positively
weighted group. Missing/constant markers, missing predictor sets and low-quality predictions remain unsupported.
For \eqn{W=R_{mt}(R_{tt}+\lambda I)^{-1}}, predictions are W z / sqrt(q),
q=diag(W (R_tt+lambda I) W'). Quality is a reference prediction metric, not measured
study accuracy. Accepted observations are preserved, and predictions never feed other predictions.
Effect/SE/P fields for new predictions are left missing. Supplied n is retained;
missing n is not inferred. Downstream analyses requiring effects or sample sizes need those inputs explicitly.
Ancestry mixtures use sum(w_a R_a), appropriate as an approximation for independent
standardized meta-analysis scores with constant coefficients. They do not reconstruct
unknown study LD or model within-person local admixture, overlapping studies or marker-specific weights.
Use setReferenceGroups to label samples without copying genotypes.
Temporary matrices are bounded by the local window; no genome-wide LD files or eigenvectors are saved.}
\references{Pasaniuc et al. (2014), doi:10.1093/bioinformatics/btu416.}
\examples{\dontrun{
stat <- impute(Glist, stat)
attr(stat, "imputation")$r2
}}
