\name{gbase-package}
\alias{gbase}
\alias{gbase-package}
\title{Shared Data Contracts for Gsuite R Packages}
\description{Lightweight, task-neutral R data contracts.}
\docType{package}
