test_that("writeBED copies and repacks selected records in physical order", {
  calls <- cbind(c(0, 1, NA, 2, 0, 2, 1), c(2, 1, 2, 0, NA, 1, 0),
    c(NA, 0, 2, 1, 2, 0, 1), c(2, 2, 0, NA, 1, 1, 0))
  source <- write_tiny_plink(calls, c("c", "a", "z", "b"))
  dir <- tempfile("gbase-write-bed-")
  dir.create(dir)
  on.exit({
    unlink_tiny_plink(source)
    unlink(dir, recursive = TRUE)
  })
  bed <- source$paths[["bed"]]
  subset <- function(name, ...) writeBED(bed, bedWrite = file.path(dir, paste0(name, ".bed")), ...)
  Glist <- gprep(bedfiles = bed)
  GAlist <- list(rsids = c("z", "a"))
  Glist <- gprep(Glist, task = "subset", rsids = GAlist$rsids)
  expected_paths <- paste0(tools::file_path_sans_ext(bed), ".subset.", c("bed", "bim", "fam", "ext"))
  on.exit(unlink(expected_paths), add = TRUE)
  expect_true(all(file.exists(expected_paths)))
  expect_identical(Glist$rsids, list(c("a", "z")))
  expect_identical(Glist$ids, paste0("I", 0:6))
  expect_silent(validate_Glist(Glist))

  rsids <- c("b", "missing-2", "c", "missing-1", "z")
  expect_message(result <- subset("all", rsids = rsids), "absent from BIM: 2")
  expect_identical(result$missing_rsids, c("missing-2", "missing-1"))
  expect_equal(c(result$n_markers, result$n_samples), c(3, 7))
  read_raw <- function(path) readBin(path, "raw", file.size(path))
  header <- as.raw(c(0x6c, 0x1b, 0x01))
  original <- matrix(read_raw(bed)[-(1:3)], nrow = 2L)
  columns <- c(1, 3, 4)
  expect_identical(read_raw(result$paths$bed), c(header, as.vector(original[, columns])))
  expect_identical(read_raw(result$paths$fam), read_raw(source$paths[["fam"]]))
  prepared <- gprep(bedfiles = result$paths$bed)
  expect_identical(prepared$rsids[[1]], c("c", "z", "b"))

  sample_rows <- c(1, 3, 4, 6, 7)
  ids <- paste0("I", rev(sample_rows) - 1L)
  partial <- subset("partial", rsids = rev(prepared$rsids[[1]]), ids = ids)
  expected_bed <- file.path(dir, "expected.bed")
  write_tiny_bed(calls[sample_rows, columns], expected_bed)
  expect_identical(read_raw(partial$paths$bed), read_raw(expected_bed))
  expect_identical(readLines(partial$paths$bim), readLines(result$paths$bim))
  expect_identical(read.table(partial$paths$fam)[[2]], paste0("I", sample_rows - 1L))
  expect_equal(partial$n_samples, 5)

  expect_message(empty <- subset("empty", rsids = "absent"), "absent from BIM: 1")
  expect_equal(empty$n_markers, 0)
  expect_null(empty$paths)
  expect_error(subset("bad-sample", rsids = "a", ids = "absent"), "sample id not found")
  expect_error(subset("bad-rsids", rsids = c("a", "a")), "rsids must be unique")
  expect_error(subset("bad-ids", rsids = "a", ids = c("I0", "I0")), "sample ids must be unique")
  expect_error(subset("all", rsids = "a"), "output already exists")
  expect_error(writeBED(bed, bedWrite = bed, rsids = "a"), "output already exists")
  expect_error(writeBED(bed, bedWrite = file.path(dir, "collision.bed"),
    bimWrite = result$paths$bim, rsids = "a"), "output already exists")
  expect_false(any(file.exists(file.path(dir, paste0(c("empty", "bad-sample", "collision"), ".bed")))))
  expect_length(list.files(dir, all.files = TRUE, pattern = "^\\.plink-subset-"), 0)

  duplicate <- file.path(dir, "duplicate-source.bim")
  bim <- readLines(source$paths[["bim"]])
  writeLines(c(bim[1], bim[-2]), duplicate)
  expect_error(writeBED(bed, bimRead = duplicate, bedWrite = file.path(dir, "duplicate.bed"),
    rsids = "c"), "more than once")
  expect_false(file.exists(file.path(dir, "duplicate.bed")))
})

test_that("gprep subset returns new physical mappings across contributing files", {
  first <- write_tiny_plink(cbind(c(0, 1, 2), c(2, 1, 0)), c("c", "a"), "1")
  second <- write_tiny_plink(cbind(c(1, 0, 2), c(1, 2, 0)), c("z", "b"), "2")
  dir <- tempfile("gbase-subset-")
  dir.create(dir)
  on.exit({
    unlink_tiny_plink(first)
    unlink_tiny_plink(second)
    unlink(dir, recursive = TRUE)
  })
  Glist <- gprep(bedfiles = c(first$paths[["bed"]], second$paths[["bed"]]), study = "fixture")
  Glist$ldscores <- list(1:2, 1:2)
  expect_message(Glist_new <- gprep(Glist, task = "subset", c("b", "absent", "a"),
    ids = c("I2", "I0"), out_prefix = file.path(dir, "selected")), "absent from Glist: 1")
  expect_identical(Glist_new$rsids, list("a", "b"))
  expect_identical(Glist_new$ids, c("I0", "I2"))
  expect_identical(Glist_new$missing_rsids, "absent")
  expect_true(all(file.exists(Glist_new$gstatfiles)))
  expect_identical(lapply(Glist_new$source_marker_indices_0based, `[`, 1L), list(0, 0))
  expect_identical(Glist_new$study, "fixture")
  expect_null(Glist_new$ldscores)
  expect_silent(validate_Glist(Glist_new))

  source <- gprep(bedfiles = Glist$bedfiles, rsids = c("a", "b"))
  expect_message(one <- gprep(source, task = "subset", rsids = c("c", "b"),
    out_prefix = file.path(dir, "one"), mapped_dir = file.path(dir, "mapped")),
    "absent from Glist: 1")
  expect_s3_class(one, "gs_mapped_genotypes")
  expect_identical(one$rsids, list("b"))
  expect_identical(one$missing_rsids, "c")
  expect_identical(one$ids, Glist$ids)
  expect_identical(one$mchr, 1L)
  expect_silent(validate_Glist(one))

  error <- suppressMessages(tryCatch(gprep(Glist, task = "subset", rsids = "absent",
    out_prefix = file.path(dir, "none")), gbase_empty_subset = identity))
  expect_s3_class(error, "gbase_empty_subset")
  expect_identical(error$missing_rsids, "absent")
  expect_false(file.exists(file.path(dir, "none.1.bed")))

  # If a later component cannot publish, roll back the earlier component.
  collision <- file.path(dir, "rollback.2.bim")
  writeLines("existing output", collision)
  expect_error(gprep(Glist, task = "subset", rsids = c("a", "b"),
    out_prefix = file.path(dir, "rollback")), "output already exists")
  expect_identical(readLines(collision), "existing output")
  expect_false(any(file.exists(file.path(dir, paste0("rollback.1.", c("bed", "bim", "fam"))))))
})
