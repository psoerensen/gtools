test_that("direct SumHer scores agree with dense observed-variance LD", {
  genotype <- cbind(a = c(0, 1, 2, 0, 1, 2),
    b = c(2, 1, 0, 0, 2, 1), mono = rep(0, 6),
    missing = c(0, 2, NA, 2, 0, 1))
  fixture <- write_tiny_plink(genotype, colnames(genotype))
  on.exit(unlink_tiny_plink(fixture), add = TRUE)
  Glist <- gprep(bedfiles = fixture$paths[["bed"]])
  annotation <- cbind(first = c(1, 0, 0, 1), other = c(0, 1, 1, 0))
  rownames(annotation) <- colnames(genotype)
  means <- colMeans(genotype, na.rm = TRUE)
  centered <- sweep(genotype, 2L, means)
  centered[is.na(centered)] <- 0
  variance <- colMeans(centered^2)
  standardized <- sweep(centered, 2L, sqrt(variance), "/")
  standardized[, variance == 0] <- 0
  r2 <- (crossprod(standardized) / nrow(genotype))^2
  for (corrected in c(TRUE, FALSE)) for (hwe in c(TRUE, FALSE)) {
    result <- gprep(Glist, task = "ldscores", window_cm = 1, annotation = annotation, corrected = corrected,
      hwe_heritability = hwe, nthreads = 1L, block_size = 1L)$ldscore_models
    ld <- r2
    if (corrected) ld <- ld - (1 - ld) / (nrow(genotype) - 2)
    ld[variance == 0, ] <- ld[, variance == 0] <- 0
    diag(ld) <- as.numeric(variance > 0)
    expected_scale <- if (hwe) means * (1 - means / 2) else variance
    for (model in names(result$settings$powers)) {
      weight <- expected_scale^(1 + result$settings$powers[[model]])
      weight[variance == 0] <- 0
      expect_equal(unname(result$scores[, , model]),
        unname(ld %*% (annotation * weight)), tolerance = 1e-12)
    }
    expect_equal(unname(result$tagging), unname(rowSums(ld)), tolerance = 1e-12)
    expect_equal(unname(result$variance), unname(variance), tolerance = 1e-12)
    other <- gprep(Glist, task = "ldscores", window_cm = 1, annotation = annotation, corrected = corrected,
      hwe_heritability = hwe, nthreads = 1L, block_size = 4L)$ldscore_models
    expect_equal(result$scores, other$scores, tolerance = 1e-12)
    threshold <- gprep(Glist, task = "ldscores", window_cm = 1, annotation = annotation, corrected = corrected,
      hwe_heritability = hwe, min_r2 = 1, nthreads = 1L)$ldscore_models
    expect_equal(threshold$tagging, result$tagging, tolerance = 1e-12)
  }
  expect_null(Glist$sparseLD)
})


test_that("gprep integrates direct scores, windows and threshold aliases", {
  genotype <- cbind(a=c(0,1,2,0,1,2), b=c(2,1,0,0,2,1), c=c(0,2,1,2,0,1))
  fixture <- write_tiny_plink(genotype, colnames(genotype))
  on.exit(unlink_tiny_plink(fixture), add=TRUE)
  g <- gprep(bedfiles=fixture$paths[["bed"]])
  direct <- gprep(g, task="ldscores", max_distance_bp=100, block_size=1L)
  expect_null(direct$sparseLD)
  expect_null(direct$ldScores)
  expect_length(direct$ldscores, g$nchr)
  expect_identical(direct$rsidsLD, g$rsids)
  expect_equal(unname(unlist(direct$ldscores)), direct$ldscore_models$ordinary_scores)
  expect_equal(direct$ldscore_models$settings$min_r2, 0)
  expect_equal(direct$ldscore_models$settings$max_distance_variants, 0)
  r2 <- cor(genotype)^2
  r2[abs(row(r2)-col(r2))>1] <- 0
  expect_equal(unname(unlist(direct$ldscores)), unname(rowSums(r2)), tolerance=1e-12)
  alias <- gprep(g, task="ldscores", max_distance_bp=100, r2=.5)
  modern <- gprep(g, task="ldscores", max_distance_bp=100, min_r2=.5)
  expect_equal(alias$ldscore_models, modern$ldscore_models)
  expect_error(gprep(g,task="ldscores",r2=0,min_r2=0), "either")
  expect_error(gprep(g,task="ldscores",window_cm=1,max_distance_bp=100), "either")
  expect_error(gprep(g,task="ldscores",max_distance_bp=0), "allow_full_ld")
  expect_error(gprep(g,task="ldscores",rsids="unknown"), "belong")
  expect_error(gprep(g,task="ldscores",out_prefix=tempfile()), "write_ld")
  expect_error(gprep(g,task="ldscores",write_ld=TRUE,window_cm=1,out_prefix=tempfile()), "physical/marker")
  selected <- gprep(g,task="ldscores",rsids=c("a","c"),max_distance_bp=0,max_distance_variants=1)
  expect_equal(unname(unlist(selected$ldscores)), rep(1+cor(genotype[,1],genotype[,3])^2,2), tolerance=1e-12)
  expect_identical(selected$ldscore_models$marker_ids,c("a","c"))
  prefix <- tempfile("direct-score-ld-")
  on.exit(unlink_sparse_ld(prefix),add=TRUE)
  disk <- gprep(g,task="ldscores",max_distance_bp=100,write_ld=TRUE,out_prefix=prefix)
  expect_equal(disk$ldscore_models$scores,direct$ldscore_models$scores,tolerance=1e-12)
  expect_equal(unname(unlist(disk$ldscores)),unname(unlist(direct$ldscores)),tolerance=1e-6)
  expect_silent(verify_ld(disk))
  expect_error(gprep(g,task="sparseld",r2=.1,min_r2=.1),"either")
  expect_false("ldscore_sumher_style" %in% getNamespaceExports("gbase"))
})


test_that("ordinary monomorphic self scores do not depend on persistence", {
  fixture <- write_tiny_plink(cbind(a=c(0,1,2,0),mono=rep(0,4)),c("a","mono"))
  on.exit(unlink_tiny_plink(fixture),add=TRUE)
  g <- gprep(bedfiles=fixture$paths[["bed"]])
  direct <- gprep(g,task="ldscores")
  prefix <- tempfile("mono-score-ld-")
  on.exit(unlink_sparse_ld(prefix),add=TRUE)
  disk <- gprep(g,task="ldscores",write_ld=TRUE,out_prefix=prefix)
  expect_equal(getLDscores(direct),getLDscores(disk),tolerance=1e-6)
  expect_equal(unname(getLDscores(direct)["mono"]),1)
  expect_equal(unname(direct$ldscore_models$scores["mono",,]),c(0,0))
})
