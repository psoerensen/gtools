.gprep_ldscores <- function(Glist, annotation, powers, ids, rsids,
    window_cm, max_bp, max_variants, min_r2, corrected, hwe_heritability,
    block_size, nthreads, write_ld, out_prefix, overwrite, allow_full_ld) {
  audited <- .gprep_validate(Glist)
  ids <- .gprep_selection(ids, "ids")
  rsids <- .gprep_selection(rsids, "rsids")
  max_bp <- .gprep_count(max_bp, "max_distance_bp", 0L)
  max_variants <- .gprep_count(max_variants, "max_distance_variants", 0L)
  use_cm <- !is.null(window_cm)
  window_cm <- if (use_cm) .gprep_number(window_cm, "window_cm") else 0
  write_ld <- .gprep_flag(write_ld, "write_ld")
  overwrite <- .gprep_flag(overwrite, "overwrite")
  if (write_ld && is.null(out_prefix)) .gbase_stop("write_ld = TRUE requires out_prefix.")
  allow_full_ld <- .gprep_flag(allow_full_ld, "allow_full_ld")
  if (!use_cm && max_bp == 0 && max_variants == 0 && !allow_full_ld)
    .gbase_stop("Set allow_full_ld = TRUE when all distance windows are disabled.")
  if (write_ld && use_cm)
    .gbase_stop("Saving pairwise LD currently requires physical/marker windows.")
  if (!write_ld && (!is.null(out_prefix) || isTRUE(overwrite)))
    .gbase_stop("out_prefix and overwrite require write_ld = TRUE for LD scores.")
  min_r2 <- .gprep_number(min_r2, "min_r2")
  corrected <- .gprep_flag(corrected, "corrected")
  hwe_heritability <- .gprep_flag(hwe_heritability, "hwe_heritability")
  block_size <- .gprep_count(block_size, "block_size")
  nthreads <- .gprep_count(nthreads, "nthreads")
  if ((use_cm && window_cm <= 0) || min_r2 < 0 || min_r2 > 1)
    .gbase_stop("`window_cm` must be positive and `min_r2` must be within [0,1].")
  if (!is.numeric(powers) || !length(powers) || any(!is.finite(powers)))
    .gbase_stop("`powers` must be a finite numeric vector.")
  if (is.null(names(powers)) || anyNA(names(powers)) ||
      any(!nzchar(names(powers))) || anyDuplicated(names(powers)))
    .gbase_stop("`powers` must have unique nonempty names.")
  all_ids <- unlist(Glist$rsids, use.names = FALSE)
  if (!is.null(rsids) && any(!rsids %in% all_ids))
    .gbase_stop("Requested score markers must belong to Glist.")
  selected_ids <- lapply(Glist$rsids, function(x) if (is.null(rsids)) x else x[x %in% rsids])
  active <- which(lengths(selected_ids) > 0L)
  if (!length(active)) .gbase_stop("`Glist` has no selected markers.")
  marker_ids <- unlist(selected_ids[active], use.names = FALSE)
  if (is.null(annotation)) {
    annotation <- matrix(1, length(marker_ids), 1L,
      dimnames = list(marker_ids, "Base"))
  }
  parsed <- .gbase_annotations(annotation, marker_ids)
  annotation_values <- parsed$values[match(marker_ids, parsed$marker_ids),
    , drop = FALSE]
  reference_ids <- if (!is.null(ids)) ids else if (!is.null(Glist$study_ids))
    Glist$study_ids else Glist$ids
  rows <- match(reference_ids, Glist$ids)
  if (anyNA(rows) || length(rows) < if (corrected) 3L else 2L)
    .gbase_stop("The reference panel has too few known samples.")
  resources <- audited$resources[active]
  families <- audited$resources[[1L]]$samples$family_id[rows]
  result <- cpp_gbase_ldscore_sumher_style(
    lapply(resources, `[[`, "paths"), families, reference_ids,
    unname(selected_ids[active]), annotation_values, unname(as.double(powers)),
    window_cm, min_r2, corrected, hwe_heritability, block_size, nthreads,
    max_bp, max_variants)
  if (!identical(as.character(result$marker_ids), marker_ids))
    .gbase_stop("Native SumHer marker order does not match Glist.")
  # Preserve the legacy ordinary LD-score unit diagonal, including markers
  # with no genotype variation. Architecture scores/tagging retain zero there.
  result$ordinary_scores[result$variance == 0] <- 1
  dimnames(result$scores) <- list(marker_ids, parsed$annotation_names,
    names(powers))
  dimnames(result$expected_heritability) <- list(marker_ids, names(powers))
  names(result$tagging) <- marker_ids
  names(result$neighbours) <- marker_ids
  names(result$variance) <- marker_ids
  names(result$heritability_scale) <- marker_ids
  result$settings <- list(window_cm = if (use_cm) window_cm else NULL,
    max_distance_bp = max_bp, max_distance_variants = max_variants,
    min_r2 = min_r2, annotation = annotation_values, marker_ids = marker_ids,
    reference_sample_size = length(reference_ids), write_ld = write_ld,
    corrected = corrected, hwe_heritability = hwe_heritability,
    block_size = block_size, nthreads = nthreads,
    powers = powers, reference_ids = reference_ids,
    source = "direct BED chunks and OpenMP-split BLAS")
  if (write_ld) Glist <- .gprep_sparseld(Glist, out_prefix, ids, rsids,
    max_bp, max_variants, min_r2, block_size, nthreads, overwrite, allow_full_ld)
  if (!write_ld && is.null(Glist$sparseLD)) {
    sizes <- lengths(selected_ids)
    ends <- cumsum(sizes)
    starts <- ends - sizes + 1L
    Glist$ldscores <- lapply(seq_along(sizes), function(i)
      if (sizes[i]) unname(result$ordinary_scores[starts[i]:ends[i]]) else numeric())
    Glist$rsidsLD <- selected_ids
    Glist$idsLD <- reference_ids
  }
  Glist$ldscore_models <- result
  validate_Glist(Glist)
  Glist
}
