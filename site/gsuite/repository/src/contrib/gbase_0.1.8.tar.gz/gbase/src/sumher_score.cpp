#include <Rcpp.h>
#include <R_ext/BLAS.h>
#include <R_ext/RS.h>
#include <gmat/sumher_score.hpp>
#include <memory>

namespace {
// Called from native OpenMP workers. No R allocation or R API calls here.
void r_blas_crossproduct(int rows,int columns,int samples,
                        const double* a,const double* b,double* c) {
  const double alpha=1.0/samples, beta=0;
  F77_CALL(dgemm)("T","N",&rows,&columns,&samples,&alpha,a,&samples,
                 b,&samples,&beta,c,&rows FCONE FCONE);
}
}

// [[Rcpp::export]]
Rcpp::List cpp_gbase_ldscore_sumher_style(
    Rcpp::List paths, Rcpp::CharacterVector families,
    Rcpp::CharacterVector individuals, Rcpp::List marker_ids,
    Rcpp::NumericMatrix annotation, Rcpp::NumericVector powers,
    double window_cm,double min_r2,bool corrected,bool hwe_heritability,
    int block_size,int threads, double max_bp, double max_variants) {
  if (paths.size()==0 || paths.size()!=marker_ids.size() ||
      families.size()!=individuals.size()) Rcpp::stop("Invalid SumHer panel selection");
  std::vector<std::shared_ptr<const gmat::BedMatrix>> components;
  gmat::BedPanelSelection selected;
  const auto family=Rcpp::as<std::vector<std::string>>(families);
  const auto individual=Rcpp::as<std::vector<std::string>>(individuals);
  for (std::size_t i=0; i<family.size(); ++i) selected.samples.push_back({family[i],individual[i]});
  for (R_xlen_t i=0; i<paths.size(); ++i) {
    Rcpp::List p(paths[i]);
    components.push_back(std::make_shared<const gmat::BedMatrix>(
      Rcpp::as<std::string>(p["bed"]),Rcpp::as<std::string>(p["bim"]),
      Rcpp::as<std::string>(p["fam"])));
    auto ids=Rcpp::as<std::vector<std::string>>(marker_ids[i]);
    if (ids.empty()) Rcpp::stop("Empty component marker selection");
    selected.markers_by_component.push_back(std::move(ids));
  }
  gmat::BedPanel panel(std::move(components),std::move(selected));
  if (panel.marker_count()!=static_cast<std::uint64_t>(annotation.nrow()))
    Rcpp::stop("SumHer annotation rows must match the selected panel");
  gmat::SumherScoreOptions options;
  options.max_distance_bp=max_bp;
  options.max_distance_variants=static_cast<std::uint64_t>(max_variants);
  options.window_cm=window_cm; options.min_r2=min_r2;
  options.corrected=corrected; options.hwe_heritability=hwe_heritability;
  options.block_size=block_size; options.threads=threads;
  options.crossproduct=r_blas_crossproduct;
  options.checkpoint=[]() {Rcpp::checkUserInterrupt();};
  const auto result=gmat::ldscore_sumher_style(panel,
    Rcpp::as<std::vector<double>>(annotation),static_cast<std::size_t>(annotation.ncol()),
    Rcpp::as<std::vector<double>>(powers),options);
  Rcpp::NumericVector scores=Rcpp::wrap(result.scores);
  scores.attr("dim")=Rcpp::IntegerVector::create(annotation.nrow(),annotation.ncol(),powers.size());
  Rcpp::NumericVector expected=Rcpp::wrap(result.expected_heritability);
  expected.attr("dim")=Rcpp::IntegerVector::create(annotation.nrow(),powers.size());
  return Rcpp::List::create(Rcpp::_["marker_ids"]=result.marker_ids,
    Rcpp::_["scores"]=scores,Rcpp::_["ordinary_scores"]=result.ordinary_scores,Rcpp::_["tagging"]=result.tagging,
    Rcpp::_["neighbours"]=result.neighbours,Rcpp::_["variance"]=result.variance,
    Rcpp::_["heritability_scale"]=result.heritability_scale,
    Rcpp::_["expected_heritability"]=expected,
    Rcpp::_["correlation_threads"]=result.correlation_threads,
    Rcpp::_["reference_samples"]=static_cast<double>(result.reference_samples));
}
