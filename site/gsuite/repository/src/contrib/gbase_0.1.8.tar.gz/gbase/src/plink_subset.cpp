#include <Rcpp.h>
#include <gmat/plink_subset.hpp>

namespace {
std::vector<std::string_view> views(const Rcpp::CharacterVector& values, const char* name) {
  std::vector<std::string_view> result;
  result.reserve(values.size());
  // A mapped character vector can generate strings on demand. Materialize
  // that input once so all borrowed string bytes stay rooted during the call.
  const auto strings = static_cast<const SEXP*>(DATAPTR_RO(values));
  for (R_xlen_t i = 0; i < values.size(); ++i) {
    const auto value = strings[i];
    if (value == NA_STRING) Rcpp::stop("%s contains NA", name);
    result.emplace_back(CHAR(value), LENGTH(value));
  }
  return result;
}
} // namespace

// [[Rcpp::export]]
Rcpp::List cpp_gbase_write_bed_subset(std::string bed, std::string bim, std::string fam,
    std::string bed_out, std::string bim_out, std::string fam_out,
    Rcpp::CharacterVector rsids, Rcpp::CharacterVector ids) {
  const auto result = gmat::write_plink_subset({bed, bim, fam}, {bed_out, bim_out, fam_out},
      views(rsids, "rsids"), views(ids, "ids"));
  return Rcpp::List::create(Rcpp::_["n_markers"] = static_cast<double>(result.marker_count),
      Rcpp::_["n_samples"] = static_cast<double>(result.sample_count),
      Rcpp::_["missing_rsids"] = result.missing_rsids);
}
