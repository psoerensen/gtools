package_dir <- Sys.getenv("R_PACKAGE_DIR")
arch <- sub("^[/\\]+", "", Sys.getenv("R_ARCH", ""))
destination <- if (nzchar(arch)) file.path(package_dir, "libs", arch) else file.path(package_dir, "libs")
dir.create(destination, recursive = TRUE, showWarnings = FALSE)
shared <- file.path(getwd(), paste0(Sys.getenv("R_PACKAGE_NAME"), .Platform$dynlib.ext))
if (!file.exists(shared) || !file.copy(shared, destination, overwrite = TRUE, copy.mode = TRUE)) stop("Could not install package shared library", call. = FALSE)
core_destination <- file.path(package_dir, "lib")
dir.create(core_destination, recursive = TRUE, showWarnings = FALSE)
core <- file.path(getwd(), "libgsuite_core.a")
core_symbols_path <- file.path(core_destination, "libgsuite_core.a.symbols.rds")
if (file.exists(core_symbols_path)) unlink(core_symbols_path)
if (!file.exists(core) || !file.copy(core, core_destination, overwrite = TRUE, copy.mode = TRUE)) stop("Could not install libgsuite_core.a", call. = FALSE)
symbol_path <- file.path(getwd(), "symbols.rds")
installed_symbols <- file.path(destination, "symbols.rds")
if (file.exists(installed_symbols)) unlink(installed_symbols)
object_files <- c("RcppExports.o", "gprep.o", "impute.o", "mapped_glist.o", "plink_subset.o", 
"sumher_score.o", "vendor/gbits/src/ancestry.o", "vendor/gbits/src/bed_summary.o", 
"vendor/gbits/src/bed_subset.o", "vendor/gbits/src/bed_selection.o", 
"vendor/gbits/src/bed_reader.o", "vendor/gbits/src/bed_writer.o", 
"vendor/gbits/src/cpu_features.o", "vendor/gbits/src/execution.o", 
"vendor/gbits/src/genotype_transform.o", "vendor/gbits/src/hap_file.o", 
"vendor/gbits/src/marker_solver.o", "vendor/gbits/src/packed_matrix.o", 
"vendor/gbits/src/phased_haplotypes.o", "vendor/gbits/src/prepared_matrix.o", 
"vendor/gbits/src/simd_kernels.o", "vendor/gbits/src/tiled_bed.o", 
"vendor/gbits/src/weighted_operators.o", "vendor/gbits/src/c_api.o", 
"vendor/gmat/src/indexed_matrix.o", "vendor/gmat/src/ancestry_panel.o", 
"vendor/gmat/src/relationship_kernels.o", "vendor/gmat/src/bed_matrix.o", 
"vendor/gmat/src/plink_subset.o", "vendor/gmat/src/mapped_plink.o", 
"vendor/gmat/src/bed_panel.o", "vendor/gmat/src/bed_region.o", 
"vendor/gmat/src/c_api.o", "vendor/gmat/src/ld_score.o", "vendor/gmat/src/sumher_score.o", 
"vendor/gmat/src/metadata_writer.o", "vendor/gmat/src/sparse_ld_compute.o", 
"vendor/gmat/src/sparse_ld_csr.o", "vendor/gmat/src/sparse_ld_disk.o", 
"vendor/gmat/src/version.o", "vendor/gmat/src/vcf_reader.o", 
"vendor/gsolve/src/weighted_least_squares.o", "vendor/gsolve/src/lbfgs.o", 
"vendor/gsolve/src/weighted_binomial_logit.o", "vendor/gsolve/src/nonnegative_least_squares.o", 
"vendor/gsolve/src/bounded_minimum.o", "vendor/gsolve/src/affine_spectral_plan.o", 
"vendor/gsolve/src/block_pcg.o", "vendor/gsolve/src/dense_spd_factorization.o", 
"vendor/gsolve/src/execution.o", "vendor/gsolve/src/chunk_ridge.o", 
"vendor/gsolve/src/dense_cholesky_inverse.o", "vendor/gsolve/src/dense_product.o", 
"vendor/gsolve/src/moment_system.o", "vendor/gsolve/src/symmetric_eigensystem.o", 
"vendor/gsolve/src/quadratic_tail.o", "vendor/gsolve/src/student_t_tail.o", 
"vendor/gsolve/src/shared_block_preconditioner.o", "vendor/gsolve/src/block_diagonal_preconditioner.o", 
"vendor/gsolve/src/minres.o", "vendor/gsolve/src/pcg.o", "vendor/gsolve/src/pcg_batch.o", 
"vendor/gsolve/src/probes.o", "vendor/gsolve/src/streaming_rectangular.o", 
"vendor/gsolve/src/rectangular_operator.o", "vendor/gsolve/src/slq.o", 
"vendor/gsolve/src/solve_plan.o", "vendor/gsolve/src/structured_operators.o", 
"vendor/gsolve/src/absolute_coarse_preconditioner.o", "vendor/gsolve/src/diagonal_estimation.o", 
"vendor/gsolve/src/two_level_preconditioner.o", "vendor/gsolve/src/version.o", 
"vendor/gimp/src/imputation.o", "vendor/greml/src/association_variance_ratio.o", 
"vendor/greml/src/prediction_heritability_grid.o", "vendor/greml/src/prediction_variance.o", 
"vendor/greml/src/fixed_effect_design.o", "vendor/greml/src/matrix_free.o", 
"vendor/greml/src/matrix_free_stochastic.o", "vendor/greml/src/matrix_free_stochastic_optimizer.o", 
"vendor/greml/src/multivariate_rhe_blup.o", "vendor/greml/src/optimizer.o", 
"vendor/greml/src/rhe_initializer.o", "vendor/greml/src/version.o"
)
valid_symbols <- function(x) is.list(x) && length(x) > 0L && !is.null(names(x)) && !anyDuplicated(names(x)) && all(vapply(x, function(z) is.matrix(z) && all(c("name", "type", "value", "size") %in% colnames(z)), logical(1)))
local_symbols <- if (file.exists(symbol_path)) readRDS(symbol_path) else NULL
if (is.null(local_symbols)) {
  read_symbols <- get0("read_symbols_from_object_file", envir=asNamespace("tools"), mode="function", inherits=FALSE)
  if (!is.null(read_symbols) && nzchar(Sys.which("nm"))) {
    local_symbols <- lapply(object_files, read_symbols)
    names(local_symbols) <- object_files
  }
}
if (valid_symbols(local_symbols) && all(object_files %in% names(local_symbols))) {
  complete_symbols <- local_symbols
  symbols_complete <- TRUE
  core_objects <- c("vendor/gbits/src/ancestry.o", "vendor/gbits/src/bed_summary.o", 
"vendor/gbits/src/bed_subset.o", "vendor/gbits/src/bed_selection.o", 
"vendor/gbits/src/bed_reader.o", "vendor/gbits/src/bed_writer.o", 
"vendor/gbits/src/cpu_features.o", "vendor/gbits/src/execution.o", 
"vendor/gbits/src/genotype_transform.o", "vendor/gbits/src/hap_file.o", 
"vendor/gbits/src/marker_solver.o", "vendor/gbits/src/packed_matrix.o", 
"vendor/gbits/src/phased_haplotypes.o", "vendor/gbits/src/prepared_matrix.o", 
"vendor/gbits/src/simd_kernels.o", "vendor/gbits/src/tiled_bed.o", 
"vendor/gbits/src/weighted_operators.o", "vendor/gbits/src/c_api.o", 
"vendor/gmat/src/indexed_matrix.o", "vendor/gmat/src/ancestry_panel.o", 
"vendor/gmat/src/relationship_kernels.o", "vendor/gmat/src/bed_matrix.o", 
"vendor/gmat/src/plink_subset.o", "vendor/gmat/src/mapped_plink.o", 
"vendor/gmat/src/bed_panel.o", "vendor/gmat/src/bed_region.o", 
"vendor/gmat/src/c_api.o", "vendor/gmat/src/ld_score.o", "vendor/gmat/src/sumher_score.o", 
"vendor/gmat/src/metadata_writer.o", "vendor/gmat/src/sparse_ld_compute.o", 
"vendor/gmat/src/sparse_ld_csr.o", "vendor/gmat/src/sparse_ld_disk.o", 
"vendor/gmat/src/version.o", "vendor/gmat/src/vcf_reader.o", 
"vendor/gsolve/src/weighted_least_squares.o", "vendor/gsolve/src/lbfgs.o", 
"vendor/gsolve/src/weighted_binomial_logit.o", "vendor/gsolve/src/nonnegative_least_squares.o", 
"vendor/gsolve/src/bounded_minimum.o", "vendor/gsolve/src/affine_spectral_plan.o", 
"vendor/gsolve/src/block_pcg.o", "vendor/gsolve/src/dense_spd_factorization.o", 
"vendor/gsolve/src/execution.o", "vendor/gsolve/src/chunk_ridge.o", 
"vendor/gsolve/src/dense_cholesky_inverse.o", "vendor/gsolve/src/dense_product.o", 
"vendor/gsolve/src/moment_system.o", "vendor/gsolve/src/symmetric_eigensystem.o", 
"vendor/gsolve/src/quadratic_tail.o", "vendor/gsolve/src/student_t_tail.o", 
"vendor/gsolve/src/shared_block_preconditioner.o", "vendor/gsolve/src/block_diagonal_preconditioner.o", 
"vendor/gsolve/src/minres.o", "vendor/gsolve/src/pcg.o", "vendor/gsolve/src/pcg_batch.o", 
"vendor/gsolve/src/probes.o", "vendor/gsolve/src/streaming_rectangular.o", 
"vendor/gsolve/src/rectangular_operator.o", "vendor/gsolve/src/slq.o", 
"vendor/gsolve/src/solve_plan.o", "vendor/gsolve/src/structured_operators.o", 
"vendor/gsolve/src/absolute_coarse_preconditioner.o", "vendor/gsolve/src/diagonal_estimation.o", 
"vendor/gsolve/src/two_level_preconditioner.o", "vendor/gsolve/src/version.o", 
"vendor/gimp/src/imputation.o", "vendor/greml/src/association_variance_ratio.o", 
"vendor/greml/src/prediction_heritability_grid.o", "vendor/greml/src/prediction_variance.o", 
"vendor/greml/src/fixed_effect_design.o", "vendor/greml/src/matrix_free.o", 
"vendor/greml/src/matrix_free_stochastic.o", "vendor/greml/src/matrix_free_stochastic_optimizer.o", 
"vendor/greml/src/multivariate_rhe_blup.o", "vendor/greml/src/optimizer.o", 
"vendor/greml/src/rhe_initializer.o", "vendor/greml/src/version.o"
)
  if (!all(core_objects %in% names(local_symbols))) stop("Missing native archive object symbol tables")
  saveRDS(local_symbols[core_objects], core_symbols_path, version=2)
  if (symbols_complete) saveRDS(complete_symbols, installed_symbols, version=2)
} else {
  message("Object symbol metadata unavailable; retaining DLL-level compiled-code checking")
}
