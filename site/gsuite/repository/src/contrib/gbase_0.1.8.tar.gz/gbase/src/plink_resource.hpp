#pragma once

#include <Rcpp.h>
#include <gmat/mapped_plink.hpp>
#include <filesystem>

inline std::unique_ptr<gmat::MappedPlinkPanel> gbase_plink_panel(
    const Rcpp::CharacterVector& path) {
  auto paths = Rcpp::as<std::vector<std::string>>(path);
  if (paths.size() == 1 && std::filesystem::is_directory(paths.front()))
    return std::make_unique<gmat::MappedPlinkPanel>(paths.front());
  return std::make_unique<gmat::MappedPlinkPanel>(paths);
}
