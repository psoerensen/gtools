#pragma once
#include "gsolve/export.h"
#include "gsolve/matrix_view.hpp"
#include <cstddef>
#include <functional>
#include <vector>
namespace gsolve {
struct WeightedBinomialLogitOptions {
  double relative_score_tolerance{1e-10},relative_step_tolerance{1e-9};
  double relative_rank_tolerance{256};
  std::size_t maximum_iterations{100},maximum_evaluations{1000};
  std::size_t memory_limit_bytes{64u*1024u*1024u};
  std::vector<double> initial_coefficients; // empty=zeros; no implicit intercept
  std::function<bool()> cancel_requested{};
};
struct WeightedBinomialLogitDiagnostics {
  std::size_t rows{},columns{},positive_weight_rows{},iterations{},evaluations{},
      derivative_evaluations{},linear_solves{},backtracks{},numerical_rank{},estimated_numeric_bytes{};
  double log_weight_sum{},normalized_log_likelihood{},scaled_score_infinity{},
      predictor_step_infinity{},relative_predictor_step{},newton_decrement_squared{},
      information_condition_estimate{};
};
struct WeightedBinomialLogitResult {
  Status status{};
  WeightedBinomialLogitDiagnostics diagnostics;
  std::vector<double> solution; // populated only on successful numerical convergence
};
// Dense finite weighted Bernoulli-logit M-estimator. Matching one-column y,w;
// offsets is empty or one matching column. No intercept, penalty, scale change,
// probability clipping, coefficient cap, pseudoinverse or rank repair is added.
// Weights are normalized by their sum; this preserves the unpenalized optimizer.
// Damped Newton uses public checked moment systems and score AND predictor-step
// gates. Work/memory/cancellation/rank failures leave solution empty. Numerical
// convergence is not a general separation test or a finite-MLE existence proof.
GSOLVE_EXPORT WeightedBinomialLogitResult solve_weighted_binomial_logit(
    ConstMatrixView design,ConstMatrixView y,ConstMatrixView weights,
    ConstMatrixView offsets={},const WeightedBinomialLogitOptions& = {}) noexcept;
}
