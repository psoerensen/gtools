#ifndef GSOLVE_EXECUTION_HPP
#define GSOLVE_EXECUTION_HPP

#include <cstdint>
#include <functional>
#include <limits>

#include "gsolve/export.h"
#include "gsolve/status.hpp"

namespace gsolve {

struct ExecutionConfig {
  std::uint32_t requested_threads{1};
};

struct ExecutionResolution {
  Status status{};
  std::uint32_t requested_threads{1};
  std::uint32_t resolved_threads{1};
  bool openmp_enabled{false};
};

// These queries do not mutate process-global OpenMP state. Parallel operations
// use operation-local num_threads clauses and deterministic logical ordering.
GSOLVE_EXPORT bool openmp_available() noexcept;
GSOLVE_EXPORT ExecutionResolution resolve_execution(
    const ExecutionConfig& execution);

// Standard-thread execution shared with PCG's fixed-block vector executor.
// Does not change OpenMP state or generic resolve_execution() semantics.
GSOLVE_EXPORT ExecutionResolution resolve_independent_execution(const ExecutionConfig&);
// All indexed work is attempted; failures are returned in logical item order.
// Callbacks must be safe on distinct items; caller owns staging/rollback.
// Metadata scratch is admitted separately from callback/OS-thread storage.
GSOLVE_EXPORT Status execute_independent_work(std::uint64_t items,
    const ExecutionConfig&,const std::function<Status(std::uint64_t,std::uint32_t)>&,
    ExecutionResolution&,std::uint64_t maximum_scratch_bytes=8ULL*1024*1024);


}  // namespace gsolve

#endif
