#pragma once
#include "gmat/export.h"
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <map>
#include <memory>
#include <string>
#include <vector>

namespace gmat {
// Task-neutral rectangular data; numerical fields are little-endian FP64,
// column-major, and validity is one byte per entry. No GWAS semantics here.
struct IndexedMatrixField {
  std::string name;
  std::filesystem::path path;
  std::string sha256;
};
struct IndexedMatrixOptions {
  std::size_t rows=0, columns=0;
  std::vector<IndexedMatrixField> fields; // includes reserved uint8 field "valid"
  std::vector<std::filesystem::path> immutable_metadata; // optional file-state guards
  std::size_t maximum_columns=1000;
  std::uint64_t maximum_result_bytes=32*1024*1024;
};
struct MatrixReadRequest {
  std::vector<std::size_t> rows, columns; // explicit output order; no duplicates
  std::vector<std::string> fields;
};
struct MatrixReadBlock {
  std::vector<std::size_t> rows, columns;
  std::map<std::string,std::vector<double>> values;
  std::vector<std::uint8_t> valid;
};
struct IndexedMatrixReadStatistics {
  std::size_t requests=0, opens=0;
  std::uint64_t payload_bytes=0, integrity_bytes=0, maximum_result_bytes=0;
  double initialization_seconds=0, read_seconds=0, integrity_seconds=0;
};
// Also usable by adapters validating their own metadata and identity boundaries.
GMAT_EXPORT std::string indexed_matrix_file_sha256(const std::filesystem::path&);
GMAT_EXPORT void validate_matrix_read_request(const MatrixReadRequest&,
    std::size_t rows,std::size_t columns,std::size_t maximum_columns,
    std::uint64_t maximum_result_bytes);

class GMAT_EXPORT IndexedMatrixReader final {
 public:
  explicit IndexedMatrixReader(IndexedMatrixOptions);
  ~IndexedMatrixReader();
  IndexedMatrixReader(IndexedMatrixReader&&) noexcept;
  IndexedMatrixReader& operator=(IndexedMatrixReader&&) noexcept;
  IndexedMatrixReader(const IndexedMatrixReader&)=delete;
  IndexedMatrixReader& operator=(const IndexedMatrixReader&)=delete;
  MatrixReadBlock read(const MatrixReadRequest&);
  const IndexedMatrixReadStatistics& statistics() const noexcept;
 private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};
} // namespace gmat
