#ifndef GMAT_RELATIONSHIP_KERNELS_HPP
#define GMAT_RELATIONSHIP_KERNELS_HPP
#include "gmat/bed_matrix.hpp"
#include <array>
#include <limits>
namespace gmat {
enum class GenomicRelationshipCoding { additive, dominance };
struct GenomicRelationshipOptions {
  GenomicRelationshipCoding coding{GenomicRelationshipCoding::dominance};
  std::vector<std::uint64_t> samples{}, markers{};
  // Optional BIM-allele1 frequencies in selected marker order, strictly (0,1).
  // Empty estimates each frequency from nonmissing selected samples.
  std::vector<double> allele_frequencies{};
  std::uint64_t marker_tile{64};
  std::uint32_t decode_threads{1};
  double independent_ridge{0.0};
  std::uint64_t maximum_workspace_bytes{std::numeric_limits<std::uint64_t>::max()};
};
struct GenomicRelationshipResult {
  std::uint64_t dimension{0}, informative_markers{0};
  std::vector<double> covariance{}, allele_frequencies{};
  double normalization{0.0};
};
// Dense, column-major relationship; O(n^2+n*marker_tile) scratch/output.
// Raw dosage counts BIM allele1. Additive x-2p, dominance {-2p^2,2p(1-p),
// -2(1-p)^2} for x={0,1,2}. Missing calls have zero coded contribution.
// Normalization sums 2p(1-p) (additive) or [2p(1-p)]^2 (dominance).
// Calls own their gbits reader; no full decoded panel is retained.
GMAT_EXPORT GenomicRelationshipResult make_genomic_relationship(
    const BedMatrix&, const GenomicRelationshipOptions& = {});
// Indexed principal submatrix of first tensor second, optionally plus ridge I.
// Input matrices must be finite symmetric covariance matrices. This primitive
// does not certify definiteness; the consuming statistical model must do so.
GMAT_EXPORT std::vector<double> indexed_product_covariance(
    std::uint64_t first_dimension,const std::vector<double>& first,
    std::uint64_t second_dimension,const std::vector<double>& second,
    const std::vector<std::array<std::uint64_t,2>>& pairs,
    double independent_ridge=0.0,
    std::uint64_t maximum_workspace_bytes=std::numeric_limits<std::uint64_t>::max());
}
#endif
