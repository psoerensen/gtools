#pragma once
#include "gsolve/matrix_view.hpp"
#include "gsolve/moment_system.hpp"
#include <cstddef>
#include <functional>
#include <vector>
namespace gsolve {
struct WeightedLeastSquaresOptions {
 double relative_rank_tolerance{256},relative_normal_tolerance{1e-9};
 bool equilibrate_columns{true},compute_inverse_information{true},retain_fitted{false};
 std::size_t memory_limit_bytes{64u*1024u*1024u};
 std::function<bool()> cancel_requested{};
};
struct WeightedLeastSquaresDiagnostics {
 std::size_t rows{},columns{},positive_weight_rows{},normalized_weight_underflows{},row_visits{},
     moment_system_calls{},requested_right_hand_sides{},successful_right_hand_sides{},estimated_numeric_bytes{};
 double log_weight_sum{},normalized_residual_sum_squares{},relative_normal_residual{};
 MomentSystemDiagnostics moment;
};
struct WeightedLeastSquaresResult {
 Status status;WeightedLeastSquaresDiagnostics diagnostics;
 std::vector<double> solution,inverse_information,column_scales,fitted,residual;
};
// Dense borrowed views; response and weights are matching one-column vectors.
// No intercept, offset, ridge, pseudoinverse or column dropping is inserted.
// Nonnegative finite weights with enough positive rows; finite X/y even on zero
// weight rows. Unit equilibration is numerical only; coefficients and inverse
// (X'WX)^-1 are returned in original units and absolute weight scale.
// Inverse information is not automatically an estimated coefficient covariance:
// known-noise versus relative-weight residual scaling belongs to the caller.
// Requested inverse diagonals outside positive finite double range fail.
// All returned arrays remain empty on failure/cancellation. Work admission excludes
// borrowed input/padding, callback and allocator overhead, not a process RSS cap.
GSOLVE_EXPORT WeightedLeastSquaresResult solve_weighted_least_squares(
 ConstMatrixView design,ConstMatrixView response,ConstMatrixView weights,
 const WeightedLeastSquaresOptions& = {}) noexcept;
}
