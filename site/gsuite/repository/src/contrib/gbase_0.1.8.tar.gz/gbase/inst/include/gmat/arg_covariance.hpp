#pragma once
#include <gmat/bed_panel.hpp>
#include <gsolve/linear_operator.hpp>
#include <array>

namespace gmat {
struct ArgIndividual {
  SampleIdentity identity;
  // Exact tskit sample NODE IDs, not row positions or inferred individual IDs.
  std::array<std::int32_t, 2> sample_nodes;
};
struct ArgBranchSpecification {
  double left{}, right{}; // Explicit half-open physical interval, no span averaging.
  double normalization{1.0}; // K = C B C' / normalization, strictly positive.
  // Empty: raw B. Otherwise nonnegative full-manifest weights summing to one.
  // Fix these from training; subset and target actions never re-estimate them.
  std::vector<double> centering_weights;
  std::string provenance; // Caller attests source/manifest correspondence.
  std::uint64_t maximum_staging_bytes{64ULL * 1024 * 1024};
};
// Opt-in gmat::arg target. Owns a tskit tree sequence behind an immutable pimpl;
// no tskit structs or private headers cross this installed C++ interface.
// Initial contract: complete, contemporaneous diploids, dated in generations,
// one root in every included local tree; no ancestry/genealogy inference.
class ArgBranchCovariance final : public gsolve::LinearOperator {
 public:
  static std::shared_ptr<const ArgBranchCovariance> load(
      const std::string& trees_path, std::vector<ArgIndividual> manifest,
      ArgBranchSpecification specification);
  ~ArgBranchCovariance() override;
  std::uint64_t rows() const noexcept override { return selection_.size(); }
  std::uint64_t columns() const noexcept override { return rows(); }
  gsolve::Symmetry symmetry() const noexcept override { return gsolve::Symmetry::symmetric; }
  gsolve::Definiteness definiteness() const noexcept override { return gsolve::Definiteness::positive_semidefinite; }
  bool concurrent_apply_supported() const noexcept override { return true; }
  bool has_exact_diagonal() const noexcept override { return true; }
  gsolve::Status apply(gsolve::ConstMatrixView, gsolve::MatrixView, gsolve::Workspace&) const override;
  gsolve::Status exact_diagonal(gsolve::MatrixView, gsolve::Workspace&) const override;
  // Ordered, unique full-manifest indices; same resource and centering base.
  std::shared_ptr<const ArgBranchCovariance> subset(std::vector<std::uint64_t>) const;
  // K[rows,cols] * input. Indices always address the FULL manifest, even on a subset.
  // All actions preserve output on failure and padding; input/output may alias.
  gsolve::Status apply_cross(const std::vector<std::uint64_t>& rows,
      const std::vector<std::uint64_t>& cols, gsolve::ConstMatrixView,
      gsolve::MatrixView, gsolve::Workspace&) const;
  const std::vector<ArgIndividual>& manifest() const noexcept;
  const ArgBranchSpecification& specification() const noexcept;
  const std::vector<std::uint64_t>& selection() const noexcept { return selection_; }
  std::uint64_t node_count() const noexcept;
  std::uint64_t edge_count() const noexcept;
  static const char* backend_version() noexcept;
 private:
  struct Impl;
  ArgBranchCovariance(std::shared_ptr<const Impl>, std::vector<std::uint64_t>);
  std::shared_ptr<const Impl> impl_;
  std::vector<std::uint64_t> selection_;
};
} // namespace gmat
