#ifndef GMAT_SUMHER_SCORE_HPP
#define GMAT_SUMHER_SCORE_HPP
#include "gmat/export.h"
#include "gmat/bed_panel.hpp"
#include <cstddef>
#include <functional>
#include <vector>
namespace gmat {
// Compute C = A'B / samples, column-major. A: samples x rows,
// B: samples x columns, C: rows x columns. Called concurrently when threads>1;
// callback must be thread-safe, must not throw, and must not call R APIs.
// The R adapter supplies dgemm from R's configured BLAS; keep BLAS threads=1.
using SumherCrossproduct = void (*)(int rows, int columns, int samples,
                                   const double* a, const double* b, double* c);
struct SumherScoreOptions {
  double window_cm=1, min_r2=0;
  double max_distance_bp=0;
  std::uint64_t max_distance_variants=0;
  bool corrected=true, hwe_heritability=true;
  int block_size=128, threads=1;
  SumherCrossproduct crossproduct=nullptr; // scalar reference fallback if absent
  std::function<void()> checkpoint{}; // main thread only, between chunks
};
struct SumherScoreResult {
  std::vector<std::string> marker_ids;
  // Column-major: marker + m*annotation + m*q*power.
  std::vector<double> scores, expected_heritability; // expected: marker + m*power
  std::vector<double> ordinary_scores; // uncorrected, min_r2-filtered scores
  std::vector<double> variance, heritability_scale, tagging, neighbours;
  std::uint64_t reference_samples=0;
  int correlation_threads=1;
};
// Annotations: column-major marker x annotation. Powers and annotations finite.
// Ordered cM within contiguous chromosomes; components are separate LD panels.
// Diagonals for polymorphic markers are one; monomorphic markers contribute
// zero. Tagging/neighbours include every in-window polymorphic pair, while
// min_r2 filters only annotation scores. No sparse LD matrix is materialized.
GMAT_EXPORT SumherScoreResult ldscore_sumher_style(
    const BedPanel&, const std::vector<double>& annotation,
    std::size_t annotation_count, const std::vector<double>& powers,
    const SumherScoreOptions& = {});
}
#endif
