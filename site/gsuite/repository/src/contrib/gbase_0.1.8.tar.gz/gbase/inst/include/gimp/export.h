#ifndef GIMP_EXPORT_H
#define GIMP_EXPORT_H

#if defined(GIMP_STATIC_DEFINE)
#  define GIMP_EXPORT
#elif defined(_WIN32) || defined(__CYGWIN__)
#  if defined(GIMP_BUILDING_LIBRARY)
#    define GIMP_EXPORT __declspec(dllexport)
#  else
#    define GIMP_EXPORT __declspec(dllimport)
#  endif
#elif defined(__GNUC__) && __GNUC__ >= 4
#  define GIMP_EXPORT __attribute__((visibility("default")))
#else
#  define GIMP_EXPORT
#endif

#endif
