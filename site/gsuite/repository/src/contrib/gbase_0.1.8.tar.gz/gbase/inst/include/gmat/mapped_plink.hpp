#ifndef GMAT_MAPPED_PLINK_HPP
#define GMAT_MAPPED_PLINK_HPP

#include "gmat/bed_matrix.hpp"

#include <cstdint>
#include <memory>
#include <optional>
#include <string>
#include <string_view>
#include <vector>

namespace gmat {

struct MappedPlinkSource {
  std::string bed;
  std::string bim;
  std::string fam;
};

struct MappedPlinkComponent {
  MappedPlinkSource source;
  std::uint64_t marker_count;
};

enum class PlinkTextField { rsids, chr, a1, a2, cpra };
enum class PlinkNumberField { pos, map, nmiss, af, af1, af2, maf, hom, het, n0, n1, n2 };

// Read-only columns. Legacy directories use memory mapping. With companion
// files, consume each text view before the next read of the same component
// and column. Use one reader per concurrent caller.
class GMAT_EXPORT MappedPlinkPanel final {
 public:
  explicit MappedPlinkPanel(const std::string& directory);
  explicit MappedPlinkPanel(const std::vector<std::string>& paths);
  ~MappedPlinkPanel();
  MappedPlinkPanel(const MappedPlinkPanel&) = delete;
  MappedPlinkPanel& operator=(const MappedPlinkPanel&) = delete;

  const std::optional<std::string>& study() const noexcept;
  const std::vector<SampleMetadata>& samples() const noexcept;
  const std::vector<MappedPlinkComponent>& components() const noexcept;

  std::string_view text(std::size_t component, PlinkTextField field, std::uint64_t row) const;
  double number(std::size_t component, PlinkNumberField field, std::uint64_t row) const;

 private:
  friend std::vector<std::string> write_plink_companions(
      const std::vector<MappedPlinkSource>&, const std::optional<std::string>&);
  MappedPlinkPanel(const std::vector<std::string>& paths, bool staged);
  struct Impl;
  std::unique_ptr<Impl> impl_;
};

// Publish a new immutable resource. Source triplets must share FAM identities
// in order. Every physical marker is written once, in BIM order.
GMAT_EXPORT void write_mapped_plink_panel(const std::string& directory,
    const std::vector<MappedPlinkSource>& sources, const std::optional<std::string>& study = {});

// Publish one same-stem .ext file per triplet. Paths are returned in
// input order. Existing outputs are refused.
GMAT_EXPORT std::vector<std::string> write_plink_companions(
    const std::vector<MappedPlinkSource>& sources, const std::optional<std::string>& study = {});

} // namespace gmat

#endif
