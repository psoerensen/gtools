#pragma once
#include <gimp/export.h>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace gimp {
struct ImputationWindow {
    // Column-major, one row per target. Non-evaluated cells have NaN quality.
    std::vector<double> prediction, quality;
    std::vector<std::uint8_t> imputed;
    std::size_t factorizations = 0;
};

// LD and scores are column-major in the same aligned window order. Nonfinite
// scores mark missing values. Targets are window row indices. The caller owns
// observed scores, orientation, study assignment, and eligibility.
GIMP_EXPORT ImputationWindow impute_window(const std::vector<double>& ld,
    const std::vector<bool>& eligible, const std::vector<double>& scores,
    const std::vector<std::size_t>& targets, std::size_t studies,
    double ridge, double minimum_r2);

// Uses a truncated symmetric pseudoinverse of the observed LD. Retains
// positive eigenvalues above relative_cutoff times the largest eigenvalue.
// The cutoff must be in (0, 1). Requires positive semidefinite LD up to
// rounding error and at most 2048 observed markers per mask.
GIMP_EXPORT ImputationWindow impute_window_spectral(const std::vector<double>& ld,
    const std::vector<bool>& eligible, const std::vector<double>& scores,
    const std::vector<std::size_t>& targets, std::size_t studies,
    double relative_cutoff, double minimum_r2);
} // namespace gimp
