#ifndef GBITS_BED_SUBSET_HPP
#define GBITS_BED_SUBSET_HPP

#include <gbits/export.h>
#include <cstdint>
#include <iosfwd>
#include <string>
#include <vector>

namespace gbits {

// Write a SNP-major BED stream for increasing, unique, zero-based marker
// rows. Empty sample_rows retains all samples and copies the packed bytes.
// Explicit sample rows are increasing and unique and retain their order.
GBITS_API void write_bed_subset(const std::string& source, std::uint64_t sample_count,
    std::uint64_t marker_count, const std::vector<std::uint64_t>& marker_rows,
    const std::vector<std::uint64_t>& sample_rows, std::ostream& output);

} // namespace gbits

#endif
