#ifndef GSOLVE_DENSE_CHOLESKY_INVERSE_HPP
#define GSOLVE_DENSE_CHOLESKY_INVERSE_HPP
#include "gsolve/linear_operator.hpp"
#include <limits>
namespace gsolve {
struct DenseCholeskyOptions {
  std::uint32_t threads{1};
  // Conservative allowance for factor plus fallback setup scratch.
  std::uint64_t maximum_factor_bytes{512ULL * 1024 * 1024};
};
// Immutable SPD inverse operator. Blocked LAPACK/BLAS with MKL when available;
// portable serial Eigen fallback. Owns O(k^2) factor, never an explicit
// inverse.
class GSOLVE_EXPORT DenseCholeskyInverse final : public LinearOperator {
public:
  DenseCholeskyInverse(ConstMatrixView, DenseCholeskyOptions = {});
  const Status &validation_status() const noexcept { return status_; }
  bool uses_mkl() const noexcept { return mkl_; }
  // Log determinant of the original SPD matrix; NaN after failed construction.
  double log_determinant() const noexcept { return logdet_; }
  std::uint64_t rows() const noexcept override { return n_; }
  std::uint64_t columns() const noexcept override { return n_; }
  Symmetry symmetry() const noexcept override { return Symmetry::symmetric; }
  Definiteness definiteness() const noexcept override {
    return status_ ? Definiteness::positive_definite : Definiteness::unknown;
  }
  Status apply(ConstMatrixView, MatrixView, Workspace &) const override;
  // Apply the retained exact factor with an independent, restored local
  // thread request. Does not mutate the factor or its default execution policy.
  // Multi-thread requests require MKL; invalid/unsupported requests publish no output.
  Status apply_with_threads(ConstMatrixView, MatrixView, Workspace &,
                            std::uint32_t threads) const;

private:
  std::uint64_t n_{0};
  std::vector<double> lower_;
  DenseCholeskyOptions options_;
  bool mkl_{false};
  double logdet_{std::numeric_limits<double>::quiet_NaN()};
  Status status_{};
};
} // namespace gsolve
#endif
