#pragma once

#include <algorithm>
#include <cstddef>
#include <limits>
#include <numeric>
#include <stdexcept>
#include <vector>

namespace gbits {

// Positional Burrows-Wheeler sweep over dense integer allele codes. Feed rows
// in either genomic direction. Divergences are in sweep coordinates: for
// adjacent ordered haplotypes, d is the first position of their shared suffix.
// d == rows_seen means no match at the newest row. d[0] is a sentinel.
class PbwtSweep {
public:
    explicit PbwtSweep(std::size_t haplotypes)
        : order_(haplotypes), divergence_(haplotypes), next_order_(haplotypes),
          next_divergence_(haplotypes) {
        if (haplotypes == 0) throw std::invalid_argument("PBWT requires haplotypes");
        std::iota(order_.begin(), order_.end(), std::size_t{0});
        maxima_.reserve(haplotypes);
    }

    const std::vector<std::size_t>& order() const noexcept { return order_; }
    const std::vector<std::size_t>& divergence() const noexcept { return divergence_; }

    void update(const std::vector<std::size_t>& codes, std::size_t alphabet) {
        const auto n = order_.size();
        if (codes.size() != n || alphabet == 0)
            throw std::invalid_argument("PBWT row dimensions differ");
        if (rows_ == std::numeric_limits<std::size_t>::max())
            throw std::length_error("PBWT sweep coordinate overflow");
        offsets_.assign(alphabet, 0);
        for (const auto code : codes) {
            if (code >= alphabet) throw std::invalid_argument("PBWT code outside alphabet");
            ++offsets_[code];
        }
        std::size_t offset = 0;
        for (auto& count : offsets_) {
            const auto next = offset + count;
            count = offset;
            offset = next;
        }
        last_.assign(alphabet, n);
        maxima_.clear();
        std::size_t binary_maxima[2]{};
        for (std::size_t i = 0; i < n; ++i) {
            const auto code = codes[order_[i]];
            const auto destination = offsets_[code]++;
            next_order_[destination] = order_[i];
            std::size_t start = rows_ + 1;
            if (alphabet <= 2) {
                for (auto& maximum : binary_maxima) maximum = std::max(maximum, divergence_[i]);
                if (last_[code] != n) start = binary_maxima[code];
                binary_maxima[code] = 0;
            } else {
                // Maintain the right-to-left record maxima of the old divergence
                // row. Query max divergence since the previous copy of this code.
                while (!maxima_.empty() && divergence_[maxima_.back()] <= divergence_[i])
                    maxima_.pop_back();
                maxima_.push_back(i);
                if (last_[code] != n)
                    start = divergence_[*std::upper_bound(maxima_.begin(), maxima_.end(), last_[code])];
            }
            next_divergence_[destination] = start;
            last_[code] = i;
        }
        order_.swap(next_order_);
        divergence_.swap(next_divergence_);
        ++rows_;
    }

private:
    std::size_t rows_ = 0;
    std::vector<std::size_t> order_, divergence_, next_order_, next_divergence_;
    std::vector<std::size_t> offsets_, last_, maxima_;
};

} // namespace gbits
