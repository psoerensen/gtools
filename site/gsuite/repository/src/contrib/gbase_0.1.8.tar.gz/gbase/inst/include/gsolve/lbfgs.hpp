#pragma once
#include "gsolve/export.h"
#include "gsolve/status.hpp"
#include <cstddef>
#include <functional>
#include <vector>
namespace gsolve {
using DifferentiableObjective=std::function<Status(const std::vector<double>&,double&,std::vector<double>&)>;
struct LbfgsOptions {
 std::size_t history_size{10},maximum_iterations{1000},maximum_evaluations{10000},maximum_backtracks{60};
 std::size_t memory_limit_bytes{64u*1024u*1024u};
 double gradient_tolerance{1e-8},relative_gradient_tolerance{0},initial_step{1},minimum_step{1e-20},backtrack_factor{.5},armijo_constant{1e-4},relative_curvature_threshold{1e-12};
 std::function<bool()> cancel_requested{};
};
struct LbfgsDiagnostics {
 std::size_t iterations{},evaluations{},backtracks{},history_updates{},curvature_skips{},direction_restarts{},estimated_numeric_bytes{};
 double initial_value{},value{},gradient_infinity{},initial_gradient_infinity{},step_infinity{},accepted_step{};
};
struct LbfgsResult {Status status{};LbfgsDiagnostics diagnostics;std::vector<double> solution;};
// Checked solver-array admission; callback/input/text/allocator overhead excluded.
GSOLVE_EXPORT std::size_t lbfgs_numeric_bytes(std::size_t dimension,std::size_t history_size);
// Safeguarded limited-memory BFGS, Armijo backtracking and gradient stationarity:
// ||g||inf <= absolute_tol + relative_tol*initial_||g||inf. No tiny-step or
// objective-change success or global minimum certificate. All failed/cancelled/
// budget-exhausted calls leave solution empty. Callback overwrites value and all
// gradient entries. Only trial non_finite_arithmetic is retried by backtracking;
// other failed callback statuses terminate. Numeric work limits are explicit.
GSOLVE_EXPORT LbfgsResult minimize_lbfgs(const DifferentiableObjective&,const std::vector<double>& initial,const LbfgsOptions& = {}) noexcept;
}
