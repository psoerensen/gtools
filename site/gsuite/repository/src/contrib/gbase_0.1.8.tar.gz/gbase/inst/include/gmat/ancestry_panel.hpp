#pragma once
#include <gmat/bed_panel.hpp>
#include <gbits/ancestry.hpp>
#include <cstddef>
namespace gmat {
// Manifest for BOTH the allele phases and the ancestry assignments. The nonempty
// phase_alignment token attests identical H1/H2 order and local phase switches.
// Bit 1 counts MarkerMetadata::allele1; no allele reinterpretation is automatic.
struct AncestryIdentity {
 std::vector<SampleIdentity> samples;
 std::vector<MarkerMetadata> markers;
 std::string phase_alignment;
};
struct AncestryCentering {
 std::vector<MarkerMetadata> markers;
 std::vector<std::string> ancestries;
 std::vector<double> frequencies; // marker-major, ancestry-minor TRAINING p
};
// One phased contribution to the AncestryPanel forward product for soft labels.
// Caller validates the aligned ancestry order, frequencies and posterior row.
inline double ancestry_forward_phase(unsigned allele,const double* probabilities,
    const double* frequencies,const double* effects,std::size_t ancestries) noexcept {
 double value=0.;
 for(std::size_t a=0;a<ancestries;++a)
  value+=probabilities[a]*(static_cast<double>(allele)-frequencies[a])*effects[a];
 return value;
}
// Immutable identity/centring binding; no genome expansion, phenotype or fit.
class GMAT_EXPORT AncestryPanel final {
 public:
 AncestryPanel(std::shared_ptr<const gbits::AncestryPhasedMatrix> matrix,
     AncestryIdentity genotype_identity,AncestryIdentity ancestry_identity,
     std::vector<std::string> ancestry_order,AncestryCentering training_centering);
 const AncestryIdentity& identity() const noexcept {return identity_;}
 const AncestryCentering& centering() const noexcept {return centering_;}
 std::vector<double> forward(const std::vector<double>& effects) const;
 std::vector<double> transpose(const std::vector<double>& response) const;
 gbits::AncestryMarkerBlock decode_marker(std::size_t marker,std::size_t first,std::size_t count) const;
 gbits::AncestryMarkerInformation marker_information(std::size_t marker,const std::vector<double>& response) const;
 std::vector<double> add_marker(std::size_t marker,const std::vector<double>& delta,const std::vector<double>& response) const;
 void update_marker(std::size_t marker,const std::vector<double>& delta,std::vector<double>& response) const;
 private:
 std::shared_ptr<const gbits::AncestryPhasedMatrix> matrix_;
 AncestryIdentity identity_;
 AncestryCentering centering_;
 std::vector<double> marker_frequencies(std::size_t marker) const;
};
}
