#pragma once
#include <cstddef>
#include <functional>
#include <vector>
#include "gsolve/export.h"
#include "gsolve/matrix_view.hpp"
namespace gsolve {
struct NonnegativeLeastSquaresOptions {
  double relative_gradient_tolerance{1e-10}, relative_rank_tolerance{0};
  std::size_t maximum_iterations{1000}, maximum_passive_solves{1000};
  std::size_t memory_limit_bytes{64u*1024u*1024u};
  std::function<bool()> cancel_requested{};
};
struct NonnegativeLeastSquaresDiagnostics {
  std::size_t rows{}, columns{}, numerical_rank{}, passive_rank{}, passive_count{};
  std::size_t iterations{}, passive_solves{}, qr_factorizations{}, estimated_numeric_bytes{};
  double gradient_tolerance{}, residual_norm{}, primal_violation{}, dual_violation{};
  double active_stationarity{}, complementarity{};
  bool full_column_rank{};
};
struct NonnegativeLeastSquaresResult {
  Status status{};
  NonnegativeLeastSquaresDiagnostics diagnostics;
  std::vector<double> solution, dual; // dual=A'(b-Ax), nonpositive on inactive coordinates
};
// Dense rectangular min ||A*x-b||_2 for x>=0, one RHS. Active-set search,
// private pivoted QR; no normal-equation ridge or clipping of an unconstrained
// solution. Rank deficiency is reported, not automatically repaired; success
// certifies the declared numerical KKT checks, not coefficient uniqueness.
// Every failure/cancellation leaves solution/dual empty; inputs are unchanged.
GSOLVE_EXPORT NonnegativeLeastSquaresResult solve_nonnegative_least_squares(
    ConstMatrixView design, ConstMatrixView rhs,
    const NonnegativeLeastSquaresOptions& = {}) noexcept;
}
