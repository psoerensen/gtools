#pragma once
#include <limits>
#include "gsolve/export.h"
#include "gsolve/status.hpp"
namespace gsolve {
struct StudentTTailResult {
  Status status{};
  double upper{std::numeric_limits<double>::quiet_NaN()};
  double two_sided{std::numeric_limits<double>::quiet_NaN()};
};
// Boost.Math complement tails, not subtraction from a rounded CDF.
// Finite positive df; +/-infinity statistics have their limiting tails.
GSOLVE_EXPORT StudentTTailResult student_t_tail(double statistic,double degrees_of_freedom);
}
