#pragma once
#include <gbits/c_api.h>
#include <gbits/export.h>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <vector>
namespace gbits {
struct AncestryMarkerBlock {
 std::vector<std::uint8_t> copies, dosage; // sample-major: row*K+k
 std::vector<double> centered;             // same layout
};
struct AncestryMarkerInformation {
 std::vector<double> score, information; // K and column-major K*K, unscaled
};
// Chromosome-local, marker-major labels: marker*n+sample in each phase.
// 0..K-1 are known assignments; 255/unknown is rejected. K is in [1,255].
// Shared phase handles must remain immutable through ALL aliases while retained.
// No phase is copied, inferred or converted from unphased genotypes.
// Input labels remain bytes; resident labels use ceil(log2 K) bits per copy.
class GBITS_API AncestryPhasedMatrix final {
 public:
 AncestryPhasedMatrix(std::shared_ptr<const gbits_phased_haplotype_handle> h1,
                     std::shared_ptr<const gbits_phased_haplotype_handle> h2,
                     std::size_t ancestries,
                     std::vector<std::uint8_t> ancestry_h1,
                     std::vector<std::uint8_t> ancestry_h2);
 AncestryPhasedMatrix(const AncestryPhasedMatrix&)=delete;
 AncestryPhasedMatrix& operator=(const AncestryPhasedMatrix&)=delete;
 std::size_t sample_count() const noexcept {return n_;}
 std::size_t marker_count() const noexcept {return m_;}
 std::size_t ancestry_count() const noexcept {return k_;}
 // Owned label payload/capacity only; excludes phases, object and allocator overhead.
 std::size_t ancestry_payload_bytes() const noexcept;
 std::size_t ancestry_capacity_bytes() const noexcept;
 // Explicit bounded decode: 1..4096 samples. Frequencies are K for this marker.
 AncestryMarkerBlock decode_marker(std::size_t marker,std::size_t first,
     std::size_t count,const std::vector<double>& frequencies) const;
 // Frequencies/effects/results use marker-major, ancestry-minor order.
 // All operations are serial, reentrant reads with call-local outputs/scratch.
 std::vector<double> forward(const std::vector<double>& frequencies,
                             const std::vector<double>& effects) const;
 std::vector<double> transpose(const std::vector<double>& frequencies,
                               const std::vector<double>& response) const;
 AncestryMarkerInformation marker_information(std::size_t marker,
     const std::vector<double>& frequencies,const std::vector<double>& response) const;
 // Returns response + Z_marker*delta; caller uses -delta for residual removal.
 std::vector<double> add_marker(std::size_t marker,
     const std::vector<double>& frequencies,const std::vector<double>& delta,
     const std::vector<double>& response) const;
 // In-place residual/product update; on arithmetic failure output may be partial.
 // delta must not alias response. No n-vector copy or temporary allocation.
 void update_marker(std::size_t marker,const std::vector<double>& frequencies,
     const std::vector<double>& delta,std::vector<double>& response) const;
 private:
 std::shared_ptr<const gbits_phased_haplotype_handle> h1_,h2_;
 std::vector<std::uint8_t> a1_,a2_;
 std::size_t n_{},m_{},k_{};
 void frequencies(const std::vector<double>&,std::size_t expected) const;
 template<class F> void visit(std::size_t marker,F&& f) const;
};
}
