#ifndef GSOLVE_MOMENT_SYSTEM_HPP
#define GSOLVE_MOMENT_SYSTEM_HPP

#include <cstdint>
#include <vector>

#include "gsolve/export.h"
#include "gsolve/matrix_view.hpp"

namespace gsolve {

struct MomentSystemDiagnostics {
  std::uint64_t dimension{0};
  std::uint64_t numerical_rank{0};
  double largest_eigenvalue{0.0};
  double smallest_retained_eigenvalue{0.0};
  double condition_estimate{0.0};
  double rank_threshold{0.0};
};

struct MomentSystemResult {
  Status status{};
  MomentSystemDiagnostics diagnostics{};
  std::vector<double> solution{};  // dimension by RHS, column-major
};

// Explicit full-pivot Householder QR, independent of the SPD moment policy.
// Rank-deficient systems return Eigen's basic least-squares solution: free
// permuted coordinates are zero, not a Moore-Penrose minimum-norm solution.
// A successful solve does not certify parameter identification. Zero tolerance
// uses Eigen's default epsilon * dimension; positive values are relative to
// maxPivot(). Finite square systems only; no ridge or component constraints.
struct QrSystemDiagnostics {
  std::uint64_t dimension{0}, numerical_rank{0};
  double relative_threshold{0}, absolute_threshold{0}, maximum_pivot{0};
  double relative_residual{0};
};
struct QrSystemResult {
  Status status{};
  QrSystemDiagnostics diagnostics{};
  std::vector<double> solution{};
};
GSOLVE_EXPORT QrSystemResult solve_full_pivot_qr_system(
    ConstMatrixView system, ConstMatrixView right_hand_sides,
    double relative_threshold = 0.0) noexcept;

// Checked solution of a small symmetric positive-definite moment system.
// Rank is diagnosed from a deterministic symmetric Jacobi eigensolve. No
// ridge, pseudoinverse, column dropping, or hidden repair is performed.
GSOLVE_EXPORT MomentSystemResult solve_moment_system(
    ConstMatrixView system, ConstMatrixView right_hand_sides,
    double relative_rank_tolerance = 256.0) noexcept;

}  // namespace gsolve

#endif
