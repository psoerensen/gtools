#ifndef GMAT_PLINK_SUBSET_HPP
#define GMAT_PLINK_SUBSET_HPP

#include "gmat/export.h"

#include <cstdint>
#include <string>
#include <string_view>
#include <vector>

namespace gmat {

struct PlinkFiles {
  std::string bed, bim, fam;
};

struct PlinkSubsetResult {
  std::uint64_t marker_count, sample_count;
  std::vector<std::string> missing_rsids;
};

// Select in physical BIM/FAM order. Empty ids retains all samples; unknown
// ids fail. Absent rsids are reported in request order. If no rsids match,
// no files are published. Destination files must be new.
GMAT_EXPORT PlinkSubsetResult write_plink_subset(const PlinkFiles& source,
    const PlinkFiles& destination, const std::vector<std::string_view>& rsids,
    const std::vector<std::string_view>& ids = {});

} // namespace gmat

#endif
