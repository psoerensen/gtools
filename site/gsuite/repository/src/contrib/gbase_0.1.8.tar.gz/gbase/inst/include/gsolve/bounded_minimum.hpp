#pragma once
#include <cstddef>
#include <functional>
#include "gsolve/export.h"
namespace gsolve {
enum class BoundedMinimumStatus { converged, iteration_limit, evaluation_limit };
struct BoundedMinimumOptions {
  int precision_bits{26}; // 2..double mantissa bits/2; Boost Brent tolerance
  std::size_t maximum_iterations{256}, maximum_evaluations{300};
};
struct BoundedMinimumResult {
  double argument{}, value{};
  std::size_t evaluations{}, iterations{};
  bool at_boundary{};
  BoundedMinimumStatus status{BoundedMinimumStatus::iteration_limit};
};
// Finite, deterministic, smooth unimodal objective on finite lower<upper.
// Both endpoints are checked. Resource exhaustion returns the best evaluated
// point with a non-converged status, never a silently successful estimate.
// Invalid arguments/nonfinite objective values throw; callback exceptions pass
// through. This is a scalar search, not a global/multimodal certificate.
GSOLVE_EXPORT BoundedMinimumResult minimize_bounded_scalar(
    const std::function<double(double)>& objective, double lower, double upper,
    const BoundedMinimumOptions& = {});
}
