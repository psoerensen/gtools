#ifndef GREML_MULTIVARIATE_RHE_BLUP_HPP
#define GREML_MULTIVARIATE_RHE_BLUP_HPP

#include <cstdint>
#include <functional>
#include <memory>
#include <string>
#include <vector>

#include "greml/fixed_effect_design.hpp"
#include "gsolve/moment_system.hpp"
#include "gsolve/pcg.hpp"

namespace greml {

struct RelationshipTraversalDiagnostic {
  std::string purpose{};
  std::uint64_t marker_visits{0};
  std::uint64_t packed_decode_passes{0};
  std::uint64_t contiguous_snp_blocks{0};
  std::uint64_t decoded_snp_records{0};
  std::uint64_t right_hand_side_count{0};
  std::uint64_t component_count{0};
  std::uint32_t requested_threads{1};
  std::uint32_t resolved_threads{1};
  double decode_seconds{0.0};
  double compute_seconds{0.0};
};

// Model-independent relationship batching contract owned statistically by
// greml. Generic implementations call each K_c once per batch; integration
// backends may fuse components sharing one packed source.
class GREML_EXPORT RelationshipBatchOperator {
 public:
  virtual ~RelationshipBatchOperator() = default;
  [[nodiscard]] virtual std::uint64_t dimension() const noexcept = 0;
  [[nodiscard]] virtual std::uint64_t component_count() const noexcept = 0;
  [[nodiscard]] virtual const std::vector<std::string>& component_names()
      const noexcept = 0;
  virtual Status apply_components(gsolve::ConstMatrixView common_input,
                                  double* component_outputs,
                                  std::uint64_t component_stride,
                                  const std::string& purpose,
                                  gsolve::Workspace& workspace) const = 0;
  virtual Status apply_component_sum(const double* component_inputs,
                                     std::uint64_t component_stride,
                                     std::uint64_t right_hand_side_count,
                                     gsolve::MatrixView output,
                                     const std::string& purpose,
                                     gsolve::Workspace& workspace) const = 0;
  virtual Status apply_component_inputs(
      const double* component_inputs, std::uint64_t component_stride,
      std::uint64_t right_hand_side_count, double* component_outputs,
      std::uint64_t output_component_stride, const std::string& purpose,
      gsolve::Workspace& workspace) const = 0;
  virtual Status exact_diagonals(gsolve::MatrixView output,
                                 const std::string& purpose,
                                 gsolve::Workspace& workspace) const = 0;
  [[nodiscard]] virtual bool has_direct_rhe_moments() const noexcept {
    return false;
  }
  virtual Status direct_rhe_moments(
      gsolve::ConstMatrixView residualized_phenotypes,
      std::vector<double>& component_trait_moments,
      std::vector<double>& component_diagonals,
      const std::string& purpose, gsolve::Workspace& workspace) const;
  [[nodiscard]] virtual std::vector<RelationshipTraversalDiagnostic>
  traversal_diagnostics() const = 0;
};

GREML_EXPORT std::shared_ptr<const RelationshipBatchOperator>
make_generic_relationship_batch_operator(
    std::vector<std::shared_ptr<const gsolve::LinearOperator>> components,
    std::vector<std::string> component_names);

enum class MultivariateRheCode {
  success = 0,
  invalid_argument,
  rank_deficient,
  ill_conditioned,
  numerical_failure
};

struct MultivariateRheOptions {
  std::uint64_t probe_count{32};
  std::uint64_t probe_batch_size{8};
  std::uint64_t seed{UINT64_C(0x6a09e667f3bcc909)};
  double relative_rank_tolerance{256.0};
  double maximum_condition_estimate{1.0e12};
  double psd_relative_floor{0.0};
  double residual_positive_relative_floor{1.0e-8};
  // Optional n-by-probe_count column-major common probe basis. When supplied,
  // it is used verbatim; no RNG is invoked.
  std::vector<double> fixed_probes{};
};

struct CovariancePsdAdjustment {
  std::string component_name{};
  std::vector<double> raw_eigenvalues{};
  std::vector<double> adjusted_eigenvalues{};
  double frobenius_change{0.0};
  bool changed{false};
};

struct MultivariateRheDiagnostics {
  gsolve::MomentSystemDiagnostics moment_system{};
  std::vector<double> moment_matrix{};
  std::vector<double> moment_matrix_standard_error{};
  std::vector<double> component_correlations{};
  std::uint64_t probe_count{0};
  std::uint64_t probe_batch_size{0};
  std::uint64_t seed{0};
  bool deterministic_probe_basis{false};
  std::vector<RelationshipTraversalDiagnostic> traversals{};
};

struct MultivariateRheResult {
  MultivariateRheCode code{MultivariateRheCode::success};
  Status status{};
  std::uint64_t sample_count{0};
  std::uint64_t trait_count{0};
  std::vector<std::string> component_names{};
  std::vector<double> residualized_response{}; // n by t
  std::vector<std::vector<double>> raw_component_covariances{};
  std::vector<double> raw_residual_covariance{};
  std::vector<std::vector<double>> adjusted_component_covariances{};
  std::vector<double> adjusted_residual_covariance{};
  std::vector<CovariancePsdAdjustment> adjustments{};
  MultivariateRheDiagnostics diagnostics{};
};

GREML_EXPORT MultivariateRheResult estimate_multivariate_rhe(
    gsolve::ConstMatrixView phenotypes,
    std::shared_ptr<const FixedEffectDesign> fixed_effects,
    std::shared_ptr<const RelationshipBatchOperator> relationships,
    const MultivariateRheOptions& options, gsolve::Workspace& workspace) noexcept;

// Prepared, immutable sample-space moment trace. Reuse requires the same
// sample ordering, fixed effects, relationships, working variances and probes.
struct PreparedSampleRhe;

struct SampleRhePreparationResult {
  Status status{};
  std::shared_ptr<const PreparedSampleRhe> prepared{};
  std::vector<double> moment_matrix{};
  std::uint64_t precision_rhs_applications{0};
};

// Empty working_variances selects ordinary RHE. Otherwise supply one
// nonnegative variance per genetic component and a positive residual variance.
// Working variances must be set independently of the responses used for fitting.
GREML_EXPORT SampleRhePreparationResult prepare_sample_rhe(
    std::shared_ptr<const FixedEffectDesign> fixed_effects,
    std::shared_ptr<const RelationshipBatchOperator> relationships,
    const std::vector<double>& working_variances,
    const MultivariateRheOptions& options, const gsolve::PcgOptions& pcg,
    gsolve::Workspace& workspace) noexcept;

// Optional fused implementation of the unprojected genetic sum
// sum_j working_variances[j] * K_j. The caller must construct it from the
// same ordered kernels, sample selection, transforms and normalizations.
// greml applies the fixed-effect projection and adds the residual variance.
GREML_EXPORT SampleRhePreparationResult prepare_sample_rhe(
    std::shared_ptr<const FixedEffectDesign> fixed_effects,
    std::shared_ptr<const RelationshipBatchOperator> relationships,
    const std::vector<double>& working_variances,
    const MultivariateRheOptions& options, const gsolve::PcgOptions& pcg,
    gsolve::Workspace& workspace,
    std::shared_ptr<const gsolve::LinearOperator> working_genetic_covariance) noexcept;

// Reuse a supplied immutable SPD preconditioner for every precision solve
// under this plan. It must be compatible with the projected working covariance
// and each equivalent operator instance. Null selects identity.
GREML_EXPORT SampleRhePreparationResult prepare_sample_rhe(
    std::shared_ptr<const FixedEffectDesign> fixed_effects,
    std::shared_ptr<const RelationshipBatchOperator> relationships,
    const std::vector<double>& working_variances,
    const MultivariateRheOptions& options, const gsolve::PcgOptions& pcg,
    gsolve::Workspace& workspace,
    std::shared_ptr<const gsolve::LinearOperator> working_genetic_covariance,
    std::shared_ptr<const gsolve::Preconditioner> preconditioner) noexcept;

// Called once with the exact projected covariance retained for every solve.
// Enables reusable preconditioners whose compatibility requires operator identity.
using SampleRhePreconditionerFactory = std::function<
    std::shared_ptr<const gsolve::Preconditioner>(
        std::shared_ptr<const gsolve::LinearOperator>)>;

GREML_EXPORT SampleRhePreparationResult prepare_sample_rhe_with_preconditioner_factory(
    std::shared_ptr<const FixedEffectDesign> fixed_effects,
    std::shared_ptr<const RelationshipBatchOperator> relationships,
    const std::vector<double>& working_variances,
    const MultivariateRheOptions& options, const gsolve::PcgOptions& pcg,
    gsolve::Workspace& workspace,
    std::shared_ptr<const gsolve::LinearOperator> working_genetic_covariance,
    const SampleRhePreconditionerFactory& factory) noexcept;

GREML_EXPORT MultivariateRheResult fit_prepared_sample_rhe(
    const PreparedSampleRhe& prepared, gsolve::ConstMatrixView phenotypes,
    gsolve::Workspace& workspace) noexcept;

struct MultivariateBlupOptions {
  gsolve::PcgOptions pcg{};
  gsolve::MultipleRhsKrylovStrategy strategy{
      gsolve::MultipleRhsKrylovStrategy::block};
  gsolve::BlockPcgOptions block{};
  gsolve::ExecutionConfig execution{};
  double true_residual_relative_tolerance{1.0e-8};
  bool allow_unit_diagonal_fallback{false};
  double block_regularization_relative_floor{1.0e-12};
};

struct MultivariateBlupDiagnostics {
  gsolve::PcgBatchResult covariance_solves{};
  std::uint64_t failed_preconditioner_blocks{0};
  std::uint64_t regularized_preconditioner_blocks{0};
  bool used_unit_diagonal_fallback{false};
  double true_residual_norm{0.0};
  double true_relative_residual_norm{0.0};
  std::vector<RelationshipTraversalDiagnostic> traversals{};
};

struct MultivariateBlupResult {
  Status status{};
  std::uint64_t sample_count{0};
  std::uint64_t trait_count{0};
  std::uint64_t fixed_effect_count{0};
  std::vector<std::string> component_names{};
  std::vector<double> fixed_effects{}; // p by t
  std::vector<double> alpha{};         // n by t
  std::vector<std::vector<double>> component_values{}; // each n by t
  std::vector<double> total_values{};  // n by t
  MultivariateBlupDiagnostics diagnostics{};
};

// Stage 2 deliberately consumes the adjusted prediction parameters returned
// by Stage 1. Raw estimates are never silently substituted.
GREML_EXPORT MultivariateBlupResult solve_multivariate_blup(
    gsolve::ConstMatrixView phenotypes,
    std::shared_ptr<const FixedEffectDesign> fixed_effects,
    std::shared_ptr<const RelationshipBatchOperator> relationships,
    const MultivariateRheResult& stage1,
    const MultivariateBlupOptions& options, gsolve::Workspace& workspace) noexcept;

}  // namespace greml

#endif
