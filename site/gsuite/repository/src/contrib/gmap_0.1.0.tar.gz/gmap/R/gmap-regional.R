.gmap_region_indices <- function(markers, reference) {
  if (!is.character(markers) || !length(markers) || anyNA(markers) ||
      any(!nzchar(markers)) || anyDuplicated(markers))
    .gmap_stop("Region markers must be nonempty and unique.")
  index <- match(markers, reference$marker_id)
  if (anyNA(index) || is.unsorted(index, strictly = TRUE))
    .gmap_stop("Region markers must exist and follow sparse-LD reference order.")
  index
}

.gmap_eigen_control <- function(value) {
  output <- .gmap_settings(value, list(maximum_dimension = 2048,
    symmetry_tolerance = 64 * .Machine$double.eps,
    verification_tolerance = 1e-10,
    retained_positive_mass = c(.995, .99, .95),
    select_on_convergence = TRUE), "eigen")
  for (name in c("maximum_dimension", "symmetry_tolerance",
      "verification_tolerance"))
    if (!is.numeric(output[[name]]) || length(output[[name]]) != 1L ||
        !is.finite(output[[name]]) || output[[name]] <= 0)
      .gmap_stop("Eigensystem controls must be positive finite values.")
  .gmap_integer(output$maximum_dimension, "maximum_dimension")
  mass <- output$retained_positive_mass
  if (!is.numeric(mass) || !length(mass) || any(!is.finite(mass)) ||
      any(mass <= 0 | mass > 1) || anyDuplicated(mass) ||
      (length(mass) > 1L && any(diff(mass) >= 0)))
    .gmap_stop("retained_positive_mass must be unique and strictly decreasing in (0, 1].")
  list(maximum_dimension = as.double(output$maximum_dimension),
    symmetry_tolerance = as.double(output$symmetry_tolerance),
    verification_tolerance = as.double(output$verification_tolerance),
    retained_positive_mass = as.double(mass),
    select_on_convergence = .gmap_flag(output$select_on_convergence,
      "select_on_convergence"))
}

.gmap_attempt_status <- function(value, method) {
  finite <- all(is.finite(c(value$mean, value$variance, value$pip)))
  if (!finite) return(list(pass = FALSE, status = "non-finite posterior"))
  if (method == "multi_effect") return(list(pass = isTRUE(value$converged),
    status = if (isTRUE(value$converged)) "converged" else
      "multi-effect did not converge"))
  agreement <- value$chain_agreement
  if (is.null(agreement) || !isTRUE(agreement$multiple_chains))
    return(list(pass = FALSE, status = "multiple chains required"))
  spread <- max(agreement$pip$maximum - agreement$pip$minimum)
  list(pass = is.finite(spread) && spread <= agreement$pip_range_threshold,
    status = if (is.finite(spread) && spread <= agreement$pip_range_threshold)
      "chain PIP range accepted" else "chain PIP range exceeded")
}

.gmap_attempt_row <- function(value, region, trait, attempt, status, pass) {
  data.frame(region = region, trait = trait, attempt = attempt,
    requested_retained_positive_mass =
      value$requested_retained_positive_mass,
    achieved_retained_positive_mass =
      value$achieved_retained_positive_mass,
    retained_rank = as.integer(value$retained_rank),
    full_rank = as.integer(value$full_rank),
    minimum_retained_eigenvalue = value$minimum_retained_eigenvalue,
    maximum_score_projection_change =
      value$maximum_score_projection_change,
    pass = pass, selected = FALSE, status = status,
    stringsAsFactors = FALSE)
}

.gmap_parameter_rows <- function(value, region, trait, method, control) {
  row <- function(parameter, estimate, learned, component = NA_integer_) {
    data.frame(region = region, trait = trait, parameter = parameter,
      component = component, estimate = estimate, learned = learned,
      summary_type = if (!learned) "fixed" else if (method == "multi_effect")
        "variational_estimate" else "posterior_mean")
  }
  parameters <- if (method == "multi_effect")
    list(residual_variance = value$residual_variance) else value$parameter_mean
  output <- list(row("residual_variance", parameters$residual_variance,
    control$estimate_residual_variance))
  if (method == "multi_effect") {
    for (j in seq_along(value$components)) output[[length(output) + 1L]] <-
      row("effect_variance", value$components[[j]]$effect_variance,
        control$estimate_effect_variance, j)
  } else {
    output[[2L]] <- row("effect_variance", parameters$effect_variance,
      control$estimate_effect_variance)
    for (j in seq_along(parameters$weights)) output[[length(output) + 1L]] <-
      row("weight", parameters$weights[[j]], control$estimate_weights, j - 1L)
  }
  do.call(rbind, output)
}

#' Fit regional Bayesian mapping models
#'
#' @param stat A `gmap_stat()` data frame or uniquely named trait list in exact
#'   sparse-LD marker order.
#' @param Glist A gbase Glist augmented by `gprep(task="sparseld")`.
#' @param regions A uniquely named list of marker vectors in reference order.
#' @param method One of `bayesc`, `bayesr` or `multi_effect`.
#' @param prior Method-specific fixed values and optional learning priors.
#' @param control Method-specific sampler, learning, posterior-set and
#'   eigensystem controls. `control$eigen$retained_positive_mass` is a strictly
#'   decreasing fallback schedule (default `c(.995, .99, .95)`). One regional
#'   eigensystem is reused; the first likelihood accepted for every named trait
#'   is retained. Set it to `1` for the exact full-rank likelihood, or set
#'   `control$eigen$select_on_convergence=FALSE` to fit only the first entry.
#' @param normalization Optional named response normalization used only for
#'   explicit residual-variance learning with in-sample LD.
#' @return A serializable `gmap_fit`. `diagnostic_summary` records the selected
#'   retained mass and rank; `eigen_attempts` records every attempted threshold.
#' @export
gmap <- function(stat, Glist, regions, method = c("multi_effect", "bayesc", "bayesr"),
                 prior = list(), control = list(), normalization = NULL) {
  call <- match.call()
  method <- match.arg(method)
  reference <- .gmap_reference(Glist)
  markers <- reference$metadata
  assembly <- Glist$assembly
  if (!is.character(assembly) || length(assembly) != 1L ||
      is.na(assembly) || !nzchar(assembly))
    .gmap_stop("Glist must declare one nonempty genome assembly.")
  .gmap_named(regions, "regions")
  indices <- lapply(regions, .gmap_region_indices, reference = markers)
  if (identical(class(stat), "data.frame")) stat <- list(trait = stat)
  else .gmap_named(stat, "stat")
  required <- c("rsids", "ea", "nea", "score", "information")
  native_stat <- lapply(stat, function(value) {
    if (!identical(class(value), "data.frame") || anyDuplicated(names(value)) ||
        length(setdiff(required, names(value))))
      .gmap_stop("Every stat entry requires rsids, ea, nea, score and information.")
    if (!identical(value$rsids, markers$marker_id) ||
        !identical(value$ea, markers$allele1) ||
        !identical(value$nea, markers$allele2))
      .gmap_stop("Statistics must match complete sparse-LD marker and allele order exactly.")
    if (!is.numeric(value$score) || !is.numeric(value$information) ||
        any(!is.finite(value$score)) || any(!is.finite(value$information)) ||
        any(value$information <= 0))
      .gmap_stop("score must be finite and information must be positive and finite.")
    data.frame(marker = value$rsids, allele1 = value$ea,
      allele2 = value$nea, score = value$score,
      marker_ss = value$information, stringsAsFactors = FALSE)
  })
  positive <- function(x) is.numeric(x) && length(x) == 1L && is.finite(x) && x > 0
  values <- list(residual_variance = NA_real_, effect_variance = NA_real_)
  if (method == "bayesc") values$inclusion_probability <- .5
  if (method == "bayesr") values <- c(values, list(
    weights = c(.7, .1, .1, .1), variance_multipliers = c(0, .01, .1, 1)))
  if (method != "multi_effect") values <- c(values, list(
    effect_variance_prior = NULL, residual_variance_prior = NULL,
    weight_prior = NULL))
  prior <- .gmap_settings(prior, values, "prior")
  if (!positive(prior$residual_variance) || !positive(prior$effect_variance))
    .gmap_stop("Supply positive residual_variance and effect_variance.")
  if (method == "bayesc") {
    .gmap_probability(prior$inclusion_probability, "inclusion_probability", TRUE)
  } else if (method == "bayesr") {
    if (!is.numeric(prior$weights) || !is.numeric(prior$variance_multipliers) ||
        length(prior$weights) < 2L ||
        length(prior$weights) != length(prior$variance_multipliers) ||
        any(!is.finite(c(prior$weights, prior$variance_multipliers))) ||
        any(prior$weights < 0) || abs(sum(prior$weights) - 1) > 1e-10 ||
        prior$variance_multipliers[[1L]] != 0 ||
        any(diff(prior$variance_multipliers) <= 0))
      .gmap_stop("BayesR needs normalized weights and increasing multipliers starting at zero.")
  }
  defaults <- if (method == "multi_effect") list(effects = 10L,
    max_sweeps = 200L, objective_tolerance = 1e-8,
    estimate_effect_variance = FALSE,
    variance_learning = list(max_updates = 200L, relative_tolerance = 1e-8),
    residual_relative_tolerance = 1e-8) else list(burnin = 100L,
    sampling_sweeps = 1000L, thinning = 1L, seeds = c(1, 2),
    retain_diagnostics = FALSE, pip_range_threshold = .1,
    estimate_effect_variance = FALSE, estimate_weights = FALSE)
  defaults <- c(defaults, list(estimate_residual_variance = FALSE,
    sets = list(), eigen = list()))
  controls <- .gmap_settings(control, defaults, "control")
  controls$sets <- .gmap_set_control(controls$sets, method)
  controls$eigen <- .gmap_eigen_control(controls$eigen)
  if (any(lengths(indices) > controls$eigen$maximum_dimension))
    .gmap_stop("A region exceeds the configured dense dimension limit.")
  if (method == "multi_effect") {
    controls$variance_learning <- .gmap_settings(controls$variance_learning,
      list(max_updates = 200L, relative_tolerance = 1e-8), "variance_learning")
    .gmap_integer(controls$effects, "effects")
    .gmap_integer(controls$max_sweeps, "max_sweeps")
    .gmap_integer(controls$variance_learning$max_updates, "max_updates")
    if (!positive(controls$objective_tolerance) ||
        !positive(controls$variance_learning$relative_tolerance))
      .gmap_stop("Multi-effect tolerances must be positive.")
  } else {
    .gmap_integer(controls$burnin, "burnin", 0L)
    .gmap_integer(controls$sampling_sweeps, "sampling_sweeps")
    .gmap_integer(controls$thinning, "thinning")
    .gmap_probability(controls$pip_range_threshold, "pip_range_threshold")
    if (!is.numeric(controls$seeds) || !length(controls$seeds) ||
        any(!is.finite(controls$seeds)) || any(controls$seeds < 0) ||
        any(controls$seeds > 2^32 - 1) || any(controls$seeds != floor(controls$seeds)) ||
        anyDuplicated(controls$seeds))
      .gmap_stop("seeds must be distinct uint32 values.")
    controls$retain_diagnostics <- .gmap_flag(controls$retain_diagnostics,
      "retain_diagnostics")
    controls$estimate_weights <- .gmap_flag(controls$estimate_weights,
      "estimate_weights")
  }
  controls$estimate_effect_variance <- .gmap_flag(
    controls$estimate_effect_variance, "estimate_effect_variance")
  controls$estimate_residual_variance <- .gmap_flag(
    controls$estimate_residual_variance, "estimate_residual_variance")
  if (controls$estimate_residual_variance &&
      any(controls$eigen$retained_positive_mass < 1))
    .gmap_stop("Residual-variance learning currently requires retained_positive_mass = 1.")
  .gmap_learning(prior, controls, method)
  normal <- .gmap_normalization(normalization, names(stat),
    controls$estimate_residual_variance, reference$sparseLD$n)
  region_info <- lapply(names(regions), function(name) {
    index <- indices[[name]]
    chromosome <- unique(markers$chromosome[index])
    position <- markers$base_pair_position[index]
    if (length(chromosome) != 1L || anyNA(chromosome) || !nzchar(chromosome) ||
        any(!is.finite(position) | position < 1 | position != floor(position)))
      .gmap_stop("Every region requires one chromosome and positive integer positions.")
    list(id = name, chromosome = chromosome, assembly = assembly,
      start = min(position), end = max(position),
      markers = markers[index, , drop = FALSE])
  })
  names(region_info) <- names(regions)
  details <- sets <- stats::setNames(vector("list", length(regions)), names(regions))
  rows <- diagnostics <- attempts <- parameters <- list()
  reference_id <- if (is.character(reference$sparseLD$reference) &&
      length(reference$sparseLD$reference) == 1L &&
      nzchar(reference$sparseLD$reference)) reference$sparseLD$reference else
    "gbase-sparse-ld"
  reader <- cpp_gmap_open_ld(reference$sparseLD$prefix)
  on.exit(cpp_gmap_release_ld(reader), add = TRUE)
  for (region in names(regions)) {
    prepared <- tryCatch(cpp_gmap_prepare_region(reader,
      as.double(indices[[region]]), region_info[[region]], reference_id,
      controls$eigen), error = function(error)
        .gmap_stop("Region ", region, ": ", conditionMessage(error)))
    tryCatch({
      details[[region]] <- sets[[region]] <-
        stats::setNames(vector("list", length(stat)), names(stat))
      selected <- NULL
      selected_attempt <- NA_integer_
      last_complete <- NULL
      last_complete_attempt <- NA_integer_
      region_attempts <- list()
      errors <- character()
      masses <- controls$eigen$retained_positive_mass
      if (!controls$eigen$select_on_convergence) masses <- masses[[1L]]
      for (attempt in seq_along(masses)) {
        current <- stats::setNames(vector("list", length(stat)), names(stat))
        complete <- TRUE
        passed <- logical(length(stat))
        for (j in seq_along(stat)) {
          trait <- names(stat)[[j]]
          native_control <- controls
          native_control$normalization <- normal[[trait]]
          value <- tryCatch(cpp_gmap_fit_region(prepared,
            native_stat[[trait]], trait, method, prior, native_control,
            masses[[attempt]]), error = identity)
          if (inherits(value, "error")) {
            complete <- FALSE
            errors <- c(errors, paste0("attempt ", attempt, ", trait ", trait,
              ": ", conditionMessage(value)))
            region_attempts[[length(region_attempts) + 1L]] <- data.frame(
              region = region, trait = trait, attempt = attempt,
              requested_retained_positive_mass = masses[[attempt]],
              achieved_retained_positive_mass = NA_real_,
              retained_rank = NA_integer_, full_rank = NA_integer_,
              minimum_retained_eigenvalue = NA_real_,
              maximum_score_projection_change = NA_real_,
              pass = FALSE,
              selected = FALSE, status = conditionMessage(value),
              stringsAsFactors = FALSE)
          } else {
            current[[trait]] <- value
            status <- .gmap_attempt_status(value, method)
            passed[[j]] <- status$pass
            region_attempts[[length(region_attempts) + 1L]] <-
              .gmap_attempt_row(value, region, trait, attempt,
                status$status, status$pass)
          }
        }
        if (complete) {
          last_complete <- current
          last_complete_attempt <- attempt
        }
        if (complete && (!controls$eigen$select_on_convergence || all(passed))) {
          selected <- current
          selected_attempt <- attempt
          break
        }
      }
      if (is.null(selected)) {
        selected <- last_complete
        selected_attempt <- last_complete_attempt
        if (is.null(selected)) .gmap_stop("Region ", region,
          ": every eigen-likelihood attempt failed: ", paste(errors, collapse = "; "))
        warning("Region ", region,
          ": no eigen-likelihood attempt met the convergence rule; the final complete fit is provisional.",
          call. = FALSE)
      }
      for (j in seq_along(region_attempts))
        region_attempts[[j]]$selected <-
          region_attempts[[j]]$attempt == selected_attempt
      attempts <- c(attempts, region_attempts)
      for (trait in names(stat)) {
        value <- selected[[trait]]
        rows[[length(rows) + 1L]] <- data.frame(reference = reference_id,
          region = region, trait = trait, marker = regions[[region]],
          position = markers$base_pair_position[indices[[region]]],
          mean = value$mean, variance = value$variance, pip = value$pip)
        agreement <- value$chain_agreement
        accepted <- .gmap_attempt_status(value, method)$pass
        converged <- if (method == "multi_effect") value$converged else accepted
        diagnostics[[length(diagnostics) + 1L]] <- data.frame(region = region,
          trait = trait, converged = converged,
          status = if (accepted) "accepted" else "provisional",
          incomplete_ld_reference = value$sets$incomplete_ld_reference,
          imported_eigensystem = value$imported_eigensystem,
          requested_retained_positive_mass =
            value$requested_retained_positive_mass,
          achieved_retained_positive_mass =
            value$achieved_retained_positive_mass,
          retained_rank = as.integer(value$retained_rank),
          full_rank = as.integer(value$full_rank),
          minimum_retained_eigenvalue = value$minimum_retained_eigenvalue,
          maximum_score_projection_change =
            value$maximum_score_projection_change,
          attempts = selected_attempt,
          fallback_required = selected_attempt > 1L,
          chains = if (is.null(agreement)) NA_integer_ else length(agreement$seeds),
          max_pip_range = if (is.null(agreement) || !agreement$multiple_chains)
            NA_real_ else max(agreement$pip$maximum - agreement$pip$minimum),
          sweeps = if (method == "multi_effect") value$sweeps else NA_real_)
        parameters[[length(parameters) + 1L]] <- .gmap_parameter_rows(value,
          region, trait, method, controls)
        details[[region]][[trait]] <- value
        sets[[region]][[trait]] <- value$sets
      }
    }, finally = cpp_gmap_release_region(prepared))
  }
  structure(list(schema_version = 1L, source = "regional_summary",
    estimates = do.call(rbind, rows), sets = sets, details = details,
    diagnostic_summary = do.call(rbind, diagnostics),
    eigen_attempts = do.call(rbind, attempts),
    parameters = do.call(rbind, parameters), normalization = normal,
    region_metadata = region_info,
    reference = list(reference = reference_id, assembly = assembly,
      checksums = reference$sparseLD$checksums,
      prefix = reference$sparseLD$prefix),
    selection = list(regions = regions, traits = names(stat)),
    prior = prior, control = controls,
    input_provenance = lapply(stat, function(value) {
      item <- attr(value, "gmap_preparation", exact = TRUE)
      if (is.null(item)) list(method = "supplied_cross_products") else item
    }), method = method, call = call), class = c("gmap_fit", "list"))
}

#' @export
print.gmap_fit <- function(x, ...) {
  cat("Regional mapping:", x$method, "\n")
  print(x$diagnostic_summary, row.names = FALSE)
  invisible(x)
}

#' @export
summary.gmap_fit <- function(object, ...) {
  list(method = object$method, source = object$source,
    estimates = object$estimates, diagnostics = object$diagnostic_summary,
    sets = gmap_sets(object)$summary,
    parameters = object$parameters, prior = object$prior,
    control = object$control)
}

#' @export
plot.gmap_fit <- function(x, region = NULL, trait = NULL,
    quantity = c("pip", "chains", "objective"), ...) {
  region <- .gmap_select_one(region, names(x$selection$regions), "region")
  trait <- .gmap_select_one(trait, x$selection$traits, "trait")
  quantity <- match.arg(quantity); detail <- x$details[[region]][[trait]]
  title <- paste(region, trait, x$method, sep = " / ")
  position <- x$region_metadata[[region]]$markers$base_pair_position
  if (quantity == "pip") {
    graphics::plot(position, detail$pip, xlab = "Position (bp)",
      ylab = "Posterior inclusion probability", ylim = c(0, 1),
      main = title, pch = 19, ...)
  } else if (quantity == "chains") {
    if (is.null(detail$chain_agreement))
      .gmap_stop("Chain diagnostics apply to regional BayesC/BayesR fits.")
    agreement <- detail$chain_agreement
    graphics::plot(position, detail$pip, xlab = "Position (bp)",
      ylab = "PIP: pooled and between-chain range", ylim = c(0, 1),
      main = title, pch = 19, ...)
    graphics::segments(position, agreement$pip$minimum, position,
      agreement$pip$maximum, col = "grey40")
  } else {
    if (is.null(detail$objective))
      .gmap_stop("Objective trace applies to multi-effect fits.")
    graphics::plot(seq_along(detail$objective) - 1L, detail$objective,
      type = "l", xlab = "Sweep", ylab = "Native objective", main = title, ...)
  }
  invisible(x)
}
