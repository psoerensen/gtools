.gmap_stop <- function(...) stop(..., call. = FALSE)

.gmap_reference <- function(Glist) {
  gbase::validate_Glist(Glist)
  if (!is.list(Glist$sparseLD))
    .gmap_stop("`Glist` must be augmented with `gprep(task = 'sparseld')`.")
  metadata <- Glist$sparseLD$marker_metadata
  required <- c("marker_id", "chromosome", "base_pair_position",
    "allele1", "allele2")
  if (!is.data.frame(metadata) || length(setdiff(required, names(metadata))) ||
      !nrow(metadata)) .gmap_stop("Glist sparse-LD marker metadata is incomplete.")
  list(metadata = metadata, sparseLD = Glist$sparseLD)
}

.gmap_named <- function(x, name) {
  if (!is.list(x) || !length(x) || is.null(names(x)) || anyNA(names(x)) ||
      any(!nzchar(names(x))) || anyDuplicated(names(x)))
    .gmap_stop("`", name, "` must be a nonempty uniquely named list.")
  x
}

#' Prepare ordinary linear-regression summaries for regional mapping
#'
#' @param stat An ordinary checked data frame, or named list of data frames,
#'   containing `rsids`, `ea`, `nea`, `b`, `seb` and `n` in complete sparse-LD
#'   marker order.
#' @param Glist A `gbase::gprep()` Glist augmented with
#'   `gbase::gprep(Glist=, task="sparseld")`.
#' @param phenotype_variance Positive sample variance using denominator `n-1`.
#'   For multiple traits provide a vector named exactly as `stat`, or one
#'   deliberately shared unnamed scalar.
#' @return The same data-frame/list shape with `score` and `information`, plus
#'   a preparation attribute recording the assumptions and reference checksums.
#' @export
gmap_stat <- function(stat, Glist, phenotype_variance) {
  reference <- .gmap_reference(Glist)
  single <- identical(class(stat), "data.frame")
  if (single) stat <- list(trait = stat) else .gmap_named(stat, "stat")
  variance <- phenotype_variance
  if (!is.numeric(variance) || !length(variance) ||
      any(!is.finite(variance)) || any(variance <= 0))
    .gmap_stop("`phenotype_variance` must contain positive finite values.")
  if (length(variance) == 1L && is.null(names(variance)))
    variance <- stats::setNames(rep(variance, length(stat)), names(stat))
  if (!identical(names(variance), names(stat)) || length(variance) != length(stat))
    .gmap_stop("Name `phenotype_variance` in stat order, or supply one unnamed scalar.")
  markers <- reference$metadata
  result <- lapply(names(stat), function(trait) {
    value <- stat[[trait]]
    columns <- c("rsids", "ea", "nea", "b", "seb", "n")
    if (!identical(class(value), "data.frame") || anyDuplicated(names(value)) ||
        length(setdiff(columns, names(value))))
      .gmap_stop("Every stat entry requires rsids, ea, nea, b, seb and n.")
    if (!identical(value$rsids, markers$marker_id) ||
        !identical(value$ea, markers$allele1) ||
        !identical(value$nea, markers$allele2))
      .gmap_stop("Statistics must match complete sparse-LD marker and allele order exactly.")
    for (name in c("b", "seb", "n"))
      if (!is.numeric(value[[name]]) || any(!is.finite(value[[name]])))
        .gmap_stop("b, seb and n must be finite numeric values.")
    if (any(value$seb <= 0)) .gmap_stop("seb must be positive.")
    if (length(unique(value$n)) != 1L || any(value$n < 3 | value$n != floor(value$n)))
      .gmap_stop("n must be one common integer of at least 3 within each trait.")
    n <- value$n[[1L]]
    information <- ((n - 1) * variance[[trait]]) /
      ((n - 2) * value$seb^2 + value$b^2)
    score <- value$b * information
    if (any(!is.finite(information) | information <= 0) || any(!is.finite(score)))
      .gmap_stop("Reconstructed cross-products are outside the finite numeric range.")
    output <- data.frame(rsids = value$rsids, chr = markers$chromosome,
      pos = markers$base_pair_position, ea = value$ea, nea = value$nea,
      score = as.double(score), information = as.double(information),
      stringsAsFactors = FALSE)
    attr(output, "gmap_preparation") <- list(
      method = "ordinary_linear_regression", n = n,
      phenotype_variance = variance[[trait]], residual_df = n - 2,
      response_ss = (n - 1) * variance[[trait]],
      assumptions = "Common samples; intercept-only OLS; conventional SE; continuous outcome",
      reference = reference$sparseLD$reference,
      checksums = reference$sparseLD$checksums)
    output
  })
  names(result) <- names(stat)
  if (single) result[[1L]] else result
}
