write_gmap_stat_bed <- function(genotype, path) {
  body <- raw()
  for (marker in seq_len(ncol(genotype))) {
    code <- c(3L, 2L, 0L)[genotype[, marker] + 1L]
    code <- c(code, rep(1L, (-length(code)) %% 4L))
    body <- c(body, as.raw(colSums(matrix(code, 4L) * c(1, 4, 16, 64))))
  }
  writeBin(c(as.raw(c(0x6c, 0x1b, 0x01)), body), path)
}

gmap_stat_fixture <- function() {
  genotype <- matrix(c(0,0,1, 0,1,1, 1,1,0, 1,2,0, 2,2,1, 2,1,2),
    nrow = 6L, byrow = TRUE)
  prefix <- tempfile("gmap-stat-")
  write_gmap_stat_bed(genotype, paste0(prefix, ".bed"))
  write.table(data.frame("1", paste0("m", 1:3), 0, 100 * 1:3, "A", "G"),
    paste0(prefix, ".bim"), quote = FALSE, row.names = FALSE, col.names = FALSE)
  write.table(data.frame(paste0("F", 1:6), paste0("I", 1:6), 0, 0, 0, -9),
    paste0(prefix, ".fam"), quote = FALSE, row.names = FALSE, col.names = FALSE)
  ld <- tempfile("gmap-stat-ld-")
  Glist <- gbase::gprep(bedfiles = paste0(prefix, ".bed"))
  Glist$assembly <- "artificial"
  Glist <- gbase::gprep(Glist = Glist, task = "sparseld", out_prefix = ld,
    max_distance_bp = 0, max_distance_variants = 3, r2 = 0, nthreads = 1)
  cleanup <- function() {
    unlink(paste0(prefix, c(".bed", ".bim", ".fam")))
    unlink(paste0(ld, c(".row_ptr.u64.bin", ".col_idx.u32.0based.bin",
      ".values.f32.bin", ".meta.txt", ".markers.tsv")))
  }
  list(Glist = Glist, cleanup = cleanup)
}
