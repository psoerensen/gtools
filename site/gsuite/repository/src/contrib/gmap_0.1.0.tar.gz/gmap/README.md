# gmap

Standalone R interfaces for regional fine-mapping and colocalisation.
The package imports `gbase`, never root `gsuite`, and uses installed public
native interfaces.

The public workflows are:

- `gmap_stat()` for explicit OLS beta/SE/n conversion;
- `gmap()` for regional multi-effect, BayesC or BayesR fitting against
  Glist-owned sparse LD, with one eigendecomposition per region and an ordered
  retained-eigenvalue-mass fallback;
- `gmap_bed()` for checked regional interpretation of a saved individual-BED
  `gbayes_fit`, without refitting;
- `gmap_sets()` for labelled set and member tables, and `gmap_bfdr()` for
  PIP-threshold Bayesian-FDR summaries;
- `gmap_coloc()` for single-causal two-trait ABF colocalisation;
- `gmap_coloc_components()` for post-fit comparison of saved multi-effect
  components, without refitting.

Prepare genotype resources with `gbase::gprep()` and add sparse LD with
`gbase::gprep(Glist = ..., task = "sparseld")`. There is no public LDlist or
root-gsuite compatibility interface.
