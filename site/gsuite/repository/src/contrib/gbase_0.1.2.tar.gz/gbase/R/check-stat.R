.gbase_stop <- function(...) stop(..., call. = FALSE)

.check_stat_threshold <- function(value, name) {
  if (is.null(value)) return(NULL)
  if (!is.numeric(value) || length(value) != 1L || !is.finite(value) ||
      value < 0 || value > 1)
    .gbase_stop("`", name, "` must be NULL or one number in [0, 1].")
  as.double(value)
}

.check_stat_flag <- function(value, name) {
  if (!is.logical(value) || length(value) != 1L || is.na(value))
    .gbase_stop("`", name, "` must be TRUE or FALSE.")
  value
}

.check_stat_hwe_one <- function(n0, n1, n2) {
  total <- n0 + n1 + n2
  rare <- 2 * min(n0, n2) + n1
  if (rare == 0 || rare == 2 * total) return(1)
  midpoint <- floor(rare * (2 * total - rare) / (2 * total))
  if ((rare - midpoint) %% 2 != 0) midpoint <- midpoint + 1
  probabilities <- numeric(rare + 1L); probabilities[midpoint + 1L] <- 1
  het <- midpoint; hom_rare <- (rare - het) / 2
  hom_common <- total - het - hom_rare
  while (het >= 2) {
    probabilities[het - 1L] <- probabilities[het + 1L] * het * (het - 1) /
      (4 * (hom_rare + 1) * (hom_common + 1))
    het <- het - 2; hom_rare <- hom_rare + 1; hom_common <- hom_common + 1
  }
  het <- midpoint; hom_rare <- (rare - het) / 2
  hom_common <- total - het - hom_rare
  while (het <= rare - 2) {
    probabilities[het + 3L] <- probabilities[het + 1L] *
      4 * hom_rare * hom_common / ((het + 2) * (het + 1))
    het <- het + 2; hom_rare <- hom_rare - 1; hom_common <- hom_common - 1
  }
  probabilities <- probabilities / sum(probabilities)
  observed <- probabilities[n1 + 1L]
  min(1, sum(probabilities[probabilities <= observed * (1 + 1e-12)]))
}

.check_stat_reference <- function(Glist) data.frame(
  rsids = unlist(Glist$rsids, use.names = FALSE),
  chr = as.character(unlist(Glist$chr, use.names = FALSE)),
  pos = as.double(unlist(Glist$pos, use.names = FALSE)),
  ea = toupper(unlist(Glist$a1, use.names = FALSE)),
  nea = toupper(unlist(Glist$a2, use.names = FALSE)),
  eaf = as.double(unlist(Glist$af, use.names = FALSE)),
  nmiss = as.double(unlist(Glist$nmiss, use.names = FALSE)),
  n0 = as.double(unlist(Glist$n0, use.names = FALSE)),
  n1 = as.double(unlist(Glist$n1, use.names = FALSE)),
  n2 = as.double(unlist(Glist$n2, use.names = FALSE)),
  stringsAsFactors = FALSE)

.check_stat_names <- function(stat) {
  aliases <- c(marker = "rsids", chromosome = "chr", position = "pos",
    effect_allele = "ea", other_allele = "nea",
    allele_frequency = "eaf", effect = "b", standard_error = "seb",
    z = "stat", z_score = "stat", p_value = "p",
    marker_sample_count = "n", sample_size = "n", a1 = "ea", a2 = "nea",
    beta = "b", se = "seb", statistic = "stat")
  names(stat) <- ifelse(names(stat) %in% names(aliases),
    aliases[names(stat)], names(stat))
  if (anyDuplicated(names(stat)))
    .gbase_stop("Summary-statistic aliases produce duplicated column names.")
  stat
}

#' Check and align marker summary statistics
#'
#' Maps an ordinary summary-statistics data frame to a prepared Glist, aligns
#' exact or swapped alleles, and applies explicit QC filters. The result is an
#' ordinary data frame using the familiar qgg column names.
#' @param Glist A prepared `gbase::gprep()` Glist.
#' @param stat An ordinary data frame. Long descriptive column names and the
#'   qgg names `rsids`, `chr`, `pos`, `ea`, `nea`, `eaf`, `b`, `seb`, `stat`,
#'   `p`, `n`, and `info` are accepted. `z` and `z_score` are normalized to
#'   `stat`.
#' @param excludeMAF,excludeMAFDIFF,excludeINFO,excludeMISS,excludeHWE Optional
#'   thresholds in `[0,1]`.
#' @param excludeCGAT,excludeINDEL,excludeDUPS,excludeMHC Logical filters.
#' @return An ordinary data frame in Glist marker order.
#' @export
checkStat <- function(Glist = NULL, stat = NULL, excludeMAF = 0.01,
    excludeMAFDIFF = 0.05, excludeINFO = 0.8, excludeCGAT = TRUE,
    excludeINDEL = TRUE, excludeDUPS = TRUE, excludeMHC = FALSE,
    excludeMISS = 0.05, excludeHWE = 1e-12) {
  validate_Glist(Glist)
  if (!identical(class(stat), "data.frame") || !nrow(stat) ||
      anyDuplicated(names(stat)))
    .gbase_stop("`stat` must be a nonempty ordinary data frame with unique columns.")
  stat <- .check_stat_names(stat)
  required <- c("rsids", "chr", "pos", "ea", "nea")
  if (length(missing <- setdiff(required, names(stat))))
    .gbase_stop("`stat` is missing: ", paste(missing, collapse = ", "), ".")
  for (name in c("rsids", "chr", "ea", "nea")) {
    if (!is.character(stat[[name]]) || anyNA(stat[[name]]) ||
        any(!nzchar(stat[[name]])))
      .gbase_stop("`stat$", name, "` must contain nonempty strings.")
  }
  if (!is.numeric(stat$pos) || anyNA(stat$pos) || any(!is.finite(stat$pos)) ||
      any(stat$pos <= 0 | stat$pos != floor(stat$pos) | stat$pos > 2^53))
    .gbase_stop("`stat$pos` must contain positive whole-number positions.")
  stat$ea <- toupper(stat$ea); stat$nea <- toupper(stat$nea)
  if (any(stat$ea == stat$nea)) .gbase_stop("Effect and other alleles must differ.")

  thresholds <- list(excludeMAF = excludeMAF,
    excludeMAFDIFF = excludeMAFDIFF, excludeINFO = excludeINFO,
    excludeMISS = excludeMISS, excludeHWE = excludeHWE)
  thresholds <- Map(.check_stat_threshold, thresholds, names(thresholds))
  flags <- list(excludeCGAT = excludeCGAT, excludeINDEL = excludeINDEL,
    excludeDUPS = excludeDUPS, excludeMHC = excludeMHC)
  flags <- Map(.check_stat_flag, flags, names(flags))

  reference <- .check_stat_reference(Glist)
  direct <- match(stat$rsids, reference$rsids)
  unresolved <- is.na(direct)
  if (any(unresolved)) {
    exact_key <- paste(stat$chr, stat$pos, stat$ea, stat$nea, sep = "_")
    swapped_key <- paste(stat$chr, stat$pos, stat$nea, stat$ea, sep = "_")
    reference_key <- paste(reference$chr, reference$pos,
      reference$ea, reference$nea, sep = "_")
    direct[unresolved] <- match(exact_key[unresolved], reference_key)
    still <- is.na(direct)
    direct[still] <- match(swapped_key[still], reference_key)
  }
  mapped <- !is.na(direct)
  message("Mapped ", sum(mapped), " of ", nrow(stat), " summary markers to Glist.")
  stat <- stat[mapped, , drop = FALSE]; direct <- direct[mapped]
  if (!nrow(stat)) .gbase_stop("No summary markers map to Glist.")
  stat$rsids <- reference$rsids[direct]
  if (flags$excludeDUPS) {
    keep <- !duplicated(stat$rsids)
    message("Excluded ", sum(!keep), " duplicated summary marker IDs.")
    stat <- stat[keep, , drop = FALSE]; direct <- direct[keep]
  } else if (anyDuplicated(stat$rsids)) {
    .gbase_stop("Mapped summary marker IDs are duplicated.")
  }

  coordinate_match <- stat$chr == reference$chr[direct] &
    as.double(stat$pos) == reference$pos[direct]
  if (any(!coordinate_match))
    .gbase_stop("Summary and Glist coordinates disagree for a mapped marker.")
  exact <- stat$ea == reference$ea[direct] & stat$nea == reference$nea[direct]
  swapped <- stat$ea == reference$nea[direct] & stat$nea == reference$ea[direct]
  if (any(!exact & !swapped))
    .gbase_stop("Summary and Glist alleles disagree for a mapped marker.")
  for (name in intersect(c("b", "stat", "score"), names(stat)))
    stat[[name]][swapped] <- -stat[[name]][swapped]
  if ("eaf" %in% names(stat)) stat$eaf[swapped] <- 1 - stat$eaf[swapped]
  stat$chr <- reference$chr[direct]; stat$pos <- reference$pos[direct]
  stat$ea <- reference$ea[direct]; stat$nea <- reference$nea[direct]

  numeric_columns <- intersect(c("eaf", "b", "seb", "stat", "score",
    "information", "p", "n", "info"), names(stat))
  for (name in numeric_columns) {
    if (!is.numeric(stat[[name]]) || anyNA(stat[[name]]) ||
        any(!is.finite(stat[[name]])))
      .gbase_stop("`stat$", name, "` must contain finite numbers.")
  }
  for (name in intersect(c("seb", "information", "n"), names(stat)))
    if (any(stat[[name]] <= 0)) .gbase_stop("`stat$", name, "` must be positive.")
  for (name in intersect(c("eaf", "p", "info"), names(stat)))
    if (any(stat[[name]] < 0 | stat[[name]] > 1))
      .gbase_stop("`stat$", name, "` must lie in [0, 1].")

  keep <- rep(TRUE, nrow(stat))
  if (flags$excludeCGAT) keep <- keep &
    !paste0(stat$ea, stat$nea) %in% c("AT", "TA", "CG", "GC")
  if (flags$excludeINDEL) keep <- keep & nchar(stat$ea) == 1L & nchar(stat$nea) == 1L
  if (flags$excludeMHC) keep <- keep &
    !(stat$chr %in% c("6", "chr6", "CHR6") & stat$pos >= 25000000 & stat$pos <= 34000000)
  ref_maf <- pmin(reference$eaf[direct], 1 - reference$eaf[direct])
  if (!is.null(thresholds$excludeMAF)) keep <- keep & ref_maf > thresholds$excludeMAF
  if (!is.null(thresholds$excludeMISS))
    keep <- keep & reference$nmiss[direct] / Glist$n <= thresholds$excludeMISS
  if (!is.null(thresholds$excludeHWE)) {
    hwe <- vapply(seq_along(direct), function(i) .check_stat_hwe_one(
      reference$n0[direct[i]], reference$n1[direct[i]], reference$n2[direct[i]]),
      numeric(1))
    keep <- keep & hwe >= thresholds$excludeHWE
  }
  if ("eaf" %in% names(stat)) {
    if (!is.null(thresholds$excludeMAF))
      keep <- keep & pmin(stat$eaf, 1 - stat$eaf) > thresholds$excludeMAF
    if (!is.null(thresholds$excludeMAFDIFF))
      keep <- keep & abs(stat$eaf - reference$eaf[direct]) <= thresholds$excludeMAFDIFF
  }
  if ("info" %in% names(stat) && !is.null(thresholds$excludeINFO))
    keep <- keep & stat$info >= thresholds$excludeINFO
  message("Retained ", sum(keep), " of ", length(keep), " mapped summary markers after QC.")
  stat <- stat[keep, , drop = FALSE]; direct <- direct[keep]
  if (!nrow(stat)) .gbase_stop("No summary markers remain after QC.")
  stat <- stat[order(direct), , drop = FALSE]
  canonical <- c("rsids", "chr", "pos", "ea", "nea", "eaf", "b", "seb",
    "stat", "score", "information", "p", "n", "info")
  stat <- stat[c(intersect(canonical, names(stat)), setdiff(names(stat), canonical))]
  rownames(stat) <- stat$rsids
  class(stat) <- "data.frame"
  stat
}

#' Construct explicit variant keys
#' @param x An ordinary data frame with qgg or descriptive identity columns.
#' @return Character keys preserving the supplied allele orientation.
#' @export
variant_key <- function(x) {
  if (!identical(class(x), "data.frame"))
    .gbase_stop("`x` must be an ordinary data frame.")
  x <- .check_stat_names(x)
  required <- c("chr", "pos", "ea", "nea")
  if (length(missing <- setdiff(required, names(x))))
    .gbase_stop("`x` is missing: ", paste(missing, collapse = ", "), ".")
  paste(x$chr, format(x$pos, scientific = FALSE, trim = TRUE),
    x$ea, x$nea, sep = ":")
}
