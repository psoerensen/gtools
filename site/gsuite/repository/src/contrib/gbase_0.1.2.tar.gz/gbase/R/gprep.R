#' Report the loaded genotype-native contracts
#'
#' @return Nested build-header and runtime version and ABI information for
#'   `gmat`, `gbits`, and `gsolve`.
#' @export
gbase_native_info <- function() cpp_gbase_native_info()

.onLoad <- function(libname, pkgname) {
  info <- cpp_gbase_native_info()
  ok <- identical(info$gmat$runtime_version, "0.6.0") &&
    identical(as.character(info$gmat$runtime_abi), "0") &&
    identical(info$gbits$runtime_version, "0.21.0") &&
    identical(as.character(info$gbits$runtime_abi), "4") &&
    identical(info$gsolve$runtime_version, "0.27.0") &&
    identical(as.character(info$gsolve$runtime_abi), "4") &&
    all(vapply(info,function(x) identical(x$header_version,x$runtime_version) &&
      identical(as.character(x$header_abi),as.character(x$runtime_abi)),logical(1)))
  if (!ok) .gbase_stop("Loaded gmat/gbits/gsolve versions or ABIs are incompatible with gbase.")
}

.gprep_path <- function(x, name) {
  if (!is.character(x) || !length(x) || anyNA(x) || any(!nzchar(x)))
    .gbase_stop("`", name, "` must contain nonempty file paths.")
  missing <- !file.exists(x) | dir.exists(x)
  if (any(missing)) .gbase_stop("Missing `", name, "` file: ", x[which(missing)[1L]])
  unname(normalizePath(x, winslash = "/", mustWork = TRUE))
}
.gprep_companion <- function(x, extension) {
  if (any(!grepl("\\.bed$", x, ignore.case = TRUE)))
    .gbase_stop("Cannot infer companion path from a non-.bed file.")
  sub("\\.bed$", paste0(".", extension), x, ignore.case = TRUE)
}
.gprep_selection <- function(x, name) {
  if (is.null(x)) return(NULL)
  if (!is.character(x) || !length(x) || anyNA(x) || any(!nzchar(x)) || anyDuplicated(x))
    .gbase_stop("`", name, "` must contain unique nonempty identifiers.")
  x
}
.gprep_count <- function(x, name, minimum = 1L) {
  if (!is.numeric(x) || length(x) != 1L || !is.finite(x) || x != floor(x) ||
      x < minimum || x > .Machine$integer.max)
    .gbase_stop("`", name, "` must be an integer of at least ", minimum, ".")
  as.integer(x)
}
.gprep_number <- function(x, name, lower = 0) {
  if (!is.numeric(x) || length(x) != 1L || !is.finite(x) || x < lower)
    .gbase_stop("`", name, "` must be finite and at least ", lower, ".")
  as.double(x)
}
.gprep_flag <- function(x, name) {
  if (!is.logical(x) || length(x) != 1L || is.na(x))
    .gbase_stop("`", name, "` must be TRUE or FALSE.")
  x
}
.gprep_prefix <- function(x) {
  if (!is.character(x) || length(x) != 1L || is.na(x) || !nzchar(x))
    .gbase_stop("`out_prefix` must be one nonempty path.")
  if (!dir.exists(dirname(x))) .gbase_stop("The output-prefix directory does not exist.")
  file.path(normalizePath(dirname(x), winslash = "/", mustWork = TRUE), basename(x))
}
.gprep_paths <- function(resources) lapply(resources, `[[`, "paths")

#' Prepare a serializable PLINK genotype descriptor
#'
#' `task = "prepare"` validates PLINK BED/BIM/FAM triplets and computes exact
#' selected-sample marker summaries. `task = "sparseld"` returns the supplied
#' Glist augmented with a disk-backed sparse signed-LD resource.
#' `task = "eigen"` computes reusable full regional LD eigenvalues from BED,
#' without using the sparse-LD windows or cutoff.
#' @param Glist A prepared Glist for `task = "sparseld"` or `"eigen"`.
#' @param study Optional study label.
#' @param bedfiles,bimfiles,famfiles PLINK file paths.
#' @param ids,rsids Optional ordered sample IDs and marker IDs.
#' @param task One of `"prepare"`, `"sparseld"`, or `"eigen"`.
#' @param nthreads Positive local thread count.
#' @param out_prefix Sparse-LD output prefix.
#' @param max_distance_bp,max_distance_variants Sparse-LD windows; zero disables a window.
#' @param r2 Minimum retained squared correlation.
#' @param block_size Positive marker block size.
#' @param overwrite Replace an existing owned sparse-LD resource.
#' @param allow_full_ld Authorize both distance windows being disabled.
#' @param sets Named list of nonempty unique marker-ID vectors for `task = "eigen"`.
#' Each set must resolve to one chromosome; membership is stored in reference order.
#' @param eigen_control Named numerical controls as in [ld_eigen()]. The dimension
#' limit applies to the smaller of the sample and marker dimensions.
#' @param msize Familiar alias for max_distance_variants. When supplied alone,
#'   uses a marker-count-only window and retains all correlations (r2 = 0).
#' @param ldfiles Familiar single output name; its .ld suffix is removed to form
#'   the sparse-resource prefix. The native resource layout remains unchanged.
#' @return A serializable object with class `c("gs_genotypes", "Glist")`.
#' @md
#' @export
gprep <- function(Glist = NULL, study = NULL, bedfiles = NULL,
    bimfiles = NULL, famfiles = NULL, ids = NULL, rsids = NULL,
    task = "prepare", nthreads = 1L, out_prefix = NULL,
    max_distance_bp = 1000000, max_distance_variants = 1000L,
    r2 = 0.01, block_size = 1024L, overwrite = FALSE,
    allow_full_ld = FALSE, sets = NULL, eigen_control = list(),
    msize = NULL, ldfiles = NULL) {
  if (!is.null(msize) || !is.null(ldfiles)) {
    if (!identical(task, "sparseld"))
      .gbase_stop("`msize` and `ldfiles` require task = 'sparseld'.")
    if (!is.null(msize)) {
      if (!missing(max_distance_variants))
        .gbase_stop("Specify either `msize` or `max_distance_variants`, not both.")
      max_distance_variants <- msize
      if (missing(max_distance_bp)) max_distance_bp <- 0
      if (missing(r2)) r2 <- 0
    }
    if (!is.null(ldfiles)) {
      if (!is.null(out_prefix)) .gbase_stop("Specify either `ldfiles` or `out_prefix`, not both.")
      if (!is.character(ldfiles) || length(ldfiles) != 1L || is.na(ldfiles) || !nzchar(ldfiles))
        .gbase_stop("`ldfiles` must be one nonempty sparse-resource output name.")
      out_prefix <- sub("\\.ld$", "", ldfiles, ignore.case = TRUE)
    }
  }
  if (!is.character(task) || length(task) != 1L || is.na(task) ||
      !task %in% c("prepare", "sparseld", "eigen"))
    .gbase_stop("`task` must be `prepare`, `sparseld`, or `eigen`.")
  if (task == "eigen") return(.gprep_eigen(Glist, sets, ids, rsids,
    nthreads, out_prefix, eigen_control))
  if (!is.null(sets) || length(eigen_control))
    .gbase_stop("`sets` and `eigen_control` require task = 'eigen'.")
  if (task == "sparseld") return(.gprep_sparseld(Glist, out_prefix, ids,
    rsids, max_distance_bp, max_distance_variants, r2, block_size,
    nthreads, overwrite, allow_full_ld))
  if (!is.null(Glist)) .gbase_stop("`Glist` must be NULL for preparation.")
  if (!is.null(study) && (!is.character(study) || length(study) != 1L || is.na(study)))
    .gbase_stop("`study` must be NULL or one string.")
  bedfiles <- .gprep_path(bedfiles, "bedfiles")
  if (is.null(bimfiles)) bimfiles <- .gprep_companion(bedfiles, "bim")
  if (is.null(famfiles)) famfiles <- .gprep_companion(bedfiles, "fam")
  if (length(bimfiles) != length(bedfiles) || length(famfiles) != length(bedfiles))
    .gbase_stop("PLINK path vectors must have equal lengths.")
  bimfiles <- .gprep_path(bimfiles, "bimfiles"); famfiles <- .gprep_path(famfiles, "famfiles")
  ids <- .gprep_selection(ids, "ids"); rsids <- .gprep_selection(rsids, "rsids")
  nthreads <- .gprep_count(nthreads, "nthreads")
  resources <- lapply(seq_along(bedfiles), function(i)
    cpp_gbase_bed_resource(bedfiles[i], bimfiles[i], famfiles[i]))
  canonical <- resources[[1L]]$samples
  if (anyDuplicated(canonical$individual_id)) .gbase_stop("FAM individual IDs must be globally unique.")
  rows <- if (is.null(ids)) seq_len(nrow(canonical)) else match(ids, canonical$individual_id)
  if (anyNA(rows)) .gbase_stop("Requested sample ID not found: ", ids[which(is.na(rows))[1L]])
  all_markers <- unlist(lapply(resources, function(x) x$markers$marker_id), use.names = FALSE)
  if (anyDuplicated(all_markers)) .gbase_stop("Marker IDs must be globally unique.")
  if (!is.null(rsids) && any(!rsids %in% all_markers)) .gbase_stop("Requested marker ID not found.")
  source <- lapply(resources, function(x) as.double(which(if (is.null(rsids))
    rep(TRUE, x$marker_count) else x$markers$marker_id %in% rsids) - 1L))
  metadata <- Map(function(x, i) x$markers[i + 1, , drop = FALSE], resources, source)
  paths <- .gprep_paths(resources)
  sample_selection <- if (is.null(ids)) data.frame(family_id=character(),individual_id=character()) else
    data.frame(family_id=canonical$family_id[rows], individual_id=ids, stringsAsFactors=FALSE)
  panel <- cpp_gbase_bed_panel(paths, sample_selection$family_id,
    sample_selection$individual_id, lapply(metadata, `[[`, "marker_id"))
  counts <- cpp_gbase_bed_counts(bedfiles, resources[[1L]]$sample_count,
    vapply(resources, `[[`, numeric(1), "marker_count"),
    panel$sample_source_indices_0based, source, nthreads)
  observed <- lapply(counts, function(x) x$n0 + x$n1 + x$n2)
  if (any(unlist(observed) == 0)) .gbase_stop("A selected marker has no observed genotypes.")
  af <- Map(function(x,n) (2*x$n2+x$n1)/(2*n), counts, observed)
  result <- list(study=study,bedfiles=bedfiles,bimfiles=bimfiles,famfiles=famfiles,
    ids=canonical$individual_id,study_ids=ids,n=resources[[1L]]$sample_count,nchr=length(resources),
    physical_marker_counts=vapply(resources,`[[`,numeric(1),"marker_count"),
    rsids=lapply(metadata,`[[`,"marker_id"),mchr=vapply(metadata,nrow,integer(1)),
    chr=lapply(metadata,`[[`,"chromosome"),pos=lapply(metadata,`[[`,"base_pair_position"),
    map=lapply(metadata,`[[`,"genetic_distance_cm"),a1=lapply(metadata,`[[`,"allele1"),
    a2=lapply(metadata,`[[`,"allele2"),af=af,af1=af,af2=lapply(af,function(x)1-x),
    maf=lapply(af,function(x)pmin(x,1-x)),nmiss=lapply(counts,`[[`,"nmiss"),
    hom=Map(function(x,n)(x$n0+x$n2)/n,counts,observed),het=Map(function(x,n)x$n1/n,counts,observed),
    n0=lapply(counts,`[[`,"n0"),n1=lapply(counts,`[[`,"n1"),n2=lapply(counts,`[[`,"n2"),
    assembly=NULL,source_marker_indices_0based=source,
    sample_source_indices_0based=panel$sample_source_indices_0based,
    genotype_format="PLINK BED SNP-major",marker_selection_order="canonical file/BIM order",
    provenance=list(persistent_store="existing PLINK BED files",summary_samples=if(is.null(ids))"all" else "ids subset",dosage_allele="BIM field 5 (a1)",af_policy="exact empirical; no clipping",versions=gbase_native_info()))
  result$cpra <- Map(function(chr,pos,a1,a2) paste(chr,pos,a1,a2,sep="_"),result$chr,result$pos,result$a1,result$a2)
  result$m <- sum(result$mchr); class(result) <- c("gs_genotypes","Glist"); result
}

#' Validate a prepared Glist
#' @param Glist A prepared genotype object.
#' @return The object invisibly. Sparse-LD descriptor identity and file
#'   availability are checked without rescanning the immutable CSR payload.
#' @export
validate_Glist <- function(Glist) {
  .gprep_validate(Glist, collect_resources=FALSE)
  invisible(Glist)
}

#' Fully verify a prepared sparse-LD resource
#'
#' This is the explicit integrity check for a newly received, copied, or
#' suspected sparse-LD resource. Ordinary consumers should use
#' `validate_Glist()`, which checks the serializable descriptor without
#' hashing or rescanning the complete payload.
#' @param Glist A prepared Glist augmented by `gprep(task = "sparseld")`.
#' @return The object invisibly after native structure, metadata, checksums,
#'   and recorded ordinary LD scores have been verified.
#' @export
verify_ld <- function(Glist) {
  .gprep_validate(Glist)
  if (is.null(Glist$sparseLD))
    .gbase_stop("`Glist` has no sparse LD; use gprep(Glist, task = 'sparseld').")
  .gprep_verify_sparse_ld(Glist)
  invisible(Glist)
}

.gprep_checksums <- function(paths) {
  hashes <- unname(tools::md5sum(unlist(paths, use.names = FALSE)))
  if (anyNA(hashes)) .gbase_stop("Cannot read every sparse-LD resource file.")
  stats::setNames(hashes, names(paths))
}

.gprep_validate_sparse_ld <- function(Glist) {
  saved <- Glist$sparseLD
  if (!is.list(saved)) .gbase_stop("Glist sparseLD must be a prepared resource.")
  required <- c("prefix", "format", "version", "paths", "n", "source_n", "m", "nnz", "chr", "rsids",
    "sample_ids", "sample_indices_0based", "marker_indices_0based",
    "marker_metadata", "checksums")
  if (length(missing <- setdiff(required, names(saved))))
    .gbase_stop("Glist sparseLD is missing: ", paste(missing, collapse = ", "))
  if (!is.character(saved$prefix) || length(saved$prefix) != 1L ||
      is.na(saved$prefix) || !nzchar(saved$prefix) ||
      !identical(saved$prefix, .gprep_prefix(saved$prefix)))
    .gbase_stop("Glist sparse-LD prefix must remain canonical and unchanged.")
  if (!identical(saved$format, "sparse_ld_csr") ||
      !identical(as.integer(saved$version), 1L))
    .gbase_stop("Glist sparse-LD format is unsupported.")
  path_names <- c("row_ptr", "col_idx", "values", "metadata", "markers")
  if (!is.list(saved$paths) || !identical(names(saved$paths), path_names) ||
      any(lengths(saved$paths) != 1L))
    .gbase_stop("Glist sparse-LD paths are invalid.")
  canonical_paths <- lapply(saved$paths, .gprep_path, name = "Glist sparse-LD path")
  if (!identical(saved$paths, canonical_paths))
    .gbase_stop("Glist sparse-LD paths must remain canonical and unchanged.")
  expected_paths <- stats::setNames(lapply(c(".row_ptr.u64.bin", ".col_idx.u32.0based.bin",
    ".values.f32.bin", ".meta.txt", ".markers.tsv"),
    function(suffix) paste0(saved$prefix, suffix)), path_names)
  if (!identical(saved$paths, expected_paths))
    .gbase_stop("Glist sparse-LD paths do not match its prefix.")
  if (!identical(Glist$ldfiles, saved$paths))
    .gbase_stop("Glist ldfiles do not identify its sparse-LD resource.")
  if (!identical(Glist$idsLD, saved$sample_ids))
    .gbase_stop("Glist idsLD do not identify its sparse-LD samples.")
  if (!is.numeric(saved$chr) || anyNA(saved$chr) ||
      any(saved$chr != floor(saved$chr)) || any(saved$chr < 1 | saved$chr > Glist$nchr) ||
      anyDuplicated(saved$chr) || !is.list(saved$rsids) ||
      length(saved$rsids) != length(saved$chr) || !identical(Glist$rsidsLD, {
        by_file <- vector("list", Glist$nchr)
        by_file[] <- list(character())
        by_file[saved$chr] <- saved$rsids
        by_file
      }))
    .gbase_stop("Glist rsidsLD do not identify its sparse-LD markers.")
  if (!is.data.frame(saved$marker_metadata) ||
      !all(c("marker_id", "allele_frequency", "source_marker_index_0based") %in%
        names(saved$marker_metadata)) ||
      !identical(unlist(saved$rsids, use.names = FALSE), saved$marker_metadata$marker_id))
    .gbase_stop("Glist sparse-LD marker identity is inconsistent.")
  expected_marker_indices <- Map(function(ids, component) {
    selected <- match(ids, Glist$rsids[[component]])
    if (anyNA(selected)) return(NULL)
    Glist$source_marker_indices_0based[[component]][selected]
  }, saved$rsids, saved$chr)
  if (!is.list(saved$marker_indices_0based) ||
      length(saved$marker_indices_0based) != length(saved$chr) ||
      !identical(as.double(unlist(saved$marker_indices_0based, use.names = FALSE)),
        as.double(saved$marker_metadata$source_marker_index_0based)) ||
      !identical(saved$marker_indices_0based, unname(expected_marker_indices)))
    .gbase_stop("Glist sparse-LD marker mappings are inconsistent.")
  counts <- c(n = saved$n, source_n = saved$source_n, m = saved$m, nnz = saved$nnz)
  if (!is.numeric(counts) || anyNA(counts) || any(!is.finite(counts)) ||
      any(counts != floor(counts)) || saved$n < 2 || saved$source_n < saved$n ||
      saved$m < 1 || saved$nnz < 0 || nrow(saved$marker_metadata) != saved$m)
    .gbase_stop("Glist sparse-LD dimensions are invalid.")
  sample_indices <- saved$sample_indices_0based
  if (!is.numeric(sample_indices) || anyNA(sample_indices) ||
      any(!is.finite(sample_indices)) || any(sample_indices != floor(sample_indices)) ||
      any(sample_indices < 0 | sample_indices >= Glist$n) || anyDuplicated(sample_indices) ||
      length(sample_indices) != saved$n || length(saved$sample_ids) != saved$n ||
      !identical(saved$sample_ids, Glist$ids[sample_indices + 1L]))
    .gbase_stop("Glist sparse-LD sample order is inconsistent.")
  af <- saved$marker_metadata$allele_frequency
  if (!is.numeric(af) || length(af) != saved$m || anyNA(af) ||
      any(!is.finite(af)) || any(af < 0 | af > 1))
    .gbase_stop("Glist sparse-LD allele frequencies are invalid.")
  recorded_scores <- unlist(Glist$ldscores, use.names = FALSE)
  if (!is.list(Glist$ldscores) || length(Glist$ldscores) != Glist$nchr ||
      !identical(lengths(Glist$ldscores), lengths(Glist$rsidsLD)) ||
      !is.numeric(recorded_scores) || length(recorded_scores) != saved$m ||
      anyNA(recorded_scores) || any(!is.finite(recorded_scores)))
    .gbase_stop("Glist sparse-LD scores are invalid.")
  if (!is.character(saved$checksums) || anyNA(saved$checksums) ||
      !identical(names(saved$checksums), names(saved$paths)) ||
      any(!nzchar(saved$checksums)))
    .gbase_stop("Glist sparse-LD checksums are invalid.")
  invisible(saved)
}

.gprep_verify_sparse_ld <- function(Glist) {
  saved <- .gprep_validate_sparse_ld(Glist)
  resource <- cpp_gbase_sparse_ld_open(saved$prefix)
  marker_fields <- names(resource$markers)
  if (!identical(saved$prefix, resource$prefix) ||
      !identical(saved$format, resource$format) ||
      !identical(as.integer(saved$version), as.integer(resource$format_version)) ||
      !identical(saved$paths, resource$paths) ||
      !identical(as.double(saved$n), as.double(resource$reference_sample_count)) ||
      !identical(as.double(saved$source_n), as.double(resource$source_sample_count)) ||
      !identical(as.double(saved$m), as.double(resource$marker_count)) ||
      !identical(as.double(saved$nnz), as.double(resource$stored_entry_count)) ||
      !identical(saved$marker_metadata[marker_fields], resource$markers) ||
      !identical(unlist(saved$rsids, use.names = FALSE), resource$markers$marker_id) ||
      !identical(as.double(unlist(saved$marker_indices_0based, use.names = FALSE)),
        as.double(resource$markers$source_marker_index_0based)))
    .gbase_stop("Glist sparse-LD metadata does not match its native resource.")
  if (!identical(saved$checksums, .gprep_checksums(resource$paths)))
    .gbase_stop("Glist sparse-LD files changed after preparation.")
  scores <- cpp_gbase_ld_scores(saved$prefix, FALSE, NULL, character(), character())
  if (!isTRUE(all.equal(unname(unlist(Glist$ldscores, use.names = FALSE)),
        unname(scores), tolerance = 1e-12)))
    .gbase_stop("Glist sparse-LD scores do not match the native resource.")
  invisible(resource)
}

.gprep_validate_ld_blocks <- function(saved, sparse_ld) {
  if (!is.list(saved) || !identical(saved$schema_version, 1L) ||
      !is.data.frame(saved$blocks) || !is.numeric(saved$offsets_0based) ||
      !identical(saved$sparse_ld_checksums, sparse_ld$checksums))
    .gbase_stop("Glist ldBlocks is not tied to its sparse-LD identity.")
  expected <- .gbase_block_table(saved$blocks,
    sparse_ld$marker_metadata$marker_id,
    as.character(sparse_ld$marker_metadata$chromosome))
  offsets <- c(expected$begin_0based, tail(expected$end_0based, 1L))
  if (!identical(saved$blocks, expected) || !identical(saved$offsets_0based, offsets))
    .gbase_stop("Glist ldBlocks manifest is inconsistent.")
  invisible(saved)
}

.gprep_validate <- function(Glist, collect_resources=TRUE) {
  if (!inherits(Glist,"gs_genotypes") || !inherits(Glist,"Glist") || !is.list(Glist))
    .gbase_stop("`Glist` must be a prepared gs_genotypes/Glist object.")
  required <- c("bedfiles","bimfiles","famfiles","ids","study_ids","n","nchr","physical_marker_counts","rsids","chr","pos","a1","a2","af","source_marker_indices_0based","sample_source_indices_0based")
  if (length(missing <- setdiff(required,names(Glist)))) .gbase_stop("Glist is missing: ",paste(missing,collapse=", "))
  nchr <- .gprep_count(Glist$nchr,"Glist$nchr")
  if(any(vapply(Glist[c("bedfiles","bimfiles","famfiles")],length,integer(1))!=nchr)) .gbase_stop("Glist file vectors do not match `nchr`.")
  bed <- .gprep_path(Glist$bedfiles,"Glist$bedfiles"); bim <- .gprep_path(Glist$bimfiles,"Glist$bimfiles"); fam <- .gprep_path(Glist$famfiles,"Glist$famfiles")
  if(!identical(unname(bed),unname(Glist$bedfiles))||!identical(unname(bim),unname(Glist$bimfiles))||!identical(unname(fam),unname(Glist$famfiles))) .gbase_stop("Glist paths must remain canonical and unchanged.")
  fields <- c("rsids","chr","pos","a1","a2","af","source_marker_indices_0based")
  if(any(vapply(Glist[fields],length,integer(1))!=nchr)) .gbase_stop("Glist marker fields do not match `nchr`.")
  if(length(Glist$physical_marker_counts)!=nchr) .gbase_stop("Glist physical marker counts no longer match BIM files.")
  resources <- if(collect_resources) vector("list",nchr) else list()
  source_ids <- vector("list",nchr)
  canonical <- reference_identity <- NULL
  # Validation retains only IDs needed for the global uniqueness check. Full
  # BIM metadata stays live for one component unless an internal caller needs it.
  for(i in seq_len(nchr)) {
    resource <- cpp_gbase_bed_resource(bed[i],bim[i],fam[i])
    if(!identical(as.double(Glist$physical_marker_counts[i]),as.double(resource$marker_count)))
      .gbase_stop("Glist physical marker counts no longer match BIM files.")
    if(i==1L) {
      canonical <- resource$samples$individual_id
      if(!identical(Glist$ids,canonical)||!identical(as.double(Glist$n),as.double(length(canonical))))
        .gbase_stop("Glist samples no longer match FAM.")
      if(anyNA(canonical)||any(!nzchar(canonical))||anyDuplicated(canonical))
        .gbase_stop("BedPanel individual IDs must be non-empty and globally unique.")
      reference_identity <- resource$samples[c("family_id","individual_id")]
    }
    if(!identical(resource$samples[c("family_id","individual_id")],reference_identity))
      .gbase_stop("BedPanel components must have identical ordered FAM identities.")
    source_ids[[i]] <- resource$markers$marker_id
    source <- Glist$source_marker_indices_0based[[i]]
    if(!is.numeric(source)||anyNA(source)||any(!is.finite(source))||any(source!=floor(source))||any(source<0)||any(source>=resource$marker_count)||anyDuplicated(source))
      .gbase_stop("Glist has invalid source marker indices for file ",i,".")
    m <- resource$markers[source+1,,drop=FALSE]
    if(!identical(Glist$rsids[[i]],m$marker_id)||!identical(Glist$chr[[i]],m$chromosome)||!identical(as.double(Glist$pos[[i]]),as.double(m$base_pair_position))||!identical(Glist$a1[[i]],m$allele1)||!identical(Glist$a2[[i]],m$allele2))
      .gbase_stop("Glist markers no longer match BIM file ",i,".")
    af <- Glist$af[[i]]
    if(!is.numeric(af)||length(af)!=length(source)||anyNA(af)||any(!is.finite(af))||any(af<0|af>1))
      .gbase_stop("Glist allele frequencies are invalid for file ",i,".")
    if(collect_resources) resources[[i]] <- resource
    else rm(resource,m)
  }
  source_ids <- unlist(source_ids,use.names=FALSE)
  if(anyNA(source_ids)||any(!nzchar(source_ids))||anyDuplicated(source_ids))
    .gbase_stop("BedPanel source marker IDs must be globally unique.")
  prepared_ids <- if(is.null(Glist$study_ids)) Glist$ids else .gprep_selection(Glist$study_ids,"Glist$study_ids")
  expected_rows <- as.double(match(prepared_ids,Glist$ids)-1L)
  if(anyNA(expected_rows)||!identical(Glist$sample_source_indices_0based,expected_rows)) .gbase_stop("Glist sample source indices are inconsistent.")
  if (!is.null(Glist$sparseLD)) {
    sparse_ld <- .gprep_validate_sparse_ld(Glist)
    if (!is.null(Glist$ldBlocks)) .gprep_validate_ld_blocks(Glist$ldBlocks, sparse_ld)
  } else if (!is.null(Glist$ldBlocks)) {
    .gbase_stop("Glist ldBlocks requires sparse LD.")
  }
  if (!is.null(Glist$eigen)) .gprep_validate_eigen(Glist)
  list(resources=resources)
}

.gprep_sparseld <- function(Glist,out_prefix,ids,rsids,max_bp,max_variants,r2,block_size,threads,overwrite,allow_full) {
  audited <- .gprep_validate(Glist); ids <- .gprep_selection(ids,"ids"); rsids <- .gprep_selection(rsids,"rsids")
  threads <- .gprep_count(threads,"nthreads"); max_bp <- .gprep_count(max_bp,"max_distance_bp",0L); max_variants <- .gprep_count(max_variants,"max_distance_variants",0L); block_size <- .gprep_count(block_size,"block_size"); r2 <- .gprep_number(r2,"r2")
  overwrite <- .gprep_flag(overwrite,"overwrite"); allow_full <- .gprep_flag(allow_full,"allow_full_ld")
  if(r2>1) .gbase_stop("`r2` must be at most 1."); if(max_bp==0L&&max_variants==0L&&!allow_full) .gbase_stop("Set `allow_full_ld = TRUE` when both windows are disabled.")
  reference_ids <- if(!is.null(ids)) ids else if(!is.null(Glist$study_ids)) Glist$study_ids else Glist$ids
  rows <- match(reference_ids,Glist$ids); if(anyNA(rows)||length(rows)<2L) .gbase_stop("Sparse LD requires at least two known reference samples.")
  selected <- lapply(Glist$rsids,function(x) if(is.null(rsids)) rep(TRUE,length(x)) else x%in%rsids)
  selected_ids <- Map(function(x,k)x[k],Glist$rsids,selected); source <- Map(function(x,k)x[k],Glist$source_marker_indices_0based,selected); active <- which(lengths(selected_ids)>0L)
  if(!length(active)) .gbase_stop("Sparse LD requires markers.")
  resources <- audited$resources[active]
  families <- audited$resources[[1L]]$samples$family_id[rows]
  paths <- lapply(resources,`[[`,"paths"); marker_ids <- unname(selected_ids[active])
  panel <- cpp_gbase_bed_panel(paths,families,reference_ids,marker_ids)
  if(!identical(panel$sample_source_indices_0based,as.double(rows-1L))||
      !identical(panel$component_marker_indices_0based,unname(source[active]))) .gbase_stop("Resolved sparse-LD rows or markers do not match stored BED offsets.")
  if(is.null(out_prefix)) out_prefix<-file.path(dirname(Glist$bedfiles[active[1L]]),"sparseLD")
  resource <- cpp_gbase_sparse_ld(paths,families,reference_ids,marker_ids,.gprep_prefix(out_prefix),list(block_size=block_size,max_distance_bp=max_bp,max_distance_markers=max_variants,r2_threshold=r2,threads=threads,overwrite=overwrite,allow_full_ld=allow_full))
  reopened <- cpp_gbase_sparse_ld_identity(resource$prefix); if(!identical(resource$markers,reopened$markers)||!identical(resource$settings,reopened$settings)) .gbase_stop("Sparse-LD identity reopen failed.")
  prepared_ids <- if(is.null(Glist$study_ids)) Glist$ids else Glist$study_ids
  if(identical(reference_ids,prepared_ids)) {
    af <- Map(function(x,k)x[k],Glist$af,selected)[active]
    af_source <- "prepared Glist allele frequencies"
  } else {
    counts <- cpp_gbase_bed_counts(Glist$bedfiles[active],Glist$n,vapply(resources,`[[`,numeric(1),"marker_count"),as.double(rows-1L),source[active],threads)
    observed<-lapply(counts,function(x)x$n0+x$n1+x$n2)
    if(any(unlist(observed)==0)) .gbase_stop("A sparse-LD marker has no observed genotypes in the reference samples.")
    af<-Map(function(x,n)(2*x$n2+x$n1)/(2*n),counts,observed)
    af_source <- "recomputed for LD reference samples with packed BED counts"
  }
  scores<-cpp_gbase_ld_scores(resource$prefix,FALSE,NULL,character(),character()); rsids_ld<-vector("list",Glist$nchr); score_by_file<-vector("list",Glist$nchr); offset<-0L
  for(i in seq_along(active)){k<-active[i];n<-length(selected_ids[[k]]);take<-seq.int(offset+1L,offset+n);rsids_ld[[k]]<-selected_ids[[k]];score_by_file[[k]]<-scores[take];offset<-offset+n}
  for(k in setdiff(seq_len(Glist$nchr),active)){rsids_ld[[k]]<-character();score_by_file[[k]]<-numeric()}
  meta<-resource$markers;meta$allele_frequency<-unlist(af,use.names=FALSE)
  Glist$sparseLD<-list(prefix=resource$prefix,format=resource$format,version=as.integer(resource$format_version),paths=resource$paths,n=length(reference_ids),source_n=Glist$n,m=resource$marker_count,nnz=resource$stored_entry_count,chr=active,bed_files=Glist$bedfiles[active],cls=lapply(source[active],function(x)x+1),rows=as.integer(rows),af=af,rsids=selected_ids[active],sample_ids=reference_ids,sample_indices_0based=as.double(rows-1L),marker_indices_0based=source[active],marker_metadata=meta,r2_threshold=r2,max_distance_bp=max_bp,max_distance_variants=max_variants,block_size=block_size,nthreads=threads,checksums=.gprep_checksums(resource$paths),provenance=list(owner="gmat",storage="strict upper-triangle CSR with implicit unit diagonal",value="signed correlation r",threshold="retain when r^2 >= r2_threshold",ld_score="1 + sum of retained off-diagonal r^2",dosage_allele="BIM field 5 (a1)",missing="mean imputation after centering; standardized value zero",sample_selection=if(!is.null(ids))"explicit ids" else if(!is.null(Glist$study_ids))"Glist$study_ids" else "all Glist$ids",requested_sample_order=reference_ids,requested_marker_order=rsids,physical_marker_order="canonical file/BIM order",allele_frequency_source=af_source,allow_full_ld=allow_full,gmat_version=gbase_native_info()$gmat$runtime_version))
  Glist$ldfiles<-resource$paths;Glist$rsidsLD<-rsids_ld;Glist$idsLD<-reference_ids;Glist$ldscores<-score_by_file;Glist$ldBlocks<-NULL;Glist
}

#' @export
print.gs_genotypes <- function(x, ...) {
  cat("<gs_genotypes/Glist>\n", "  Samples: ", x$n, "\n",
      "  Files: ", x$nchr, "; markers: ", sum(x$mchr), "\n", sep="")
  if(!is.null(x$sparseLD)) cat("  Sparse LD:",x$sparseLD$m,"markers\n")
  if(!is.null(x$ldBlocks)) cat("  LD blocks:",nrow(x$ldBlocks$blocks),"\n")
  invisible(x)
}
